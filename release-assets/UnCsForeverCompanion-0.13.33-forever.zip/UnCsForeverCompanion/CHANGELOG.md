# UnCs Forever Companion

## [0.13.33](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.33) (2026-11-23)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.31...0.13.33) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge aleilsandro into main for Companion 0.13.33  
- Merge commit '2a57e834a0ebf74e585123ac614bc8bd3f783a8a' into aleilsandro  
- Merge thomas into main for Companion 0.13.32  
- Commit personal branch work before merging to main  
- Document atlas changes and guild presence fixes  
- Document bundled maps and Companion deployment  
- Merge commit '20062c4551e572b9331b42f6ee6626d4595df8f8' into aleilsandro  
- Pull local main before syncing personal branch  
- Keep guild presence independent of position and stabilize list order  
- Restore standalone WebCompanion deployer  
