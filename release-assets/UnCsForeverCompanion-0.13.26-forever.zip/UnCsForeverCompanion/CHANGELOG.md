# UnCs Forever Companion

## [0.13.26](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.26) (2026-11-22)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.25...0.13.26) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Fix Pulser public connection for 0.13.26  
    Correggi il collegamento pubblico del Pulser  
- Connect Pulser through public endpoint  
