# UnCs Forever Companion

## [0.13.23](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.23) (2026-11-22)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.22...0.13.23) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Fix Funnel position continuity for 0.13.23  
    Correggi la continuità delle posizioni su Funnel  
- Keep guild positions visible during Funnel handover  
- Keep a permanent Pulser installer download  
    Mantieni il download fisso di UnCs Pulser  
- Keep a permanent download for the latest Pulser installer  
