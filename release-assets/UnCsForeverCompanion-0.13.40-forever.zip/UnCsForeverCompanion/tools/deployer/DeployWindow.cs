using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Security.Principal;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

internal sealed class DeployWindow : Form
{
    private readonly Label main = new Label();
    private readonly Label live = new Label();
    private readonly Label pulser = new Label();
    private readonly Button refresh = new Button();
    private readonly Button publish = new Button();
    private readonly Button release = new Button();
    private readonly TextBox log = new TextBox();
    private readonly ProgressBar progress = new ProgressBar();
    private string selectedCommit = "";
    private bool releaseReady;
    private bool busy;

    internal DeployWindow()
    {
        Text = "UnCs Deploy";
        AutoScaleDimensions = new SizeF(96, 96);
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(650, 400);
        MinimumSize = new Size(590, 376);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10);
        BackColor = Color.FromArgb(14, 31, 51);
        ForeColor = Color.FromArgb(245, 237, 212);

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 7, Padding = new Padding(20) };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (int i = 0; i < 4; i++) layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var heading = new Label {
            Text = "UnCs Foreve WebCompanion", Font = new Font("Segoe UI", 19),
            Dock = DockStyle.Fill, AutoSize = true, Margin = new Padding(3, 0, 3, 11),
            ForeColor = Color.FromArgb(230, 196, 123)
        };
        main.Dock = live.Dock = pulser.Dock = DockStyle.Fill;
        main.AutoSize = live.AutoSize = pulser.AutoSize = true;
        main.Text = "main  ·  in lettura";
        live.Text = "Server live  ·  in lettura";
        pulser.Text = "Pulser  ·  in lettura";
        log.Dock = DockStyle.Fill;
        log.Multiline = log.ReadOnly = true;
        log.ScrollBars = ScrollBars.Vertical;
        log.BackColor = Color.FromArgb(8, 20, 35);
        log.ForeColor = ForeColor;
        log.Font = new Font("Consolas", 9);
        log.TabStop = false;
        progress.Dock = DockStyle.Top;
        progress.Height = 9;
        progress.Style = ProgressBarStyle.Marquee;
        progress.Visible = false;

        var actions = new TableLayoutPanel {
            Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 4, RowCount = 1, Margin = new Padding(0, 12, 0, 0)
        };
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        actions.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        publish.Text = "Pubblica sul server";
        publish.MinimumSize = new Size(171, 36);
        publish.Enabled = false;
        publish.BackColor = Color.FromArgb(229, 190, 112);
        publish.ForeColor = Color.FromArgb(18, 31, 44);
        publish.FlatStyle = FlatStyle.Flat;
        publish.UseVisualStyleBackColor = false;
        refresh.Text = "Rileggi main";
        refresh.MinimumSize = new Size(128, 36);
        refresh.BackColor = Color.FromArgb(32, 57, 83);
        refresh.ForeColor = ForeColor;
        refresh.FlatStyle = FlatStyle.Flat;
        refresh.UseVisualStyleBackColor = false;
        release.Text = "Pubblica Pulser e addon";
        release.Enabled = false;
        release.BackColor = refresh.BackColor;
        release.ForeColor = ForeColor;
        release.FlatStyle = FlatStyle.Flat;
        release.UseVisualStyleBackColor = false;
        foreach (Button button in new[] { refresh, publish, release })
        {
            button.AutoSize = true;
            button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button.Padding = new Padding(12, 6, 12, 6);
        }
        actions.Controls.Add(refresh, 1, 0);
        actions.Controls.Add(publish, 2, 0);
        actions.Controls.Add(release, 3, 0);
        layout.Controls.Add(heading);
        layout.Controls.Add(main);
        layout.Controls.Add(live);
        layout.Controls.Add(pulser);
        layout.Controls.Add(log);
        layout.Controls.Add(progress);
        layout.Controls.Add(actions);
        Controls.Add(layout);

        Shown += async (sender, args) => await Run("status");
        refresh.Click += async (sender, args) => await Run("status");
        publish.Click += async (sender, args) => await Run("deploy");
        release.Click += async (sender, args) => await Run("release");
        FormClosing += (sender, args) => { if (busy) args.Cancel = true; };
    }

    internal void CheckLayout(string preview)
    {
        CreateControl();
        foreach (float scale in new[] { 1f, 1.25f, 1.2f })
        {
            if (scale != 1f) Scale(new SizeF(scale, scale));
            PerformLayout();
            foreach (Button button in new[] { refresh, publish, release })
            {
                Rectangle frame = button.Bounds;
                for (Control parent = button.Parent; parent != this; parent = parent.Parent)
                {
                    if (!parent.ClientRectangle.Contains(frame)) throw new InvalidOperationException(button.Text + " tagliato.");
                    frame.Offset(parent.Location);
                }
                if (!ClientRectangle.Contains(frame) || button.Height < button.PreferredSize.Height ||
                    button.Width < TextRenderer.MeasureText(button.Text, button.Font).Width)
                    throw new InvalidOperationException(button.Text + " tagliato.");
            }
        }
        if (!String.IsNullOrEmpty(preview))
        {
            publish.Enabled = true;
            release.Enabled = true;
            using (var bitmap = new Bitmap(Width, Height))
            {
                using (var graphics = Graphics.FromImage(bitmap)) graphics.Clear(BackColor);
                foreach (Button button in new[] { refresh, publish, release })
                {
                    Rectangle frame = button.Bounds;
                    for (Control parent = button.Parent; parent != this; parent = parent.Parent) frame.Offset(parent.Location);
                    button.DrawToBitmap(bitmap, frame);
                }
                bitmap.Save(preview);
            }
        }
    }

    private async Task Run(string mode)
    {
        if (busy) return;
        string requested = selectedCommit;
        busy = true;
        publish.Enabled = refresh.Enabled = release.Enabled = false;
        progress.Visible = true;
        if (mode == "status") log.Clear();
        try
        {
            int code = await Task.Run(() => DeployCommand.Run(mode, requested, line => BeginInvoke(new Action(() => ShowLine(line)))));
            if (code != 0)
            {
                selectedCommit = "";
                log.AppendText("Operazione interrotta. Premi Rileggi main per ricontrollare lo stato." + Environment.NewLine);
            }
            else if (mode == "deploy") log.AppendText("Deploy completato e verificato." + Environment.NewLine);
        }
        catch (Exception error)
        {
            selectedCommit = "";
            log.AppendText(error.Message + Environment.NewLine);
        }
        finally
        {
            busy = false;
            progress.Visible = false;
            refresh.Enabled = true;
            publish.Enabled = selectedCommit.Length == 40;
            release.Enabled = publish.Enabled && releaseReady;
        }
    }

    private void ShowLine(string line)
    {
        if (line.StartsWith("MAIN "))
        {
            var status = Regex.Match(line, @"^MAIN ([a-f0-9]{40})( \| .+)$");
            if (status.Success)
            {
                selectedCommit = status.Groups[1].Value;
                main.Text = "main  ·  " + selectedCommit.Substring(0, 12) + status.Groups[2].Value;
            }
        }
        else if (line.StartsWith("LIVE "))
        {
            string status = line.Substring(5);
            live.Text = "Server live  ·  " + Regex.Replace(status, "^[a-f0-9]{40}", match => match.Value.Substring(0, 12));
        }
        else if (line.StartsWith("PULSER "))
        {
            var values = line.Split(' ');
            if (values.Length == 4)
            {
                releaseReady = values[1] == "ready";
                pulser.Text = values[1] == "unknown" ? "Pulser  ·  feed non verificabile"
                    : "Pulser in tray  ·  " + values[2] + "     main  ·  " + values[3];
                if (values[1] == "tagged") pulser.Text += "     ·     tag inviato";
                if (values[1] == "blocked") pulser.Text += "     ·     tag occupato";
            }
        }
        log.AppendText(line + Environment.NewLine);
    }
}

internal static class DeployCommand
{
    private static string Quote(string text)
    {
        if (text.IndexOf('"') >= 0) throw new ArgumentException("Percorso non valido.");
        return "\"" + text + "\"";
    }

    internal static int Run(string mode, string commit, Action<string> output)
    {
        if (mode != "status" && !Regex.IsMatch(commit, "^[a-f0-9]{40}$")) throw new InvalidOperationException("Leggi main prima del deploy.");
        string files = Path.Combine(Path.GetTempPath(), "uncs-deploy-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(files);
        string client = Path.Combine(files, "client.ps1");
        string server = Path.Combine(files, "server.ps1");
        try
        {
            Extract("client.ps1", client);
            Extract("server.ps1", server);
            string arguments = "-NoProfile -NonInteractive -File " + Quote(client)
                + " -Repository " + Quote(BuildSettings.Repository) + " -Git " + Quote(BuildSettings.Git) + " -Node " + Quote(BuildSettings.Node)
                + " -Npm " + Quote(BuildSettings.Npm) + " -RemoteScript " + Quote(server)
                + " -Owner " + Quote(BuildSettings.Owner) + " -Mode " + Quote(mode);
            if (mode != "status") arguments += " -Commit " + Quote(commit);
            var settings = new ProcessStartInfo(BuildSettings.PowerShell, arguments) {
                WorkingDirectory = BuildSettings.Repository, UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardOutput = true, RedirectStandardError = true
            };
            using (Process child = new Process { StartInfo = settings })
            {
                child.OutputDataReceived += (sender, args) => { if (args.Data != null) output(args.Data); };
                child.ErrorDataReceived += (sender, args) => {
                    if (args.Data != null) ShowErrorOutput(args.Data, output);
                };
                child.Start();
                child.BeginOutputReadLine();
                child.BeginErrorReadLine();
                child.WaitForExit();
                return child.ExitCode;
            }
        }
        finally
        {
            File.Delete(client);
            File.Delete(server);
            Directory.Delete(files);
        }
    }

    private static void ShowErrorOutput(string line, Action<string> output)
    {
        if (line.Trim() == "#< CLIXML") return;
        if (!line.TrimStart().StartsWith("<Objs", StringComparison.Ordinal)) { output(line); return; }
        try
        {
            var document = new XmlDocument { XmlResolver = null };
            document.LoadXml(line);
            foreach (XmlNode error in document.SelectNodes("//*[local-name()='S' and (@S='Error' or @S='Warning')]"))
                output(Regex.Replace(error.InnerText, "_x([0-9A-Fa-f]{4})_", match => ((char)Convert.ToInt32(match.Groups[1].Value, 16)).ToString()));
        }
        catch (XmlException) { output(line); }
    }

    private static void Extract(string name, string path)
    {
        using (Stream source = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
        using (FileStream target = File.Create(path))
        {
            if (source == null) throw new InvalidOperationException("Risorsa mancante: " + name);
            source.CopyTo(target);
        }
    }
}

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (WindowsIdentity.GetCurrent().User.Value != BuildSettings.Owner) return 5;
        if (args.Length == 2 && args[0] == "--check")
        {
            using (var report = new StreamWriter(args[1]))
            {
                return DeployCommand.Run("status", "", line => { lock (report) report.WriteLine(line); });
            }
        }
        if (args.Length == 3 && args[0] == "--check-pulser")
        {
            using (var report = new StreamWriter(args[2]))
            {
                return DeployCommand.Run("release-preview", args[1], line => { lock (report) report.WriteLine(line); });
            }
        }
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        if (args.Length == 3 && args[0] == "--check-layout")
        {
            try
            {
                using (var window = new DeployWindow()) window.CheckLayout(args[2]);
                File.WriteAllText(args[1], "Pulsanti verificati anche con ingrandimento del 150%.");
                return 0;
            }
            catch (Exception error) { File.WriteAllText(args[1], error.Message); return 3; }
        }
        Application.Run(new DeployWindow());
        return 0;
    }
}
