param(
    [string]$Git = (Get-Command git.exe -ErrorAction Stop).Source,
    [string]$Node = (Get-Command node.exe -ErrorAction Stop).Source,
    [string]$PowerShell = (Get-Command pwsh.exe -ErrorAction Stop).Source,
    [string]$Npm
)
$ErrorActionPreference = 'Stop'
$repository = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
if (-not $Npm) {
    $Npm = Join-Path (Split-Path -Parent $Node) 'node_modules/npm/bin/npm-cli.js'
}
foreach ($dependency in @($Git, $Node, $PowerShell, $Npm)) {
    if (-not (Test-Path -LiteralPath $dependency -PathType Leaf)) { throw "File necessario non trovato: $dependency" }
}
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$settings = Join-Path ([IO.Path]::GetTempPath()) ("uncs-settings-" + [guid]::NewGuid().ToString('N') + '.cs')
$output = Join-Path $PSScriptRoot 'UnCs Deploy.exe'
$values = [ordered]@{
    Repository = $repository
    Git = $Git
    Node = $Node
    Npm = $Npm
    PowerShell = $PowerShell
    Owner = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
}
try {
    $lines = foreach ($entry in $values.GetEnumerator()) {
        '    internal const string {0} = @"{1}";' -f $entry.Key, $entry.Value.Replace('"', '""')
    }
    @('internal static class BuildSettings {') + $lines + '}' | Set-Content -LiteralPath $settings -Encoding utf8BOM
    & $compiler /nologo /target:winexe "/out:$output" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "/resource:$PSScriptRoot\client.ps1,client.ps1" "/resource:$PSScriptRoot\server.ps1,server.ps1" "$PSScriptRoot\DeployWindow.cs" $settings
    if ($LASTEXITCODE -ne 0) { throw 'Compilazione di UnCs Deploy non riuscita.' }
    Get-Item -LiteralPath $output
} finally {
    Remove-Item -LiteralPath $settings -ErrorAction SilentlyContinue
}
