param(
    [Parameter(Mandatory)][string]$Repository,
    [Parameter(Mandatory)][string]$Git,
    [Parameter(Mandatory)][string]$Node,
    [Parameter(Mandatory)][string]$Npm,
    [Parameter(Mandatory)][string]$RemoteScript,
    [Parameter(Mandatory)][string]$Owner,
    [ValidateSet('status','preview','deploy','release-preview','release')][string]$Mode = 'status',
    [string]$Commit
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
if ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne $Owner) { throw 'Operatore non autorizzato' }
$env:Path = (Split-Path -Parent $Node) + [IO.Path]::PathSeparator + $env:Path
$hostName = 'uncs-server'
$expectedOrigin = 'https://github.com/aleilsandro/UnCsForeverCompanion.git'
$feedUrl = 'https://uncs-server.tail1b66eb.ts.net:8447/bridge/releases/latest.yml'

function Invoke-Remote([string]$Action, [string]$Sha = '', [string]$File = '', [string]$Hash = '') {
    $variables = '$Mode=''' + $Action + '''; $Commit=''' + $Sha + '''; $Upload=''' + $File + '''; $Digest=''' + $Hash + ''';'
    $source = $variables + "`n" + (Get-Content -LiteralPath $RemoteScript -Raw)
    $name = 'uncs-deploy-' + [Guid]::NewGuid().ToString('N') + '.ps1'
    $local = Join-Path ([IO.Path]::GetTempPath()) $name
    try {
        [IO.File]::WriteAllText($local, $source, [Text.UTF8Encoding]::new($true))
        $digest = (Get-FileHash -LiteralPath $local -Algorithm SHA256).Hash
        & "$env:WINDIR/System32/OpenSSH/scp.exe" -o BatchMode=yes -o ConnectTimeout=8 -o StrictHostKeyChecking=yes $local ("${hostName}:$name")
        if ($LASTEXITCODE) { throw 'Trasferimento dello script non riuscito' }
        $loader = @'
$ErrorActionPreference='Stop'
$file=Join-Path $env:USERPROFILE '__FILE__'
if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne '__HASH__') { throw 'Integrita script non valida' }
try { & ([ScriptBlock]::Create((Get-Content -LiteralPath $file -Raw))) } catch { Write-Error $_ -ErrorAction Continue; exit 1 }
finally { Remove-Item -LiteralPath $file -Force }
'@
        $entry = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($loader.Replace('__FILE__', $name).Replace('__HASH__', $digest)))
        & "$env:WINDIR/System32/OpenSSH/ssh.exe" -n -o BatchMode=yes -o ConnectTimeout=8 -o StrictHostKeyChecking=yes $hostName powershell -NoProfile -NonInteractive -EncodedCommand $entry
        if ($LASTEXITCODE) { throw 'Operazione SSH non completata. Controlla i dettagli sopra.' }
    } finally { Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue }
}

function Read-MainVersion([string]$Sha) {
    $manifest = & $Git show "${Sha}:desktop/package.json"
    if ($LASTEXITCODE) { throw 'Versione di main non trovata' }
    $version = ($manifest -join "`n" | ConvertFrom-Json).version
    if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versione di main non valida' }
    return $version
}

function Read-PulserRelease([string]$Sha, [string]$MainVersion) {
    $toc = & $Git show "${Sha}:UnCsForeverCompanion.toc"
    if ($LASTEXITCODE) { throw 'Versione addon di main non trovata' }
    $version = [regex]::Match(($toc -join "`n"), '(?m)^## Version: (\d+\.\d+\.\d+)\s*$').Groups[1].Value
    $lua = & $Git show "${Sha}:UnCsForeverCompanion.lua"
    if ($LASTEXITCODE) { throw 'Sorgente addon di main non trovata' }
    $addon = [regex]::Match(($lua -join "`n"), '(?m)^ns\.VERSION = "(\d+\.\d+\.\d+)"').Groups[1].Value
    if (!$version -or $MainVersion -ne $version -or $addon -ne $version) { throw 'Versioni di Pulser e addon diverse su main' }
    $response = Invoke-WebRequest $feedUrl -TimeoutSec 12
    $feed = if ($response.Content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($response.Content) } else { [string]$response.Content }
    $published = [regex]::Match($feed, '(?m)^version: (\d+\.\d+\.\d+)\s*$').Groups[1].Value
    if (!$published) { throw 'Versione disponibile dalla tray non verificabile' }
    $reference = "refs/tags/$version"
    $result = [ordered]@{ Version=$version; Published=$published; Ref=$reference; State='ready' }
    if ([version]$version -le [version]$published) { $result.State='current'; return [pscustomobject]$result }
    $tags = & $Git ls-remote origin $reference ("${reference}^{}")
    if ($LASTEXITCODE) { throw 'Tag su GitHub non verificabile' }
    if ($tags) {
        $tip = ($tags | Select-Object -Last 1) -split '\s+'
        $result.State = if ($tip[0] -eq $Sha) { 'tagged' } else { 'blocked' }
    }
    return [pscustomobject]$result
}

function Write-PulserStatus($Release) {
    "PULSER $($Release.State) $($Release.Published) $($Release.Version)"
}

Push-Location -LiteralPath $Repository
try {
    $origin = (& $Git remote get-url origin)
    if ($LASTEXITCODE -or $origin -ne $expectedOrigin) { throw 'Repository GitHub inatteso' }
    & $Git fetch origin '+refs/heads/main:refs/remotes/origin/main'
    if ($LASTEXITCODE) { throw 'Sincronizzazione di main non riuscita' }
    $main = (& $Git rev-parse refs/remotes/origin/main).Trim()
    if ($LASTEXITCODE -or $main -notmatch '^[a-f0-9]{40}$') { throw 'Commit di main non valido' }
    $mainVersion = ''
    try { $mainVersion = Read-MainVersion $main }
    catch { "main: $($_.Exception.Message)" }
    $versionLabel = if ($mainVersion) { "versione $mainVersion" } else { 'versione non disponibile' }
    "MAIN $main | $versionLabel"
    if ($Mode -eq 'status') {
        try { Write-PulserStatus (Read-PulserRelease $main $mainVersion) }
        catch { "PULSER unknown - -"; "Pulser: $($_.Exception.Message)" }
        Invoke-Remote status
        return
    }
    if ($Commit -ne $main) { throw 'main e cambiata. Premi Rileggi main prima di pubblicare.' }
    if ($Mode -in 'release-preview','release') {
        $release = Read-PulserRelease $main $mainVersion
        Write-PulserStatus $release
        if ($Mode -eq 'release-preview') { return }
        if ($release.State -eq 'current') { 'La tray offre gia questa versione o una piu recente.'; return }
        if ($release.State -eq 'tagged') { 'Tag gia presente. Controlla la build su GitHub Actions.'; return }
        if ($release.State -ne 'ready') { throw 'Il tag esiste gia su un altro commit' }
        $originTip = & $Git ls-remote --exit-code origin refs/heads/main
        if ($LASTEXITCODE -or ($originTip -split '\s+')[0] -ne $main) { throw 'main e cambiata. Rileggi e riprova.' }
        & $Git push origin "${main}:$($release.Ref)"
        if ($LASTEXITCODE) { throw 'Pubblicazione del tag non riuscita' }
        $confirmed = & $Git ls-remote --exit-code origin $release.Ref
        if ($LASTEXITCODE -or ($confirmed -split '\s+')[0] -ne $main) { throw 'Il tag inviato non e verificabile su GitHub' }
        $release.State = 'tagged'
        Write-PulserStatus $release
        "Tag $($release.Version) inviato. La tray lo proporra quando la release pubblica sara disponibile."
        'https://github.com/aleilsandro/UnCsForeverCompanion/actions'
        return
    }

    $runId = [Guid]::NewGuid().ToString('N')
    $runs = Join-Path $Repository '.release/uncs-deploy/runs'
    $run = Join-Path $runs $runId
    New-Item -Path $run -ItemType Directory -Force | Out-Null
    try {
        $archive = Join-Path $run 'source.zip'
        $snapshot = Join-Path $run 'source'
        $package = Join-Path $run 'package'
        & $Git archive --format=zip -o $archive $Commit
        if ($LASTEXITCODE) { throw 'Esportazione del commit non riuscita' }
        Expand-Archive -LiteralPath $archive -DestinationPath $snapshot
        $desktop = Join-Path $snapshot 'desktop'
        Push-Location -LiteralPath $desktop
        $skip = $env:ELECTRON_SKIP_BINARY_DOWNLOAD
        try {
            $env:ELECTRON_SKIP_BINARY_DOWNLOAD = '1'
            'Installazione delle dipendenze dal lockfile di main.'
            & $Node $Npm ci --no-audit --no-fund
            if ($LASTEXITCODE) { throw 'Installazione npm ci non riuscita' }
            'Compilazione della web app.'
            & $Node '.\node_modules\electron-vite\bin\electron-vite.js' build --config electron.bridge.vite.config.ts
            if ($LASTEXITCODE) { throw 'Compilazione del renderer non riuscita' }
        } finally { $env:ELECTRON_SKIP_BINARY_DOWNLOAD = $skip; Pop-Location }
        if (!(Test-Path -LiteralPath (Join-Path $desktop 'out/renderer/index.html'))) { throw 'Renderer compilato non trovato' }
        New-Item -Path "$package/web","$package/desktop/out" -ItemType Directory -Force | Out-Null
        Get-ChildItem -LiteralPath (Join-Path $snapshot 'web') -Filter '*.cjs' -File |
            Where-Object { $_.Name -notlike '*.test.cjs' } | Copy-Item -Destination "$package/web/"
        Copy-Item -LiteralPath "$desktop/package.json" -Destination "$package/desktop/"
        Copy-Item -LiteralPath "$desktop/out/renderer" -Destination "$package/desktop/out/" -Recurse
        Set-Content -LiteralPath "$package/deploy-commit.txt" -Value $main -Encoding ascii

        $originTip = & $Git ls-remote --exit-code origin refs/heads/main
        if ($LASTEXITCODE -or ($originTip -split '\s+')[0] -ne $main) { throw 'main e cambiata durante la build. Rileggi e riprova.' }
        $upload = 'uncs-web-' + $runId + '.zip'
        $zip = Join-Path $run $upload
        Compress-Archive -Path "$package/*" -DestinationPath $zip -CompressionLevel Fastest
        $digest = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        'Trasferimento al server via SSH.'
        & "$env:WINDIR/System32/OpenSSH/scp.exe" -o BatchMode=yes -o ConnectTimeout=8 -o StrictHostKeyChecking=yes $zip ("${hostName}:$upload")
        if ($LASTEXITCODE) { throw 'Trasferimento non riuscito' }
        Invoke-Remote $Mode $main $upload $digest
    } finally {
        $expected = [IO.Path]::GetFullPath($run)
        $resolved = (Resolve-Path -LiteralPath $run).ProviderPath
        if ($resolved -eq $expected -and (Split-Path -Parent $resolved) -eq $runs -and (Split-Path -Leaf $resolved) -eq $runId) {
            Remove-Item -LiteralPath $resolved -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
} finally { Pop-Location }
