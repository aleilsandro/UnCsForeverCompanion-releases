$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = 'E:\UnCsForeverWeb'
$legacy = Join-Path $root 'pulser-01317'
$deployments = Join-Path $root 'deployments'
$taskName = 'UnCs-Forever-Web'

function Read-Health([int]$Port, [string]$Version = '') {
    $url = "http://127.0.0.1:$Port"
    for ($attempt = 0; $attempt -lt 15; $attempt++) {
        try {
            $status = Invoke-RestMethod "$url/healthz" -TimeoutSec 2
            if ($status.service -eq 'uncs-forever-web' -and $status.mapConfigured -and (!$Version -or $status.version -eq $Version)) {
                $page = (Invoke-WebRequest "$url/" -UseBasicParsing -TimeoutSec 3).Content
                $script = [regex]::Match($page, 'src="\./(assets/[\w.-]+\.js)"').Groups[1].Value
                if (!$script) { throw 'Script del renderer non trovato' }
                $null = Invoke-WebRequest "$url/$script" -UseBasicParsing -Method Head -TimeoutSec 3
                $null = Invoke-WebRequest "$url/openmap/overview.png" -UseBasicParsing -Method Head -TimeoutSec 3
                return $status
            }
        } catch {}
        Start-Sleep -Milliseconds 600
    }
    throw "Verifica non superata sulla porta $Port"
}

function Read-Task {
    $task = Get-ScheduledTask -TaskName $taskName
    if ($task.Actions.Count -ne 1) { throw 'Configurazione inattesa del servizio WebCompanion' }
    $action = $task.Actions[0]
    $directory = $action.WorkingDirectory
    if ($directory -ne $legacy -and $directory -notmatch '^E:\\UnCsForeverWeb\\deployments\\[a-f0-9]{40}-[a-f0-9]{8}$') {
        throw 'Il servizio usa una directory diversa da quella di WebCompanion'
    }
    if ($task.State -ne 'Running' -or $action.Arguments -ne ('"' + (Join-Path $directory 'start.cjs') + '"')) {
        throw 'Il servizio non e attivo con il launcher atteso'
    }
    return $action
}

if ($Mode -eq 'status') {
    $action = Read-Task
    $status = Read-Health 8796
    $marker = Join-Path $action.WorkingDirectory 'deploy-commit.txt'
    $active = if (Test-Path -LiteralPath $marker) { (Get-Content -LiteralPath $marker -Raw).Trim() } else { 'deploy precedente' }
    "LIVE $active | versione $($status.version)"
    return
}

if ($Mode -notin @('preview', 'deploy') -or $Commit -notmatch '^[a-f0-9]{40}$' -or
    $Upload -notmatch '^uncs-web-[a-f0-9]{32}\.zip$' -or $Digest -notmatch '^[a-f0-9]{64}$') {
    throw 'Parametri di deploy non validi'
}

New-Item -Path $deployments -ItemType Directory -Force | Out-Null
$lock = [IO.File]::Open((Join-Path $deployments 'deployment.lock'), 'OpenOrCreate', 'ReadWrite', 'None')
try {
    $action = Read-Task
    $previous = Read-Health 8796
    $inbound = Join-Path $env:USERPROFILE $Upload
    if ((Get-FileHash -LiteralPath $inbound -Algorithm SHA256).Hash -ne $Digest) { throw 'Archivio trasferito non integro' }
    $next = Join-Path $deployments ($Commit + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
    Expand-Archive -LiteralPath $inbound -DestinationPath $next
    if ((Get-Content -LiteralPath (Join-Path $next 'deploy-commit.txt') -Raw).Trim() -ne $Commit) { throw 'Commit del pacchetto non corrispondente' }
    $version = (Get-Content -LiteralPath (Join-Path $next 'desktop/package.json') -Raw | ConvertFrom-Json).version
    if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versione del pacchetto non valida' }

    $settings = Get-Content -LiteralPath (Join-Path $legacy 'start.cjs') -Raw
    if (!$settings.Contains("join(__dirname, 'releases')") -or !$settings.Contains("require('./web/server.cjs')")) {
        throw 'Il launcher di riferimento e cambiato'
    }
    $settings = $settings.Replace("join(__dirname, 'releases')", "'E:/UnCsForeverWeb/pulser-01317/releases'")
    $launcher = Join-Path $next 'start.cjs'
    [IO.File]::WriteAllText($launcher, $settings, [Text.UTF8Encoding]::new($false))
    & $action.Execute --check $launcher
    if ($LASTEXITCODE) { throw 'Launcher Node non valido' }

    # Reserve a free loopback port for the preview, leaving the live task running.
    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = $listener.LocalEndpoint.Port
    $listener.Stop()
    $oldPort = $env:UNCS_WEB_PORT
    try {
        $env:UNCS_WEB_PORT = [string]$port
        $preview = Start-Process -FilePath $action.Execute -ArgumentList ('"' + $launcher + '"') -WorkingDirectory $next -WindowStyle Hidden -PassThru
    } finally { $env:UNCS_WEB_PORT = $oldPort }
    try {
        $null = Read-Health $port $version
        if ($preview.HasExited) { throw 'Il processo di anteprima si e chiuso' }
        "Anteprima privata verificata sulla porta $port."
    } finally {
        if (!$preview.HasExited) { $preview.Kill(); $preview.WaitForExit() }
        $preview.Dispose()
    }
    if ($Mode -eq 'preview') {
        $null = Read-Health 8796 $previous.version
        "PREVIEW $Commit"
        return
    }

    $active = Read-Task
    if ($active.WorkingDirectory -ne $action.WorkingDirectory) { throw 'Il deploy attivo e cambiato durante la verifica' }
    $replacement = New-ScheduledTaskAction -Execute $action.Execute -WorkingDirectory $next -Argument ('"' + $launcher + '"')
    try {
        Stop-ScheduledTask -TaskName $taskName
        Set-ScheduledTask -TaskName $taskName -Action $replacement | Out-Null
        Start-ScheduledTask -TaskName $taskName
        $null = Read-Health 8796 $version
        "LIVE $Commit | versione $version"
    } catch {
        $failure = $_.Exception.Message
        Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
        Set-ScheduledTask -TaskName $taskName -Action $action | Out-Null
        Start-ScheduledTask -TaskName $taskName
        $null = Read-Health 8796 $previous.version
        throw "Deploy fallito. Versione precedente ripristinata. $failure"
    }
} finally {
    $lock.Dispose()
}
