# UnCs Forever Companion

## [0.13.40](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.40) (2026-11-24)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.37...0.13.40) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge thomas into main for Companion 0.13.40  
- Add farming sessions and dungeon preparation guides  
- Merge Companion local workflow docs for 0.13.39  
- Rebuild local web app and Pulser after main sync  
- Merge commit '9a26a0aa2041afb50494bcc995708f94e39ca19f' into aleilsandro-local  
    # Conflicts:  
    #	README.md  
- Document Companion follow and local launcher updates  
- Merge thomas into main for Companion 0.13.38  
- Add dungeon sessions, completion tracking and private party markers  
