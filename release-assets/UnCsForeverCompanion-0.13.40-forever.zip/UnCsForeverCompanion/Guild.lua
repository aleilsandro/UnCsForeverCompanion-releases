-- The online roster is available from WoW; exact coordinates are only available when a member
-- shares them through this addon's or OpenMap's guild-only addon protocol.
local _, ns = ...
local function Ok(ok, ...) if ok then return ... end end
local function Try(f, ...) if f then return Ok(pcall(f, ...)) end end
local function Secret(v) return issecretvalue and issecretvalue(v) end
local function Num(v) if type(v) == "number" and not Secret(v) and v == v and v ~= math.huge and v ~= -math.huge then return v end end
local function Str(v) if type(v) == "string" and not Secret(v) then return v end end
local function Key(name)
  name = Str(name)
  if not name then return end
  -- Forever names may arrive as First-Surname-CAMWOW... or First Surname-CAMWOW...
  name = name:gsub("%-[Cc][Aa][Mm][Ww][Oo][Ww][%w]+$", "")
  return name:lower():gsub("%-", " "):gsub("%s+", " "):match("^%s*(.-)%s*$")
end
local function WorldPoint(map, x, y)
  if not (Num(map) and Num(x) and Num(y)) or x < 0 or x > 1 or y < 0 or y > 1 then return end
  local l, r, t, b = Try(C_Map.GetMapRectOnMap, map, 947)
  l, r, t, b = Num(l), Num(r), Num(t), Num(b)
  if not (l and r and t and b and r > l and b > t) then return end
  local u, v = l + (r-l)*x, t + (b-t)*y
  if u < 0 or u > 1 or v < 0 or v > 1 then return end
  return math.floor(u*100000+0.5), math.floor(v*100000+0.5)
end

local heard = {}
local zoneIndex, nextZoneIndex = {}, 0
local function Zones(now)
  if now < nextZoneIndex then return end
  nextZoneIndex = now + 300
  local found = {}
  for _, world in ipairs({947}) do
    local zoneType=Enum and Enum.UIMapType and Enum.UIMapType.Zone
    local children = Try(C_Map.GetMapChildrenInfo, world, zoneType, true)
    if type(children) == "table" then
      for _, info in ipairs(children) do
        local name, id = type(info)=="table" and Str(info.name), type(info)=="table" and Num(info.mapID)
        if name and id then
          local k=name:lower()
          if found[k] and found[k] ~= id then found[k]=false elseif found[k] == nil then found[k]=id end
        end
      end
    end
  end
  zoneIndex=found
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("CHAT_MSG_ADDON")
frame:SetScript("OnEvent", function(_, event, prefix, text, channel, sender)
  if event=="PLAYER_LOGIN" then
    Try(C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix, "OpenMapLoc")
    Try(C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix, "UnCsGuild")
    return
  end
  if (Str(prefix) ~= "OpenMapLoc" and Str(prefix) ~= "UnCsGuild") or Str(channel) ~= "GUILD" or not Str(sender) or not Str(text) then return end
  local key=Key(sender); if not key then return end
  if text=="L0" then if heard[key] then heard[key][prefix]=nil end; return end
  local m,x,y=text:match("^L1\t(%d+)\t([%d.]+)\t([%d.]+)\t")
  m,x,y=tonumber(m),tonumber(x),tonumber(y)
  if not (m and x and y and x>=0 and x<=1 and y>=0 and y<=1) then return end
  local u,v=WorldPoint(m,x,y)
  if u and v then
    heard[key]=heard[key] or {}
    heard[key][prefix]={x=u,y=v,at=GetTime()}
  end
end)
local lastRosterRequest=-60
local sent={at=-1000}
ns.StopGuildShare=function()
  if sent.active and Try(IsInGuild) then Try(C_ChatInfo and C_ChatInfo.SendAddonMessage,"UnCsGuild","L0","GUILD") end
  sent={at=-1000}
end
local function Share(now)
  if not (ns.db and ns.db.guildShare) then return end
  local inInstance=Try(IsInInstance)
  local map=not inInstance and Num(Try(C_Map.GetBestMapForUnit,"player"))
  local pos=map and Try(C_Map.GetPlayerMapPosition,map,"player")
  local x,y=type(pos)=="table" and Num(pos.x), type(pos)=="table" and Num(pos.y)
  if not (map and x and y and x>=0 and x<=1 and y>=0 and y<=1 and WorldPoint(map,x,y)) then
    if not inInstance and Try(UnitIsAFK,"player")==true then return end
    if sent.active then Try(C_ChatInfo and C_ChatInfo.SendAddonMessage,"UnCsGuild","L0","GUILD"); sent.active=false end
    return
  end
  local moved=map~=sent.map or math.abs(x-(sent.x or 0))>=.001 or math.abs(y-(sent.y or 0))>=.001
  if now-sent.at < (moved and 3 or 60) then return end
  local _,class=Try(UnitClass,"player")
  local text=("L1\t%d\t%.4f\t%.4f\t%s\t%d"):format(map,x,y,Str(class) or "",Num(Try(UnitLevel,"player")) or 0)
  Try(C_ChatInfo and C_ChatInfo.SendAddonMessage,"UnCsGuild",text,"GUILD")
  -- Some client versions return no status on success, so retry on the ordinary interval.
  sent={map=map,x=x,y=y,at=now,active=true}
end
local function BuildGuild()
  if not Try(IsInGuild) then heard={}; sent={at=-1000}; return {list={}} end
  local now=GetTime()
  Share(now)
  if now-lastRosterRequest >= 60 then
    lastRosterRequest=now
    Try(C_GuildInfo and C_GuildInfo.GuildRoster or GuildRoster)
  end
  Zones(now)
  local count=Num(Try(GetNumGuildMembers)) or 0
  local first,second=Try(UnitName,"player")
  local me=Key((Str(first) or "") .. (Str(second) and second~="" and " "..second or ""))
  local list, active, duplicate, entries = {}, {}, {}, {}
  -- Do not attach a location when two roster names normalize to the same key.
  for i=1,count do
    local name,_,_,level,_,area,_,_,online,_,class,_,_,_,_,_,guid=Try(GetGuildRosterInfo,i)
    local key=Key(name)
    if key and not Secret(online) and online==false then heard[key]=nil end
    if key and not Secret(online) and online and key~=me and not (Str(guid) and guid==Try(UnitGUID,"player")) then
      if active[key] then duplicate[key]=true end
      active[key]=true
      entries[#entries+1]={key=key,entry={n=Str(name),c=Str(class),l=Num(level),z=Str(area)}}
    end
  end
  for _,item in ipairs(entries) do
    local key,entry=item.key,item.entry
    local place
    local sources=heard[key]
    if not duplicate[key] and sources then
      local zone=entry.z or ""
      for source,candidate in pairs(sources) do
        if candidate.zone and candidate.zone~=zone then sources[source]=nil
        else
          candidate.zone=zone
          if not place or candidate.at>place.at then place=candidate end
        end
      end
    end
    if place then entry.x,entry.y,entry.exact=place.x,place.y,true
    elseif entry.z then
      local map=zoneIndex[entry.z:lower()]
      if map then entry.x,entry.y=WorldPoint(map,.5,.5) end
    end
    list[#list+1]=entry
  end
  for key,sources in pairs(heard) do
    if not active[key] or duplicate[key] then
      for source,place in pairs(sources) do if now-place.at>150 then sources[source]=nil end end
    end
    if not next(sources) then heard[key]=nil end
  end
  table.sort(list,function(a,b) return a.n<b.n end)
  return {list=list,share=ns.db and ns.db.guildShare == true}
end
ns.sections[#ns.sections+1]={name="guild",period=3,build=BuildGuild,refresh=30,combat=true}
