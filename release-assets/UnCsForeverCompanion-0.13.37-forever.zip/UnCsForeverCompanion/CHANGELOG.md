# UnCs Forever Companion

## [0.13.37](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.37) (2026-11-23)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.36...0.13.37) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge smooth guild follow for Companion 0.13.37  
- Merge commit 'f1dc45538e36506a9d4f2aa754a13260df6518ee' into aleilsandro-local  
- Smooth guild camera and player markers  
