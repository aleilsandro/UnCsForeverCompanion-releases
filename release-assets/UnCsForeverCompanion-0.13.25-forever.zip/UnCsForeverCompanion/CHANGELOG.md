# UnCs Forever Companion

## [0.13.25](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.25) (2026-11-22)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.23...0.13.25) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Fix browser activation for 0.13.25  
- Fix activation form origin in browsers  
- Merge Discord Pulser bot for 0.13.24  
- Add role-gated Discord Pulser activation command  
