# UnCs Forever Companion

## [0.13.28](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.28) (2026-11-23)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.26...0.13.28) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge thomas into main for Companion 0.13.28  
- Integrate Thomas Companion map and Pulser features  
- Merge commit '5b25c09a10ef0b2075ab580a5e9ee74ade452f11'  
- Document Tailscale access to WebCompanion  
