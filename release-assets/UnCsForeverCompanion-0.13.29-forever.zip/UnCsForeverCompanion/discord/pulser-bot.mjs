import { readFile } from 'node:fs/promises'
import { WebSocket } from 'ws'

const guild = '1091004272306561128'
const allowedRole = '1566506659751133214'
const application = '1566497156477624320'
const config = JSON.parse((await readFile(process.env.UNCS_DISCORD_CONFIG, 'utf8')).replace(/^\uFEFF/, ''))
if (config.guildId !== guild || !config.token) throw Error('Configurazione Discord non valida')
const api = 'https://discord.com/api/v10'
const authorization = `Bot ${config.token}`
async function request(path, init = {}) {
  const response = await fetch(api + path, {
    ...init, headers: { Authorization: authorization, 'Content-Type': 'application/json', ...init.headers },
    signal: AbortSignal.timeout(8000),
  })
  if (!response.ok) throw Error(`Discord HTTP ${response.status}`)
  return response.status === 204 ? null : response.json()
}
async function answer(interaction) {
  const { id, token, member, data, guild_id: origin } = interaction
  if (origin !== guild || data?.name !== 'pulser' || member?.user?.bot) return
  const respond = (type, body) => request(`/interactions/${id}/${token}/callback`, {
    method: 'POST', body: JSON.stringify({ type, data: body }),
  })
  if (!member?.roles?.includes(allowedRole)) {
    await respond(4, { content: 'Il comando è riservato al ruolo Unconscious Force.', flags: 64 })
    return
  }
  await respond(5, { flags: 64 })
  let content
  try {
    const current = await request(`/guilds/${guild}/members/${member.user.id}`)
    if (!current.roles?.includes(allowedRole)) throw Error('Ruolo non più valido')
    const response = await fetch('https://uncs-server.tail1b66eb.ts.net:8447/access/invite', {
      method: 'POST', signal: AbortSignal.timeout(8000), redirect: 'error',
    })
    if (!response.ok) throw Error('Invito non disponibile')
    const invite = await response.json()
    if (!/^[A-Za-z0-9_-]{43}$/.test(invite.token)) throw Error('Invito non valido')
    content = `Il tuo codice personale monouso è:\n\`${invite.token}\`\nApri **UnCs Forever Web** dal Desktop o dalla tray e inserisci il codice. Scade dopo sette giorni.`
  } catch {
    content = 'Non riesco a creare il codice. Riprova tra qualche minuto oppure contatta un officer.'
  }
  await request(`/webhooks/${application}/${token}/messages/@original`, {
    method: 'PATCH', body: JSON.stringify({ content, allowed_mentions: { parse: [] } }),
  })
}
await request(`/applications/${application}/guilds/${guild}/commands`, {
  method: 'POST', body: JSON.stringify({ name: 'pulser', description: 'Ricevi un codice personale per attivare UnCs Pulser', type: 1 }),
})
let sequence = null
let delay = 1000
function connect() {
  const socket = new WebSocket('wss://gateway.discord.gg/?v=10&encoding=json')
  let heartbeat
  let lastAck = true
  socket.on('message', raw => {
    let message
    try { message = JSON.parse(raw.toString()) } catch { return }
    if (message.s !== null && message.s !== undefined) sequence = message.s
    if (message.op === 10) {
      heartbeat = setInterval(() => {
        if (!lastAck) return socket.terminate()
        lastAck = false
        socket.send(JSON.stringify({ op: 1, d: sequence }))
      }, message.d.heartbeat_interval)
      socket.send(JSON.stringify({ op: 2, d: { token: config.token, intents: 0, properties: { os: 'windows', browser: 'uncs', device: 'uncs' } } }))
    } else if (message.op === 11) lastAck = true
    else if (message.op === 7 || message.op === 9) socket.close()
    else if (message.t === 'READY') { delay = 1000; console.log('Bot Pulser connesso.') }
    else if (message.t === 'INTERACTION_CREATE') void answer(message.d).catch(() => console.error('Comando Pulser non completato.'))
  })
  socket.on('error', () => {})
  socket.on('close', () => {
    clearInterval(heartbeat)
    setTimeout(connect, delay)
    delay = Math.min(delay * 2, 60000)
  })
}
connect()
