$ErrorActionPreference = 'Stop'
$env:UNCS_DISCORD_CONFIG = 'C:\Users\crewu\UnCsDiscordNews\.local\discord.json'
$node = 'C:\Program Files\nodejs\node.exe'
Set-Location -LiteralPath $PSScriptRoot
& $node (Join-Path $PSScriptRoot 'pulser-bot.mjs') *>> (Join-Path $PSScriptRoot 'pulser-bot.log')
exit $LASTEXITCODE
