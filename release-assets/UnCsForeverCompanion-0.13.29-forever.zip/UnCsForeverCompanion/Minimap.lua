local _, ns = ...
local button

local function position()
  local angle = math.rad(tonumber(ns.db.minimapAngle) or 220)
  local x, y = math.cos(angle), math.sin(angle)
  local halfW, halfH = Minimap:GetWidth() / 2, Minimap:GetHeight() / 2
  if not GetMinimapShape or GetMinimapShape() == "ROUND" then
    x, y = x * (halfW + 5), y * (halfH + 5)
  else
    local edge = math.max(math.abs(x), math.abs(y))
    x, y = x / edge * (halfW + 10), y / edge * (halfH + 10)
  end
  button:ClearAllPoints()
  button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

function ns.UpdateMinimapVisibility()
  if button and ns.db then button:SetShown(ns.db.minimapVisible ~= false) end
end

local function createButton()
  if button or not Minimap or not ns.db then return end
  button = CreateFrame("Button", "UnCsForeverCompanionMinimapButton", Minimap)
  button:SetSize(31, 31)
  button:SetFrameStrata("MEDIUM")
  button:SetFrameLevel(8)
  button:RegisterForClicks("LeftButtonUp")
  button:RegisterForDrag("LeftButton")
  local background = button:CreateTexture(nil, "BACKGROUND")
  background:SetSize(20, 20)
  background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
  background:SetPoint("CENTER")
  local icon = button:CreateTexture(nil, "ARTWORK")
  icon:SetSize(18, 18)
  icon:SetTexture("Interface\\Icons\\INV_Misc_Map_01")
  icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
  icon:SetPoint("CENTER")
  local border = button:CreateTexture(nil, "OVERLAY")
  border:SetSize(50, 50)
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  border:SetPoint("TOPLEFT")
  button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  button:SetScript("OnClick", function() if ns.OpenSettings then ns.OpenSettings() end end)
  button:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local x, y = GetCursorPosition()
      local scale = Minimap:GetEffectiveScale()
      local mx, my = Minimap:GetCenter()
      if not mx or not my or not scale or scale == 0 then return end
      ns.db.minimapAngle = math.deg(math.atan2(y / scale - my, x / scale - mx))
      position()
    end)
  end)
  button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  button:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("UnCs Forever Companion")
    GameTooltip:AddLine("Clic: impostazioni. Trascina: sposta icona.", 1, 1, 1)
    GameTooltip:Show()
  end)
  button:SetScript("OnLeave", function() GameTooltip:Hide() end)
  position()
  ns.UpdateMinimapVisibility()
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", createButton)
