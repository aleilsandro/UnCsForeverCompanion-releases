# UnCs Forever Companion

## [0.13.29](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.29) (2026-11-23)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.28...0.13.29) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge complete private cartography for Companion 0.13.29  
- Ship the full verified cartography with private web deployments  
