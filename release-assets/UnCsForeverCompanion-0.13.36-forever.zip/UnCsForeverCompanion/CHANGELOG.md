# UnCs Forever Companion

## [0.13.36](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.36) (2026-11-23)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.33...0.13.36) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge local Companion improvements for 0.13.36  
- Merge commit '359c38b15eb88c789a7dae0400d66b4060b346a8' into aleilsandro-local  
    # Conflicts:  
    #	desktop/src/renderer/src/App.svelte  
    #	desktop/src/renderer/src/OpenAtlas.svelte  
- Improve guild tracking, atlas zoom and Pulser update prompts  
- Merge thomas into main for Companion 0.13.35  
- Move the map pin button and document dungeon sessions  
- Merge aleilsandro into main for Companion 0.13.34  
- Merge commit 'a2c24cc6bd22fc2232170effce271a915be4bc48' into aleilsandro  
- Install updated Companion skills after pulling main  
