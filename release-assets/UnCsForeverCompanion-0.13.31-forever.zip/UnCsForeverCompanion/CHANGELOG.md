# UnCs Forever Companion

## [0.13.31](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.31) (2026-11-23)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.29...0.13.31) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge thomas into main for Companion 0.13.31  
- Keep dungeon entrance routes and caves visible  
- Trim empty and open-water pixels from atlas coast masks  
- Animate atlas wheel zoom around the cursor  
- Use minimap terrain at every atlas zoom  
- Keep detailed atlas art and focus cities and AFK players  
- Focus the atlas on selected dungeon maps  
- Allow deeper atlas zoom  
- Smooth atlas tile joins and preserve the original coastline  
- Add atlas notes, guild pins and dungeon quest navigation  
- Merge dungeon and city map fixes for Companion 0.13.30  
- Open dungeon maps on selection and restore underground capitals  
