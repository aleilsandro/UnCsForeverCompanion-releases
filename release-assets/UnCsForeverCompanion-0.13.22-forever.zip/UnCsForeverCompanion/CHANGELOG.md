# UnCs Forever Companion

## [0.13.22](https://github.com/aleilsandro/UnCsForeverCompanion/tree/0.13.22) (2026-11-22)
[Full Changelog](https://github.com/aleilsandro/UnCsForeverCompanion/compare/0.13.21...0.13.22) [Previous Releases](https://github.com/aleilsandro/UnCsForeverCompanion/releases)

- Merge reliable Pulser updates for 0.13.22  
- Publish complete Pulser releases and add resilient update feeds  
