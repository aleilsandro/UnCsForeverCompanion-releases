'use strict'

const { createHash, randomBytes, randomUUID } = require('node:crypto')
const { mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } = require('node:fs')
const { dirname } = require('node:path')

const guildName = 'Unconscious Clan'
const secret = () => randomBytes(32).toString('base64url')
const digest = value => createHash('sha256').update(value).digest('hex')
const tokenPattern = /^[A-Za-z0-9_-]{43}$/
const hashPattern = /^[a-f0-9]{64}$/
const cookieName = '__Host-uncs-map'
const cookiePattern = new RegExp(`(?:^|;\\s*)${cookieName}=([A-Za-z0-9_-]{43})(?:;|$)`)
const month = 30 * 24 * 60 * 60_000
const pairLifetime = 5 * 60_000
const browserCookie = token => `${cookieName}=${token}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=${12 * month / 1000}`

function accessStore(path) {
  mkdirSync(dirname(path), { recursive: true })
  let state = { invites: {}, pulsers: {}, browsers: {} }
  try {
    const saved = JSON.parse(readFileSync(path, 'utf8'))
    if (!saved.invites || !saved.pulsers || !saved.browsers) throw Error('Archivio accessi non valido')
    state = saved
  } catch (error) { if (error.code !== 'ENOENT') throw error }
  const pending = new Map()

  function change(edit) {
    const copy = structuredClone(state)
    edit(copy)
    const temp = path + '.' + randomUUID() + '.tmp'
    try {
      writeFileSync(temp, JSON.stringify(copy), { mode: 0o600, flag: 'wx' })
      renameSync(temp, path)
      state = copy
    } finally { rmSync(temp, { force: true }) }
  }
  function invite(now = Date.now()) {
    const token = secret(), expires = now + 7 * 24 * 60 * 60_000
    change(draft => {
      for (const [key, expiry] of Object.entries(draft.invites)) if (expiry <= now) delete draft.invites[key]
      if (Object.keys(draft.invites).length >= 250) throw Error('Troppi inviti in attesa')
      draft.invites[digest(token)] = expires
    })
    return { token, expires, reference: digest(token).slice(0, 8) }
  }
  function activate(id, token, now = Date.now()) {
    if (!hashPattern.test(id) || !tokenPattern.test(token) || state.pulsers[id]) return null
    const key = digest(token)
    if (!(state.invites[key] > now) || Object.keys(state.pulsers).length >= 300) return null
    const browserToken = secret()
    change(draft => {
      delete draft.invites[key]
      draft.pulsers[id] = { id, source: randomUUID(), reference: key.slice(0, 8), added: now }
      draft.browsers[digest(browserToken)] = { owner: id, id: randomUUID(), label: 'Browser di attivazione', added: now, expires: now + 12 * month }
    })
    return browserCookie(browserToken)
  }
  function pulser(authorization) {
    const token = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(authorization ?? '')?.[1]
    return token && state.pulsers[digest(token)]
  }
  function session(cookie, now = Date.now()) {
    const token = cookiePattern.exec(cookie ?? '')?.[1]
    const key = token && digest(token)
    const browser = key && state.browsers[key]
    return browser && browser.expires > now && state.pulsers[browser.owner] ? key : null
  }
  function sessionOwner(cookie) {
    const key = session(cookie)
    return key ? state.browsers[key].owner : undefined
  }
  function pair(owner, label, now = Date.now()) {
    for (const [key, value] of pending) if (value.expires <= now) pending.delete(key)
    const waiting = [...pending].filter(([, value]) => value.owner === owner)
    if (waiting.length >= 5) pending.delete(waiting[0][0])
    const token = secret()
    pending.set(digest(token), { owner, label, expires: now + pairLifetime })
    return token
  }
  function redeem(token, cookie, now = Date.now()) {
    if (typeof token !== 'string' || !tokenPattern.test(token)) return null
    const key = digest(token), pairing = pending.get(key)
    if (!pairing || pairing.expires <= now || !state.pulsers[pairing.owner]) return null
    const previous = session(cookie, now)
    if (previous && state.browsers[previous].owner === pairing.owner) {
      pending.delete(key)
      return { alreadyPaired: true }
    }
    const browserToken = secret()
    change(draft => {
      for (const [key, device] of Object.entries(draft.browsers)) if (device.expires <= now) delete draft.browsers[key]
      if (Object.values(draft.browsers).filter(device => device.owner === pairing.owner).length >= 16) throw Error('Troppi browser abbinati')
      if (previous) delete draft.browsers[previous]
      draft.browsers[digest(browserToken)] = { owner: pairing.owner, id: randomUUID(), label: pairing.label, added: now, expires: now + 12 * month }
    })
    pending.delete(key)
    return { cookie: browserCookie(browserToken) }
  }
  function devices(owner, now = Date.now()) {
    return Object.values(state.browsers)
      .filter(device => device.owner === owner && device.expires > now)
      .map(({ id, label, added }) => ({ id, label, added }))
  }
  function revoke(owner, id) {
    const match = Object.entries(state.browsers).find(([, device]) => device.owner === owner && device.id === id)
    if (!match) return null
    change(draft => { delete draft.browsers[match[0]] })
    return match[0]
  }
  function namePublisher(id, name) {
    if (!state.pulsers[id].name) change(draft => { draft.pulsers[id].name = name })
  }
  function publishers() {
    return Object.values(state.pulsers).map(({ id, reference, added, name }) => ({ id, reference, added, name }))
  }
  function revokePublisher(id) {
    if (typeof id !== 'string' || !hashPattern.test(id) || !state.pulsers[id]) return null
    const source = state.pulsers[id].source
    change(draft => {
      delete draft.pulsers[id]
      for (const [key, browser] of Object.entries(draft.browsers)) if (browser.owner === id) delete draft.browsers[key]
    })
    return source
  }
  return { invite, activate, pulser, pair, redeem, session, sessionOwner, devices, revoke, namePublisher, publishers, revokePublisher }
}

const pairingScript = `
const token = location.hash.slice(1)
history.replaceState(null, '', '/abbina')
if (token) {
  fetch('/access/redeem', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) })
    .then(r => { if (!r.ok) throw Error(); location.replace('/') })
    .catch(() => { document.querySelector('p').textContent = 'Link scaduto o già usato. Generane uno nuovo dalla tray del Pulser.' })
} else document.querySelector('p').textContent = 'Apri il link generato dalla tray del Pulser.'
`
function accessPage(title, text, body = '') {
  return `<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${title} · UnCs</title><style>
    body{min-height:100vh;margin:0;display:grid;place-items:center;background:#0b1c34;color:#f6edda;font:16px system-ui}
    main{width:min(28rem,calc(100vw - 5rem));padding:2rem;border:1px solid #cba969;background:#122842;border-radius:6px}
    h1{color:#edca82;font:2rem Georgia}p{line-height:1.5}label,input,button{display:block;margin-top:1rem}input{box-sizing:border-box;width:100%;padding:.6rem}button{padding:.6rem 1rem;background:#edca82;border:0;font:inherit;color:#14243a}a{color:#edca82}
    </style><main><h1>${title}</h1><p>${text}</p>${body}</main></html>`
}

module.exports = { accessStore, accessPage, pairingScript, hashPattern, guildName }
