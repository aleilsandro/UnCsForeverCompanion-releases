'use strict'

const assert = require('node:assert/strict')
const { test } = require('node:test')
const { mkdtemp, rm, writeFile } = require('node:fs/promises')
const { join } = require('node:path')
const { tmpdir } = require('node:os')
const { pulserReleases } = require('./pulser-release.cjs')

const installer = version => `UnCs-Forever-Web-Setup-${version}.exe`
const manifest = (version, size = 200) => `version: ${version}\nfiles:\n  - url: ${installer(version)}\n    size: ${size}\npath: ${installer(version)}\nsha512: ${'A'.repeat(86)}==\n`
const release = (version, size = 200, draft = false) => ({
  tag_name: version, draft,
  assets: [{ name: installer(version), state: 'uploaded', size }, { name: 'pulser-latest.yml', state: 'uploaded' }],
})

test('serves the highest verified release and falls back past a broken or incomplete candidate', async t => {
  const folder = await mkdtemp(join(tmpdir(), 'pulser-releases-'))
  t.after(() => rm(folder, { recursive: true, force: true }))
  await writeFile(join(folder, 'latest.yml'), manifest('0.13.17'))
  t.mock.method(globalThis, 'fetch', async url => {
    if (url.startsWith('https://api.github.com/')) return Response.json([
      release('0.13.21'), release('0.13.22'), release('0.13.23', 999),
      release('0.13.24', 200, true),
    ])
    assert.doesNotMatch(url, /0\.13\.24/)
    return new Response(manifest(/\/download\/(\d+\.\d+\.\d+)\//.exec(url)[1]))
  })
  const get = await pulserReleases(folder)
  const result = await get()
  assert.equal(result.version, '0.13.22')
  assert.match(result.url, /\/0\.13\.22\/UnCs-Forever-Web-Setup-0\.13\.22\.exe$/)
  assert.equal((await get()).version, '0.13.22')
})
