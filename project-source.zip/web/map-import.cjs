'use strict'
const { randomUUID, createHash, timingSafeEqual } = require('node:crypto')
const { createWriteStream } = require('node:fs')
const { mkdir, readFile, readdir, rename, rm, stat, writeFile } = require('node:fs/promises')
const { dirname, join } = require('node:path')
const { Transform } = require('node:stream')
const { pipeline } = require('node:stream/promises')

const mapFiles = /^\/(?:openmap\/(?:(?:manifest|maps|detail|native|city|city-mini|banners|dungeon-status|alignment)\.json|overview\.png|(?:base|banner|city-mini|native)\/\d+\.png|detail\/[01]_4_\d+_\d+\.png|\d+_\d+\.png)|tiles\/(?:interiors\.json|rooms\/\d+\.dxt|i\d+\/(?:blocks\/\d+\/\d+\.dxt|\d+\/\d+\/\d+\.png)))$/
const folderId = /^[a-f0-9-]{36}$/
const fileLimit = 32 * 1024 * 1024
const batchLimit = 1500 * 1024 * 1024

async function mapImport(root, loginHash) {
  if (loginHash && !/^[a-f0-9]{64}$/i.test(loginHash)) throw Error('Hash dell’amministratore della mappa non valido')
  const authorized = loginHash ? Buffer.from(loginHash, 'hex') : null
  if (authorized && !root) throw Error('Cartella import non configurata')
  const pointer = root && join(root, 'active.txt')
  const readPointer = async () => {
    if (!pointer) return null
    try {
      const id = (await readFile(pointer, 'utf8')).trim()
      return folderId.test(id) ? join(root, id) : null
    } catch (error) {
      if (error.code !== 'ENOENT') throw error
      return null
    }
  }
  let active = await readPointer()
  let current
  const matchRoute = /^\/map-import(?:\/([a-f0-9-]{36})(\/.*)?)?$/
  function isAdmin(req) {
    const login = req.headers['tailscale-user-login']
    return !!authorized && !req.headers.origin && typeof login === 'string' &&
      timingSafeEqual(createHash('sha256').update(login.trim().toLowerCase()).digest(), authorized)
  }
  async function handle(req, res, pathname, send) {
    const matched = matchRoute.exec(pathname)
    if (!matched) return false
    if (!isAdmin(req)) { send(res, 403, {}); return true }
    const [, id, name] = matched
    if (!id && req.method === 'GET') { send(res, 200, { configured: !!active }); return true }
    if (!id && req.method === 'POST') {
      if (current && !current.busy && Date.now() - current.touched > 10 * 60 * 1000) {
        current.busy = true
        try { await rm(join(root, current.id), { recursive: true, force: true }); current = undefined }
        finally { if (current) current.busy = false }
      }
      if (current) { send(res, 409, {}); return true }
      const batch = { id: randomUUID(), total: 0, files: new Set(), busy: true, touched: Date.now() }
      current = batch
      try {
        const stored = await readdir(root, { withFileTypes: true })
        if (stored.filter(entry => entry.isDirectory() && folderId.test(entry.name)).length >= 3) {
          current = undefined
          send(res, 507, { error: 'Sono già presenti tre importazioni. Liberare spazio sul server prima di caricarne un’altra.' })
          return true
        }
        await mkdir(join(root, batch.id))
      } catch (error) { current = undefined; throw error }
      batch.busy = false
      send(res, 201, { id: batch.id })
      return true
    }
    if (!current || id !== current.id || current.busy) { send(res, 409, {}); return true }
    const batch = current
    const dir = join(root, id)
    batch.busy = true
    try {
      if (req.method === 'DELETE' && !name) {
        await rm(dir, { recursive: true, force: true })
        current = undefined
        send(res, 200, {})
      } else if (req.method === 'PUT' && name && mapFiles.test(name)) {
        if (batch.files.has(name)) { send(res, 409, { error: `File già caricato: ${name}` }); return true }
        const length = Number(req.headers['content-length'])
        if (!Number.isInteger(length) || length <= 0 || length > fileLimit || batch.total + length > batchLimit || batch.files.size >= 20000) {
          send(res, 413, {})
          return true
        }
        const target = join(dir, name.slice(1))
        await mkdir(dirname(target), { recursive: true })
        let bytes = 0
        const check = new Transform({
          transform(chunk, _encoding, done) {
            bytes += chunk.length
            done(bytes > length ? Error('Dimensione imprevista') : null, chunk)
          },
        })
        const partial = target + '.upload'
        try {
          await pipeline(req, check, createWriteStream(partial, { flags: 'wx' }))
          if (bytes !== length) throw Error('File incompleto')
          await rename(partial, target)
        } finally { await rm(partial, { force: true }).catch(() => {}) }
        batch.total += bytes
        batch.files.add(name)
        send(res, 200, {})
      } else if (req.method === 'POST' && !name) {
        const manifest = await readFile(join(dir, 'openmap', 'manifest.json'), 'utf8').then(JSON.parse).catch(() => null)
        if (!Array.isArray(manifest) || !manifest.length || manifest.length > 10000 || manifest.some(pair =>
          !Array.isArray(pair) || pair.length !== 2 || pair.some(n => !Number.isInteger(n) || n < 0 || n > 99))) {
          send(res, 422, { error: 'Manifesto mondo mancante o non valido' })
          return true
        }
        for (const [x, y] of manifest) {
          const tile = await stat(join(dir, 'openmap', `${x}_${y}.png`)).catch(() => null)
          if (!tile?.isFile()) { send(res, 422, { error: `Tessera mancante: ${x}_${y}.png` }); return true }
        }
        const next = join(root, `active-${id}.tmp`)
        try {
          await writeFile(next, id, { flag: 'wx' })
          await rename(next, pointer)
        } finally { await rm(next, { force: true }).catch(() => {}) }
        active = dir
        current = undefined
        send(res, 200, { files: batch.files.size, bytes: batch.total })
      } else send(res, 405, {})
    } finally { batch.busy = false; batch.touched = Date.now() }
    return true
  }
  return { active: () => active, handle, isAdmin }
}
module.exports = { mapFiles, mapImport }
