'use strict'

const assert = require('node:assert/strict')
const { once } = require('node:events')
const { createHash, randomBytes, randomUUID } = require('node:crypto')
const { spawn } = require('node:child_process')
const { mkdtemp, readFile, rm, writeFile } = require('node:fs/promises')
const { createServer } = require('node:net')
const { tmpdir } = require('node:os')
const { join } = require('node:path')
const { test } = require('node:test')
const { accessStore } = require('./access.cjs')

const hash = value => createHash('sha256').update(value).digest('hex')
const secret = () => randomBytes(32).toString('base64url')
const browserCookie = value => value.split(';')[0]

test('invites and browser links expire, and only the owner can revoke a persistent browser', async t => {
  const root = await mkdtemp(join(tmpdir(), 'uncs-access-'))
  t.after(() => rm(root, { recursive: true, force: true }))
  const filename = join(root, 'access.json')
  const store = accessStore(filename)
  const invite = store.invite(100)
  const token = secret(), owner = hash(token)
  assert.equal(store.activate(owner, invite.token, invite.expires), null)
  assert.ok(store.activate(owner, invite.token, 101))
  assert.equal(store.activate(hash(secret()), invite.token, 102), null)
  assert.equal(store.pulser('Bearer ' + token).id, owner)

  const pair = store.pair(owner, 'Telefono', 500)
  assert.equal(store.redeem(pair, null, 300_500), null)
  const link = store.pair(owner, 'Altro PC', 800)
  const paired = store.redeem(link, null, 801)
  assert.equal(store.redeem(link, null, 802), null)
  const cookie = browserCookie(paired.cookie)
  const repeated = store.pair(owner, 'Altro PC', 803)
  assert.deepEqual(store.redeem(repeated, cookie, 804), { alreadyPaired: true })
  const restored = accessStore(filename)
  assert.ok(restored.session(cookie, 810))
  const device = restored.devices(owner, 810).find(device => device.label === 'Altro PC')
  assert.equal(restored.revoke(hash(secret()), device.id), null)
  assert.ok(restored.revoke(owner, device.id))
  assert.equal(restored.session(cookie, 811), null)
  const persisted = await readFile(filename, 'utf8')
  assert.ok(!persisted.includes(token) && !persisted.includes(invite.token) && !persisted.includes(link))
})

test('the public listener protects the map, and only an activated Pulser in the configured guild can publish', { timeout: 15_000 }, async t => {
  async function getPort() {
    const socket = createServer().listen(0, '127.0.0.1')
    await once(socket, 'listening')
    const { port } = socket.address()
    await new Promise(resolve => socket.close(resolve))
    return port
  }
  const localPort = await getPort()
  let publicPort = await getPort()
  while (localPort === publicPort) publicPort = await getPort()
  const root = await mkdtemp(join(tmpdir(), 'uncs-pairing-'))
  await writeFile(join(root, 'index.html'), '<main>Cartografia di prova</main>')
  const publicOrigin = 'https://mappa.test:10000'
  const admin = 'owner@example.test'
  const child = spawn(process.execPath, [join(__dirname, 'server.cjs')], {
    env: { ...process.env, UNCS_WEB_PORT: localPort, UNCS_WEB_PUBLIC_PORT: publicPort,
      UNCS_WEB_PUBLIC_ORIGIN: publicOrigin, UNCS_WEB_BRIDGE: '1', UNCS_WEB_RENDERER: root,
      UNCS_WEB_MAP_IMPORT_ROOT: root, UNCS_WEB_MAP_ADMIN: hash(admin), UNCS_WEB_ACCESS_FILE: join(root, 'access.json'),
      UNCS_WEB_BRIDGE_RELEASES: '', UNCS_WEB_MAP_ROOT: '', UNCS_WEB_PUBLISH_KEY: '' },
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  const exited = once(child, 'exit')
  t.after(async () => {
    child.kill()
    await exited
    await rm(root, { recursive: true, force: true })
  })
  let output = ''
  child.stdout.on('data', data => { output += data })
  child.stderr.on('data', data => { output += data })
  for (let i = 0; i < 100 && !output.includes(`127.0.0.1:${publicPort}`) && child.exitCode === null; i++) {
    await new Promise(resolve => setTimeout(resolve, 20))
  }
  assert.match(output, new RegExp(`127.0.0.1:${publicPort}`))
  const publicUrl = `http://127.0.0.1:${publicPort}`
  const privateUrl = `http://127.0.0.1:${localPort}`
  const read = (url, headers) => fetch(url, { headers, signal: AbortSignal.timeout(2500) })
  const post = (url, body, headers) => fetch(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify(body), signal: AbortSignal.timeout(2500),
  })
  assert.match(await (await read(publicUrl + '/')).text(), /Abbina|abbina/)
  assert.equal((await read(publicUrl + '/events')).status, 401)
  assert.equal((await read(publicUrl + '/openmap/manifest.json')).status, 401)
  const adminHeaders = { 'tailscale-user-login': admin }
  assert.equal((await post(publicUrl + '/access/invite', {}, adminHeaders)).status, 401)
  assert.equal((await post(privateUrl + '/access/invite', {})).status, 403)
  const response = await post(privateUrl + '/access/invite', {}, adminHeaders)
  assert.equal(response.status, 200)
  const invite = (await response.json()).token
  const token = secret(), id = hash(token)
  const activationPage = await read(publicUrl + '/attiva/' + id)
  assert.equal(activationPage.headers.get('referrer-policy'), 'same-origin')
  const activate = origin => fetch(publicUrl + '/access/activate', {
    method: 'POST', redirect: 'manual', headers: { origin, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ id, invite }), signal: AbortSignal.timeout(2500),
  })
  assert.equal((await activate('https://other.test')).status, 403)
  assert.equal((await activate('null')).status, 403)
  const activation = await activate(publicOrigin)
  assert.equal(activation.status, 303)
  assert.match(activation.headers.get('set-cookie'), /Secure; HttpOnly; SameSite=Lax/)
  assert.equal((await activate(publicOrigin)).status, 403)
  const authorization = 'Bearer ' + token
  const legacyLogin = { 'tailscale-user-login': 'legacy@example.test' }
  const point = { source: randomUUID(), name: 'Alberto', level: 60, pos: { wx: 100, wy: 200, ww: 1002, wh: 668, facing: 135 },
    flights: { side: 'A', known: [12], checked: [0] } }
  assert.equal((await post(publicUrl + '/bridge/publish', point, legacyLogin)).status, 401)
  assert.equal((await post(publicUrl + '/bridge/publish', { ...point, guild: 'Altra gilda' }, { authorization })).status, 403)
  assert.equal((await post(publicUrl + '/bridge/publish', { ...point, guild: 'Unconscious Clan' }, { authorization })).status, 200)
  assert.equal((await post(privateUrl + '/bridge/publish', { ...point, name: 'SoloPrivato' }, legacyLogin)).status, 200)
  const privateStream = await read(privateUrl + '/events')
  const privateReader = privateStream.body.getReader()
  try {
    let frame = ''
    while (!frame.includes('event: link')) frame += Buffer.from((await privateReader.read()).value).toString()
    assert.match(frame, /Alberto/)
    assert.match(frame, /SoloPrivato/)
    assert.doesNotMatch(frame, /"flights":/)
  } finally { await privateReader.cancel() }
  const pairing = await post(publicUrl + '/access/pair', { label: 'Secondo PC' }, { authorization })
  const oneTime = (await pairing.json()).token
  const redemption = await post(publicUrl + '/access/redeem', { token: oneTime }, { origin: publicOrigin })
  assert.equal(redemption.status, 200)
  const cookie = browserCookie(redemption.headers.get('set-cookie'))
  assert.equal((await post(publicUrl + '/access/redeem', { token: oneTime }, { origin: publicOrigin })).status, 403)
  assert.match(await (await read(publicUrl + '/', { cookie })).text(), /Cartografia di prova/)
  const stream = await read(publicUrl + '/events', { cookie })
  const reader = stream.body.getReader()
  try {
    let frame = ''
    while (!frame.includes('event: link')) frame += Buffer.from((await reader.read()).value).toString()
    assert.match(frame, /Alberto/)
    assert.match(frame, /"facing":135/)
    assert.match(frame, /"flights":\{"side":"A","known":\[12\],"checked":\[0\]\}/)
    assert.doesNotMatch(frame, /SoloPrivato/)
    const { devices } = await (await read(publicUrl + '/access/devices', { authorization })).json()
    const device = devices.find(value => value.label === 'Secondo PC')
    assert.equal((await post(publicUrl + '/access/revoke', { id: device.id }, { authorization })).status, 200)
    await assert.rejects(reader.read())
    assert.equal((await read(publicUrl + '/events', { cookie })).status, 401)
  } finally { await reader.cancel().catch(() => {}) }
  assert.equal((await post(privateUrl + '/access/remove-pulser', { id }, adminHeaders)).status, 200)
  assert.equal((await read(publicUrl + '/access/devices', { authorization })).status, 401)
})
