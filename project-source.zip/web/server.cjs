'use strict'
const http = require('node:http')
const { createReadStream } = require('node:fs')
const { realpath, stat } = require('node:fs/promises')
const { extname, join, resolve, relative, isAbsolute, sep } = require('node:path')
const { pipeline } = require('node:stream/promises')
const { createHash, timingSafeEqual } = require('node:crypto')
const { bridgeSources } = require('./bridge-sources.cjs')
const { mapFiles, mapImport } = require('./map-import.cjs')
const { pulserReleases } = require('./pulser-release.cjs')
const { accessStore, accessPage, pairingScript, hashPattern, guildName } = require('./access.cjs')

const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  '.json': 'application/json', '.yml': 'application/yaml; charset=utf-8',
  '.dxt': 'application/octet-stream', '.exe': 'application/octet-stream', '.zip': 'application/zip',
}
const assets = /^\/assets\/[a-z0-9._-]+\.(?:js|css|svg|png|woff2?|ttf)$/i

async function start() {
  const port = Number(process.env.UNCS_WEB_PORT || 8796)
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw Error('UNCS_WEB_PORT non valida')
  const renderer = await realpath(process.env.UNCS_WEB_RENDERER || resolve(__dirname, '../desktop/out/renderer'))
  await stat(join(renderer, 'index.html'))
  const mapRoot = process.env.UNCS_WEB_MAP_ROOT ? await realpath(process.env.UNCS_WEB_MAP_ROOT) : null
  const importRoot = process.env.UNCS_WEB_MAP_IMPORT_ROOT ? await realpath(process.env.UNCS_WEB_MAP_IMPORT_ROOT) : null
  const importer = await mapImport(importRoot, process.env.UNCS_WEB_MAP_ADMIN)
  const bridgeEnabled = process.env.UNCS_WEB_BRIDGE === '1'
  const bridgeReleaseRoot = process.env.UNCS_WEB_BRIDGE_RELEASES ? await realpath(process.env.UNCS_WEB_BRIDGE_RELEASES) : null
  const latestPulser = await pulserReleases(bridgeReleaseRoot)
  const bridge = bridgeSources()
  const publicBridge = bridgeSources()
  const accessPath = process.env.UNCS_WEB_ACCESS_FILE || (bridgeEnabled && port === 8796 && importRoot && join(importRoot, 'pulser-access.json'))
  const access = accessPath ? accessStore(accessPath) : null
  const publicPort = Number(process.env.UNCS_WEB_PUBLIC_PORT || 8797)
  const publicOrigin = new URL(process.env.UNCS_WEB_PUBLIC_ORIGIN || 'https://uncs-server.tail1b66eb.ts.net:10000').origin
  if (access && (!bridgeEnabled || !Number.isInteger(publicPort) || publicPort < 1024 || publicPort > 65535 || publicPort === port || !publicOrigin.startsWith('https://'))) throw Error('Configurazione accesso pubblico non valida')
  const version = process.env.UNCS_WEB_VERSION || require('../desktop/package.json').version
  const key = process.env.UNCS_WEB_PUBLISH_KEY
  if (key && key.length < 32) throw Error('Chiave di pubblicazione troppo corta')
  const hash = value => createHash('sha256').update(value).digest()
  const publisher = key ? hash(`Bearer ${key}`) : null
  const viewers = new Map()
  let lastLink, lastUpload = 0, expires
  const setup = {
    gameFolder: 'server', version, addon: null, questie: false, shortestPath: false,
    done: true, onTop: false, webPublishing: !!publisher && !bridgeEnabled, webBridge: bridgeEnabled,
  }
  const headers = {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; frame-ancestors 'none'; base-uri 'none'; object-src 'none'; form-action 'self'",
  }
  function send(res, status, value) {
    res.writeHead(status, { ...headers, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' })
    res.end(JSON.stringify(value))
  }
  function html(req, res, status, body) {
    res.writeHead(status, { ...headers, 'Content-Type': types['.html'], 'Cache-Control': 'no-store' })
    res.end(req.method === 'HEAD' ? undefined : body)
  }
  async function smallBody(req) {
    let size = 0
    const chunks = []
    for await (const chunk of req) {
      size += chunk.length
      if (size > 16 * 1024) { req.destroy(); return null }
      chunks.push(chunk)
    }
    return Buffer.concat(chunks).toString('utf8')
  }
  async function jsonBody(req) {
    if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) return null
    try { return JSON.parse(await smallBody(req)) } catch { return null }
  }
  async function file(req, res, root, name, cache) {
    let target, info
    try {
      target = await realpath(join(root, name))
      const rel = relative(root, target)
      if (!rel || rel === '..' || rel.startsWith('..' + sep) || isAbsolute(rel)) return send(res, 404, {})
      info = await stat(target)
    } catch (error) {
      if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return send(res, 404, {})
      throw error
    }
    if (!info.isFile()) return send(res, 404, {})
    res.writeHead(200, { ...headers, 'Content-Type': types[extname(name).toLowerCase()], 'Content-Length': info.size, 'Cache-Control': cache })
    if (req.method === 'HEAD') return res.end()
    await pipeline(createReadStream(target), res)
  }
  function broadcast(publicView = false) {
    const frame = `id: ${Date.now()}\nevent: link\ndata: ${JSON.stringify(publicView ? publicBridge.snapshot() : lastLink)}\n\n`
    for (const [viewer, browser] of viewers) {
      if ((browser !== null) !== publicView) continue
      if ((browser && !access.session(browser.cookie)) || !viewer.write(frame)) viewer.destroy()
    }
  }
  function broadcastBridge() {
    lastLink = bridge.snapshot()
    broadcast()
  }
  if (bridgeEnabled) setInterval(() => {
    const now = Date.now()
    if (bridge.prune(now)) broadcastBridge()
    if (access && publicBridge.prune(now)) broadcast(true)
  }, 1000).unref()
  async function publicAccess(req, res, url) {
    const path = url.pathname, read = req.method === 'GET' || req.method === 'HEAD'
    const sameOrigin = req.headers.origin === publicOrigin
    const activation = /^\/attiva\/([a-f0-9]{64})$/.exec(path)
    if (activation && read) {
      const form = `<form method="post" action="/access/activate"><input type="hidden" name="id" value="${activation[1]}"><label for="invite">Codice d’invito della gilda</label><input id="invite" name="invite" required maxlength="43" autocomplete="off" spellcheck="false"><button>Attiva Pulser</button></form>`
      return html(req, res, 200, accessPage('Attiva UnCs Pulser', 'Inserisci il codice ricevuto da un officer della gilda.', form))
    }
    if (path === '/abbina' && read) return html(req, res, 200, accessPage('Abbina il browser', 'Abbinamento in corso…', '<script src="/access/pair.js" defer></script>'))
    if (path === '/access/pair.js' && read) {
      res.writeHead(200, { ...headers, 'Content-Type': types['.js'], 'Cache-Control': 'no-store' })
      return res.end(req.method === 'HEAD' ? undefined : pairingScript)
    }
    if (path === '/access/status' && read) return send(res, 200, { pairing: true })
    if (path === '/access/activate' && req.method === 'POST') {
      if (!sameOrigin || !/^application\/x-www-form-urlencoded(?:;|$)/i.test(req.headers['content-type'] || '')) return send(res, 403, {})
      const input = new URLSearchParams(await smallBody(req))
      const cookie = access.activate(input.get('id'), (input.get('invite') ?? '').trim())
      if (!cookie) {
        return html(req, res, 403, accessPage('Invito non valido', 'Controlla il codice o richiedine uno nuovo a un officer.',
          hashPattern.test(input.get('id')) ? `<a href="/attiva/${input.get('id')}">Riprova</a>` : ''))
      }
      res.writeHead(303, { ...headers, Location: '/', 'Cache-Control': 'no-store', 'Set-Cookie': cookie })
      return res.end()
    }
    if (path === '/access/redeem' && req.method === 'POST') {
      if (!sameOrigin) return send(res, 403, {})
      const result = access.redeem((await jsonBody(req))?.token, req.headers.cookie)
      if (!result) return send(res, 403, {})
      if (result.cookie) res.setHeader('Set-Cookie', result.cookie)
      return send(res, 200, {})
    }
    if (!['/access/devices', '/access/pair', '/access/revoke', '/bridge/publish'].includes(path)) return false
    const publisher = !req.headers.origin && access.pulser(req.headers.authorization)
    if (!publisher) return send(res, 401, {})
    if (path === '/access/devices' && read) return send(res, 200, { devices: access.devices(publisher.id) })
    if (req.method !== 'POST') return send(res, 405, {})
    const data = await jsonBody(req)
    if (access.pulser(req.headers.authorization)?.source !== publisher.source) return send(res, 401, {})
    if (!data || typeof data !== 'object' || Array.isArray(data)) return send(res, 400, {})
    if (path === '/access/pair') {
      const label = typeof data.label === 'string' ? data.label.trim().slice(0, 48) : ''
      const token = access.pair(publisher.id, label || 'Browser abbinato')
      return send(res, 200, { token })
    }
    if (path === '/access/revoke') {
      const revoked = access.revoke(publisher.id, data.id)
      if (!revoked) return send(res, 404, {})
      for (const [viewer, browser] of viewers) if (browser?.id === revoked) viewer.destroy()
      return send(res, 200, {})
    }
    if (data.stopped !== true && data.guild !== guildName) return send(res, 403, {})
    const status = publicBridge.update(publisher.id, { ...data, source: publisher.source })
    if (status === 200) {
      if (data.stopped !== true) access.namePublisher(publisher.id, data.name)
      broadcast(true)
    }
    return send(res, status, {})
  }
  async function bridgePublish(req, res) {
    if (!bridgeEnabled) return send(res, 404, {})
    const login = req.headers['tailscale-user-login']
    if (typeof login !== 'string' || !login || login.length > 256 || req.headers.origin) return send(res, 403, {})
    if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) return send(res, 415, {})
    const chunks = []
    let size = 0
    for await (const chunk of req) {
      size += chunk.length
      if (size > 16 * 1024) return res.destroy()
      chunks.push(chunk)
    }
    let data
    try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')) } catch { return send(res, 400, {}) }
    const status = bridge.update(login, data)
    if (status === 200) broadcastBridge()
    return send(res, status, {})
  }
  async function publish(req, res) {
    if (!publisher || bridgeEnabled) return send(res, 404, {})
    if (!timingSafeEqual(hash(req.headers.authorization || ''), publisher)) return send(res, 401, {})
    if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) return send(res, 415, {})
    if (Date.now() - lastUpload < 500) return send(res, 429, {})
    const max = 96 * 1024
    const chunks = []
    let size = 0
    for await (const chunk of req) {
      size += chunk.length
      if (size > max) return res.destroy()
      chunks.push(chunk)
    }
    let data
    try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')) } catch { return send(res, 400, {}) }
    const { pos, guild, geometry, guildAge } = data || {}
    const worldPoint = pos && [pos.wx, pos.wy].every(n => Number.isFinite(n) && n >= 0 && n <= 100000)
    if (!worldPoint || ![pos.ww, pos.wh].every(n => Number.isFinite(n) && n > 0 && n < 10000)) return send(res, 400, {})
    lastUpload = Date.now()
    const sections = { pos, geometry }
    const updatedAt = { pos: lastUpload }
    if (Array.isArray(guild?.list) && Number.isFinite(guildAge) && guildAge >= 0 && guildAge <= 60000) {
      sections.guild = guild
      updatedAt.guild = lastUpload - guildAge
    }
    lastLink = { game: 'open', seconds: 0, reads: 0, cpu: 0, state: { sections, updatedAt, protocol: null, blocks: 0, lost: 0, corrupt: 0 } }
    broadcast()
    clearTimeout(expires)
    expires = setTimeout(() => {
      lastLink = { ...lastLink, game: 'closed', state: { ...lastLink.state, sections: {}, updatedAt: {} } }
      broadcast()
    }, 25000)
    return send(res, 200, {})
  }
  async function serve(req, res, publicView) {
    try {
      const url = new URL(req.url, 'http://localhost'), { pathname } = url
      let browser = null
      if (publicView) {
        if (pathname === '/map-import' || pathname.startsWith('/map-import/') || pathname === '/publish') return send(res, 404, {})
        if ((pathname.startsWith('/access/') || pathname.startsWith('/attiva/') || pathname === '/abbina' || pathname === '/bridge/publish') &&
          await publicAccess(req, res, url) !== false) return
        const id = access.session(req.headers.cookie)
        if (id) browser = { id, cookie: req.headers.cookie }
        else if (pathname === '/') return html(req, res, 200, accessPage('Mappa UnCs', 'Apri la mappa dalla tray del Pulser oppure abbina questo browser con il QR o il link monouso.'))
        else if (!pathname.startsWith('/bridge/releases/') && pathname !== '/healthz') return send(res, 401, {})
      } else if (pathname === '/access/invite' || pathname === '/access/publishers' || pathname === '/access/remove-pulser') {
        if (!access || !importer.isAdmin(req)) return send(res, 403, {})
        if (pathname === '/access/invite' && req.method === 'POST') return send(res, 200, access.invite())
        if (pathname === '/access/publishers' && req.method === 'GET') return send(res, 200, { publishers: access.publishers() })
        if (pathname === '/access/remove-pulser' && req.method === 'POST') {
          const id = (await jsonBody(req))?.id, source = access.revokePublisher(id)
          if (!source) return send(res, 404, {})
          publicBridge.update(id, { source, stopped: true })
          broadcast(true)
          return send(res, 200, {})
        }
        return send(res, 405, {})
      }
      if (pathname === '/map-import' || pathname.startsWith('/map-import/')) {
        if (!await importer.handle(req, res, pathname, send)) send(res, 404, {})
        return
      }
      if (req.method === 'POST' && pathname === '/bridge/publish') return await bridgePublish(req, res)
      if (req.method === 'POST' && pathname === '/publish') return await publish(req, res)
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, {})
      if (pathname === '/healthz') return send(res, 200, { service: 'uncs-forever-web', version, mapConfigured: !!(importer.active() ?? mapRoot) })
      if (pathname === '/events') {
        if (req.method === 'HEAD') return res.writeHead(200, { ...headers, 'Content-Type': 'text/event-stream' }).end()
        if (viewers.size >= 100) return send(res, 503, {})
        res.writeHead(200, { ...headers, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store' })
        res.write(`event: setup\ndata: ${JSON.stringify(setup)}\n\n`)
        const current = publicView ? publicBridge.snapshot() : lastLink
        if (current) res.write(`id: ${Date.now()}\nevent: link\ndata: ${JSON.stringify(current)}\n\n`)
        viewers.set(res, browser)
        const heartbeat = setInterval(() => {
          if ((browser && !access.session(browser.cookie)) || !res.write(': heartbeat\n\n')) res.destroy()
        }, 25000)
        res.once('close', () => {
          clearInterval(heartbeat)
          viewers.delete(res)
        })
        return
      }
      if (pathname === '/') return await file(req, res, renderer, 'index.html', 'no-store')
      const release = /^\/bridge\/releases\/(latest\.yml|UnCs-Pulser-Setup\.exe|UnCs-Forever-Web-Setup-[0-9]+\.[0-9]+\.[0-9]+\.exe|UnCsForeverCompanion-source-[0-9]+\.[0-9]+\.[0-9]+\.zip)$/.exec(pathname)
      if (release && bridgeReleaseRoot) {
        const [, name] = release
        const latest = await latestPulser()
        if (name === 'latest.yml') {
          res.writeHead(200, { ...headers, 'Content-Type': types['.yml'], 'Cache-Control': 'no-store' })
          return res.end(req.method === 'HEAD' ? undefined : latest.manifest)
        }
        if (name === 'UnCs-Pulser-Setup.exe' || (latest.url && name === latest.name)) {
          const target = latest.url ?? `/bridge/releases/${latest.name}`
          return res.writeHead(302, { ...headers, Location: target, 'Cache-Control': 'no-store' }).end()
        }
        return await file(req, res, bridgeReleaseRoot, name, 'private, max-age=86400')
      }
      if (assets.test(pathname)) return await file(req, res, renderer, pathname.slice(1), 'private, max-age=31536000, immutable')
      const activeMap = importer.active() ?? mapRoot
      if (mapFiles.test(pathname) && activeMap) return await file(req, res, activeMap, pathname.slice(1), pathname.endsWith('.json') ? 'no-store' : 'private, max-age=60')
      if (pathname === '/openmap/manifest.json') return send(res, 200, [])
      return send(res, 404, {})
    } catch {
      if (res.headersSent) return res.destroy()
      send(res, 500, {})
    }
  }
  function listen(at, publicView) {
    const server = http.createServer((req, res) => serve(req, res, publicView))
    server.on('error', error => { console.error(error.message); process.exit(1) })
    server.listen(at, '127.0.0.1', () => console.log(`UnCs Forever Web su 127.0.0.1:${at}`))
  }
  listen(port, false)
  if (access) listen(publicPort, true)
}

start().catch(error => { console.error(error.message); process.exitCode = 1 })
