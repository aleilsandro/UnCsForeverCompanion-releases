'use strict'
const assert = require('node:assert/strict')
const { createHash } = require('node:crypto')
const { mkdtemp, readFile, rm } = require('node:fs/promises')
const { createServer } = require('node:http')
const { tmpdir } = require('node:os')
const { join } = require('node:path')
const { test } = require('node:test')
const { mapImport } = require('./map-import.cjs')

test('only the owner can publish a complete map and it survives a new server instance', async t => {
  const root = await mkdtemp(join(tmpdir(), 'uncs-map-'))
  const login = 'map-owner@example.test'
  const hash = createHash('sha256').update(login).digest('hex')
  const importer = await mapImport(root, hash)
  const server = createServer((req, res) => {
    const send = (response, status, value) => {
      response.writeHead(status, { 'Content-Type': 'application/json' })
      response.end(JSON.stringify(value))
    }
    importer.handle(req, res, req.url, send).catch(() => send(res, 500, {}))
  })
  t.after(async () => {
    await new Promise(resolve => server.close(resolve))
    await rm(root, { recursive: true, force: true })
  })
  await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', resolve)
  })
  const url = 'http://127.0.0.1:' + server.address().port + '/map-import'
  const request = (path, method, body, headers = {}) => fetch(url + path, {
    method, body, headers: { 'Tailscale-User-Login': login, ...headers },
  })
  assert.equal((await fetch(url)).status, 403)
  assert.equal((await request('', 'POST', undefined, { Origin: url })).status, 403)
  const created = await request('', 'POST')
  assert.equal(created.status, 201)
  const { id } = await created.json()
  const batch = '/' + id
  assert.equal((await request(batch + '/openmap/manifest.json', 'PUT', '[[0,0]]')).status, 200)
  assert.equal((await request(batch, 'POST')).status, 422)
  assert.equal(importer.active(), null)
  const image = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACklEQVR4nGMAAQAABQABDQottAAAAABJRU5ErkJggg==', 'base64')
  assert.equal((await request(batch + '/openmap/0_0.png', 'PUT', image)).status, 200)
  assert.equal((await request(batch, 'POST')).status, 200)
  const restarted = await mapImport(root, hash)
  assert.deepEqual(await readFile(join(restarted.active(), 'openmap', '0_0.png')), image)

  const replacement = await (await request('', 'POST')).json()
  assert.equal((await request('/' + replacement.id, 'DELETE')).status, 200)
  assert.equal(importer.active(), restarted.active())
})
