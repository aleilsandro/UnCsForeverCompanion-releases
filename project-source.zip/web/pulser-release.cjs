'use strict'
const { readFile } = require('node:fs/promises')
const { join } = require('node:path')

const repository = 'aleilsandro/UnCsForeverCompanion-releases'
const downloadAsset = 'pulser-latest.yml'
const versionPattern = /^\d+\.\d+\.\d+$/

function parseManifest(body) {
  const version = /^version: (\d+\.\d+\.\d+)\s*$/m.exec(body)?.[1]
  if (!version) return null
  const name = `UnCs-Forever-Web-Setup-${version}.exe`
  const path = /^path: (\S+)\s*$/m.exec(body)?.[1]
  const digest = /^sha512: ([A-Za-z0-9+/]{86}==)\s*$/m.exec(body)?.[1]
  const size = Number(/^    size: (\d+)\s*$/m.exec(body)?.[1])
  if (path !== name || !digest || !Number.isSafeInteger(size) || size <= 0) return null
  const manifest = `version: ${version}\nfiles:\n  - url: ${name}\n    sha512: ${digest}\n    size: ${size}\npath: ${name}\nsha512: ${digest}\n`
  return { version, name, manifest }
}

function isNewer(version, previous) {
  const parts = previous.split('.').map(Number)
  for (const [index, part] of version.split('.').map(Number).entries()) {
    if (part !== parts[index]) return part > parts[index]
  }
  return false
}

async function pulserReleases(root) {
  if (!root) return async () => null
  const local = parseManifest(await readFile(join(root, 'latest.yml'), 'utf8'))
  if (!local) throw Error('Manifesto locale del Pulser non valido')
  let latest = local, nextCheck = 0, check
  async function discover() {
    const response = await fetch(`https://api.github.com/repos/${repository}/releases?per_page=10`, {
      signal: AbortSignal.timeout(4500), headers: { 'User-Agent': 'UnCs-Pulser-Releases' },
    })
    if (!response.ok) return
    const releases = await response.json()
    for (const { draft, prerelease, tag_name: tag, assets } of releases) {
      if (draft || prerelease || !versionPattern.test(tag) || !isNewer(tag, latest.version)) continue
      const name = `UnCs-Forever-Web-Setup-${tag}.exe`
      if (!assets.some(asset => asset.name === name) || !assets.some(asset => asset.name === downloadAsset)) continue
      const base = `https://github.com/${repository}/releases/download/${tag}/`
      const manifest = await fetch(base + downloadAsset, { signal: AbortSignal.timeout(4500) })
      if (!manifest.ok) continue
      const release = parseManifest(await manifest.text())
      if (release?.version === tag) latest = { ...release, url: base + name }
      break
    }
  }
  return async () => {
    if (Date.now() >= nextCheck && !check) {
      nextCheck = Date.now() + 5 * 60_000
      check = discover().catch(() => {}).finally(() => { check = undefined })
    }
    await check
    return latest
  }
}

module.exports = { pulserReleases }
