#Requires -Version 7.0
[CmdletBinding()]
param(
    [switch]$InstallShortcut,
    [string]$MapRoot,
    [string]$GameRoot,
    [switch]$Pulser,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$repo = Split-Path -Parent $PSScriptRoot
$desktopProject = Join-Path $repo 'desktop'
$state = Join-Path $repo '.release/local-web'
$mapConfig = Join-Path $state 'map-root.txt'
$port = 18796
$url = "http://127.0.0.1:$port/"
New-Item -Path $state -ItemType Directory -Force | Out-Null

if ($PSBoundParameters.ContainsKey('MapRoot')) {
    $resolved = (Resolve-Path -LiteralPath $MapRoot).ProviderPath
    if (!(Test-Path -LiteralPath (Join-Path $resolved 'openmap/manifest.json') -PathType Leaf)) {
        throw 'Indica la cartella del pacchetto che contiene openmap/manifest.json.'
    }
    Set-Content -LiteralPath $mapConfig -Value $resolved -Encoding utf8NoBOM
}

if ($InstallShortcut) {
    $desktop = [Environment]::GetFolderPath('DesktopDirectory')
    $shortcut = Join-Path $desktop 'UnCs WebCompanion - LOCALE.lnk'
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($shortcut)
    $link.TargetPath = (Get-Process -Id $PID).Path
    $link.Arguments = '-NoProfile -File "' + $PSCommandPath + '"'
    if ($Pulser) { $link.Arguments += ' -Pulser' }
    $link.WorkingDirectory = $repo
    $link.Description = "Avvia la copia locale da questo progetto e apre $url."
    $link.IconLocation = "$env:SystemRoot\System32\shell32.dll,14"
    $link.Save()
    Write-Host "Collegamento locale creato: $shortcut"
    return
}

$node = (Get-Command node.exe -CommandType Application).Source
$major = & $node -p 'Number(process.versions.node.split(".")[0])'
if ($LASTEXITCODE -or [int]$major -lt 24) { throw 'Installa Node.js 24 o superiore prima di avviare la mappa locale.' }

function Read-LocalHealth {
    try { Invoke-RestMethod -Uri "${url}healthz" -TimeoutSec 2 } catch { $null }
}

$lock = $null
$server = $null
$pulserProcess = $null
try {
    try {
        $lock = [IO.File]::Open((Join-Path $state 'server.lock'), 'OpenOrCreate', 'ReadWrite', 'None')
    } catch [IO.IOException] {
        $running = Read-LocalHealth
        if ($running.service -eq 'uncs-forever-web' -and (!$Pulser -or $running.localPulser)) {
            if (!$NoBrowser) { Start-Process $url }
            return
        }
        throw 'La mappa di questo checkout è già in avvio oppure la cartella di lavoro è occupata.'
    }
    $client = [Net.Sockets.TcpClient]::new()
    try {
        $task = $client.ConnectAsync('127.0.0.1', $port)
        if ($task.Wait(500) -and $client.Connected) { throw "Porta $port già occupata. Chiudi il servizio che la usa prima di riprovare." }
    } catch [AggregateException] {
        if ($_.Exception.GetBaseException() -isnot [Net.Sockets.SocketException]) { throw }
    } finally { $client.Dispose() }

    $localMap = if (Test-Path -LiteralPath $mapConfig) { (Get-Content -LiteralPath $mapConfig -Raw).Trim() }
    if ($localMap -and !(Test-Path -LiteralPath (Join-Path $localMap 'openmap/manifest.json') -PathType Leaf)) {
        throw 'Pacchetto cartografico non trovato. Imposta di nuovo -MapRoot.'
    }

    Push-Location -LiteralPath $desktopProject
    try {
        $stamp = Join-Path $state 'package-lock.sha256'
        $lockHash = (Get-FileHash -LiteralPath 'package-lock.json').Hash
        $installed = if (Test-Path -LiteralPath $stamp) { Get-Content -LiteralPath $stamp }
        $builder = 'node_modules/electron-vite/bin/electron-vite.js'
        if ($installed -ne $lockHash -or !(Test-Path -LiteralPath $builder -PathType Leaf)) {
            $npm = (Get-Command npm.cmd -CommandType Application).Source
            $download = $env:ELECTRON_SKIP_BINARY_DOWNLOAD
            try {
                $env:ELECTRON_SKIP_BINARY_DOWNLOAD = '1'
                & $npm ci --no-audit --no-fund
                if ($LASTEXITCODE) { throw 'Installazione delle dipendenze non riuscita.' }
            } finally { $env:ELECTRON_SKIP_BINARY_DOWNLOAD = $download }
            Set-Content -LiteralPath $stamp -Value $lockHash -Encoding ascii
        }
        & $node $builder build --config electron.bridge.vite.config.ts
        if ($LASTEXITCODE) { throw 'Compilazione della mappa locale non riuscita.' }
        if ($localMap) {
            & $node 'out/bridge/map-services.js' $localMap $GameRoot
            if ($LASTEXITCODE) { Write-Warning 'Livelli dei servizi non disponibili nel pacchetto locale.' }
            & $node 'out/bridge/map-dungeons.js' $localMap $GameRoot
            if ($LASTEXITCODE) { Write-Warning 'Mappe dei dungeon o delle caverne non disponibili nel pacchetto locale.' }
            & $node 'out/bridge/map-gathering.js' $localMap $GameRoot
            if ($LASTEXITCODE) { Write-Warning 'Requisiti di raccolta non aggiornati nel pacchetto locale.' }
        }
        if ($Pulser) {
            $electron = Join-Path $desktopProject 'node_modules/electron/dist/electron.exe'
            if (!(Test-Path -LiteralPath $electron -PathType Leaf)) {
                & $node 'node_modules/electron/install.js'
                if ($LASTEXITCODE -or !(Test-Path -LiteralPath $electron -PathType Leaf)) { throw 'Installazione di Electron per Pulser non riuscita.' }
            }
        }
    } finally { Pop-Location }

    $settings = [Diagnostics.ProcessStartInfo]::new($node)
    $settings.WorkingDirectory = $repo
    $settings.UseShellExecute = $false
    $settings.ArgumentList.Add((Join-Path $PSScriptRoot 'server.cjs'))
    foreach ($key in @($settings.Environment.Keys)) {
        if ($key -like 'UNCS_WEB_*') { $settings.Environment.Remove($key) | Out-Null }
    }
    $settings.Environment['UNCS_WEB_PORT'] = [string]$port
    if ($localMap) {
        $settings.Environment['UNCS_WEB_MAP_ROOT'] = $localMap
        $settings.Environment['UNCS_WEB_MAP_SOURCE'] = 'external'
    }
    if ($Pulser) {
        $localKey = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant()
        $settings.Environment['UNCS_WEB_BRIDGE'] = '1'
        $settings.Environment['UNCS_WEB_LOCAL_PULSER_KEY'] = $localKey
        $settings.Environment['UNCS_WEB_GUILD_PINS_FILE'] = Join-Path $state 'guild-pins.json'
    }
    $server = [Diagnostics.Process]::Start($settings)
    $version = (Get-Content -LiteralPath (Join-Path $desktopProject 'package.json') -Raw | ConvertFrom-Json).version
    $ready = $null
    for ($attempt = 0; $attempt -lt 30 -and !$server.HasExited; $attempt++) {
        $ready = Read-LocalHealth
        if ($ready.service -eq 'uncs-forever-web' -and $ready.version -eq $version) { break }
        Start-Sleep -Milliseconds 200
    }
    if ($server.HasExited -or $ready.service -ne 'uncs-forever-web' -or $ready.version -ne $version) {
        throw 'La web app locale non ha superato il controllo di avvio.'
    }
    if ($Pulser) {
        if (!$ready.localPulser) { throw 'Il server locale non ha attivato la modalità Pulser.' }
        $pulserProfile = Join-Path $state 'pulser'
        New-Item -ItemType Directory -Path $pulserProfile -Force | Out-Null
        $pulserSettings = [Diagnostics.ProcessStartInfo]::new($electron)
        $pulserSettings.WorkingDirectory = $desktopProject
        $pulserSettings.UseShellExecute = $false
        $pulserSettings.CreateNoWindow = $true
        $pulserSettings.ArgumentList.Add((Join-Path $desktopProject 'out/bridge/web-bridge.js'))
        $pulserSettings.ArgumentList.Add('--local')
        $pulserSettings.Environment['UNCS_WEB_LOCAL_PULSER_KEY'] = $localKey
        $pulserSettings.Environment['UNCS_WEB_LOCAL_PULSER_PROFILE'] = $pulserProfile
        if ($localMap) { $pulserSettings.Environment['UNCS_WEB_MAP_ROOT'] = $localMap }
        $pulserProcess = [Diagnostics.Process]::Start($pulserSettings)
        if ($pulserProcess.WaitForExit(350)) { throw 'Il Pulser locale si è chiuso in fase di avvio.' }
        Write-Host 'Pulser locale avviato. Lo stato della cattura è nel menu della tray.'
    }
    if (!$ready.mapConfigured) { Write-Host 'Cartografia locale assente. Configurala con -MapRoot quando hai il pacchetto della gilda.' }
    Write-Host "Web app LOCALE $version - $url"
    Write-Host 'Premi Ctrl+C nella finestra per fermarla. Riapri il collegamento per ricompilare dopo una modifica.'
    if (!$NoBrowser) { Start-Process $url }
    while (!$server.HasExited) { Start-Sleep -Milliseconds 300 }
    if ($server.ExitCode) { throw "Il server locale si è chiuso con codice $($server.ExitCode)." }
} finally {
    if ($pulserProcess -and !$pulserProcess.HasExited) { $pulserProcess.Kill(); $pulserProcess.WaitForExit() }
    if ($pulserProcess) { $pulserProcess.Dispose() }
    if ($server -and !$server.HasExited) { $server.Kill(); $server.WaitForExit() }
    if ($server) { $server.Dispose() }
    if ($lock) { $lock.Dispose() }
}
