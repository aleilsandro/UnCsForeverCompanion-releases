const assert = require('node:assert/strict')
const { test } = require('node:test')
const { randomUUID } = require('node:crypto')
const { bridgeSources } = require('./bridge-sources.cjs')

test('simultaneous publishers have independent positions and expiry', () => {
  const state = bridgeSources()
  const first = { source: randomUUID(), name: 'Primo', pos: { wx: 123, wy: 456, ww: 1002, wh: 668 } }
  const second = { ...first, source: randomUUID(), name: 'Secondo' }
  assert.equal(state.update('a', first, 1000), 200)
  assert.equal(state.update('b', second, 2000), 200)
  assert.equal(state.update('a', first, 1100), 429)
  assert.equal(state.snapshot(2000).state.sections.guild.list.length, 2)
  assert.equal(state.prune(26000), true)
  assert.deepEqual(state.snapshot(26000).state.sections.guild.list.map(p => p.n), ['Secondo'])
  assert.equal(state.update('b', { source: second.source, stopped: true }, 26500), 200)
  assert.equal(state.snapshot(26500).game, 'closed')
})
