const assert = require('node:assert/strict')
const { test } = require('node:test')
const { randomUUID } = require('node:crypto')
const { bridgeSources } = require('./bridge-sources.cjs')

test('simultaneous publishers have independent positions and expiry', () => {
  const state = bridgeSources()
  const first = { source: randomUUID(), name: 'Primo', pos: { wx: 123, wy: 456, ww: 1002, wh: 668, facing: 0 } }
  const second = { ...first, source: randomUUID(), name: 'Secondo', pos: { ...first.pos, facing: 360 } }
  assert.equal(state.update('a', first, 1000), 200)
  assert.equal(state.update('b', second, 2000), 200)
  assert.equal(state.update('a', first, 1100), 429)
  const members = state.snapshot(2000).state.sections.guild.list
  assert.equal(members.length, 2)
  assert.equal(members.find(member => member.n === 'Primo').facing, 0)
  assert.equal(members.find(member => member.n === 'Secondo').facing, undefined)
  assert.equal(state.prune(26000), true)
  assert.deepEqual(state.snapshot(26000).state.sections.guild.list.map(p => p.n), ['Secondo'])
  assert.equal(state.update('b', { source: second.source, stopped: true }, 26500), 200)
  assert.equal(state.snapshot(26500).game, 'closed')
})

test('a paired viewer receives only their own current position and flight status', () => {
  const bridge = bridgeSources()
  const pos = { wx: 123, wy: 456, ww: 1002, wh: 668 }
  const alicePosition = { world: 0, north: -1234, west: 200 }
  const bobPosition = { world: 1, north: 400, west: -600 }
  const alice = { source: randomUUID(), name: 'Alice', pos: { ...pos, ...alicePosition }, flights: { side: 'A', known: [12], checked: [0] } }
  const bob = { source: randomUUID(), name: 'Bob', pos: { ...pos, ...bobPosition }, flights: { side: 'A', known: [], checked: [0] } }
  assert.equal(bridge.update('alice', alice, 1000, true), 200)
  assert.equal(bridge.update('bob', bob, 1100, true), 200)
  assert.equal(bridge.update('bob', { ...alice, name: 'Private' }, 1200), 200)
  assert.deepEqual(bridge.snapshot(1200, true, { login: 'bob', publicVisible: true }).state.sections.flights, bob.flights)
  assert.deepEqual(bridge.snapshot(1200, false, { login: 'alice', publicVisible: true }).state.sections.flights, alice.flights)
  assert.equal(bridge.snapshot(1200, true).state.sections.flights, undefined)
  assert.equal(bridge.snapshot(1200, true).state.sections.ownPosition, undefined)
  assert.deepEqual(bridge.snapshot(1200, true, { login: 'bob', publicVisible: true }).state.sections.ownPosition, bobPosition)
  assert.equal(bridge.snapshot(1200, true).state.sections.ownCharacter, undefined)
  assert.equal(bridge.snapshot(1200, true, { login: 'bob', publicVisible: true }).state.sections.ownCharacter, 'Bob')
  const aliceState = bridge.snapshot(1200, false, { login: 'alice', publicVisible: true }).state
  assert.deepEqual(aliceState.sections.ownPosition, alicePosition)
  assert.equal(aliceState.updatedAt.ownPosition, 1000)
  assert.equal(bridge.snapshot(26000, true, { login: 'alice', publicVisible: true }).state.sections.ownPosition, undefined)
  assert.equal(bridge.update('alice', { ...alice, name: 'Alt', flights: undefined }, 1600, true), 200)
  assert.equal(bridge.snapshot(1600, true, { login: 'alice', publicVisible: true }).state.sections.flights, undefined)
})

test('instance coordinates stay personal and only mutually listed companions join the map', () => {
  const bridge = bridgeSources()
  const player = (name, x, party, id = 36) => ({
    source: randomUUID(), name, party, pos: { inst: { id, kind: 'party', x, y: -10, level: 1, mini: { x: 22 } }, facing: 23 },
  })
  const alice = player('Alice-Realm', -60, ['Bob Realm', 'Eve Realm', 'Sam Realm'])
  const bob = player('Bob-Realm', -75, ['Alice Realm'])
  const eve = player('Eve-Realm', -80, [])
  const sam = player('Sam-Realm', -90, ['Alice Realm'], 33)
  for (const [name, sample] of Object.entries({ alice, bob, eve, sam })) assert.equal(bridge.update(name, sample, 1000, true), 200)
  const view = owner => bridge.snapshot(1200, true, owner).state.sections
  assert.deepEqual(view({ login: 'alice', publicVisible: true }).pos, { inst: { id: 36, kind: 'party', x: -60, y: -10, level: 1 }, facing: 23 })
  assert.deepEqual(view({ login: 'alice', publicVisible: true }).group.list, [{ n: 'Bob-Realm', i: 36, wx: -75, wy: -10, l: 1 }])
  assert.deepEqual(view().guild.list.map(({ n, z, x, y }) => ({ n, z, x, y })),
    ['Alice-Realm', 'Bob-Realm', 'Eve-Realm', 'Sam-Realm'].map(n => ({ n, z: 'In un’istanza', x: undefined, y: undefined })))
  assert.equal(view().pos, undefined)
  assert.equal(view().group, undefined)
  assert.equal(view({ login: 'alice', publicVisible: false }).pos, undefined)
  assert.equal(bridge.snapshot(26000, true, { login: 'alice', publicVisible: true }).state.sections.pos, undefined)
})

test('alternating updates keep alphabetical order and a presence-only character remains listed', () => {
  const bridge = bridgeSources()
  const alice = { source: randomUUID(), name: 'Alice', online: true, zone: 'Elwynn Forest' }
  const bob = { source: randomUUID(), name: 'Bob', pos: { wx: 123, wy: 456, ww: 1002, wh: 668 } }
  assert.equal(bridge.update('a', alice, 1000), 200)
  assert.equal(bridge.update('b', bob, 1500), 200)
  assert.equal(bridge.update('a', alice, 2000), 200)
  assert.deepEqual(bridge.snapshot(2000).state.sections.guild.list.map(row => row.n), ['Alice', 'Bob'])
  assert.equal(bridge.update('b', bob, 2500), 200)
  assert.deepEqual(bridge.snapshot(2500).state.sections.guild.list.map(row => row.n), ['Alice', 'Bob'])
  assert.equal(bridge.update('a', alice, 26000), 200)
  assert.deepEqual(bridge.snapshot(27000).state.sections.guild.list.map(row => [row.n, row.x]), [['Alice', undefined], ['Bob', 123]])
  assert.equal(bridge.update('a', { source: alice.source, stopped: true }, 28000), 200)
  assert.deepEqual(bridge.snapshot(28000).state.sections.guild.list, [])
})

test('dungeon session progress stays with the owner and clears on exit or reset', () => {
  const bridge = bridgeSources()
  const pilot = { source: randomUUID(), name: 'Pilot', pos: { inst: { id: 36, kind: 'party' } } }
  const peer = { ...pilot, source: randomUUID(), name: 'Peer', party: ['Pilot'] }
  const kills = { map: 36, list: ['Sneed', 'Sneed', 123, ''] }
  const progress = login => bridge.snapshot(4000, true, login && { login, publicVisible: true }).state.sections.run_kills

  assert.equal(bridge.update('pilot', { ...pilot, party: ['Peer'], runKills: kills }, 1000, true), 200)
  assert.equal(bridge.update('peer', peer, 1000, true), 200)
  assert.deepEqual(progress('pilot'), { map: 36, list: ['Sneed'] })
  assert.equal(progress('peer'), undefined)
  assert.equal(progress(), undefined)
  assert.equal(bridge.update('pilot', { ...pilot, runKills: { map: 33, list: kills.list } }, 1700, true), 200)
  assert.equal(progress('pilot'), undefined)
  assert.equal(bridge.update('pilot', { ...pilot, runKills: { map: 36, list: [] } }, 2400, true), 200)
  assert.deepEqual(progress('pilot'), { map: 36, list: [] })
  assert.equal(bridge.update('pilot', { ...pilot, pos: { wx: 123, wy: 456, ww: 1002, wh: 668 }, runKills: kills }, 3100, true), 200)
  assert.equal(progress('pilot'), undefined)
})

test('positions and class of non-guild party members only reach their owner', () => {
  const bridge = bridgeSources()
  const pilot = { source: randomUUID(), name: 'Pilot', cls: 'PRIEST', pos: { wx: 300, wy: 400, ww: 1002, wh: 668 } }
  const outsider = { source: randomUUID(), name: 'Observer', pos: { wx: 500, wy: 600, ww: 1002, wh: 668 } }
  const hunter = { n: 'Friend', c: 'HUNTER', m: 1429, x: 30, y: 84 }
  const group = [hunter, { ...hunter, n: 'Bad coords', x: -1 }, { ...hunter, n: 'Pilot' }]
  assert.equal(bridge.update('pilot', { ...pilot, worldParty: true, group }, 1000, true), 200)
  assert.equal(bridge.update('observer', outsider, 1000, true), 200)
  const progress = login => bridge.snapshot(2000, true, login && { login, publicVisible: true }).state.sections
  assert.deepEqual(progress('pilot').group, { party: true, list: [hunter] })
  assert.equal(progress('observer').group, undefined)
  assert.equal(progress().group, undefined)
  assert.deepEqual(progress().guild.list.map(row => [row.n, row.c]), [['Observer', undefined], ['Pilot', 'PRIEST']])
  assert.equal(bridge.update('pilot', { ...pilot, worldParty: false, group }, 1700, true), 200)
  assert.equal(progress('pilot').group, undefined)
})

test('dungeon completions stay private, follow the character and survive leaving the instance', () => {
  const bridge = bridgeSources()
  const pilot = { source: randomUUID(), name: 'Pilot', pos: { inst: { id: 36, kind: 'party' } } }
  const outsider = { source: randomUUID(), name: 'Observer', pos: { wx: 500, wy: 600, ww: 1002, wh: 668 } }
  const update = (fields, now) => bridge.update('pilot', { ...pilot, ...fields }, now, true)
  const read = (login, now) => bridge.snapshot(now, true, login && { login, publicVisible: true }).state.sections.dungeon_progress
  const dungeonProgress = { name: 'Pilot', maps: [36, 36, -5, '33', 43], legacy: [33, '48', 33], quests: [391, 391, -1, '400', 400], active: [42, 42, null, -1] }

  assert.equal(update({ dungeonProgress }, 1000), 200)
  assert.equal(bridge.update('observer', outsider, 1000, true), 200)
  const expected = { name: 'Pilot', maps: [36, 43], legacy: [33], quests: [391, 400], active: [42] }
  assert.deepEqual(read('pilot', 1300), expected)
  assert.equal(read('observer', 1300), undefined)
  assert.equal(read(undefined, 1300), undefined)
  assert.equal(update({ pos: { wx: 100, wy: 200, ww: 1002, wh: 668 }, dungeonProgress }, 1700), 200)
  assert.deepEqual(read('pilot', 1900), expected)
  assert.equal(update({ name: 'Alt', dungeonProgress }, 2400), 200)
  assert.equal(read('pilot', 2600), undefined)
  assert.equal(update({ name: 'Alt', dungeonProgress: { name: 'Alt', maps: [] } }, 3100), 200)
  assert.deepEqual(read('pilot', 3300), { name: 'Alt', maps: [], legacy: [] })
})

test('farming and account wallets only reach the paired owner', () => {
  const bridge = bridgeSources()
  const pilot = { source: randomUUID(), name: 'Pilot', online: true }
  const peer = { source: randomUUID(), name: 'Observer', online: true }
  const report = { name: 'Pilot', seconds: 3600, earned: 20000, spent: 1000, vendor: 2000, auction: 4000,
    loot: { value: 14000, count: 10, unpriced: 2 },
    wallets: [{ name: 'Pilot', realm: 'Forever', money: 10000, seen: 1767000000 },
      { name: 'Alt', realm: 'Forever', money: 40000, seen: 1766999999 }] }
  assert.equal(bridge.update('pilot', { ...pilot, farming: report }, 1000, true), 200)
  assert.equal(bridge.update('observer', { ...peer, farming: report }, 1000, true), 200)
  const read = login => bridge.snapshot(3000, true, login && { login, publicVisible: true }).state.sections
  assert.deepEqual(read('pilot').farming, report)
  assert.equal(read('observer').farming, undefined)
  assert.equal(read().farming, undefined)
  assert.equal(bridge.update('pilot', { ...pilot, farming: { ...report, auction: 20000 } }, 1800, true), 200)
  assert.equal(read('pilot').farming, undefined)
  const privateReport = { ...report, name: 'Alt', expenses: [[1767000000, 500], [1766999999, 1000]] }
  assert.equal(bridge.update('pilot', { ...pilot, name: 'Alt', privateFarming: true, farming: { ...privateReport, expenses: [...privateReport.expenses, [1767000000, -1], [0]] },
    pos: { wx: 400, wy: 500, ww: 1002, wh: 668 }, cls: 'MAGE' }, 2500, true), 200)
  assert.deepEqual(read('pilot').farming, privateReport)
  assert.equal(read('pilot').ownCharacter, 'Alt')
  assert.equal(read('pilot').ownPosition, undefined)
  assert.equal(read('observer').farming, undefined)
  assert.equal(read().farming, undefined)
  assert.deepEqual(read().guild.list.map(row => row.n), ['Observer'])
})
