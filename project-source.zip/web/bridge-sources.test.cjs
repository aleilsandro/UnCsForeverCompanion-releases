const assert = require('node:assert/strict')
const { test } = require('node:test')
const { randomUUID } = require('node:crypto')
const { bridgeSources } = require('./bridge-sources.cjs')

test('simultaneous publishers have independent positions and expiry', () => {
  const state = bridgeSources()
  const first = { source: randomUUID(), name: 'Primo', pos: { wx: 123, wy: 456, ww: 1002, wh: 668, facing: 0 } }
  const second = { ...first, source: randomUUID(), name: 'Secondo', pos: { ...first.pos, facing: 360 } }
  assert.equal(state.update('a', first, 1000), 200)
  assert.equal(state.update('b', second, 2000), 200)
  assert.equal(state.update('a', first, 1100), 429)
  const members = state.snapshot(2000).state.sections.guild.list
  assert.equal(members.length, 2)
  assert.equal(members.find(member => member.n === 'Primo').facing, 0)
  assert.equal(members.find(member => member.n === 'Secondo').facing, undefined)
  assert.equal(state.prune(26000), true)
  assert.deepEqual(state.snapshot(26000).state.sections.guild.list.map(p => p.n), ['Secondo'])
  assert.equal(state.update('b', { source: second.source, stopped: true }, 26500), 200)
  assert.equal(state.snapshot(26500).game, 'closed')
})

test('a paired viewer receives only their own current position and flight status', () => {
  const bridge = bridgeSources()
  const pos = { wx: 123, wy: 456, ww: 1002, wh: 668 }
  const alicePosition = { world: 0, north: -1234, west: 200 }
  const bobPosition = { world: 1, north: 400, west: -600 }
  const alice = { source: randomUUID(), name: 'Alice', pos: { ...pos, ...alicePosition }, flights: { side: 'A', known: [12], checked: [0] } }
  const bob = { source: randomUUID(), name: 'Bob', pos: { ...pos, ...bobPosition }, flights: { side: 'A', known: [], checked: [0] } }
  assert.equal(bridge.update('alice', alice, 1000, true), 200)
  assert.equal(bridge.update('bob', bob, 1100, true), 200)
  assert.equal(bridge.update('bob', { ...alice, name: 'Private' }, 1200), 200)
  assert.deepEqual(bridge.snapshot(1200, true, { login: 'bob', publicVisible: true }).state.sections.flights, bob.flights)
  assert.deepEqual(bridge.snapshot(1200, false, { login: 'alice', publicVisible: true }).state.sections.flights, alice.flights)
  assert.equal(bridge.snapshot(1200, true).state.sections.flights, undefined)
  assert.equal(bridge.snapshot(1200, true).state.sections.ownPosition, undefined)
  assert.deepEqual(bridge.snapshot(1200, true, { login: 'bob', publicVisible: true }).state.sections.ownPosition, bobPosition)
  assert.equal(bridge.snapshot(1200, true).state.sections.ownCharacter, undefined)
  assert.equal(bridge.snapshot(1200, true, { login: 'bob', publicVisible: true }).state.sections.ownCharacter, 'Bob')
  const aliceState = bridge.snapshot(1200, false, { login: 'alice', publicVisible: true }).state
  assert.deepEqual(aliceState.sections.ownPosition, alicePosition)
  assert.equal(aliceState.updatedAt.ownPosition, 1000)
  assert.equal(bridge.snapshot(26000, true, { login: 'alice', publicVisible: true }).state.sections.ownPosition, undefined)
  assert.equal(bridge.update('alice', { ...alice, name: 'Alt', flights: undefined }, 1600, true), 200)
  assert.equal(bridge.snapshot(1600, true, { login: 'alice', publicVisible: true }).state.sections.flights, undefined)
})

test('instance coordinates stay personal and only mutually listed companions join the map', () => {
  const bridge = bridgeSources()
  const player = (name, x, party, id = 36) => ({
    source: randomUUID(), name, party, pos: { inst: { id, kind: 'party', x, y: -10, level: 1, mini: { x: 22 } }, facing: 23 },
  })
  const alice = player('Alice-Realm', -60, ['Bob Realm', 'Eve Realm', 'Sam Realm'])
  const bob = player('Bob-Realm', -75, ['Alice Realm'])
  const eve = player('Eve-Realm', -80, [])
  const sam = player('Sam-Realm', -90, ['Alice Realm'], 33)
  for (const [name, sample] of Object.entries({ alice, bob, eve, sam })) assert.equal(bridge.update(name, sample, 1000, true), 200)
  const view = owner => bridge.snapshot(1200, true, owner).state.sections
  assert.deepEqual(view({ login: 'alice', publicVisible: true }).pos, { inst: { id: 36, kind: 'party', x: -60, y: -10, level: 1 }, facing: 23 })
  assert.deepEqual(view({ login: 'alice', publicVisible: true }).group.list, [{ n: 'Bob-Realm', i: 36, wx: -75, wy: -10, l: 1 }])
  assert.deepEqual(view().guild.list.map(({ n, z, x, y }) => ({ n, z, x, y })),
    ['Alice-Realm', 'Bob-Realm', 'Eve-Realm', 'Sam-Realm'].map(n => ({ n, z: 'In un’istanza', x: undefined, y: undefined })))
  assert.equal(view().pos, undefined)
  assert.equal(view().group, undefined)
  assert.equal(view({ login: 'alice', publicVisible: false }).pos, undefined)
  assert.equal(bridge.snapshot(26000, true, { login: 'alice', publicVisible: true }).state.sections.pos, undefined)
})

test('alternating updates keep alphabetical order and a presence-only character remains listed', () => {
  const bridge = bridgeSources()
  const alice = { source: randomUUID(), name: 'Alice', online: true, zone: 'Elwynn Forest' }
  const bob = { source: randomUUID(), name: 'Bob', pos: { wx: 123, wy: 456, ww: 1002, wh: 668 } }
  assert.equal(bridge.update('a', alice, 1000), 200)
  assert.equal(bridge.update('b', bob, 1500), 200)
  assert.equal(bridge.update('a', alice, 2000), 200)
  assert.deepEqual(bridge.snapshot(2000).state.sections.guild.list.map(row => row.n), ['Alice', 'Bob'])
  assert.equal(bridge.update('b', bob, 2500), 200)
  assert.deepEqual(bridge.snapshot(2500).state.sections.guild.list.map(row => row.n), ['Alice', 'Bob'])
  assert.equal(bridge.update('a', alice, 26000), 200)
  assert.deepEqual(bridge.snapshot(27000).state.sections.guild.list.map(row => [row.n, row.x]), [['Alice', undefined], ['Bob', 123]])
  assert.equal(bridge.update('a', { source: alice.source, stopped: true }, 28000), 200)
  assert.deepEqual(bridge.snapshot(28000).state.sections.guild.list, [])
})
