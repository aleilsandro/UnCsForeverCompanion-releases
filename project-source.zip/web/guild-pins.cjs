'use strict'
const { randomUUID } = require('node:crypto')
const { readFile, rename, rm, writeFile } = require('node:fs/promises')

function draftFrom(value) {
  if (!value || typeof value !== 'object') return null
  const { x, y } = value
  const name = typeof value.name === 'string' ? value.name.trim() : ''
  const note = typeof value.note === 'string' ? value.note.trim() : ''
  if ((!name && !note) || name.length > 80 || note.length > 500 ||
      ![x, y].every(n => Number.isInteger(n) && n >= 0 && n <= 100000)) return null
  return { name, note, x, y }
}

async function guildPins(file) {
  let pins = []
  try {
    const saved = JSON.parse(await readFile(file, 'utf8'))
    if (Array.isArray(saved)) pins = saved.filter(pin => pin && typeof pin.id === 'string' && typeof pin.owner === 'string' && draftFrom(pin))
  } catch (error) {
    if (error.code !== 'ENOENT') throw error
  }
  let queue = Promise.resolve()
  function change(update) {
    const operation = queue.then(async () => {
      const result = update(pins)
      if (!result.pins) return result.status
      const temporary = file + '.' + randomUUID() + '.tmp'
      try {
        await writeFile(temporary, JSON.stringify(result.pins), { flag: 'wx' })
        await rename(temporary, file)
      } finally { await rm(temporary, { force: true }).catch(() => {}) }
      pins = result.pins
      return result.status
    })
    queue = operation.catch(() => {})
    return operation
  }
  return {
    list(owner) { return pins.map(({ owner: saved, ...pin }) => ({ ...pin, removable: saved === owner })) },
    add(owner, value) {
      const draft = draftFrom(value)
      if (!draft) return Promise.resolve(400)
      return change(current => current.length >= 200 ? { status: 409 } :
        { status: 201, pins: [...current, { ...draft, owner, id: randomUUID() }] })
    },
    remove(owner, id) {
      return change(current => current.some(pin => pin.id === id && pin.owner === owner)
        ? { status: 200, pins: current.filter(pin => pin.id !== id) } : { status: 404 })
    },
  }
}

module.exports = { guildPins }
