'use strict'

const expiry = 25_000
const coordinate = value => Number.isFinite(value) && value >= 0 && value <= 100000
const dimension = value => Number.isFinite(value) && value > 0 && value < 10000
const heading = value => Number.isFinite(value) && value >= 0 && value < 360
const yards = value => Number.isFinite(value) && Math.abs(value) <= 17067
const classToken = value => typeof value === 'string' && /^[A-Z]{3,16}$/.test(value)
const positiveIds = (values, limit) => Array.isArray(values) ? [...new Set(values.slice(0, limit).filter(id => Number.isSafeInteger(id) && id > 0))] : []
const percent = value => Number.isFinite(value) && value >= 0 && value <= 100
const validFloor = value => Number.isInteger(value) && value >= 0 && value < 100
const validName = name => typeof name === 'string' && name.trim() && name.length <= 128 && !/[\u0000-\u001f]/.test(name)
const characterKey = name => name.trim().toLowerCase().replace(/[-\s]+/g, ' ')

function farmingFrom(value, owner) {
  if (value?.name !== owner) return
  const { seconds, earned, spent, vendor, auction, wallets, loot, balance } = value
  const amount = amount => Number.isSafeInteger(amount) && amount >= 0 && amount <= 1e12
  if (![seconds, earned, spent, vendor, auction].every(amount) || vendor + auction > earned) return
  const balances = Array.isArray(wallets) ? wallets.slice(0, 100).flatMap(wallet =>
    validName(wallet?.name) && typeof wallet.realm === 'string' && wallet.realm.length <= 128
      && amount(wallet.money) && amount(wallet.seen)
      ? [{ name: wallet.name, realm: wallet.realm, money: wallet.money, seen: wallet.seen }] : [],
  ) : []
  const expenses = Array.isArray(value.expenses) ? value.expenses.slice(0, 100).flatMap(entry =>
    Array.isArray(entry) && entry.length === 2 && amount(entry[0]) && amount(entry[1]) && entry[1] > 0
      ? [[entry[0], entry[1]]] : [],
  ) : undefined
  const estimate = amount(loot?.value) && amount(loot?.count) && amount(loot?.unpriced) && loot.unpriced <= loot.count
    ? { value: loot.value, count: loot.count, unpriced: loot.unpriced } : undefined
  return { name: owner, seconds, earned, spent, vendor, auction, wallets: balances,
    ...(amount(balance) && { balance }), ...(expenses && { expenses }), ...(estimate && { loot: estimate }) }
}

function instanceOf(value) {
  if (!value || !Number.isSafeInteger(value.id) || value.id <= 0 || !['party', 'raid'].includes(value.kind)) return
  return { id: value.id, kind: value.kind, ...(validName(value.name) && { name: value.name }),
    ...(yards(value.x) && yards(value.y) && { x: value.x, y: value.y }),
    ...(validFloor(value.level) && { level: value.level }) }
}

function bridgeSources() {
  const sources = new Map()
  function update(login, data, now = Date.now(), publicVisible = false) {
    if (!data || typeof data.source !== 'string' || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(data.source)) return 400
    const key = `${publicVisible ? 'public' : 'private'}\0${login}\0${data.source.toLowerCase()}`
    if (data.stopped === true) { sources.delete(key); return 200 }
    const { name, level, cls, pos, geometry } = data
    const privateFarming = data.privateFarming === true
    if (!validName(name)) return 400
    const farming = farmingFrom(data.farming, name)
    if (privateFarming && !farming) return 400
    if (!privateFarming && (pos === undefined ? data.online !== true : !pos || typeof pos !== 'object')) return 400
    const inst = !privateFarming && instanceOf(pos?.inst)
    if (!privateFarming && pos && (pos.inst ? !inst : !coordinate(pos.wx) || !coordinate(pos.wy) || !dimension(pos.ww) || !dimension(pos.wh))) return 400
    prune(now)
    if (!sources.has(key) && sources.size >= 150 &&
        [...sources.values()].filter(value => value.publicVisible === publicVisible).length >= 150) return 503
    const previous = sources.get(key)
    if (previous && now - previous.at < 500) return 429
    if (privateFarming) {
      sources.set(key, { farming, at: now, login, member: { n: name }, publicVisible, privateFarming })
      return 200
    }
    const zone = inst ? 'In un’istanza' : data.zone ?? pos?.zone
    const member = { n: name.trim(), l: Number.isInteger(level) && level > 0 && level <= 100 ? level : undefined,
      ...(classToken(cls) && { c: cls }),
      z: typeof zone === 'string' ? zone.slice(0, 128) : undefined,
      ...(pos && !inst && { x: pos.wx, y: pos.wy, exact: true, ...(heading(pos.facing) && { facing: pos.facing }) }) }
    const state = data.flights
    const flights = state && (state.side === 'A' || state.side === 'H') ? {
      side: state.side,
      known: Array.isArray(state.known) ? state.known.slice(0, 200).filter(id => Number.isSafeInteger(id) && id > 0) : [],
      checked: Array.isArray(state.checked) ? state.checked.slice(0, 2).filter(id => id === 0 || id === 1) : [],
    } : undefined
    const worldParty = !!pos && !inst && data.worldParty === true
    const group = Array.isArray(data.group) ? data.group.slice(0, inst ? 40 : 4).flatMap(row => {
      if (!row || !validName(row.n) || characterKey(row.n) === characterKey(name)) return []
      const identity = { n: row.n, ...(classToken(row.c) && { c: row.c }) }
      if (inst && row.i === inst.id && yards(row.wx) && yards(row.wy))
        return [{ ...identity, i: row.i, wx: row.wx, wy: row.wy, ...(validFloor(row.l) && { l: row.l }) }]
      if (worldParty && Number.isSafeInteger(row.m) && row.m > 1 && percent(row.x) && percent(row.y))
        return [{ ...identity, m: row.m, x: row.x, y: row.y }]
      return []
    }) : []
    const position = inst ? { inst, ...(heading(pos.facing) && { facing: pos.facing }) } : pos && {
      wx: pos.wx, wy: pos.wy, ww: pos.ww, wh: pos.wh, north: pos.north, west: pos.west, world: pos.world,
    }
    const party = inst && Array.isArray(data.party) ? data.party.slice(0, 40).filter(validName).map(characterKey) : []
    const reportedKills = data.runKills
    const runKills = inst?.kind === 'party' && reportedKills?.map === inst.id && Array.isArray(reportedKills.list)
      ? { map: inst.id, list: [...new Set(reportedKills.list.slice(0, 80).filter(validName))] } : undefined
    const progress = data.dungeonProgress
    const dungeonProgress = progress?.name === name && Array.isArray(progress.maps)
      ? { name: name.trim(), maps: positiveIds(progress.maps, 128), legacy: positiveIds(progress.legacy, 128),
        ...(Array.isArray(progress.quests) && { quests: positiveIds(progress.quests, 1024) }),
        ...(Array.isArray(progress.active) && { active: positiveIds(progress.active, 1024) }) }
      : undefined
    sources.set(key, { runKills, dungeonProgress, farming, at: now, login, member, pos: position, geometry: inst ? undefined : geometry, publicVisible, flights, group, party, worldParty })
    return 200
  }
  function prune(now) {
    let changed = false
    for (const [key, value] of sources) if (now - value.at >= expiry) {
      sources.delete(key)
      changed = true
    }
    return changed
  }
  function snapshot(now = Date.now(), publicOnly = false, owner) {
    const ordered = [...sources.values()].filter(value => now - value.at < expiry && (!publicOnly || value.publicVisible)).sort((a, b) => b.at - a.at)
    const shared = ordered.filter(value => !value.privateFarming)
    const points = new Map()
    for (const { member } of shared) {
      const name = characterKey(member.n)
      if (!points.has(name)) points.set(name, member)
    }
    const seed = shared.find(value => value.geometry && Number.isFinite(value.pos?.north) && Number.isFinite(value.pos?.west))
    const list = [...points.values()].sort((a, b) => a.n.localeCompare(b.n, 'it', { sensitivity: 'base' }) || a.n.localeCompare(b.n, 'it'))
    const sections = { guild: { list }, pos: seed?.pos, geometry: seed?.geometry }
    const own = owner && ordered.find(value => value.login === owner.login && value.publicVisible === owner.publicVisible)
    if (own) sections.ownCharacter = own.member.n
    if (own?.flights) sections.flights = own.flights
    if (own?.dungeonProgress) sections.dungeon_progress = own.dungeonProgress
    if (own?.farming) sections.farming = own.farming
    const updatedAt = shared.length ? { guild: now, pos: seed?.at ?? now } : {}
    if (own?.farming) updatedAt.farming = own.at
    if (own?.pos?.inst) {
      sections.pos = own.pos
      if (own.runKills) sections.run_kills = own.runKills
      const players = new Map(own.group.map(row => [characterKey(row.n), row]))
      for (const peer of shared) {
        const name = characterKey(peer.member.n), inst = peer.pos?.inst
        if (peer === own || peer.publicVisible !== own.publicVisible || !inst || inst.id !== own.pos.inst.id
          || !own.party.includes(name) || !peer.party.includes(characterKey(own.member.n)) || !yards(inst.x) || !yards(inst.y)) continue
        if (!players.has(name)) players.set(name, { n: peer.member.n, ...(peer.member.c && { c: peer.member.c }), i: inst.id, wx: inst.x, wy: inst.y, l: inst.level })
      }
      sections.group = { list: [...players.values()] }
      updatedAt.pos = updatedAt.group = own.at
    } else if (own?.worldParty) {
      sections.group = { list: own.group, party: true }
      updatedAt.group = own.at
    }
    if (own?.pos && (own.pos.world === 0 || own.pos.world === 1) && Number.isFinite(own.pos.north) && Number.isFinite(own.pos.west)) {
      const { world, north, west } = own.pos
      sections.ownPosition = { world, north, west }
      updatedAt.ownPosition = own.at
    }
    return { game: shared.length || own ? 'open' : 'closed', seconds: 0, reads: 0, cpu: 0,
      state: { sections, updatedAt, protocol: null, blocks: 0, lost: 0, corrupt: 0 } }
  }
  return { update, prune, snapshot }
}
module.exports = { bridgeSources }
