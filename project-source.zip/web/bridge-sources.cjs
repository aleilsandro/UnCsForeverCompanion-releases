'use strict'

const expiry = 25_000
const coordinate = value => Number.isFinite(value) && value >= 0 && value <= 100000
const dimension = value => Number.isFinite(value) && value > 0 && value < 10000
const heading = value => Number.isFinite(value) && value >= 0 && value < 360

function bridgeSources() {
  const sources = new Map()
  function update(login, data, now = Date.now(), publicVisible = false) {
    if (!data || typeof data.source !== 'string' || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(data.source)) return 400
    const key = `${publicVisible ? 'public' : 'private'}\0${login}\0${data.source.toLowerCase()}`
    if (data.stopped === true) { sources.delete(key); return 200 }
    const { name, level, pos, geometry } = data
    if (typeof name !== 'string' || !name.trim() || name.length > 128 || /[\u0000-\u001f]/.test(name)) return 400
    if (!pos || !coordinate(pos.wx) || !coordinate(pos.wy) || !dimension(pos.ww) || !dimension(pos.wh) || pos.inst) return 400
    prune(now)
    if (!sources.has(key) && sources.size >= 150 &&
        [...sources.values()].filter(value => value.publicVisible === publicVisible).length >= 150) return 503
    const previous = sources.get(key)
    if (previous && now - previous.at < 500) return 429
    const member = { n: name.trim(), l: Number.isInteger(level) && level > 0 && level <= 100 ? level : undefined,
      z: typeof pos.zone === 'string' ? pos.zone.slice(0, 128) : undefined, x: pos.wx, y: pos.wy, exact: true,
      ...(heading(pos.facing) ? { facing: pos.facing } : {}) }
    const { wx, wy, ww, wh, north, west, world } = pos
    sources.set(key, { at: now, member, pos: { wx, wy, ww, wh, north, west, world }, geometry, publicVisible })
    return 200
  }
  function prune(now) {
    let changed = false
    for (const [key, value] of sources) if (now - value.at >= expiry) {
      sources.delete(key)
      changed = true
    }
    return changed
  }
  function snapshot(now = Date.now(), publicOnly = false) {
    const ordered = [...sources.values()].filter(value => !publicOnly || value.publicVisible).sort((a, b) => b.at - a.at)
    const points = new Map()
    for (const { member } of ordered) {
      const name = member.n.toLowerCase().replaceAll('-', ' ').replace(/\s+/g, ' ')
      if (!points.has(name)) points.set(name, member)
    }
    const seed = ordered.find(value => value.geometry && Number.isFinite(value.pos.north) && Number.isFinite(value.pos.west))
    const sections = { guild: { list: [...points.values()] }, pos: seed?.pos, geometry: seed?.geometry }
    const updatedAt = ordered.length ? { guild: now, pos: seed?.at ?? now } : {}
    return { game: ordered.length ? 'open' : 'closed', seconds: 0, reads: 0, cpu: 0,
      state: { sections, updatedAt, protocol: null, blocks: 0, lost: 0, corrupt: 0 } }
  }
  return { update, prune, snapshot }
}
module.exports = { bridgeSources }
