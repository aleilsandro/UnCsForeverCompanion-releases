'use strict'

const expiry = 25_000
const coordinate = value => Number.isFinite(value) && value >= 0 && value <= 100000
const dimension = value => Number.isFinite(value) && value > 0 && value < 10000
const heading = value => Number.isFinite(value) && value >= 0 && value < 360
const yards = value => Number.isFinite(value) && Math.abs(value) <= 17067
const validFloor = value => Number.isInteger(value) && value >= 0 && value < 100
const validName = name => typeof name === 'string' && name.trim() && name.length <= 128 && !/[\u0000-\u001f]/.test(name)
const characterKey = name => name.trim().toLowerCase().replace(/[-\s]+/g, ' ')

function instanceOf(value) {
  if (!value || !Number.isSafeInteger(value.id) || value.id <= 0 || !['party', 'raid'].includes(value.kind)) return
  return { id: value.id, kind: value.kind, ...(validName(value.name) && { name: value.name }),
    ...(yards(value.x) && yards(value.y) && { x: value.x, y: value.y }),
    ...(validFloor(value.level) && { level: value.level }) }
}

function bridgeSources() {
  const sources = new Map()
  function update(login, data, now = Date.now(), publicVisible = false) {
    if (!data || typeof data.source !== 'string' || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(data.source)) return 400
    const key = `${publicVisible ? 'public' : 'private'}\0${login}\0${data.source.toLowerCase()}`
    if (data.stopped === true) { sources.delete(key); return 200 }
    const { name, level, pos, geometry } = data
    if (!validName(name) || !pos) return 400
    const inst = instanceOf(pos.inst)
    if (pos.inst ? !inst : !coordinate(pos.wx) || !coordinate(pos.wy) || !dimension(pos.ww) || !dimension(pos.wh)) return 400
    prune(now)
    if (!sources.has(key) && sources.size >= 150 &&
        [...sources.values()].filter(value => value.publicVisible === publicVisible).length >= 150) return 503
    const previous = sources.get(key)
    if (previous && now - previous.at < 500) return 429
    const member = { n: name.trim(), l: Number.isInteger(level) && level > 0 && level <= 100 ? level : undefined,
      z: typeof pos.zone === 'string' ? pos.zone.slice(0, 128) : undefined, x: pos.wx, y: pos.wy, exact: true,
      ...(heading(pos.facing) ? { facing: pos.facing } : {}) }
    const { wx, wy, ww, wh, north, west, world } = pos
    const state = data.flights
    const flights = state && (state.side === 'A' || state.side === 'H') ? {
      side: state.side,
      known: Array.isArray(state.known) ? state.known.slice(0, 200).filter(id => Number.isSafeInteger(id) && id > 0) : [],
      checked: Array.isArray(state.checked) ? state.checked.slice(0, 2).filter(id => id === 0 || id === 1) : [],
    } : undefined
    const group = inst && Array.isArray(data.group) ? data.group.slice(0, 40).flatMap(row =>
      row && row.i === inst.id && validName(row.n) && yards(row.wx) && yards(row.wy)
        ? [{ n: row.n, i: row.i, wx: row.wx, wy: row.wy, ...(validFloor(row.l) && { l: row.l }) }] : []) : []
    const position = inst ? { inst, ...(heading(pos.facing) && { facing: pos.facing }) } : { wx, wy, ww, wh, north, west, world }
    const party = inst && Array.isArray(data.party) ? data.party.slice(0, 40).filter(validName).map(characterKey) : []
    sources.set(key, { at: now, login, member, pos: position, geometry: inst ? undefined : geometry, publicVisible, flights, group, party })
    return 200
  }
  function prune(now) {
    let changed = false
    for (const [key, value] of sources) if (now - value.at >= expiry) {
      sources.delete(key)
      changed = true
    }
    return changed
  }
  function snapshot(now = Date.now(), publicOnly = false, owner) {
    const ordered = [...sources.values()].filter(value => !publicOnly || value.publicVisible).sort((a, b) => b.at - a.at)
    const points = new Map()
    for (const { member, pos } of ordered) {
      if (pos.inst) continue
      const name = characterKey(member.n)
      if (!points.has(name)) points.set(name, member)
    }
    const seed = ordered.find(value => value.geometry && Number.isFinite(value.pos.north) && Number.isFinite(value.pos.west))
    const sections = { guild: { list: [...points.values()] }, pos: seed?.pos, geometry: seed?.geometry }
    const own = owner && ordered.find(value => value.login === owner.login && value.publicVisible === owner.publicVisible && now - value.at < expiry)
    if (own?.flights) sections.flights = own.flights
    const updatedAt = ordered.length ? { guild: now, pos: seed?.at ?? now } : {}
    if (own?.pos.inst) {
      sections.pos = own.pos
      const players = new Map(own.group.map(row => [characterKey(row.n), row]))
      for (const peer of ordered) {
        const name = characterKey(peer.member.n), inst = peer.pos.inst
        if (peer === own || peer.publicVisible !== own.publicVisible || now - peer.at >= expiry || !inst || inst.id !== own.pos.inst.id
          || !own.party.includes(name) || !peer.party.includes(characterKey(own.member.n)) || !yards(inst.x) || !yards(inst.y)) continue
        if (!players.has(name)) players.set(name, { n: peer.member.n, i: inst.id, wx: inst.x, wy: inst.y, l: inst.level })
      }
      sections.group = { list: [...players.values()] }
      updatedAt.pos = updatedAt.group = own.at
    }
    if (own && (own.pos.world === 0 || own.pos.world === 1) && Number.isFinite(own.pos.north) && Number.isFinite(own.pos.west)) {
      const { world, north, west } = own.pos
      sections.ownPosition = { world, north, west }
      updatedAt.ownPosition = own.at
    }
    return { game: ordered.length ? 'open' : 'closed', seconds: 0, reads: 0, cpu: 0,
      state: { sections, updatedAt, protocol: null, blocks: 0, lost: 0, corrupt: 0 } }
  }
  return { update, prune, snapshot }
}
module.exports = { bridgeSources }
