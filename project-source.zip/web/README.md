# UnCs Foreve WebCompanion

Il servizio usa il renderer condiviso e gira in Node.js. Da `desktop/`, eseguire `npm ci` e `npm run build`, poi avviare `node web/server.cjs` dalla radice. Il deploy include `desktop/out/renderer/`, i moduli `web/*.cjs` usati dal servizio e `desktop/package.json`.

Il processo ascolta su `127.0.0.1:8796`. Per assegnare una porta diversa usare `UNCS_WEB_PORT`. Su UnCs Server dedicare al servizio una porta HTTPS Tailscale Serve libera e verificare `/healthz` prima e dopo il collegamento.

La web app cerca le risorse della mappa sotto `UNCS_WEB_MAP_ROOT`. I file conservano gli stessi percorsi delle richieste del renderer, per esempio `openmap/manifest.json`, `openmap/base/1.png` e `openmap/maps.json`. Il manifesto contiene le coppie `[colonna, riga]` delle immagini `openmap/<colonna>_<riga>.png`. Per esplorare nello zoom di dettaglio a gioco chiuso, fornire anche `openmap/alignment.json` con `width`, `height` e `worlds`, indicizzati per continente come `{ g, swap }`. Usare soltanto risorse per cui si ha il diritto di condivisione. La cartografia non è inclusa nel pacchetto del server.

Per provare la sorgente live, configurare `UNCS_WEB_PUBLISH_KEY` con una chiave casuale di almeno 32 caratteri, conservata fuori dal repository. Il browser del PC di gioco apre la pagina HTTPS, usa **Sorgente WoW** e seleziona la finestra del gioco. Il lettore prova a decodificare i pixel ai bordi e invia soltanto la posizione, l’elenco della gilda e la geometria. Gli altri dispositivi visualizzano le posizioni ricevute. Il server mantiene solo l’ultimo aggiornamento in memoria e lo fa scadere dopo 25 secondi. La cattura richiede una verifica con WoW reale sul browser. La posizione nei dungeon richiede il supporto del lettore desktop.

L’istanza privata usa i permessi della rete Tailscale. Prima di esporre il servizio su Internet, aggiungere autenticazione per le pagine, i file e il flusso delle posizioni.

## UnCs Pulser e installer

Con le dipendenze di `desktop/` installate, eseguire `pwsh -File installer/build-web-bridge.ps1` su Windows. Il risultato è in `desktop/dist-bridge/`. Il setup installa l’addon scelto, crea il collegamento alla mappa e permette di abilitare l’avvio al login. Il menu della tray apre la mappa, gestisce l’avvio, cerca aggiornamenti e chiude il Pulser. Passare `-Version X.Y.Z` per assegnare una versione del Pulser indipendente dal companion e pubblicare insieme il setup e il suo `latest.yml`.

Sul server impostare `UNCS_WEB_BRIDGE=1` e indicare in `UNCS_WEB_BRIDGE_RELEASES` la cartella degli installer del ponte e del manifesto. Il ponte usa `/bridge/publish`. Sul listener privato il server usa l’identità verificata da Tailscale Serve. Sul listener dedicato a Funnel il server verifica la credenziale del Pulser attivato. Il Pulser aggiornato invia soltanto la posizione del proprio personaggio di Unconscious Clan quando la condivisione dell’addon è attiva. La modalità del ponte sostituisce la sorgente del browser quando è abilitata. Il ponte aggiorna il proprio programma dalla tray. Per reinstallare l’addon si può riaprire l’installer.

Il menu e il tooltip della tray mostrano la versione del Pulser installata. Il Pulser controlla gli aggiornamenti all’avvio e ogni 30 minuti. Quando trova una nuova release avvisa nella tray. L’installer riusa il percorso di WoW Forever salvato e applica anche l’addon incluso. Con WoW aperto, usare `/reload` dopo l’installazione. Sulle installazioni precedenti al controllo periodico, usare una volta **Cerca aggiornamenti**.

Il link fisso per Discord è `/bridge/releases/UnCs-Pulser-Setup.exe` sulla porta della mappa. Prima di attivare Funnel si può usare la pagina GitHub `releases/latest` del repository pubblico. I workflow allegano il setup e il manifesto `pulser-latest.yml` alle release taggate. Il server espone la release pubblica completa più recente che rileva su GitHub, con il pacchetto locale come fallback.

## Accesso alla mappa senza Tailscale

Sul server UnCs, il deploy in modalità Pulser con `UNCS_WEB_MAP_IMPORT_ROOT` configurato apre anche un listener su `127.0.0.1:8797` e salva gli accessi in `pulser-access.json` nella cartella persistente di import. In sviluppo si può impostare esplicitamente `UNCS_WEB_ACCESS_FILE` e scegliere una porta con `UNCS_WEB_PUBLIC_PORT`. `UNCS_WEB_PUBLIC_ORIGIN` deve corrispondere all’indirizzo HTTPS visitato dagli utenti. Per UnCs è `https://uncs-server.tail1b66eb.ts.net:10000`. Fare il backup dell’archivio degli accessi insieme agli altri dati persistenti.

La prima volta, dopo aver distribuito la nuova versione e verificato la risposta locale di `http://127.0.0.1:8797/access/status`, inoltrare soltanto il listener dedicato tramite Funnel. Eseguire sul server in una console amministrativa:

```powershell
tailscale funnel --bg --https=10000 http://127.0.0.1:8797
```

Verificare da una rete senza Tailscale che la pagina iniziale chieda l’abbinamento e che `/events` rifiuti un browser non abbinato. La porta privata 8447 resta disponibile per gli utenti esistenti e per l’amministrazione. Il listener Funnel accetta solo le posizioni dei Pulser attivati. La mappa privata continua a ricevere le posizioni inviate sul canale privato durante la migrazione.

Con un Pulser aggiornato e collegato a Tailscale, l’amministratore della mappa può scegliere **Crea invito Pulser** dalla tray e passare il codice al gildano dopo aver verificato il personaggio. Il codice scade dopo sette giorni e attiva un solo PC di gioco. QR e link di abbinamento scadono dopo cinque minuti e sono monouso. Il browser mantiene l’abbinamento per 360 giorni o fino alla revoca. L’amministratore può usare **Disattiva un Pulser della gilda** per revocare il PC di gioco e tutti i browser associati. I gildani abbinati possono aprire la mappa senza WoW attivo.

## Cartografia permanente

L’istanza privata serve un pacchetto di 2.432 file, inclusa la panoramica scontornata. Include le tessere del mondo, i livelli di dettaglio disponibili, le ricostruzioni sotterranee di Ironforge e Undercity e l’allineamento di entrambi i continenti. Per aggiungere i dungeon a questo pacchetto servono le relative tessere e i manifesti.

Configurare `UNCS_WEB_MAP_IMPORT_ROOT` con una cartella persistente, scrivibile dal processo del server. Impostare `UNCS_WEB_MAP_ADMIN` con lo SHA-256 esadecimale del login Tailscale dell’amministratore, senza spazi ai bordi e in minuscolo prima di calcolarne l’hash. Usare Tailscale Serve in modalità privata, così il proxy fornisce l’identità verificata.

Nel menu del Pulser dell’amministratore, scegliere **Carica cartografia sul server** e selezionare la cartella che contiene `openmap/` e, se presente, `tiles/`. Includere le tessere base e i livelli di dettaglio desiderati, con i relativi manifesti. Il Pulser carica i file cartografici che l’amministratore ha il diritto di condividere. Il server attiva il pacchetto completo dopo il caricamento, conserva la versione attiva al riavvio e la serve anche a WoW e Pulser chiusi. Le posizioni live continuano ad arrivare separatamente.

Per pubblicare nuove immagini o livelli di zoom, preparare un nuovo pacchetto completo e selezionarlo dalla stessa voce della tray. Durante l’invio la mappa continua a usare la versione attiva. Aggiornare la pagina web dopo il completamento per leggere i nuovi manifesti. L’aggiornamento del software e quello della cartografia sono indipendenti.

Per il mare uniforme, includere `openmap/overview.png` con la terra già scontornata su fondo trasparente. L’immagine deve coprire l’intero atlante, in rapporto 1002 × 668, usando le stesse coordinate delle tessere base. La web app usa il suo canale alfa per mantenere il contorno anche sulle tessere di dettaglio.

Fare il backup dell’intera cartella, incluso `active.txt`. Il server conserva fino a tre importazioni. Per liberare spazio, rimuovere una versione inattiva, verificando l’identificativo attivo in `active.txt` e che nessun caricamento sia in corso.
