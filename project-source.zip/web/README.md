# UnCs Foreve WebCompanion

Il servizio usa il renderer condiviso e gira in Node.js. Da `desktop/`, eseguire `npm ci` e `npm run build`, poi avviare `node web/server.cjs` dalla radice. Il deploy include `desktop/out/renderer/`, i moduli `web/*.cjs` usati dal servizio e `desktop/package.json`.

Per sviluppare su Windows, seguire il [setup locale di Thomas](../COLLABORAZIONE.md#web-app-locale-sul-pc-di-thomas). Il collegamento locale avvia lo stesso servizio sulla porta 18796 del proprio PC. Aggiungere `-Pulser` a `web/local.ps1` per collegare la cattura locale all’istanza di prova. Il launcher usa un profilo Pulser locale e una chiave temporanea per comunicare con il server su loopback. Verificare `/healthz` e lo stato della cattura nella tray.

Il processo ascolta su `127.0.0.1:8796`. Per assegnare una porta diversa usare `UNCS_WEB_PORT`. Su UnCs Server dedicare al servizio una porta HTTPS Tailscale Serve libera e verificare `/healthz` prima e dopo il collegamento.

Il checkout privato include la cartografia in `desktop/src/renderer/public/cartography/`. La compilazione la copia in `desktop/out/renderer/cartography/`, che UnCs Deploy trasferisce insieme al renderer. Il server usa l’intero pacchetto di quella revisione e restituisce il suo identificativo in `mapRevision` su `/healthz`. L’archivio sorgente delle release pubbliche esclude questa cartografia privata.

Per usare una cartografia esterna imposta `UNCS_WEB_MAP_SOURCE=external` e configura `UNCS_WEB_MAP_ROOT` o l’importazione amministrativa. Il launcher locale seleziona questa modalità con `-MapRoot`. I file conservano i percorsi delle richieste del renderer, per esempio `openmap/manifest.json`, `openmap/base/1.png` e `openmap/maps.json`. Il manifesto contiene le coppie `[colonna, riga]` delle immagini `openmap/<colonna>_<riga>.png`. Lo zoom di dettaglio usa `openmap/alignment.json` con `width`, `height` e `worlds`, indicizzati per continente come `{ g, swap }`. Usare risorse autorizzate alla condivisione.

Per provare la sorgente live, configurare `UNCS_WEB_PUBLISH_KEY` con una chiave casuale di almeno 32 caratteri, conservata fuori dal repository. Il browser del PC di gioco apre la pagina HTTPS, usa **Sorgente WoW** e seleziona la finestra del gioco. Il lettore prova a decodificare i pixel ai bordi e invia soltanto la posizione, l’elenco della gilda e la geometria. Gli altri dispositivi visualizzano le posizioni ricevute. Il server mantiene solo l’ultimo aggiornamento in memoria e lo fa scadere dopo 25 secondi. La cattura richiede una verifica con WoW reale sul browser. La posizione nei dungeon richiede il supporto del lettore desktop.

L’istanza privata usa i permessi della rete Tailscale. Prima di esporre il servizio su Internet, aggiungere autenticazione per le pagine, i file e il flusso delle posizioni.

## UnCs Pulser e installer

Con le dipendenze di `desktop/` installate, eseguire `pwsh -File installer/build-web-bridge.ps1` su Windows. Il risultato è in `desktop/dist-bridge/`. Il setup installa l’addon scelto, crea il collegamento alla mappa e permette di abilitare l’avvio al login. Il menu della tray apre la mappa, gestisce l’avvio, cerca aggiornamenti e chiude il Pulser. Passare `-Version X.Y.Z` per assegnare una versione del Pulser indipendente dal companion e pubblicare insieme il setup e il suo `latest.yml`.

Sul server impostare `UNCS_WEB_BRIDGE=1` e indicare in `UNCS_WEB_BRIDGE_RELEASES` la cartella degli installer del ponte e del manifesto. Il ponte usa `/bridge/publish`. Sul listener privato il server usa l’identità verificata da Tailscale Serve. Sul listener dedicato a Funnel il server verifica la credenziale del Pulser attivato. Per la condivisione di gilda il Pulser invia la posizione del proprio personaggio di Unconscious Clan quando la condivisione dell’addon è attiva. Il flusso include anche il progresso dei punti volo. Il server seleziona lo stato personale usando l’identità del browser e la sorgente attiva del suo Pulser. La modalità del ponte sostituisce la sorgente del browser quando è abilitata. Il ponte aggiorna il proprio programma dalla tray. Per reinstallare l’addon si può riaprire l’installer.

Il menu e il tooltip della tray mostrano la versione del Pulser installata. Il Pulser controlla gli aggiornamenti all’avvio e ogni 10 minuti. Può scaricare direttamente dalla release GitHub e riprovare sulle sorgenti disponibili del server UnCs. Quando trova una nuova release avvisa nella tray. L’installer riusa il percorso di WoW Forever salvato e applica anche l’addon incluso. Con WoW aperto, usare `/reload` dopo l’installazione.

Per Discord usa il [link diretto all’ultimo installer Pulser](https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/latest/download/UnCs-Pulser-Setup.exe). Il workflow allega la stessa copia con nome fisso e con nome versionato, verifica che abbiano lo stesso checksum e pubblica entrambi con lo ZIP dell’addon, i manifesti e i sorgenti. Il server verifica la release pubblica di GitHub ogni 90 secondi quando riceve richieste e mantiene l’ultima release valida o il pacchetto locale come fallback.

## Accesso alla mappa senza Tailscale

Sul server UnCs, il deploy in modalità Pulser con `UNCS_WEB_MAP_IMPORT_ROOT` configurato apre anche un listener su `127.0.0.1:8797` e salva gli accessi in `pulser-access.json` nella cartella persistente di import. In sviluppo si può impostare esplicitamente `UNCS_WEB_ACCESS_FILE` e scegliere una porta con `UNCS_WEB_PUBLIC_PORT`. `UNCS_WEB_PUBLIC_ORIGIN` deve corrispondere all’indirizzo HTTPS visitato dagli utenti. Per UnCs è `https://uncs-server.tail1b66eb.ts.net:10000`. Fare il backup dell’archivio degli accessi insieme agli altri dati persistenti.

La prima volta, dopo aver distribuito la nuova versione e verificato la risposta locale di `http://127.0.0.1:8797/access/status`, inoltrare soltanto il listener dedicato tramite Funnel. Eseguire sul server in una console amministrativa:

```powershell
tailscale funnel --bg --https=10000 http://127.0.0.1:8797
```

Verificare da una rete senza Tailscale che la pagina iniziale chieda l’abbinamento e che `/events` rifiuti un browser non abbinato. La porta privata 8447 resta disponibile per gli utenti esistenti e per l’amministrazione. La mappa privata mostra anche i Pulser attivati che inviano tramite Funnel. Il listener Funnel mostra soltanto le posizioni dei Pulser attivati.

Con un Pulser aggiornato e collegato a Tailscale, l’amministratore della mappa può scegliere **Amministrazione → Crea invito Pulser** dalla tray e passare il codice al gildano dopo aver verificato il personaggio. Il codice scade dopo sette giorni e attiva un solo PC di gioco. QR e link di abbinamento scadono dopo cinque minuti e sono monouso. Il browser mantiene l’abbinamento per 360 giorni o fino alla revoca. Da **Amministrazione → Disattiva un Pulser della gilda** si può revocare il PC di gioco e tutti i browser associati. I gildani abbinati possono aprire la mappa senza WoW attivo.

Il bot dedicato `discord/pulser-bot.mjs` risponde a `/pulser` sul Discord UnCs. Verifica il ruolo **Unconscious Force**, richiede un invito sul collegamento Tailscale amministrativo e lo mostra in un messaggio Discord visibile solo al richiedente. Il server che esegue il bot deve poter raggiungere la porta privata 8447 con l’identità amministrativa della mappa. Il file di configurazione Discord si indica con `UNCS_DISCORD_CONFIG` e rimane fuori dalla repository. Per le dipendenze eseguire `npm ci --omit=dev` nella cartella `discord`.

Su UnCs Server il bot è nella cartella `C:\Users\crewu\UnCsPulserBot` e usa le credenziali del bot già configurato in `UnCsDiscordNews`. L’attività pianificata `UnCs-Pulser-Discord` lo avvia all’accensione con l’account `uncs`; il log è `pulser-bot.log` nella cartella del bot. Il deploy della web app e quello del bot sono distinti: dopo una modifica al bot, sincronizzare i suoi file, installare le dipendenze se cambia il lockfile e riavviare soltanto questa attività.

## Cartografia permanente

Il pacchetto incluso contiene la panoramica scontornata, le tessere di dettaglio, l’allineamento dei continenti, le ricostruzioni di Ironforge e Undercity, le icone originali, 29 mappe di istanza e 330 voci per caverne e miniere. Include i manifesti e le risorse di servizi, raccolta, missioni e bottino.

Configurare `UNCS_WEB_MAP_IMPORT_ROOT` con una cartella persistente, scrivibile dal processo del server. Impostare `UNCS_WEB_MAP_ADMIN` con lo SHA-256 esadecimale del login Tailscale dell’amministratore, senza spazi ai bordi e in minuscolo prima di calcolarne l’hash. Usare Tailscale Serve in modalità privata, così il proxy fornisce l’identità verificata.

Dal menu **Amministrazione → Carica cartografia sul server** del Pulser, selezionare la cartella che contiene `openmap/` e, se presente, `tiles/`. Includere le tessere base e i livelli di dettaglio desiderati, con i relativi manifesti. Il Pulser carica i file cartografici che l’amministratore ha il diritto di condividere. Il server attiva il pacchetto completo dopo il caricamento, conserva la versione attiva al riavvio e la serve anche a WoW e Pulser chiusi. Le posizioni live continuano ad arrivare separatamente.

Per pubblicare nuove immagini o livelli di zoom, preparare un nuovo pacchetto completo e selezionarlo dalla stessa voce della tray. Un’importazione completata prevale sulla revisione cartografica inclusa nel deploy in uso e continua ad applicarsi dopo i riavvii. Quando il deploy include una nuova revisione, il server attiva il nuovo pacchetto conservando le importazioni precedenti su disco. Aggiornare la pagina dopo il completamento per rileggere i manifesti.

Per il mare uniforme, includere `openmap/overview.png` con la terra già scontornata su fondo trasparente. L’immagine deve coprire l’intero atlante, in rapporto 1002 × 668, usando le stesse coordinate delle tessere base. Il renderer ricava dal canale alfa una maschera separata per le tessere di dettaglio. La maschera segue le coste e si estende in corrispondenza dei moli censiti nelle rotte marittime. La panoramica e le tessere originali restano nel pacchetto.

Fare il backup dell’intera cartella, incluso `active.txt`. Il server conserva fino a tre importazioni. Per liberare spazio, rimuovere una versione inattiva, verificando l’identificativo attivo in `active.txt` e che nessun caricamento sia in corso.

### Accesso con Tailscale attivo: porta 10000

La mappa pubblica usa HTTPS sulla porta TCP 10000 e Funnel inoltra le richieste al listener locale 127.0.0.1:8797. Un computer con Tailscale attivo può risolvere lo stesso nome all'indirizzo Tailscale privato del server: in quel caso la connessione è soggetta alle regole di accesso della tailnet, anche se Funnel funziona da Internet. Un ping riuscito non dimostra che la porta TCP sia accessibile.

Per autorizzare un utente Tailscale specifico, l'amministratore apre la console Tailscale, Access controls → JSON editor, e aggiunge `tcp:10000` alla proprietà `ip` del grant già esistente per quell'utente e per il server. Conservare le altre porte e limitare `src` e `dst` ai soggetti necessari. La configurazione corrente autorizza la porta al gruppo UnCs Team; gli accessi e l'abbinamento della WebCompanion restano necessari. Non inserire token o credenziali nella documentazione.

Sul PC interessato verificare:

```powershell
Test-NetConnection uncs-server.tail1b66eb.ts.net -Port 10000
```

Il risultato atteso è `TcpTestSucceeded : True`. Quindi aprire la mappa dalla tray del Pulser e verificare la connessione. La modifica della policy è indipendente dal deploy del codice e dalla pubblicazione del Pulser. Thomas ha confermato il funzionamento con Tailscale attivo dopo l'aggiunta della porta alla regola.

## Dati cartografici e cache locali

Le integrazioni di Thomas usano il pacchetto impostato con `-MapRoot`. Conservare `openmap/overview.png`, le tessere di dettaglio e i manifesti delle città del Companion. Il launcher prepara i layer mancanti nel pacchetto locale, fuori dalla cartella di WoW. Usare `-GameRoot` se WoW Forever è in un percorso personalizzato.

| Risorsa | Origine e utilizzo |
| --- | --- |
| `openmap/services.json` e `tiles/icons/` | Il generatore dei servizi legge QuestieDB Forever e le tabelle delle mappe di WoW. Le icone delle categorie e dei trasporti provengono dal client. La ricerca e il filtro per professione usano i dati del pacchetto. |
| `openmap/dungeon-journal.json` | Missioni, origini e bottino derivano da QuestieDB Forever e dai dati supplementari di AllTheThings inclusi nei sorgenti. ForeverDungeonJournal resta un riferimento. |
| `tiles/interiors.json`, `tiles/i*/`, `tiles/rooms/`, `openmap/caves.json` | Mappe interne dei dungeon, risorse delle stanze e geometria delle caverne ricavate dalla cartografia del client. La disponibilità dipende dalle risorse presenti. |
| `openmap/loot-items-v1.json` e `openmap/loot-icons/` | Schede e texture originali del bottino preparate dai dati locali di WoW. Il launcher riusa le risorse già generate e aggiorna le schede se il catalogo, la build del gioco o i dati della cache sono più recenti. |
| `openmap/gathering-v1.json` | Requisiti per zona. Estrazione mineraria ed Erbalismo incrociano i nodi censiti in QuestieDB Forever con la tabella dei requisiti nel client. La Pesca usa i valori Classic per l’area. La Scuoiatura stima i requisiti dai livelli dei mostri noti come scuoiabili. Il launcher rigenera il file quando rileva una build del gioco o un catalogo QuestieDB più recente. |

OpenMap è una fonte di riferimento per alcuni nomi, intervalli e posizioni. Le rotte si basano anche sui tracciati registrati nelle tabelle di WoW Forever. I layer statici si consultano a gioco spento quando il pacchetto contiene già i dati. Le attribuzioni sono in `THIRD-PARTY-LICENSES`.

Per i punti volo, l’addon UnCs osserva i dati della mappa del maestro di volo e il Pulser riusa i punti confermati dalla propria cache per personaggio. Se sono presenti dati OpenMap di quel personaggio, il Pulser può importare come testo i punti già noti in sola lettura. Le conferme successive funzionano anche con il solo addon UnCs. Il Pulser salva il progresso nel suo profilo, fuori da WoW.

Per distribuire le integrazioni, compilare il renderer a partire dal checkout privato e distribuire insieme i moduli `web/*.cjs` e `desktop/out/renderer/` con la sua cartografia. Verificare `/healthz`, la panoramica, le icone e l’apertura degli interni sul server. Il workflow della release Pulser compila il ponte e include l’addon dallo stesso sorgente. Pubblicare la versione con il manifesto generato dalla build affinché il Pulser installato la rilevi.

Il Pulser usa le coordinate fornite da WoW quando disponibili. In alternativa legge la minimappa a schermo e prepara le risorse dell’istanza dalla copia di WoW in sola lettura. La cache risiede nel profilo del Pulser. Le coordinate interne vengono restituite al browser associato al Pulser. Per le coordinate trasmesse da un altro Pulser, il server verifica che entrambi i giocatori risultino nello stesso gruppo e sulla stessa mappa di istanza.
