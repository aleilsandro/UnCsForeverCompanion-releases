!include nsDialogs.nsh

!define UNCS_BRIDGE_RUN "UnCs Forever Web Bridge"
!define UNCS_BRIDGE_SETUP "Software\UnCsForeverWebBridge"
!define UNCS_BRIDGE_SHORTCUT "UnCs Forever Web.lnk"

!ifndef BUILD_UNINSTALLER
  Var WowPath
  Var WowInput
  Var LoginBox
  Var LoginChecked

  !macro customPageAfterChangeDir
    Page custom UnCsShowWow UnCsReadWow

  Function UnCsShowWow
    ${If} ${isUpdated}
      Abort
    ${EndIf}
    ${If} $WowPath == ""
      ReadRegStr $WowPath HKCU "${UNCS_BRIDGE_SETUP}" "WoW"
    ${EndIf}
    ${If} $LoginChecked == ""
      StrCpy $LoginChecked ${BST_CHECKED}
      ReadRegStr $0 HKCU "${UNCS_BRIDGE_SETUP}" "WoW"
      ReadRegStr $1 HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${UNCS_BRIDGE_RUN}"
      ${If} $0 != ""
      ${AndIf} $1 == ""
        StrCpy $LoginChecked ${BST_UNCHECKED}
      ${EndIf}
    ${EndIf}
    !insertmacro MUI_HEADER_TEXT "World of Warcraft Forever" "Seleziona la cartella di gioco per installare l'addon UnCs."
    nsDialogs::Create 1018
    Pop $0
    ${If} $0 == error
      Abort
    ${EndIf}
    ${NSD_CreateLabel} 0 0 100% 24u "Scegli la cartella World of Warcraft o direttamente la cartella _forever_."
    Pop $0
    ${NSD_CreateDirRequest} 0 29u 75% 13u "$WowPath"
    Pop $WowInput
    ${NSD_CreateBrowseButton} 77% 28u 23% 15u "Sfoglia..."
    Pop $0
    ${NSD_OnClick} $0 UnCsBrowseWow
    ${NSD_CreateCheckbox} 0 58u 100% 14u "Avvia UnCs Pulser al login di Windows"
    Pop $LoginBox
    ${NSD_SetState} $LoginBox $LoginChecked
    ${NSD_CreateLabel} 0 79u 100% 32u "UnCs Pulser invia al server la posizione del tuo personaggio quando la condivisione nell'addon e' attiva. La mappa si apre dal collegamento sul desktop."
    Pop $0
    nsDialogs::Show
  FunctionEnd

  Function UnCsBrowseWow
    Pop $0
    ${NSD_GetText} $WowInput $WowPath
    nsDialogs::SelectFolderDialog "Seleziona la cartella World of Warcraft" "$WowPath"
    Pop $0
    ${If} $0 != "error"
      ${NSD_SetText} $WowInput $0
    ${EndIf}
  FunctionEnd

  Function UnCsReadWow
    ${NSD_GetText} $WowInput $WowPath
    ${NSD_GetState} $LoginBox $LoginChecked
    ${IfNot} ${FileExists} "$WowPath\_forever_\Wow.exe"
    ${AndIfNot} ${FileExists} "$WowPath\Wow.exe"
      MessageBox MB_ICONEXCLAMATION|MB_OK "Non trovo WoW Forever nella cartella indicata."
      Abort
    ${EndIf}
  FunctionEnd
  !macroend

  !macro customInstall
    ${If} $WowPath == ""
      ReadRegStr $WowPath HKCU "${UNCS_BRIDGE_SETUP}" "WoW"
    ${EndIf}
    ${If} $WowPath == ""
      SetErrorLevel 11
      Abort "Cartella WoW Forever non selezionata."
    ${EndIf}
    ExecWait '"$INSTDIR\resources\uncs-helper.exe" --install-bridge-addon "$WowPath" "$INSTDIR\resources\bridge-addon.zip"' $0
    ${If} $0 != "0"
      SetErrorLevel 12
      Abort "Impossibile installare l'addon. Controlla la cartella WoW Forever e i permessi."
    ${EndIf}
    WriteRegStr HKCU "${UNCS_BRIDGE_SETUP}" "WoW" "$WowPath"
    ${IfNot} ${isUpdated}
      ${If} $LoginChecked == ${BST_CHECKED}
        WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${UNCS_BRIDGE_RUN}" '"$appExe"'
      ${ElseIf} $LoginChecked != ""
        DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${UNCS_BRIDGE_RUN}"
      ${EndIf}
    ${EndIf}
    Delete "$DESKTOP\UnCs Forever Web.url"
    CreateShortCut "$DESKTOP\${UNCS_BRIDGE_SHORTCUT}" "$appExe" "--open-map" "$INSTDIR\resources\bridge.ico"
  !macroend
!endif

!macro customUnInstall
  ${IfNot} ${isUpdated}
    DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${UNCS_BRIDGE_RUN}"
    DeleteRegKey HKCU "${UNCS_BRIDGE_SETUP}"
    Delete "$DESKTOP\${UNCS_BRIDGE_SHORTCUT}"
    Delete "$DESKTOP\UnCs Forever Web.url"
  ${EndIf}
!macroend
