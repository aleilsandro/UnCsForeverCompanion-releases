// Windows helper for installing and replacing the UnCs addon.
using System;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace UnCsInstaller {
  static class AddonFiles {
    public static string Destination(string addons,string addon,string name) {
      if(String.IsNullOrEmpty(name) || name.Contains("\\") || name.Contains(":"))throw new InvalidOperationException("Percorso non valido nello ZIP.");
      var parts=name.Split('/'); if(parts.Any(p=>p=="." || p=="..") || parts[0]!=addon)throw new InvalidOperationException("Lo ZIP non contiene solo la cartella addon attesa.");
      string root=Path.GetFullPath(Path.Combine(addons,addon)).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
      string target=Path.GetFullPath(Path.Combine(addons,name.Replace('/',Path.DirectorySeparatorChar)));
      if(!target.StartsWith(root,StringComparison.OrdinalIgnoreCase) && !target.Equals(root.TrimEnd(Path.DirectorySeparatorChar),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Percorso fuori dalla cartella addon.");
      return target;
    }
    public static void Install(string zip,string addons,string addon) {
      using(var archive=ZipFile.OpenRead(zip)) {
        bool toc=false;long total=0,limit=(addon=="OpenMap" ? 1536L : 250L)*1024*1024;
        foreach(var entry in archive.Entries) {Destination(addons,addon,entry.FullName);total+=entry.Length;if(total>limit)throw new InvalidOperationException("Archivio addon troppo grande.");if(entry.FullName.Equals(addon+"/"+addon+".toc",StringComparison.OrdinalIgnoreCase))toc=true;}
        if(!toc)throw new InvalidOperationException("Il TOC dell’addon non è presente nello ZIP.");
        foreach(var entry in archive.Entries) {string target=Destination(addons,addon,entry.FullName);if(entry.FullName.EndsWith("/")){Directory.CreateDirectory(target);continue;}Directory.CreateDirectory(Path.GetDirectoryName(target));using(var input=entry.Open())using(var output=new FileStream(target,FileMode.Create,FileAccess.Write,FileShare.None))input.CopyTo(output);}
      }
    }
    public static void Update(string zip,string addons) {
      const string addon="UnCsForeverCompanion";
      Directory.CreateDirectory(addons);
      string work=Path.Combine(addons,".u"+Guid.NewGuid().ToString("N").Substring(0,8));
      string current=Path.Combine(addons,addon), staged=Path.Combine(work,addon), backup=Path.Combine(work,"previous");
      bool backedUp=false;
      try {
        Directory.CreateDirectory(work);Install(zip,work,addon);
        if(Directory.Exists(current)){Directory.Move(current,backup);backedUp=true;}
        try {Directory.Move(staged,current);} catch {if(backedUp)Directory.Move(backup,current);throw;}
      } finally {try {if(Directory.Exists(work) && (!backedUp || Directory.Exists(current)))Directory.Delete(work,true);}catch{}}
    }
  }
  static class Program {
    static int Main(string[] args) {
      if(args.Length==3 && args[0]=="--install-bridge-addon") {
        try {
          string root=Path.GetFullPath(args[1]);
          string forever=File.Exists(Path.Combine(root,"_forever_","Wow.exe")) ? Path.Combine(root,"_forever_") : root;
          if(!String.Equals(Path.GetFileName(forever.TrimEnd('\\')),"_forever_",StringComparison.OrdinalIgnoreCase) || !File.Exists(Path.Combine(forever,"Wow.exe")))return 11;
          AddonFiles.Update(args[2],Path.Combine(forever,"Interface","AddOns"));
          return 0;
        }catch{return 12;}
      }
      if(args.Length==3 && args[0]=="--update-addon") {
        try {AddonFiles.Update(args[2],args[1]);return 0;}catch{return 10;}
      }
      if(args.Length==1 && args[0]=="--self-test") {
        string test=Path.Combine(Path.GetTempPath(),"ut"+Guid.NewGuid().ToString("N").Substring(0,8));
        try {
          Directory.CreateDirectory(test);string root=Path.Combine(test,"AddOns");
          AddonFiles.Destination(root,"OpenMap","OpenMap/OpenMap.toc");
          try{AddonFiles.Destination(root,"OpenMap","OpenMap/../evil");return 1;}catch(InvalidOperationException){}
          try{AddonFiles.Destination(root,"OpenMap","Unrelated/Unrelated.toc");return 2;}catch(InvalidOperationException){}
          string zip=Path.Combine(test,"valid.zip");
          using(var archive=ZipFile.Open(zip,ZipArchiveMode.Create))using(var writer=new StreamWriter(archive.CreateEntry("OpenMap/OpenMap.toc").Open()))writer.Write("## Interface: 16001");
          AddonFiles.Install(zip,root,"OpenMap");
          if(!File.Exists(Path.Combine(root,"OpenMap","OpenMap.toc")))return 3;
          string addonZip=Path.Combine(test,"addon.zip");
          using(var archive=ZipFile.Open(addonZip,ZipArchiveMode.Create))using(var writer=new StreamWriter(archive.CreateEntry("UnCsForeverCompanion/UnCsForeverCompanion.toc").Open()))writer.Write("## Version: 2.0.0");
          string old=Path.Combine(root,"UnCsForeverCompanion");Directory.CreateDirectory(old);File.WriteAllText(Path.Combine(old,"old.txt"),"old");
          AddonFiles.Update(addonZip,root);
          if(!File.Exists(Path.Combine(old,"UnCsForeverCompanion.toc")) || File.Exists(Path.Combine(old,"old.txt")))return 7;
          try {AddonFiles.Update(zip,root);return 8;}catch(InvalidOperationException){}
          if(!File.Exists(Path.Combine(old,"UnCsForeverCompanion.toc")))return 9;
          return 0;
        }catch{return 6;}finally{try{Directory.Delete(test,true);}catch{}}
      }
      return 2;
    }
  }
}
