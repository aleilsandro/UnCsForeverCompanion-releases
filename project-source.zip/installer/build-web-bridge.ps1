param([switch]$Unpacked, [string]$Version)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$desktop = Join-Path $root 'desktop'
$resources = Join-Path $desktop 'bridge-resources'
$addon = Join-Path $resources 'UnCsForeverCompanion'
$manifest = Join-Path $root 'UnCsForeverCompanion.toc'
$package = Get-Content -LiteralPath (Join-Path $desktop 'package.json') -Raw | ConvertFrom-Json
if (!$Version) { $Version = $package.version }
if ($Version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versione del pacchetto non valida.' }

New-Item -ItemType Directory -Path $resources,$addon -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $root 'design\pulser.ico') -Destination (Join-Path $resources 'bridge.ico') -Force
Copy-Item -LiteralPath (Join-Path $root 'LICENSE') -Destination (Join-Path $resources 'LICENSE.txt') -Force
Copy-Item -LiteralPath (Join-Path $root 'THIRD-PARTY-LICENSES') -Destination (Join-Path $resources 'THIRD-PARTY-LICENSES.txt') -Force
Copy-Item -LiteralPath $manifest -Destination $addon -Force
Get-Content -LiteralPath $manifest | ForEach-Object {
    $name = $_.Trim()
    if (!$name -or $name.StartsWith('#')) { return }
    if ($name -notmatch '^[\w.-]+\.lua$') { throw "Percorso addon non previsto: $name" }
    Copy-Item -LiteralPath (Join-Path $root $name) -Destination $addon -Force
}
Compress-Archive -LiteralPath $addon -DestinationPath (Join-Path $resources 'bridge-addon.zip') -Force
@'
provider: generic
url: https://uncs-server.tail1b66eb.ts.net:8447/bridge/releases/
updaterCacheDirName: uncs-forever-web-bridge-updater
'@ | Set-Content -LiteralPath (Join-Path $resources 'app-update.yml') -Encoding ascii

$helper = Join-Path $resources 'uncs-helper.exe'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
& $compiler /nologo /target:winexe "/out:$helper" /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll (Join-Path $PSScriptRoot 'PulserAddonHelper.cs')
if ($LASTEXITCODE -ne 0) { throw 'Compilazione del helper non riuscita.' }
$test = Start-Process -FilePath $helper -ArgumentList '--self-test' -WindowStyle Hidden -Wait -PassThru
if ($test.ExitCode -ne 0) { throw "Autotest del helper fallito: $($test.ExitCode)" }

Push-Location $desktop
try {
    node .\node_modules\electron-vite\bin\electron-vite.js build --config electron.bridge.vite.config.ts
    if ($LASTEXITCODE -ne 0) { throw 'Compilazione del ponte non riuscita.' }
    $targetArgs = if ($Unpacked) { @('--win', '--dir') } else { @('--win', 'nsis') }
    node .\node_modules\electron-builder\out\cli\cli.js --config bridge-builder.json "--config.extraMetadata.version=$Version" @targetArgs --publish never
    if ($LASTEXITCODE -ne 0) { throw 'Creazione del pacchetto Windows non riuscita.' }
    if (!$Unpacked) {
        $name = "UnCs-Forever-Web-Setup-$Version.exe"
        $exe = Get-Item -LiteralPath (Join-Path 'dist-bridge' $name)
        $stream = $exe.OpenRead()
        $sha = [Security.Cryptography.SHA512]::Create()
        try { $digest = [Convert]::ToBase64String($sha.ComputeHash($stream)) } finally { $sha.Dispose(); $stream.Dispose() }
        @"
version: $Version
files:
  - url: $name
    sha512: $digest
    size: $($exe.Length)
path: $name
sha512: $digest
"@ | Set-Content -LiteralPath 'dist-bridge\latest.yml' -Encoding ascii
        $exe.FullName
    }
} finally { Pop-Location }
