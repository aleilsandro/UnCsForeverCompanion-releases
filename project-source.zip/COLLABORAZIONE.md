# Lavorare insieme

Il repository privato `aleilsandro/UnCsForeverCompanion` contiene il progetto di sviluppo:

- radice: addon WoW;
- `desktop/`: renderer della mappa, sorgenti del Pulser e codice condiviso;
- `web/`: server privato, posizioni e cartografia;
- `installer/`: build del setup Pulser e helper di installazione dell’addon;
- `design/`: proposte e risorse precedenti di riferimento.

La vecchia cartella locale `app/` è esterna a Git: non è sincronizzata. Lavorare invece su `desktop/` dentro questo repository. `node_modules/`, cache, installer compilati e cartelle di build non vengono inviati: si possono rigenerare. Non inserire token o dati personali nel repository.

## I branch

Alessandro usa `aleilsandro`. Thomas usa `thomas`. Entrambi partono da `main` e possono scambiarsi modifiche tramite pull request. Il link alla repository privata richiede l'accesso GitHub autorizzato.

Thomas, dopo aver accettato l'invito, può clonare il repository e selezionare il suo branch:

```sh
git clone https://github.com/aleilsandro/UnCsForeverCompanion.git
cd UnCsForeverCompanion
git switch thomas
```

Prima di lavorare, controllare che il proprio branch sia quello previsto e recuperare le sue modifiche:

```sh
git status
git pull --ff-only
```

Dopo avere verificato le modifiche, salvarle e inviarle dal proprio branch:

```sh
git add <file-da-salvare>
git commit -m "Descrizione delle modifiche"
git push
```

Per sincronizzare i file su GitHub servono commit e push. Quando `main` cambia, aggiorna il tuo branch con la skill 1. Per integrare il tuo lavoro in `main`, usa la skill 2 oppure apri una pull request.

## Skill Codex condivise

Le tre skill condivise sono in `.agents/skills/`. Apri il clone del Companion come cartella del progetto in Codex. Per richiamare una skill in chat, digita `$` e cerca il suo nome, oppure scrivi il nome completo nel messaggio. Se il selettore non si aggiorna dopo aver aggiornato il clone, riapri Codex. Puoi anche chiedere a Codex di leggere il relativo `SKILL.md`.

- **1 — Main to Branch** · `$1-main-to-branch` integra `origin/main` nel branch personale corrente con un merge, conserva i commit e invia il risultato al suo remoto.
- **2 — Branch to Main** · `$2-branch-to-main` integra il branch personale corrente in `main`, incrementa la versione patch e invia `main` dopo le verifiche.
- **3 — Aggiorna documentazione** · `$3-aggiorna-documentazione` legge gli Markdown e ricostruisce il lavoro recente da stato Git, diff, cronologia e verifiche. Aggiorna i documenti pertinenti con le modifiche confermate e lo stato effettivo della distribuzione.

Le skill 1 e 2 verificano lo stato Git e preservano il lavoro locale quando trovano conflitti o modifiche incerte.

Il repository pubblico dei download è separato. Un push su un branch di sviluppo o su `main` non pubblica automaticamente una nuova release: la pubblicazione pubblica resta un passaggio distinto.
