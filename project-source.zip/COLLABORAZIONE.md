# Lavorare insieme

Il repository privato `aleilsandro/UnCsForeverCompanion` contiene il progetto di sviluppo:

- radice: addon WoW;
- `desktop/`: renderer della mappa, sorgenti del Pulser e codice condiviso;
- `web/`: server privato, posizioni e cartografia;
- `installer/`: build del setup Pulser e helper di installazione dell’addon;
- `design/`: proposte e risorse precedenti di riferimento.

La vecchia cartella locale `app/` è esterna a Git: non è sincronizzata. Lavorare invece su `desktop/` dentro questo repository. `node_modules/`, cache, installer compilati e cartelle di build non vengono inviati: si possono rigenerare. Non inserire token o dati personali nel repository.

## I branch

Alessandro usa `aleilsandro`. Thomas usa `thomas`. Entrambi partono da `main` e possono scambiarsi modifiche tramite pull request. Il link alla repository privata richiede l'accesso GitHub autorizzato.

Thomas, dopo aver accettato l'invito, può clonare il repository e selezionare il suo branch:

```sh
git clone https://github.com/aleilsandro/UnCsForeverCompanion.git
cd UnCsForeverCompanion
git switch thomas
```

Prima di lavorare, controllare che il proprio branch sia quello previsto e recuperare le sue modifiche:

```sh
git status
git pull --ff-only
```

Dopo avere verificato le modifiche, salvarle e inviarle dal proprio branch:

```sh
git add <file-da-salvare>
git commit -m "Descrizione delle modifiche"
git push
```

Per sincronizzare i file su GitHub servono commit e push. Quando `main` cambia, aggiorna il tuo branch con la skill 1. Per integrare il tuo lavoro in `main`, usa la skill 2 oppure apri una pull request.

## Web app locale sul PC di Thomas

Sviluppa nel branch `thomas` e prova la mappa su Windows all’indirizzo `http://127.0.0.1:18796/`. Alessandro gestisce la web app online sul server UnCs. La copia locale usa lo stesso renderer e lo stesso server web del progetto.

1. Installa **Node.js 24** con npm, **Git** e **PowerShell 7**. Apri il progetto in Codex dalla root del tuo clone.
2. Aggiorna il branch secondo il flusso sopra. Per partire dalla versione del server, verifica con Alessandro la versione e il commit mostrati da **UnCs Deploy → Server live**. Integra `origin/main` con la skill 1 quando corrisponde al deploy. Per riprodurre un deploy precedente con precisione, usa un checkout separato del commit indicato, lasciando il branch di lavoro dov’è.
3. Dalla root del clone esegui il comando qui sotto una volta. Codex, sul PC di Thomas, può eseguirlo durante il primo setup.

   ```powershell
   pwsh -NoProfile -File web/local.ps1 -InstallShortcut
   ```

4. Sul Desktop apri **UnCs WebCompanion - LOCALE**. Il primo avvio installa le dipendenze dal lockfile. Poi compila il renderer del checkout, avvia il server su `127.0.0.1:18796` e apre il browser dopo il controllo di avvio. Il numero di versione mostrato nella console e su `/healthz` viene da `desktop/package.json`. Il collegamento **UnCs Forever Web** creato dall’installer Pulser apre la mappa online.
5. Dopo modifiche al codice, premi **Ctrl+C** nella finestra locale e riapri il collegamento per ricompilare. Se sposti il clone, riesegui il comando del punto 3 per aggiornare il percorso del collegamento.

Il checkout privato include la cartografia sotto `desktop/src/renderer/public/cartography/`. Il launcher la usa di default. Per provare un pacchetto esterno autorizzato, indica la cartella che contiene `openmap/manifest.json`. Il percorso viene salvato solo nel tuo checkout. Un esempio:

```powershell
pwsh -NoProfile -File web/local.ps1 -MapRoot 'D:\MappeUnCs' -InstallShortcut
```

Puoi avviare la stessa app dal terminale con `pwsh -NoProfile -File web/local.ps1`. interfaccia ma’interfaccia, ma le immagini della mappa non saranno disponibili. Le posizioni live e gli abbinamenti della produzione non vengono copiati nella sessione locale.

Per avviare anche il Pulser locale, usa uno di questi comandi dalla radice dei sorgenti:

```powershell
pwsh -NoProfile -File web/local.ps1 -Pulser
pwsh -NoProfile -File web/local.ps1 -InstallShortcut -Pulser
```

Il primo avvia web app e Pulser. Il secondo crea il collegamento con l’opzione Pulser. Il launcher prepara servizi, dungeon, caverne, schede del bottino e requisiti di raccolta nel pacchetto locale quando i dati necessari sono disponibili. Per verificare i livelli statici puoi tenere WoW chiuso. Per verificare posizioni e punti volo personali, usa WoW con l’addon UnCs e controlla lo stato della cattura nella tray.

Durante le prove, leggi le risorse, la cache e i dati già salvati da WoW. Scrivi le risorse derivate nel pacchetto cartografico e il progresso di volo nel profilo del Pulser. Lascia intatta l’installazione di gioco e usa i layer per aggiungere informazioni sopra la cartografia originale. I dettagli delle funzioni sono nel [README](README.md#integrazioni-di-thomas) e nella [guida web](web/README.md#dati-cartografici-e-cache-locali).

Se il commit da riprodurre precede il launcher, copia solo `web/local.ps1` nel suo checkout di prova. Avvialo dal terminale, così il collegamento sul Desktop resta associato al branch di sviluppo. Ferma prima l’altra istanza locale, perché entrambe usano la porta 18796.

## Skill Codex condivise

Le tre skill condivise sono in `.agents/skills/`. Apri il clone del Companion come cartella del progetto in Codex. Per richiamare una skill in chat, digita `$` e cerca il suo nome, oppure scrivi il nome completo nel messaggio. Se il selettore non si aggiorna dopo aver aggiornato il clone, riapri Codex. Puoi anche chiedere a Codex di leggere il relativo `SKILL.md`.

- **1 — Main to Branch** · `$1-main-to-branch` aggiorna prima la `main` locale con `git pull --ff-only origin main`, poi torna sul branch personale, integra quel commit e invia il risultato dopo le verifiche.
- **2 — Branch to Main** · `$2-branch-to-main` integra il branch personale corrente in `main`, incrementa la versione patch e invia `main` dopo le verifiche.
- **3 — Aggiorna documentazione** · `$3-aggiorna-documentazione` legge gli Markdown e ricostruisce il lavoro recente da stato Git, diff, cronologia e verifiche. Aggiorna i documenti pertinenti con le modifiche confermate e lo stato effettivo della distribuzione.

Le skill 1 e 2 verificano lo stato Git e preservano il lavoro locale quando trovano conflitti o modifiche incerte.

Il repository pubblico dei download è separato. Un push su un branch di sviluppo o su `main` non pubblica automaticamente una nuova release: la pubblicazione pubblica resta un passaggio distinto.
