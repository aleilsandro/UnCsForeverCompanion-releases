param(
    [Parameter(Mandatory)][ValidatePattern('^\d+\.\d+\.\d+$')][string]$Version
)

$ErrorActionPreference = 'Stop'
$installer = "UnCs-Forever-Web-Setup-$Version.exe"
$alias = 'UnCs-Pulser-Setup.exe'
$addon = "UnCsForeverCompanion-$Version-forever.zip"
$source = "UnCsForeverCompanion-source-$Version.zip"
$folder = 'desktop/dist-bridge'
$manifestPath = "$folder/latest.yml"
$files = @("$folder/$installer", "$folder/$alias", $manifestPath, "$folder/pulser-latest.yml", "release-assets/$addon", 'release-assets/release.json', $source)

$manifest = Get-Content -Raw -LiteralPath $manifestPath
$size = (Get-Item -LiteralPath "$folder/$installer").Length
$sha = [Convert]::ToBase64String([Convert]::FromHexString((Get-FileHash -LiteralPath "$folder/$installer" -Algorithm SHA512).Hash))
if ($manifest -notmatch "(?m)^version: $([regex]::Escape($Version))\s*$" -or
    $manifest -notmatch "(?m)^path: $([regex]::Escape($installer))\s*$" -or
    $manifest -notmatch "(?m)^sha512: $([regex]::Escape($sha))\s*$" -or
    $manifest -notmatch "(?m)^    size: $size\s*$") { throw "Il manifesto non corrisponde all'installer." }

$metadata = Get-Content -Raw -LiteralPath 'release-assets/release.json' | ConvertFrom-Json
if (!($metadata.releases | Where-Object { $_.filename -eq $addon -and $_.version -eq $Version })) {
    throw 'Il pacchetto addon non corrisponde alla versione del Pulser.'
}
Copy-Item -LiteralPath $manifestPath -Destination "$folder/pulser-latest.yml"
Copy-Item -LiteralPath "$folder/$installer" -Destination "$folder/$alias"
Copy-Item -LiteralPath 'project-source.zip' -Destination $source
$expected = $files | ForEach-Object { Get-Item -LiteralPath $_ }

function Read-Release {
    $query = '.[] | select(.tag_name == "' + $Version + '")'
    $json = gh api "repos/$env:GITHUB_REPOSITORY/releases?per_page=100" --paginate --jq $query
    if ($LASTEXITCODE) { throw 'Impossibile leggere le release pubbliche.' }
    if ($json) { return $json | ConvertFrom-Json }
}

function Confirm-InstallerAlias($Release) {
    $versioned = $Release.assets | Where-Object name -eq $installer
    $stable = $Release.assets | Where-Object name -eq $alias
    if ($versioned.digest -notmatch '^sha256:[a-f0-9]{64}$' -or $stable.digest -ne $versioned.digest -or $stable.size -ne $versioned.size) {
        throw 'Il download con nome fisso non coincide con il setup della release.'
    }
}

$release = Read-Release
if ($release -and !$release.draft) {
    foreach ($file in $expected) {
        if (!($release.assets | Where-Object { $_.name -eq $file.Name -and $_.state -eq 'uploaded' -and $_.size -gt 0 })) {
            throw 'La versione risulta già pubblicata con allegati mancanti. Verifica la release prima di riprovare.'
        }
    }
    Confirm-InstallerAlias $release
    'Release già pubblicata con tutti gli allegati.'
    return
}
if (!$release) {
    gh release create $Version --verify-tag --draft --title "UnCs Pulser $Version" --notes 'Pulser e addon WoW Forever. I sorgenti corrispondenti sono allegati.'
    if ($LASTEXITCODE) { throw 'Creazione bozza fallita.' }
}
for ($attempt = 1; $attempt -le 3; $attempt++) {
    gh release upload $Version @files --clobber
    if (!$LASTEXITCODE) { break }
    if ($attempt -eq 3) { throw 'Upload fallito: la release rimane in bozza e può essere riprovata.' }
    Start-Sleep -Seconds (5 * $attempt)
}
$release = Read-Release
if (!$release -or !$release.draft) { throw 'La bozza della release non è verificabile.' }
foreach ($file in $expected) {
    if (!($release.assets | Where-Object { $_.name -eq $file.Name -and $_.state -eq 'uploaded' -and $_.size -eq $file.Length })) {
        throw "Allegato non verificato: $($file.Name)"
    }
}
Confirm-InstallerAlias $release
gh api "repos/$env:GITHUB_REPOSITORY/releases/$($release.id)" --method PATCH -F draft=false -f make_latest=legacy --jq .html_url
if ($LASTEXITCODE) { throw 'Pubblicazione della release non riuscita.' }
