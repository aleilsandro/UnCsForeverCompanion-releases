---
name: 3-aggiorna-documentazione
description: Rileva il lavoro recente in UnCs Forever Companion e aggiorna gli Markdown del progetto con modifiche confermate, verifiche, stato delle release e istruzioni operative.
---

# Aggiornare la documentazione del Companion

Usa questa skill quando Alessandro o Thomas chiede di riallineare gli Markdown del progetto al lavoro recente, anche con una richiesta breve come «aggiorna tutti gli MD».

1. Leggi `AGENTS.md` e `COLLABORAZIONE.md`. Individua gli Markdown del repository con `git ls-files -- '*.md'` e controlla anche i nuovi Markdown del lavoro corrente. Leggi i documenti mantenuti dal progetto. Usa le istruzioni delle skill come contesto. Apri documenti di terze parti solo se servono per verificare un riferimento.
2. Ricostruisci cosa è cambiato con `git status --short --branch`, i diff staged e unstaged e la cronologia del branch. Confronta il lavoro con `origin/main...HEAD` se disponibile e con i commit recenti già integrati quando pertinente. Verifica le istruzioni e i numeri di versione nei sorgenti, nei manifesti e nei workflow. Usa le evidenze disponibili per distinguere una modifica committata, una build verificata e una release pubblicata.
3. Aggiorna ciascun documento per il suo pubblico. Usa il README per avvio e installazione, `web/README.md` per Pulser e server, `COLLABORAZIONE.md` per il lavoro condiviso e `AGENTS.md` per le istruzioni permanenti a Codex. Se esiste un changelog pertinente, registravi le modifiche destinate agli utenti. Mantieni le informazioni storiche, evita duplicazioni e correggi collegamenti e nomi superati.
4. Verifica i percorsi e i riferimenti incrociati, rileggi il diff degli Markdown e usa `git -c core.whitespace=cr-at-eol diff --check`. Riporta i documenti aggiornati e i fatti non ancora verificabili. L'aggiornamento documentale da solo non autorizza merge, tag o deploy. Segui `AGENTS.md` per eventuale commit e push già autorizzati.
