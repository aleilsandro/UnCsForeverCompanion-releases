---
name: 1-main-to-branch
description: Integra origin/main nel branch personale corrente di UnCs Forever Companion con un merge che conserva i commit, verifica e invia il branch; non modifica main né pubblica release.
---

# Aggiornare il branch personale da main

Usa questa skill quando l'utente chiede di integrare `main` nel proprio branch di UnCs Forever Companion. Alessandro usa normalmente `aleilsandro` e Thomas `thomas`: rileva il branch corrente, non dedurlo dal nome dell'account. L'invocazione autorizza fetch, merge, verifiche e push normale del branch corrente, nei limiti dell'ambiente.

1. Leggi `AGENTS.md` e `COLLABORAZIONE.md`, verifica root e remoto del repository, branch corrente non `main` e non detached, stato Git e operazioni Git eventualmente in corso. Non intervenire su altri branch. Se ci sono modifiche non committate, non cancellarle né includerle automaticamente: esaminale e metti in sicurezza soltanto quelle per cui hai autorizzazione chiara; altrimenti fermati spiegando cosa rimane da fare.
2. Esegui `git fetch origin`; verifica che il branch remoto personale esista e che la sua punta sia già contenuta nel branch locale. Non sovrascrivere lavoro remoto: se è divergente, fermati e mostra gli SHA. Memorizza SHA iniziale del branch e di `origin/main`.
3. Integra il commit esatto di `origin/main` nel branch corrente con `git merge --no-edit <SHA-main>`, senza rebase o riscrittura della storia. Se ci sono conflitti, preserva lo stato e risolvili solo quando il contenuto e l'intento sono sufficientemente chiari; non usare una scelta globale `ours`/`theirs`. Se incerti, fermati indicando i file.
4. Verifica che gli SHA iniziali di entrambi i rami siano antenati del risultato, esegui `git diff --check` e i test pertinenti alle modifiche integrate. Se falliscono, mantieni lo stato recuperabile e segnala il problema.
5. Fai un push normale del branch corrente, mai force push, e verifica lo SHA sul remoto. Se il remoto è avanzato o rifiuta il push, fermati senza sovrascriverlo.

Riporta branch, SHA di partenza e finali, eventuale merge, test ed esito del push. Non modificare `main`, tag o release pubbliche.
