---
name: 1-main-to-branch
description: Aggiorna main locale con un pull da GitHub, poi integra quel commit nel branch personale di UnCs Forever Companion, lo verifica e lo sincronizza.
---

# Aggiornare il branch personale da main

Usa questa skill quando l'utente chiede di integrare `main` nel proprio branch di UnCs Forever Companion. Alessandro usa normalmente `aleilsandro` e Thomas `thomas`: rileva il branch corrente, non dedurlo dal nome dell'account. L'invocazione autorizza fetch, pull, merge, verifiche e push normale del branch corrente, nei limiti dell'ambiente.

1. Leggi `AGENTS.md` e `COLLABORAZIONE.md`, verifica root e remoto del repository, branch corrente non `main` e non detached, stato Git e operazioni Git eventualmente in corso. Aggiorna in locale solo main e il branch personale. Se ci sono modifiche non committate, non cancellarle né includerle automaticamente: esaminale e metti in sicurezza soltanto quelle per cui hai autorizzazione chiara; altrimenti fermati spiegando cosa rimane da fare.
2. Esegui `git fetch origin`; verifica che il branch remoto personale esista e che la sua punta sia già contenuta nel branch locale. Non sovrascrivere lavoro remoto: se è divergente, fermati e mostra gli SHA. Memorizza lo SHA iniziale e il nome del branch personale.
3. Con la copia di lavoro pulita, passa a `main` con `git switch main` ed esegui `git pull --ff-only origin main`. Prima di procedere verifica che `main` coincida con `origin/main` e registra lo SHA. Se il pull fallisce o gli SHA non coincidono, torna al branch personale se possibile e segnala il problema. Dopo un pull riuscito, torna al branch personale e integra lo SHA esatto della main appena aggiornata con `git merge --no-edit <SHA-main>`, senza rebase o riscrittura della storia. Se ci sono conflitti, preserva lo stato e risolvili solo quando il contenuto e l'intento sono sufficientemente chiari; non usare una scelta globale `ours`/`theirs`. Se incerti, fermati indicando i file.
4. Verifica che gli SHA iniziali di entrambi i rami siano antenati del risultato, esegui `git diff --check` e i test pertinenti alle modifiche integrate. Se falliscono, mantieni lo stato recuperabile e segnala il problema.
5. Fai un push normale del branch corrente, mai force push, e verifica lo SHA sul remoto. Se il remoto è avanzato o rifiuta il push, fermati senza sovrascriverlo.

Riporta branch, SHA di partenza e finali, eventuale merge, test ed esito del push. Il pull aggiorna solo la main locale. Il push riguarda solo il branch personale.
