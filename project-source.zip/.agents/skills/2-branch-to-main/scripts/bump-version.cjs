'use strict'
// Call from the repository root after starting the non-committed merge.
const fs = require('node:fs')
const path = require('node:path')

function bump(root) {
  const files = ['UnCsForeverCompanion.toc', 'UnCsForeverCompanion.lua', 'desktop/package.json', 'desktop/package-lock.json']
  const original = files.map(file => fs.readFileSync(path.join(root, file), 'utf8'))
  const tocPattern = /^(## Version:[ \t]*)(\d+\.\d+\.\d+)([ \t\r]*)$/gm
  const luaPattern = /^(ns\.VERSION\s*=\s*")(\d+\.\d+\.\d+)(")/gm
  const findSingle = (text, pattern, label) => {
    const matches = [...text.matchAll(pattern)]
    if (matches.length !== 1) throw new Error(`${label}: serve esattamente una versione MAJOR.MINOR.PATCH`)
    return matches[0][2]
  }
  const oldVersion = findSingle(original[0], tocPattern, 'TOC')
  if (findSingle(original[1], luaPattern, 'Lua') !== oldVersion) throw new Error('Le versioni TOC e Lua non coincidono')
  const parts = oldVersion.split('.').map(Number)
  if (parts.some(n => !Number.isSafeInteger(n)) || parts[2] >= Number.MAX_SAFE_INTEGER) throw new Error('Versione fuori intervallo')
  const version = `${parts[0]}.${parts[1]}.${parts[2] + 1}`
  const pkg = JSON.parse(original[2]), lock = JSON.parse(original[3])
  if (typeof pkg.version !== 'string' || !lock.packages || !lock.packages[''] || typeof lock.packages[''].version !== 'string') throw new Error('Metadati package o lockfile non validi')
  pkg.version = version
  lock.version = version
  lock.packages[''].version = version
  const ending = text => text.endsWith('\r\n') ? '\r\n' : text.endsWith('\n') ? '\n' : ''
  const json = (value, source) => JSON.stringify(value, null, 2).replace(/\n/g, source.includes('\r\n') ? '\r\n' : '\n') + ending(source)
  const replaceVersion = (text, pattern) => text.replace(pattern, (_match, prefix, _previous, suffix) => prefix + version + suffix)
  const updated = [replaceVersion(original[0], tocPattern), replaceVersion(original[1], luaPattern), json(pkg, original[2]), json(lock, original[3])]
  let done = 0
  try { for (; done < files.length; done++) fs.writeFileSync(path.join(root, files[done]), updated[done], 'utf8') }
  catch (error) { for (let i = 0; i < done; i++) fs.writeFileSync(path.join(root, files[i]), original[i], 'utf8'); throw error }
  return { oldVersion, version, files }
}

if (require.main === module) {
  try { const result = bump(process.cwd()); process.stdout.write(`${result.oldVersion} -> ${result.version}\n${result.files.join('\n')}\n`) }
  catch (error) { process.stderr.write(`Versioning fallito: ${error.message}\n`); process.exitCode = 1 }
}
module.exports = { bump }
