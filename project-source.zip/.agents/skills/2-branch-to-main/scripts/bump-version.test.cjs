'use strict'
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const { bump } = require('./bump-version.cjs')

function fixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'uncs-ver-'))
  fs.mkdirSync(path.join(root, 'desktop'))
  fs.writeFileSync(path.join(root, 'UnCsForeverCompanion.toc'), '## Interface: 16001\r\n## Version: 0.13.14\r\nfile.lua\r\n')
  fs.writeFileSync(path.join(root, 'UnCsForeverCompanion.lua'), 'ns.VERSION = "0.13.14" -- note\nns.PROTOCOL = 2\n')
  fs.writeFileSync(path.join(root, 'desktop/package.json'), '{\n  "name": "example",\n  "version": "0.1.0"\n}\n')
  fs.writeFileSync(path.join(root, 'desktop/package-lock.json'), '{\n  "version": "0.0.0",\n  "packages": { "": { "version": "0.0.0" }, "node_modules/example": { "version": "1.2.3" } }\n}\n')
  return root
}
test('increments the addon patch and aligns only the root package versions', () => {
  const root = fixture()
  try {
    assert.deepEqual([bump(root).oldVersion, JSON.parse(fs.readFileSync(path.join(root, 'desktop/package.json'))).version], ['0.13.14', '0.13.15'])
    assert.match(fs.readFileSync(path.join(root, 'UnCsForeverCompanion.toc'), 'utf8'), /## Version: 0\.13\.15\r\nfile\.lua/)
    assert.match(fs.readFileSync(path.join(root, 'UnCsForeverCompanion.lua'), 'utf8'), /ns\.VERSION = "0\.13\.15" -- note/)
    const lock = JSON.parse(fs.readFileSync(path.join(root, 'desktop/package-lock.json')))
    assert.equal(lock.version, '0.13.15'); assert.equal(lock.packages[''].version, '0.13.15'); assert.equal(lock.packages['node_modules/example'].version, '1.2.3')
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
test('leaves files untouched if addon versions differ', () => {
  const root = fixture()
  try {
    const lua = path.join(root, 'UnCsForeverCompanion.lua'), toc = path.join(root, 'UnCsForeverCompanion.toc')
    fs.writeFileSync(lua, 'ns.VERSION = "0.13.13"\n')
    const before = fs.readFileSync(toc, 'utf8')
    assert.throws(() => bump(root), /non coincidono/)
    assert.equal(fs.readFileSync(toc, 'utf8'), before)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
