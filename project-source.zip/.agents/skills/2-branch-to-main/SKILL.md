---
name: 2-branch-to-main
description: Committa il lavoro del branch personale di UnCs Forever Companion, poi lo integra in main, incrementa la versione patch e invia main dopo le verifiche.
---

# Portare il branch personale in main

Usa questa skill solo quando l'utente chiede esplicitamente di integrare il branch corrente in `main` con versioning. L'invocazione autorizza il commit iniziale del lavoro, il merge, l'incremento patch, le verifiche e il push normale di `main`, nei limiti dell'ambiente. Non crea tag né pubblica installer o release.

1. Leggi `AGENTS.md` e `COLLABORAZIONE.md`. Verifica che il checkout sia sul branch personale, che il remoto sia corretto e che non ci siano operazioni Git aperte. Esamina le modifiche staged, unstaged e i file nuovi. Aggiungi e committa tutto il lavoro pertinente, inclusi i nuovi file. Escludi segreti, cache, build e modifiche estranee. Se rimangono modifiche locali, conserva il commit appena creato e fermati prima di cambiare branch. Se era già tutto committato, usa lo SHA corrente.
2. Esegui `git fetch origin`. Verifica che il branch sorgente contenga la punta remota del branch personale, se esiste, e la nuova `origin/main`. È normale che il nuovo commit esista solo in locale: usa lo SHA locale come sorgente del merge. Se il remoto personale è avanti o divergente, oppure manca la main aggiornata, fermati e indica come sincronizzarli. Se il commit sorgente è già contenuto in `origin/main`, fermati senza incrementare la versione. Registra gli SHA esatti di sorgente e main.
3. Passa a `main` solo con working tree pulita e aggiorna con `git merge --ff-only origin/main`. Se `main` locale non può essere aggiornato senza riscrivere storia, fermati. Esegui `git merge --no-ff --no-commit <SHA-sorgente>`: ciò mantiene entrambi i genitori e permette di includere il versioning nello stesso merge. Se ci sono conflitti, mantieni il lavoro e risolvili solo se l'intento è chiaro; non applicare `ours`/`theirs` globali. Se incerti, fermati e mostra lo stato.
4. Dalla root esegui `node .agents/skills/2-branch-to-main/scripts/bump-version.cjs`. Lo script incrementa la patch della versione addon in TOC e Lua e allinea versione e metadati lockfile del companion. Se le due versioni addon non coincidono o non sono semver semplici, fermati e risolvi la discrepanza senza indovinare. Il workflow di release usa il tag come versione di build: non creare un tag automaticamente.
5. Esamina il diff e le versioni, esegui `git diff --check`, i test pertinenti e i controlli di compilazione disponibili. Verifica che non siano entrati dati personali, segreti, cache o binari generati. Se un controllo fallisce non fare push e lascia lo stato recuperabile.
6. Aggiungi solo i quattro file di versione creati dallo script, crea il commit di merge con `git commit` e verifica che entrambi gli SHA originali siano antenati. Controlla che `origin/main` non sia avanzato; fai solo `git push origin main`, mai force push. Verifica lo SHA su GitHub. Se il push viene rifiutato, fermati senza riscrivere il remoto.
7. Torna al branch sorgente con `git switch <branch>` solo dopo una verifica di working tree pulita. Non cancellare né riscrivere il branch personale.

Riporta il commit iniziale del lavoro, se creato, il branch e lo SHA sorgente, SHA main iniziale/finale, versione precedente/nuova, test, risultato del push e branch finale. Un merge in `main` non rende disponibile l'installer pubblico: pubblicazione e tag restano espliciti e separati.
