---
name: 2-branch-to-main
description: Integra il branch personale corrente di UnCs Forever Companion in main con merge e incremento di versione, verifica e push di main; non pubblica release.
---

# Portare il branch personale in main

Usa questa skill solo quando l'utente chiede esplicitamente di integrare il branch corrente in `main` con versioning. L'invocazione autorizza il merge, l'incremento patch, le verifiche e il push normale di `main`, nei limiti dell'ambiente. Non crea tag né pubblica installer o release.

1. Leggi `AGENTS.md` e `COLLABORAZIONE.md`. Registra branch corrente e SHA: deve essere un branch personale, non `main` né detached. Verifica working tree pulita, assenza di operazioni Git aperte, remoto corretto e nessun segreto o file generato da includere. Non scartare o committare automaticamente modifiche non correlate.
2. Esegui `git fetch origin`. Il branch sorgente locale deve coincidere con il suo remoto e contenere `origin/main`: in caso contrario fermati e, se appropriato, suggerisci `$1-main-to-branch`. Se il commit sorgente è già contenuto in `origin/main`, fermati senza incrementare la versione. Salva gli SHA esatti di sorgente e main.
3. Passa a `main` solo con working tree pulita e aggiorna con `git merge --ff-only origin/main`. Se `main` locale non può essere aggiornato senza riscrivere storia, fermati. Esegui `git merge --no-ff --no-commit <SHA-sorgente>`: ciò mantiene entrambi i genitori e permette di includere il versioning nello stesso merge. Se ci sono conflitti, mantieni il lavoro e risolvili solo se l'intento è chiaro; non applicare `ours`/`theirs` globali. Se incerti, fermati e mostra lo stato.
4. Dalla root esegui `node .agents/skills/2-branch-to-main/scripts/bump-version.cjs`. Lo script incrementa la patch della versione addon in TOC e Lua e allinea versione e metadati lockfile del companion. Se le due versioni addon non coincidono o non sono semver semplici, fermati e risolvi la discrepanza senza indovinare. Il workflow di release usa il tag come versione di build: non creare un tag automaticamente.
5. Esamina il diff e le versioni, esegui `git diff --check`, i test pertinenti e i controlli di compilazione disponibili. Verifica che non siano entrati dati personali, segreti, cache o binari generati. Se un controllo fallisce non fare push e lascia lo stato recuperabile.
6. Aggiungi solo i quattro file di versione creati dallo script, crea il commit di merge con `git commit` e verifica che entrambi gli SHA originali siano antenati. Controlla che `origin/main` non sia avanzato; fai solo `git push origin main`, mai force push. Verifica lo SHA su GitHub. Se il push viene rifiutato, fermati senza riscrivere il remoto.
7. Torna al branch sorgente con `git switch <branch>` solo dopo una verifica di working tree pulita. Non cancellare né riscrivere il branch personale.

Riporta branch e SHA sorgente, SHA main iniziale/finale, versione precedente/nuova, test, risultato del push e branch finale. Un merge in `main` non rende disponibile l'installer pubblico: pubblicazione e tag restano espliciti e separati.
