# Lavoro condiviso

Questo repository privato è la fonte ufficiale di UnCs Foreve WebCompanion. L’addon è nella radice, il renderer condiviso e Pulser sono in `desktop/`, il servizio web in `web/` e il setup Pulser in `installer/`. Per le modifiche usa questa copia del repository.

Alessandro lavora nel branch `aleilsandro`; Thomas lavora nel branch `thomas`. Non modificare o inviare direttamente `main` per il lavoro ordinario. Prima di intervenire controllare branch, stato Git e modifiche presenti, evitando di sovrascrivere lavoro altrui. Usare `1-main-to-branch` per aggiornare il branch personale, `2-branch-to-main` per l’integrazione con versionamento quando l’utente la richiede e `3-aggiorna-documentazione` per riallineare gli Markdown al lavoro verificato. Per integrare in `main` si può anche aprire una pull request.

Sul PC di Thomas, leggere la sezione **Web app locale sul PC di Thomas** di `COLLABORAZIONE.md` prima di lavorare sulla web app. Per il primo setup su Windows, eseguire dalla root del suo checkout `pwsh -NoProfile -File web/local.ps1 -InstallShortcut`. Il collegamento **UnCs WebCompanion - LOCALE** va creato sul Desktop di Thomas e avvia la mappa da quel checkout. Eseguire sviluppo e prove sulla copia locale. I deploy sul server UnCs sono gestiti da Alessandro.

Accedere all’installazione di WoW in sola lettura ed escludere qualsiasi iniezione nel client o intervento sui file di gioco. Scrivere i dati generati fuori dall’installazione. Conservare la cartografia originale del Companion e aggiungere gli elementi come layer. Verificare le icone nel client WoW Forever e le interazioni sia con mouse sia con touch. OpenMap e ForeverDungeonJournal sono riferimenti e possono mancare durante l’uso del Companion.

Al termine di lavoro richiesto e verificato, salvare nel branch corrente solo le modifiche pertinenti, con commit e push, se l'utente ha autorizzato la sincronizzazione. Non includere password, token, file personali, dipendenze installate o file generati. Segnalare eventuali errori di sincronizzazione; non dichiarare sincronizzato ciò che non è stato inviato.

La pubblicazione richiede un tag di rilascio e la configurazione del workflow pubblico. Per confermare una versione disponibile verificare la release o il manifesto effettivamente servito.

Le skill condivise sono in `.agents/skills/`. Se non compaiono nel catalogo di Codex dopo il clone, riaprire la sessione o leggere direttamente il rispettivo `SKILL.md`. Le istruzioni dell'utente e le autorizzazioni dell'ambiente prevalgono sulle skill.
