# Lavoro condiviso

Questo repository privato è la fonte ufficiale di UnCs Foreve WebCompanion. L’addon è nella radice, il renderer condiviso e Pulser sono in `desktop/`, il servizio web in `web/` e il setup Pulser in `installer/`. Per le modifiche usa questa copia del repository.

Alessandro lavora nel branch `aleilsandro`; Thomas lavora nel branch `thomas`. Non modificare o inviare direttamente `main` per il lavoro ordinario. Prima di intervenire controllare branch, stato Git e modifiche presenti, evitando di sovrascrivere lavoro altrui. Usare `1-main-to-branch` per aggiornare il branch personale, `2-branch-to-main` per l’integrazione con versionamento quando l’utente la richiede e `3-aggiorna-documentazione` per riallineare gli Markdown al lavoro verificato. Per integrare in `main` si può anche aprire una pull request.

Al termine di lavoro richiesto e verificato, salvare nel branch corrente solo le modifiche pertinenti, con commit e push, se l'utente ha autorizzato la sincronizzazione. Non includere password, token, file personali, dipendenze installate o file generati. Segnalare eventuali errori di sincronizzazione; non dichiarare sincronizzato ciò che non è stato inviato.

La pubblicazione richiede un tag di rilascio e la configurazione del workflow pubblico. Per confermare una versione disponibile verificare la release o il manifesto effettivamente servito.

Le skill condivise sono in `.agents/skills/`. Se non compaiono nel catalogo di Codex dopo il clone, riaprire la sessione o leggere direttamente il rispettivo `SKILL.md`. Le istruzioni dell'utente e le autorizzazioni dell'ambiente prevalgono sulle skill.
