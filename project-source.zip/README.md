# UnCs Forever WebCompanion

Mappa web della gilda per World of Warcraft Forever (interfaccia 16001). UnCs Pulser e l’addon UnCs Forever Companion inviano la posizione alla mappa. La cartografia risiede sul server e si può esplorare anche a gioco chiuso. [Apri la mappa della gilda](https://uncs-server.tail1b66eb.ts.net:8447/).

## Installazione

Su Windows, scarica UnCs Pulser da GitHub e indica la cartella di WoW Forever nel setup. Lo stesso installer contiene Pulser e addon della release pubblica più recente, salva il percorso di gioco e crea il collegamento **UnCs Forever Web** sul Desktop. [Scarica l’ultimo installer Pulser](https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/latest/download/UnCs-Pulser-Setup.exe).

Quando l’accesso via Funnel è attivo, usa **Apri mappa web** dalla tray o il collegamento sul Desktop. Al primo accesso inserisci nel browser il codice monouso ricevuto da un officer. Il browser del PC si abbina durante l’attivazione. Per telefono o tablet scegli **Abbina un dispositivo → Mostra QR**. Per un altro PC scegli **Copia link per un altro PC**. Ogni browser si abbina una volta. Poi può aprire la mappa dai preferiti. Per revocare l’accesso di un browser usa **Scollega un browser**.

Il Pulser installato cerca aggiornamenti all’avvio e ogni 10 minuti. Conferma dalla tray per aggiornare insieme Pulser e addon. Se WoW è aperto, usa `/reload` dopo l’installazione.

Per installare solo l’addon, estrai la cartella `UnCsForeverCompanion` dallo ZIP della release in `World of Warcraft/_forever_/Interface/AddOns/` e riavvia il gioco o usa `/reload`.

## Gilda

L’addon condivide la posizione nel mondo aperto sul canale addon della gilda. Il Pulser trasmette alla web app solo per un personaggio di **Unconscious Clan** con la condivisione attiva. Usa `/uncs guild` per attivare o disattivare la condivisione UnCs. Se il gioco segnala il personaggio AFK e le coordinate sono temporaneamente assenti, l’addon usa l’ultimo punto noto nella stessa zona. Se il Pulser perde il segnale, la posizione web scade entro 25 secondi dall’ultimo invio. L’eventuale condivisione di OpenMap si gestisce separatamente.

Se usi Tailscale e la mappa non si apre, consulta [la verifica della porta 10000](web/README.md#accesso-con-tailscale-attivo-porta-10000).

## Sviluppo e rilascio

### Integrazioni di Thomas

Per provare queste integrazioni con il Pulser, segui il [setup locale di Thomas](COLLABORAZIONE.md#web-app-locale-sul-pc-di-thomas).

#### Mappa e navigazione

- **Atlante in alta risoluzione.** Il terreno delle minimappe è visibile a ogni zoom. Da vicino l’atlante carica le tessere a risoluzione più alta. La rotella cambia l’ingrandimento in modo continuo attorno al cursore. Su touch puoi usare il gesto a due dita. La maschera costiera nasconde i vuoti neri e l’acqua delle tessere lungo le coste. Da vicino conserva i moli censiti, per esempio Menethil, Auberdine e Theramore.
- **Mappe delle città.** Quando centri una capitale e ti avvicini, la pianta resta nitida e la zona circostante si attenua e si sfoca. A Stormwind, Darnassus e Orgrimmar il passaggio segue una sfumatura attorno alla città. A Ironforge e Undercity il contorno segue le stanze sotterranee.
- **Nome e livelli delle zone.** Il nome e l’intervallo di livello consigliato compaiono in alto al centro quando passi sulla zona con il mouse o la tocchi.
- **Livelli mappa.** Il menu nella barra superiore permette di scegliere punti volo, dungeon, navi, zeppelin, caverne, miniere e servizi.
- **Ricerca.** Usa **Cerca** per trovare un luogo o un PNG per nome, categoria o zona ed evidenziarlo sulla mappa. In **Per nome**, **Cerca su Wowhead** apre la ricerca di WoW Forever in una nuova scheda, anche senza risultati locali. Il collegamento esterno richiede Internet. **Il più vicino** usa la posizione ricevuta dal Pulser per mostrare la distanza in linea d’aria sul tuo continente. Puoi cercare anche il maestro di una singola professione o il punto volo sbloccato più vicino.
- **Posizioni e note.** Scegli un nome in **Gildani sulla mappa**, nella barra in alto, per trovare la posizione che condivide. Usa **Centrati sul giocatore** per tornare alla tua posizione. Con **Aggiungi pin** puoi dare un nome o scrivere una nota in un punto della mappa. Le note personali restano nel browser. I pin condivisi compaiono ai gildani con un browser abbinato.
- **Navi e zeppelin.** Passa sopra l’icona originale o toccala per vedere la rotta, la destinazione e il riquadro su due righe «Da …» e «a …». Sono inclusi i tre collegamenti di Auberdine.
- **Punti volo personali.** L’icona originale è verde per gli sbloccati e grigia per gli altri. Il riquadro distingue i punti bloccati da quelli ancora da verificare. Il Pulser conserva il progresso confermato per personaggio. Per verificare un continente, apri la mappa di un maestro di volo con WoW, l’addon UnCs e il Pulser attivi.

#### Servizi e professioni

- **Servizi.** Puoi scegliere locande, cassette della posta, mercanti, riparatori, banchieri, case d’asta e istruttori di classe. Gli istruttori di professione si filtrano per singolo mestiere.
- **Abilità di raccolta.** In **Livelli mappa** scegli separatamente Estrazione mineraria, Erbalismo, Pesca e Scuoiatura. I requisiti compaiono al passaggio del mouse o al tocco della zona. Il pacchetto verificato contiene dati per 46 zone, con copertura variabile per professione. Ogni browser ricorda le proprie spunte. La Pesca indica quando i valori sono Classic. La Scuoiatura mostra una stima basata sulle creature censite.

#### Dungeon

- **Menu e mappa interna.** Il menu **Dungeon** elenca nomi e intervalli di livello. Clicca o tocca il simbolo del dungeon oppure selezionalo dal menu per aprire la pianta scontornata, con la mappa circostante attenuata e sfocata. Il pannello mostra ali, piani, boss, missioni e bottino. Ai piani superiori i passaggi sottostanti restano visibili in secondo piano, come al **Piano 2/2** di Wailing Caverns.
- **Missioni e bottino.** Le missioni mostrano origine, prerequisiti, obiettivi e coordinate quando disponibili. Seleziona un boss per aprire la sua lista del bottino. Le schede degli oggetti mostrano icona originale, colore di rarità, requisiti, statistiche ed effetti disponibili. Per alcuni effetti viene mostrato il solo nome. Le schede si consultano con mouse, tastiera e touch.
- **Catene di missioni.** La scheda mostra l’inizio, le tappe e i PNG della catena quando sono censiti. Le missioni richieste e quelle alternative sono indicate separatamente. Seleziona un PNG con coordinate per mostrarlo sull’atlante.
- **Ingressi.** La scheda **Ingresso** distingue il portale dall’imbocco della grotta, della miniera o dell’edificio quando l’accesso è censito. Le frecce dorate restano in primo piano anche quando la mappa circostante si sfoca. Se il pacchetto contiene la pianta della grotta attraversata dal percorso, la mostra sotto le frecce anche con **Caverne e miniere** disattivato. Il comportamento è stato verificato a Wailing Caverns con mouse e touch emulato. Per gli accessi senza tracciato sono disponibili indicazioni testuali. Nella minimappa interna il portale è segnato dove la posizione è nota.
- **Giocatori nell’istanza.** La minimappa mostra la tua posizione e i compagni di gruppo quando il Pulser riceve le coordinate. I segnalini sono stati verificati con dati simulati. Resta la prova di una run reale.

#### Prove e stato della distribuzione

- **PC e tablet.** L’anteprima locale è stata provata con il Pulser e con un tablet sulla stessa rete. In una prova di ottimizzazione precedente, con zoom touch e CPU rallentata, il traffico delle tessere era sceso da circa 65 MB a 15 MB. Missioni e schede del bottino si caricano quando apri le relative sezioni.
- **Dati del gioco.** Durante la preparazione della cartografia e il rilevamento della posizione, le risorse del gioco sono lette in sola lettura. Le cache restano fuori dall’installazione di WoW. Una volta preparati, i livelli statici e le schede sono consultabili a gioco spento.
- **Rilascio.** Il 23 novembre 2026 il servizio pubblico su porta 10000 riportava `0.13.31` su `/healthz`, con cartografia configurata. La stessa versione è pubblicata su GitHub con il setup Pulser e lo ZIP dell’addon. [Release 0.13.31](https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/tag/0.13.31) · [Stato del server pubblico](https://uncs-server.tail1b66eb.ts.net:10000/healthz).
- **Presenza dei gildani in sviluppo.** Su `thomas` (`d8e3e67`) la lista rimane in ordine alfabetico quando arrivano aggiornamenti alternati. Il personaggio resta in lista finché il Pulser riceve un segnale di presenza recente. Se mancano nuove coordinate, la mappa conserva l’ultimo punto noto dello stesso personaggio nella stessa zona, quando disponibile. Le prove con giocatori simulati sono passate. Resta la verifica in WoW con addon e Pulser aggiornati. La release `0.13.31` precede questa modifica.
- **Da completare.** Restano il supporto completo ai raid, il timer e l’oro della singola run e l’evidenziazione in gioco dei risultati cercati nel Companion.

### Sorgenti e versioni

Il codice dell’addon è nella radice, il renderer condiviso e Pulser sono in `desktop/`, il servizio in `web/` e il setup Windows in `installer/`. Per la build, il server e la cartografia consulta la [guida web](web/README.md). Per il flusso dei branch consulta [Lavorare insieme](COLLABORAZIONE.md). Per il deploy Windows consulta [UnCs Deploy](tools/deployer/README.md).

Le nuove release pubbliche contengono lo ZIP dell’addon, il setup Pulser con l’addon incluso, i manifesti `latest.yml` e `pulser-latest.yml` e i sorgenti corrispondenti. Il Companion desktop standalone e il bootstrapper Windows appartengono alle versioni precedenti. I sorgenti condivisi restano utilizzabili in sviluppo.

Allinea `## Version` nel TOC, `ns.VERSION` nel Lua e la versione del pacchetto desktop allo stesso `MAJOR.MINOR.PATCH`. La skill 2 aggiorna questi valori quando integra il lavoro in `main`. Il tag avvia il workflow di rilascio. Con `ENABLE_PUBLIC_RELEASE=true` e la chiave di distribuzione configurata, GitHub Actions trasferisce lo ZIP dell’addon e lo snapshot dei sorgenti alla repo pubblica. Il workflow pubblico compila il setup e pubblica la release dopo aver verificato tutti gli allegati. Se fallisce, usa **Re-run failed jobs** nel workflow che ha fallito. Una bozza incompleta resta invisibile alla tray.

Il repository di sviluppo è privato e richiede accesso autorizzato. Il repository delle release è pubblico: chi scarica l'installer non ha bisogno di un token GitHub.

## Crediti e licenze

Il progetto deriva da Twinmap Forever e include componenti di terze parti. Consulta `LICENSE` e `THIRD-PARTY-LICENSES` prima di ridistribuirlo.
