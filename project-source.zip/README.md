# UnCs Foreve WebCompanion

Mappa web della gilda per World of Warcraft Forever (interfaccia 16001). UnCs Pulser e l’addon UnCs Forever Companion inviano la posizione alla mappa. La cartografia risiede sul server e si può esplorare anche a gioco chiuso. [Apri la mappa della gilda](https://uncs-server.tail1b66eb.ts.net:8447/).

## Installazione

Su Windows, scarica UnCs Pulser da GitHub e indica la cartella di WoW Forever nel setup. Lo stesso installer contiene Pulser e addon della release pubblica più recente, salva il percorso di gioco e crea il collegamento **UnCs Forever Web** sul Desktop. [Scarica l’ultimo installer Pulser](https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/latest/download/UnCs-Pulser-Setup.exe).

Quando l’accesso via Funnel è attivo, usa **Apri mappa web** dalla tray o il collegamento sul Desktop. Al primo accesso inserisci nel browser il codice monouso ricevuto da un officer. Il browser del PC si abbina durante l’attivazione. Per telefono o tablet scegli **Abbina un dispositivo → Mostra QR**. Per un altro PC scegli **Copia link per un altro PC**. Ogni browser si abbina una volta. Poi può aprire la mappa dai preferiti. Per revocare l’accesso di un browser usa **Scollega un browser**.

Il Pulser cerca aggiornamenti all’avvio e ogni 30 minuti. Conferma dalla tray per aggiornare insieme Pulser e addon. Se WoW è aperto, usa `/reload` dopo l’installazione.

Per installare solo l’addon, estrai la cartella `UnCsForeverCompanion` dallo ZIP della release in `World of Warcraft/_forever_/Interface/AddOns/` e riavvia il gioco o usa `/reload`.

## Gilda

L’addon condivide la posizione nel mondo aperto sul canale addon della gilda. Il Pulser trasmette alla web app solo per un personaggio di **Unconscious Clan** con la condivisione attiva. Usa `/uncs guild` per attivare o disattivare la condivisione UnCs. Se il Pulser perde il segnale, la posizione scade entro 25 secondi dall’ultimo invio. L’eventuale condivisione di OpenMap si gestisce separatamente.

## Sviluppo e rilascio

Il codice dell’addon è nella radice, il renderer condiviso e Pulser sono in `desktop/`, il servizio in `web/` e il setup Windows in `installer/`. Per la build, il server e la cartografia consulta la [guida web](web/README.md). Per il flusso dei branch consulta [Lavorare insieme](COLLABORAZIONE.md).

Le nuove release pubbliche contengono lo ZIP dell’addon, il setup Pulser con l’addon incluso, i manifesti `latest.yml` e `pulser-latest.yml` e i sorgenti corrispondenti. Il Companion desktop standalone e il bootstrapper Windows appartengono alle versioni precedenti. I sorgenti condivisi restano utilizzabili in sviluppo.

Allinea `## Version` nel TOC, `ns.VERSION` nel Lua e la versione del pacchetto desktop allo stesso `MAJOR.MINOR.PATCH`. La skill 2 aggiorna questi valori quando integra il lavoro in `main`. Il tag avvia il workflow di rilascio. Con `ENABLE_PUBLIC_RELEASE=true` e la chiave di distribuzione configurata, GitHub Actions trasferisce lo ZIP dell’addon e lo snapshot dei sorgenti alla repo pubblica. Il workflow pubblico compila il setup e pubblica la release dopo aver verificato tutti gli allegati. Se fallisce, usa **Re-run failed jobs** nel workflow che ha fallito. Una bozza incompleta resta invisibile alla tray.

Il repository di sviluppo è privato e richiede accesso autorizzato. Il repository delle release è pubblico: chi scarica l'installer non ha bisogno di un token GitHub.

## Crediti e licenze

Il progetto deriva da Twinmap Forever e include componenti di terze parti. Consulta `LICENSE` e `THIRD-PARTY-LICENSES` prima di ridistribuirlo.
