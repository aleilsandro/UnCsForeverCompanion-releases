import { expect, test } from 'vitest'
import { expandDetailCoast, trimTerrainPadding } from './detail-coast-mask'

test('keeps the original shore and extends the mask only over mapped piers', () => {
  const width = 1002, height = 8
  const pixels = new Uint8ClampedArray(width * height * 4)
  const index = (x: number, y: number) => (y * width + x) * 4 + 3
  for (let y = 0; y < height; y++) for (let x = 0; x < 5; x++) pixels[index(x, y)] = 255
  pixels[index(4, 4)] = 128

  expandDetailCoast(pixels, width, height, [{ x: 12 / width, y: .5, radiusX: 3 / width, radiusY: .25 }])

  expect(pixels[index(4, 4)]).toBe(128)
  expect(pixels[index(5, 4)]).toBe(0)
  expect(pixels[index(6, 4)]).toBe(0)
  expect(pixels[index(12, 4)]).toBe(255)
  expect(pixels[index(16, 4)]).toBe(0)
})

test('trims connected black padding across a coast while preserving inland shadows and uncovered terrain', () => {
  const width = 8, height = 5
  const coast = new Uint8ClampedArray(width * height * 4)
  const terrain = new Uint8ClampedArray(coast.length)
  const pixel = (x: number, y: number) => (y * width + x) * 4
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const at = pixel(x, y)
      coast[at + 3] = x ? 255 : 0
      terrain.set([82, 60, 41, 255], at)
    }
  }
  for (const x of [0, 1, 2, 3]) terrain.set([5, 5, 4, 255], pixel(x, 2))
  terrain.set([10, 13, 9, 255], pixel(3, 3))
  terrain.set([31, 41, 36, 255], pixel(2, 3))
  terrain.set([39, 29, 19, 255], pixel(3, 4))
  terrain.set([9, 12, 9, 255], pixel(6, 2))
  terrain.set([31, 41, 36, 255], pixel(6, 3))
  terrain.set([0, 0, 0, 0], pixel(1, 1))

  const detail = new Uint8ClampedArray(coast)
  trimTerrainPadding(coast, detail, terrain, width, height)

  expect(coast[pixel(3, 3) + 3]).toBe(0)
  expect(coast[pixel(2, 3) + 3]).toBe(0)
  expect(coast[pixel(3, 4) + 3]).toBe(255)
  expect(coast[pixel(1, 2) + 3]).toBe(0)
  expect(coast[pixel(4, 2) + 3]).toBe(255)
  expect(coast[pixel(6, 2) + 3]).toBe(255)
  expect(coast[pixel(6, 3) + 3]).toBe(255)
  expect(coast[pixel(1, 1) + 3]).toBe(0)
  expect(detail[pixel(1, 1) + 3]).toBe(255)
  expect(detail[pixel(2, 3) + 3]).toBe(0)
})
