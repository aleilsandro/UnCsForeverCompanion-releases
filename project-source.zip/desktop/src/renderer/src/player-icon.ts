import L from 'leaflet'

export type CursorStyle = 'a'|'b'|'c'
export function playerIcon(style:CursorStyle):L.DivIcon {
  const body = style==='a'
    ? '<circle cx="24" cy="27" r="11" fill="#102e59" stroke="#e8c982" stroke-width="2.5"/><circle cx="24" cy="27" r="6" fill="#72bcec" stroke="#f5efd0" stroke-width="1.5"/><path d="M24 1 L32 22 L24 18 L16 22 Z" fill="#f8db92" stroke="#4e3721" stroke-width="1.5"/>'
    : style==='b'
      ? '<path d="M24 2 L39 39 L24 32 L9 39 Z" fill="#10294d" stroke="#e6d6aa" stroke-width="2.5" stroke-linejoin="round"/><path d="M24 8 L29 29 L24 25 L19 29 Z" fill="#82c9f2"/><path d="M18 34 L24 30 L30 34" fill="none" stroke="#e3bd73" stroke-width="2"/>'
      : '<path d="M24 2 L31 17 L38 20 L36 32 Q33 39 24 43 Q15 39 12 32 L10 20 L17 17 Z" fill="#173b70" stroke="#f0d28e" stroke-width="2"/><path d="M24 4 L30 21 L24 18 L18 21 Z" fill="#ecdbac"/><path d="M24 21 L29 27 L24 34 L19 27 Z" fill="#9bcdf1" stroke="#f5e8c4" stroke-width="1"/>'
  return L.divIcon({className:'player-wrap',html:`<svg class="fantasy-player" width="48" height="48" viewBox="0 0 48 48" style="filter:drop-shadow(0 2px 3px #000c);transform-origin:24px 27px">${body}</svg>`,iconSize:[48,48],iconAnchor:[24,27]})
}
export function turnPlayer(marker:L.Marker, facing:number|undefined):void {
  const icon=marker.getElement()?.querySelector<SVGElement>('.fantasy-player')
  if (icon) { icon.style.transform=`rotate(${typeof facing==='number' && Number.isFinite(facing) ? -facing : 0}deg)`; icon.style.opacity=typeof facing==='number' ? '1' : '.7' }
}
