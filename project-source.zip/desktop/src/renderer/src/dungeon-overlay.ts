import type { DungeonPins } from '../../shared/dungeon-pins'
import { dungeonGuides } from '../../shared/dungeon-journal'
import { boxOf, inPiece, piecesIn, YARDS_PER_UNIT, type Box, type InteriorMap, type Piece } from '../../shared/inside'
import { renderRooms } from './cave-minimap'
import { TILES } from './web'

const hasWings = (guide: DungeonPins): boolean =>
  dungeonGuides.some(other => other.map === guide.map && other.name !== guide.name)

export function dungeonRooms(map: InteriorMap, guide: DungeonPins): Piece[] {
  if (guide.part) return piecesIn(map.pieces, guide.part)
  return hasWings(guide) ? piecesIn(map.pieces, guide.bounds) : map.pieces
}

export function dungeonOverlayBounds(guide: DungeonPins, rooms: Piece[], hasGround: boolean): Box {
  const extent = !guide.part && !hasWings(guide) ? boxOf(rooms) : null
  const [u1, v1, u2, v2] = guide.bounds
  const [left, top, right, bottom] = extent
    ? [Math.min(u1, extent[0]), Math.min(v1, extent[1]), Math.max(u2, extent[2]), Math.max(v2, extent[3])]
    : guide.bounds
  const margin = hasGround ? 72 : 0
  return [left - margin, top - margin, right + margin, bottom + margin]
}

export function roomFloor(rooms: Piece[], u: number, v: number): number | undefined {
  let floor: number | undefined, nearest = Infinity
  for (const room of rooms) {
    if (!inPiece(room, u, v)) continue
    const distance = Math.hypot(room.u - u, room.v - v)
    if (distance < nearest) { nearest = distance; floor = room.level }
  }
  return floor
}

export async function renderDungeonOverlay(map: InteriorMap, box: Box, rooms: Piece[], floor: number,
  project: (u: number, v: number) => [number, number], guide: DungeonPins,
  signal: AbortSignal): Promise<string | null> {
  const ground = []
  if (map.ground) {
    const zoom = 5, size = 256 * YARDS_PER_UNIT / 2 ** zoom
    for (let x = Math.floor(box[0] / size); x < Math.ceil(box[2] / size); x++) {
      for (let y = Math.floor(box[1] / size); y < Math.ceil(box[3] / size); y++) {
        const image = new Image()
        image.src = `${TILES}/${map.ground}/${zoom}/${x}/${y}.png`
        ground.push(image.decode().then(() => ({ image, u: x * size, v: y * size, size })).catch(() => null))
      }
    }
  }
  // Higher levels describe vertically overlapping rooms, not a complete separate floor plan.
  const visible = rooms.filter(room => room.level <= floor).sort((a, b) => a.level - b.level)
  // Some instances are mainly navigable terrain, with few bosses inside the room images.
  const bosses = guide.bosses.map(([, u, v]) => ({ u, v, level: roomFloor(rooms, u, v) }))
  const openGround = bosses.filter(boss => boss.level === undefined).length * 2 > bosses.length
  const landmarks = bosses.filter(boss => (boss.level ?? 0) <= floor).map(({ u, v }) => [u, v] as const)
  if (guide.entrance) landmarks.push(guide.entrance)
  return renderRooms(visible, project, box, {
    ground: (await Promise.all(ground)).filter(tile => tile !== null), landmarks, openGround, selectedFloor: floor, signal,
  })
}
