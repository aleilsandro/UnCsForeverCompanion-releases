<script lang="ts">
  import { untrack } from 'svelte'
  import { DUNGEON_LOOT_FILE, dungeonDirectory, dungeonGuideFor, type DungeonJournalData, type DungeonLootDetailsById, type QuestSource } from '../../shared/dungeon-journal'
  import { OPENMAP } from './web'
  import DungeonMap from './DungeonMap.svelte'
  import DungeonLootList from './DungeonLootList.svelte'
  import type { DungeonApproach } from '../../shared/dungeon-approaches'

  let { initialNames, selectedName, onSelect, onClose, overlay = false, selectedBoss, floor = 0, maxFloor = 0, onFloor, onBoss, mapStatus, approach, onApproach }: {
    initialNames: string[]; selectedName?: string; onSelect?: (entry: typeof dungeonDirectory[number]) => void
    onClose: () => void; overlay?: boolean; selectedBoss?: { name: string }; floor?: number; maxFloor?: number
    onFloor?: (floor: number) => void; onBoss?: (boss: string) => void; mapStatus?: string
    approach?: DungeonApproach; onApproach?: (show: boolean) => void
  } = $props()
  let panel: HTMLElement
  let directorySelection = $state.raw<string[]>([])
  let wing = $state(0)
  let tab = $state<'map' | 'quests' | 'loot' | 'entrance'>('map')
  let pickedBoss = $state('')
  let journal = $state.raw<DungeonJournalData>()
  let lootDetails = $state.raw<DungeonLootDetailsById>()
  let loading = $state(true)
  const names = $derived(initialNames.length ? initialNames : directorySelection)
  const name = $derived(selectedName ?? names[wing] ?? names[0] ?? 'Dungeon')
  const guide = $derived(dungeonGuideFor(name))
  const quests = $derived(guide && journal?.quests?.[guide.map] || [])
  const bosses = $derived(guide?.bosses.map(([boss]) => boss) ?? [])
  const loot = $derived(guide && journal?.loot?.[guide.map])
  const number = new Intl.NumberFormat('it-IT', { maximumFractionDigits: 1 })

  $effect(() => {
    if ((tab !== 'quests' && tab !== 'loot') || !loading) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/dungeon-journal.json`, { signal: request.signal })
      .then(response => response.ok ? response.json() : undefined)
      .then(value => { if (!request.signal.aborted) journal = value })
      .catch(() => {})
      .finally(() => { if (!request.signal.aborted) loading = false })
    return () => request.abort()
  })
  $effect(() => {
    if (tab !== 'loot' || lootDetails !== undefined) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/${DUNGEON_LOOT_FILE}`, { signal: request.signal })
      .then(response => response.ok ? response.json() : {})
      .catch(() => ({}))
      .then(value => { if (!request.signal.aborted) lootDetails = value })
    return () => request.abort()
  })
  function showLoot(boss: string): void {
    pickedBoss = boss
    tab = 'loot'
  }
  $effect(() => {
    void name
    tab = 'map'
    pickedBoss = ''
    if (panel) panel.scrollTop = 0
  })
  $effect(() => {
    if (selectedBoss) showLoot(selectedBoss.name)
  })
  $effect(() => {
    const show = tab === 'entrance'
    untrack(() => onApproach?.(show))
  })
  function openEntry(entry: typeof dungeonDirectory[number]): void {
    if (onSelect) { onSelect(entry); return }
    wing = entry.index
    tab = 'map'
    pickedBoss = ''
    directorySelection = entry.wings
    panel.scrollTop = 0
  }
</script>

{#snippet locations(source: QuestSource)}
  {#if source.places.length}
    <ul class="locations">
      {#each source.places as place}
        <li>{place.x === undefined || place.y === undefined ? place.zone : `${place.zone} · ${number.format(place.x)} / ${number.format(place.y)}`}</li>
      {/each}
    </ul>
  {:else}
    <small>Posizione non disponibile</small>
  {/if}
{/snippet}

<aside class="dungeon-panel" class:local-preview={!overlay && !!names.length} bind:this={panel} aria-labelledby="dungeon-journal-title">
  <header>
    <h2 id="dungeon-journal-title">{name}</h2>
    <button class="close" aria-label="Chiudi scheda dungeon" onclick={onClose}>×</button>
  </header>
  {#if !names.length}
    <ul class="dungeon-directory" aria-label="Elenco dungeon">
      {#each dungeonDirectory as entry (entry.name)}
        <li><button onclick={() => openEntry(entry)}>
          <strong>{entry.name}</strong><span>Liv. {entry.min}–{entry.max}</span>
        </button></li>
      {/each}
    </ul>
  {:else}
  {#if !overlay && !initialNames.length}
    <button class="back" onclick={() => { directorySelection = []; panel.scrollTop = 0 }}>Torna alla lista</button>
  {/if}
  {#if names.length > 1}
    <label class="selector" for="dungeon-wing">Ala
      <select id="dungeon-wing" value={overlay ? names.indexOf(name) : wing} onchange={event => {
        const index = Number(event.currentTarget.value)
        const entry = dungeonDirectory.find(candidate => candidate.name === names[index])
        if (overlay && entry) onSelect?.(entry)
        else wing = index
      }}>
        {#each names as entry, index}
          <option value={index}>{entry}</option>
        {/each}
      </select>
    </label>
  {/if}
  {#if overlay && maxFloor > 0 && tab !== 'entrance'}
    <div class="floors" role="group" aria-label="Piano del dungeon">
      <button onclick={() => onFloor?.(floor - 1)} disabled={floor === 0} aria-label="Piano inferiore">−</button>
      <span>Piano {floor + 1}/{maxFloor + 1}</span>
      <button onclick={() => onFloor?.(floor + 1)} disabled={floor === maxFloor} aria-label="Piano superiore">+</button>
    </div>
  {/if}
  <div class="tabs" role="group" aria-label="Sezioni del dungeon">
    <button aria-pressed={tab === 'map'} onclick={() => tab = 'map'}>Mappa e boss</button>
    {#if onApproach}<button aria-pressed={tab === 'entrance'} onclick={() => tab = 'entrance'}>Ingresso</button>{/if}
    <button aria-pressed={tab === 'quests'} onclick={() => tab = 'quests'}>Missioni</button>
    <button aria-pressed={tab === 'loot'} onclick={() => tab = 'loot'}>Bottino</button>
  </div>

  {#if tab === 'entrance'}
    {#if approach}
      <p><strong>{approach.label}</strong></p>
      <p>{approach.directions}</p>
      {#if approach.routes?.length}
        <p>Segui le frecce dorate fino {approach.routes.length === 1 ? 'al portale' : 'al portale scelto'}.</p>
        {#if approach.routes.length > 1}
          <ul>{#each approach.routes as route}<li>{route.label}</li>{/each}</ul>
        {/if}
      {:else}
        <small>Percorso interno da rilevare.</small>
      {/if}
    {:else}
      <p>Il portale è segnato sulla mappa.</p>
    {/if}
  {:else if !guide}
    <p role="status">Scheda non disponibile per questo dungeon.</p>
  {:else if tab === 'map'}
    {#if mapStatus}<p role="status">{mapStatus}</p>{/if}
    <section class="map-and-bosses" class:embedded={overlay} aria-label="Mappa interna e lista dei boss">
      {#if !overlay}<div class="dungeon-map-frame">
        {#key guide.name}<DungeonMap {guide} onBoss={showLoot} />{/key}
      </div>{/if}
      <ol class="bosses">
        {#each bosses as boss}
          <li><button onclick={() => { onBoss?.(boss); showLoot(boss) }}>{boss}</button></li>
        {/each}
      </ol>
    </section>
  {:else if loading}
    <p role="status">Caricamento della scheda…</p>
  {:else if !journal}
    <p role="status">Missioni e bottino non disponibili nel pacchetto cartografico.</p>
  {:else if tab === 'quests'}
    {#if names.length > 1}<p>Missioni dell’intero dungeon, comprese le altre ali.</p>{/if}
    {#each quests as quest (quest.id)}
      <details>
        <summary>{quest.name}{#if quest.level}<small> · Livello minimo {quest.level}</small>{/if}{#if quest.faction}<small> · {quest.faction === 'A' ? 'Alleanza' : 'Orda'}</small>{/if}</summary>
        {#if quest.required.length}
          <p>Completa prima {#each quest.required as entry, index}{index ? ', ' : ''}<a href="https://www.wowhead.com/forever/quest={entry.id}" target="_blank" rel="noreferrer">{entry.name}</a>{/each}.</p>
        {/if}
        {#if quest.alternatives.length}
          <p>Missione precedente {#each quest.alternatives as entry, index}{index ? ' oppure ' : ''}<a href="https://www.wowhead.com/forever/quest={entry.id}" target="_blank" rel="noreferrer">{entry.name}</a>{/each}.</p>
        {/if}
        {#each quest.starts as source (`${source.kind}:${source.id}`)}
          {#if source.kind === 'item'}
            <p>Inizia usando <strong>{source.name}</strong>.</p>
            {#each source.drops ?? [] as drop}
              <div class="source">Si ottiene da {drop.name}. {@render locations(drop)}</div>
            {/each}
          {:else}
            <div class="source">{source.kind === 'npc' ? 'Parla con' : 'Interagisci con'} <strong>{source.name}</strong>. {@render locations(source)}</div>
          {/if}
        {:else}
          <p>Origine della missione non disponibile.</p>
        {/each}
        {#if quest.objectives.length}
          <ul>{#each quest.objectives as objective}<li>{objective}</li>{/each}</ul>
        {/if}
        <a href="https://www.wowhead.com/forever/quest={quest.id}" target="_blank" rel="noreferrer">Apri missione su Wowhead</a>
      </details>
    {:else}
      <p role="status">Missioni non disponibili nei dati di questo dungeon.</p>
    {/each}
  {:else}
    <label class="selector" for="dungeon-loot-boss">Boss
      <select id="dungeon-loot-boss" bind:value={pickedBoss}>
        <option value="">Tutti i boss dell’ala</option>
        {#each bosses as boss}<option value={boss}>{boss}</option>{/each}
      </select>
    </label>
    <p>Oggetti registrati in QuestieDB Forever e AllTheThings.</p>
    {#each pickedBoss ? [pickedBoss] : bosses as boss (boss)}
      {@const items = loot?.[boss] ?? []}
      <details open={!!pickedBoss}>
        <summary>{boss}<small> · {items.length} {items.length === 1 ? 'oggetto' : 'oggetti'}</small></summary>
        {#if items.length}
          <DungeonLootList {items} details={lootDetails ?? {}} />
        {:else}
          <p>Bottino non disponibile per questo boss.</p>
        {/if}
      </details>
    {/each}
  {/if}
  {/if}
</aside>

<style>
  .dungeon-panel {position:absolute;z-index:1230;top:14px;left:14px;box-sizing:border-box;width:min(375px,calc(100% - 28px));max-height:calc(100% - 92px);overflow:auto;overscroll-behavior:contain;padding:12px;border:1px solid #c19b5a;border-radius:6px;background:#0e213bf5;color:#fff0cd;box-shadow:0 8px 26px #0009;font:16px var(--font)}
  .dungeon-panel.local-preview {width:min(680px,calc(100% - 28px))}
  .map-and-bosses.embedded {display:block}
  .floors {display:flex;align-items:center;gap:8px}
  .floors button {min-width:42px}
  button:disabled {opacity:.45;cursor:default}
  header {display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
  h2 {margin:0;font-size:23px}
  button, select {min-height:42px;border:1px solid #a68757;border-radius:4px;background:#1a3859;color:inherit;padding:6px 10px;font:600 16px var(--font)}
  button {cursor:pointer}
  button:hover, button[aria-pressed=true] {background:#30567f}
  .close {min-width:42px;font-size:24px}
  .back {margin-bottom:6px}
  .dungeon-directory {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;list-style:none;margin:0;padding:0}
  .dungeon-directory button {display:flex;align-items:center;justify-content:space-between;gap:9px;width:100%;min-height:48px;text-align:left}
  .dungeon-directory span {flex:none;color:#ffe0a0;font-size:14px}
  .tabs {display:flex;flex-wrap:wrap;gap:7px;margin:12px 0}
  .selector {display:flex;align-items:center;gap:8px;margin:12px 0}
  select {min-width:0;flex:1}
  .map-and-bosses {display:grid;grid-template-columns:minmax(0,3fr) minmax(143px,1fr);gap:12px}
  .dungeon-map-frame {position:relative;min-height:290px;height:min(52vh,480px);border:1px solid #a6875780;overflow:hidden;border-radius:4px}
  .bosses {margin:0;padding-left:25px;max-height:min(52vh,480px);overflow:auto}
  .bosses li {padding:0 2px 5px}
  .bosses button {width:100%;text-align:left}
  details {border-top:1px solid #a687575b;padding:0 6px 8px}
  summary {cursor:pointer;padding:10px 0;font-weight:700}
  p, .source {margin:4px 0 9px}
  .locations {margin:3px 0;padding-left:24px;color:#dfd0b1}
  small {color:#dfd0b1}
  a {color:#b6dcff}
  @media (max-width:760px) {
    .dungeon-panel {top:auto;bottom:63px;left:10px;width:min(375px,calc(100% - 20px));max-height:36%;padding:8px}
  }
  @media (max-width:580px) {
    .dungeon-directory {grid-template-columns:1fr}
    .map-and-bosses {grid-template-columns:1fr}
    .bosses {max-height:none}
    .dungeon-map-frame {height:42vh}
  }
</style>
