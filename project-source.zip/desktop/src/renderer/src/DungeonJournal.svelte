<script lang="ts">
  import { untrack } from 'svelte'
  import { DUNGEON_LOOT_FILE, dungeonCompletionLabel, dungeonDirectory, dungeonGuideFor, questChain, type DungeonJournalData, type DungeonLootDetailsById, type QuestPlace, type QuestReference, type QuestSource, type QuestStep } from '../../shared/dungeon-journal'
  import { prepareDungeon, type PreparationPlan, type PreparationStop } from '../../shared/dungeon-preparation'
  import type { WorldPoint } from '../../shared/map-navigation'
  import { OPENMAP } from './web'
  import DungeonMap from './DungeonMap.svelte'
  import DungeonLootList from './DungeonLootList.svelte'
  import type { DungeonApproach } from '../../shared/dungeon-approaches'

  let { initialNames, selectedName, onSelect, onClose, overlay = false, selectedBoss, floor = 0, maxFloor = 0, onFloor, onBoss, mapStatus, approach, onApproach, preparation, onPreparation, onPreparationStop, onPreparationFit, locateQuestNpc, completedDungeons, legacyDungeons, completedQuests, hasDungeonProgress }: {
    initialNames: string[]; selectedName?: string; onSelect?: (entry: typeof dungeonDirectory[number]) => void
    onClose: () => void; overlay?: boolean; selectedBoss?: { name: string }; floor?: number; maxFloor?: number
    onFloor?: (floor: number) => void; onBoss?: (boss: string) => void; mapStatus?: string
    approach?: DungeonApproach; onApproach?: (show: boolean) => void
    preparation?: {
      entrance: PreparationStop
      side?: 'A' | 'H'
      level?: number
      active?: ReadonlySet<number>
      currentPosition: () => WorldPoint | undefined
      locate: (place: QuestPlace) => WorldPoint | undefined
    }
    onPreparation?: (open: boolean, plan?: PreparationPlan) => void
    onPreparationStop?: (point: WorldPoint) => void
    onPreparationFit?: () => void
    completedDungeons: ReadonlySet<number>; legacyDungeons: ReadonlySet<number>
    completedQuests?: ReadonlySet<number>; hasDungeonProgress: boolean
    locateQuestNpc?: (name: string, place: QuestPlace) => (() => void) | undefined
  } = $props()
  let panel: HTMLElement
  let directorySelection = $state.raw<string[]>([])
  let historyOpen = $state(false)
  let wing = $state(0)
  let tab = $state<'map' | 'quests' | 'loot' | 'entrance' | 'prepare'>('map')
  let pickedBoss = $state('')
  let along = $state(false)
  let origin = $state.raw<WorldPoint>()
  let journal = $state.raw<DungeonJournalData>()
  let lootDetails = $state.raw<DungeonLootDetailsById>()
  let loading = $state(true)
  const names = $derived(initialNames.length ? initialNames : directorySelection)
  const name = $derived(selectedName ?? names[wing] ?? names[0] ?? 'Dungeon')
  const guide = $derived(dungeonGuideFor(name))
  const quests = $derived(guide && journal?.quests?.[guide.map] || [])
  const bosses = $derived(guide?.bosses.map(([boss]) => boss) ?? [])
  const loot = $derived(guide && journal?.loot?.[guide.map])
  const history = $derived.by(() => {
    if (!historyOpen || names.length) return []
    const byMap = new Map<number, (typeof dungeonDirectory)[number][]>()
    for (const entry of dungeonDirectory) {
      const map = dungeonGuideFor(entry.name)?.map
      if (map === undefined) continue
      const entries = byMap.get(map)
      if (entries) entries.push(entry)
      else byMap.set(map, [entry])
    }
    return [...byMap].flatMap(([map, entries]) => {
      const completion = dungeonCompletionLabel(entries[0].name, completedDungeons, legacyDungeons)
      const delivered = journal?.quests?.[map]?.filter(quest => completedQuests?.has(quest.id)) ?? []
      return completion || delivered.length ? [{ map, entries, completion, delivered }] : []
    })
  })
  const plan = $derived(tab === 'prepare' && preparation && journal && prepareDungeon({
    ...preparation, origin, quests, steps: journal.questSteps, completed: completedQuests, along,
  }) || undefined)
  function updateOrigin(): void {
    origin = preparation?.currentPosition()
  }
  function openPreparation(): void {
    updateOrigin()
    tab = 'prepare'
  }
  const number = new Intl.NumberFormat('it-IT', { maximumFractionDigits: 1 })

  $effect(() => {
    const needsJournal = names.length ? tab === 'quests' || tab === 'loot' || tab === 'prepare' : historyOpen && !!completedQuests
    if (!needsJournal || !loading) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/dungeon-journal.json`, { signal: request.signal })
      .then(response => response.ok ? response.json() : undefined)
      .then(value => { if (!request.signal.aborted) journal = value })
      .catch(() => {})
      .finally(() => { if (!request.signal.aborted) loading = false })
    return () => request.abort()
  })
  $effect(() => {
    if (tab !== 'loot' || lootDetails !== undefined) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/${DUNGEON_LOOT_FILE}`, { signal: request.signal })
      .then(response => response.ok ? response.json() : {})
      .catch(() => ({}))
      .then(value => { if (!request.signal.aborted) lootDetails = value })
    return () => request.abort()
  })
  function showLoot(boss: string): void {
    pickedBoss = boss
    tab = 'loot'
  }
  $effect(() => {
    void name
    tab = 'map'
    pickedBoss = ''
    if (panel) panel.scrollTop = 0
  })
  $effect(() => {
    if (selectedBoss) showLoot(selectedBoss.name)
  })
  $effect(() => {
    const open = !!preparation && tab === 'prepare'
    const route = plan
    untrack(() => onPreparation?.(open, route))
  })
  $effect(() => {
    const show = tab === 'entrance'
    untrack(() => onApproach?.(show))
  })
  function openEntry(entry: typeof dungeonDirectory[number]): void {
    if (onSelect) { onSelect(entry); return }
    wing = entry.index
    tab = 'map'
    pickedBoss = ''
    directorySelection = entry.wings
    panel.scrollTop = 0
  }
</script>

{#snippet locations(source: QuestSource)}
  {#if source.places.length}
    <ul class="locations">
      {#each source.places as place}
        {@const label = place.x === undefined || place.y === undefined ? place.zone : `${place.zone} · ${number.format(place.x)} / ${number.format(place.y)}`}
        {@const show = source.kind === 'npc' && source.places.length > 1 && locateQuestNpc?.(source.name, place)}
        <li>{#if show}<button class="quest-location" onclick={show}>{label}</button>{:else}{label}{/if}</li>
      {/each}
    </ul>
  {:else}
    <small>Posizione non disponibile</small>
  {/if}
{/snippet}

{#snippet sources(entries: QuestSource[])}
  {#each entries as source (`${source.kind}:${source.id}`)}
    {#if source.kind === 'item'}
      <p>Inizia usando <strong>{source.name}</strong>.</p>
      {#each source.drops ?? [] as drop}
        <div class="source">Si ottiene da {drop.name}. {@render locations(drop)}</div>
      {/each}
    {:else}
      {@const show = source.kind === 'npc' && source.places.map(place => locateQuestNpc?.(source.name, place)).find(Boolean)}
      <div class="source">
        {source.kind === 'npc' ? 'Parla con' : 'Interagisci con'}
        {#if show}<button class="quest-location" aria-label="Mostra {source.name} sulla mappa" onclick={show}>{source.name}</button>{:else}<strong>{source.name}</strong>{/if}
        {@render locations(source)}
      </div>
    {/if}
  {:else}
    <p>Origine della missione non disponibile.</p>
  {/each}
{/snippet}

{#snippet questLinks(entries: QuestReference[], joiner: string)}
  {#each entries as entry, index}{index ? joiner : ''}<a href="https://www.wowhead.com/forever/quest={entry.id}" target="_blank" rel="noreferrer">{entry.name}</a>{/each}
{/snippet}

{#snippet prerequisites(step: QuestStep)}
  {#if step.required.length}<p>Completa tutte: {@render questLinks(step.required, ', ')}.</p>{/if}
  {#if step.alternatives.length}<p>Completa una tra: {@render questLinks(step.alternatives, ' oppure ')}.</p>{/if}
  {#if step.previous?.length}<p>Passaggio precedente: {@render questLinks(step.previous, ' oppure ')}.</p>{/if}
{/snippet}

{#snippet chainStep(reference: QuestReference, step: QuestStep | undefined, before = false)}
  <li>
    <strong>{@render questLinks([reference], ', ')}</strong>
    {#if step}
      {#if before && !step.required.length && !step.alternatives.length && !step.previous?.length}<small> · Inizio della catena</small>{/if}
      {@render prerequisites(step)}
      {@render sources(step.starts)}
    {:else}
      <small> · Origine non disponibile</small>
    {/if}
  </li>
{/snippet}

<aside class="dungeon-panel" class:local-preview={!overlay && !!names.length} bind:this={panel} aria-labelledby="dungeon-journal-title">
  <header>
    <h2 id="dungeon-journal-title">{name}</h2>
    <button class="close" aria-label="Chiudi scheda dungeon" onclick={onClose}>×</button>
  </header>
  {#if !names.length}
    <div class="tabs" role="group" aria-label="Vista elenco dungeon">
      <button aria-pressed={!historyOpen} onclick={() => historyOpen = false}>Tutti</button>
      <button aria-pressed={historyOpen} onclick={() => historyOpen = true}>Storico personale</button>
    </div>
    {#if historyOpen}
      {#if !hasDungeonProgress}
        <p role="status">Collega il Pulser con un personaggio attivo per vedere lo storico.</p>
      {:else}
        {#if !completedQuests}
          <p role="status">Stato delle missioni non disponibile dal personaggio attivo.</p>
        {:else if loading}
          <p role="status">Caricamento delle missioni…</p>
        {:else if !journal}
          <p role="status">Elenco delle missioni non disponibile nel pacchetto cartografico.</p>
        {/if}
        {#if history.length}
          <ul class="history-list" aria-label="Storico dei dungeon">
            {#each history as item (item.map)}
              <li>
                <div class="history-links">
                  {#each item.entries as entry (entry.name)}
                    <button onclick={() => openEntry(entry)}>{entry.name}</button>
                  {/each}
                </div>
                {#if item.completion}<p class="history-complete">✓ {item.completion}</p>{/if}
                {#if item.delivered.length}
                  <h3>Missioni consegnate</h3>
                  <ul>
                    {#each item.delivered as quest (quest.id)}<li>{quest.name}</li>{/each}
                  </ul>
                {/if}
              </li>
            {/each}
          </ul>
        {:else if !(completedQuests && loading)}
          <p role="status">Nessun completamento registrato.</p>
        {/if}
      {/if}
    {:else}
    <ul class="dungeon-directory" aria-label="Elenco dungeon">
      {#each dungeonDirectory as entry (entry.name)}
        {@const completion = dungeonCompletionLabel(entry.name, completedDungeons, legacyDungeons)}
        {@const levels = `Liv. ${entry.min}–${entry.max}`}
        <li>
          <button aria-label={completion ? `${entry.name}, ${levels}, ${completion}` : undefined} onclick={() => openEntry(entry)}>
            <strong>{entry.name}</strong>
            <span class="directory-meta">
              <span>{levels}</span>
              {#if completion}
                <span class="directory-check" title={completion} aria-hidden="true">✓</span>
              {/if}
            </span>
          </button>
        </li>
      {/each}
    </ul>
    {/if}
  {:else}
  {#if !overlay && !initialNames.length}
    <button class="back" onclick={() => { directorySelection = []; panel.scrollTop = 0 }}>Torna alla lista</button>
  {/if}
  {#if names.length > 1}
    <label class="selector" for="dungeon-wing">Ala
      <select id="dungeon-wing" value={overlay ? names.indexOf(name) : wing} onchange={event => {
        const index = Number(event.currentTarget.value)
        const entry = dungeonDirectory.find(candidate => candidate.name === names[index])
        if (overlay && entry) onSelect?.(entry)
        else wing = index
      }}>
        {#each names as entry, index}
          <option value={index}>{entry}</option>
        {/each}
      </select>
    </label>
  {/if}
  {#if overlay && maxFloor > 0 && tab !== 'entrance' && tab !== 'prepare'}
    <div class="floors" role="group" aria-label="Piano del dungeon">
      <button onclick={() => onFloor?.(floor - 1)} disabled={floor === 0} aria-label="Piano inferiore">−</button>
      <span>Piano {floor + 1}/{maxFloor + 1}</span>
      <button onclick={() => onFloor?.(floor + 1)} disabled={floor === maxFloor} aria-label="Piano superiore">+</button>
    </div>
  {/if}
  <div class="tabs" role="group" aria-label="Sezioni del dungeon">
    <button aria-pressed={tab === 'map'} onclick={() => tab = 'map'}>Mappa e boss</button>
    {#if onApproach}<button aria-pressed={tab === 'entrance'} onclick={() => tab = 'entrance'}>Ingresso</button>{/if}
    <button aria-pressed={tab === 'quests'} onclick={() => tab = 'quests'}>Missioni</button>
    <button aria-pressed={tab === 'loot'} onclick={() => tab = 'loot'}>Bottino</button>
    {#if preparation}<button aria-pressed={tab === 'prepare'} onclick={openPreparation}>Prepara le missioni</button>{/if}
  </div>

  {#if tab === 'entrance'}
    {#if approach}
      <p><strong>{approach.label}</strong></p>
      <p>{approach.directions}</p>
      {#if approach.routes?.length}
        <p>Segui le frecce dorate fino {approach.routes.length === 1 ? 'al portale' : 'al portale scelto'}.</p>
        {#if approach.routes.length > 1}
          <ul>{#each approach.routes as route}<li>{route.label}</li>{/each}</ul>
        {/if}
      {:else}
        <small>Percorso interno da rilevare.</small>
      {/if}
    {:else}
      <p>Il portale è segnato sulla mappa.</p>
    {/if}
  {:else if !guide}
    <p role="status">Scheda non disponibile per questo dungeon.</p>
  {:else if tab === 'map'}
    {#if mapStatus}<p role="status">{mapStatus}</p>{/if}
    <section class="map-and-bosses" class:embedded={overlay} aria-label="Mappa interna e lista dei boss">
      {#if !overlay}<div class="dungeon-map-frame">
        {#key guide.name}<DungeonMap {guide} onBoss={showLoot} />{/key}
      </div>{/if}
      <ol class="bosses">
        {#each bosses as boss}
          <li><button onclick={() => { onBoss?.(boss); showLoot(boss) }}>{boss}</button></li>
        {/each}
      </ol>
    </section>
  {:else if loading}
    <p role="status">Caricamento della scheda…</p>
  {:else if !journal}
    <p role="status">Missioni e bottino non disponibili nel pacchetto cartografico.</p>
  {:else if tab === 'prepare' && plan}
    <div class="tabs preparation-modes" role="group" aria-label="Missioni lungo il percorso">
      <button aria-pressed={!along} onclick={() => along = false}>Giro completo</button>
      <button aria-pressed={along} onclick={() => along = true}>Lungo il tragitto</button>
    </div>
    {#if !origin}<p><small>Partenza stimata dall’ingresso. Collega il Pulser nel mondo per partire dal personaggio.</small></p>{/if}
    {#if !completedQuests || !preparation?.active}<p><small>Progresso missioni incompleto. Alcune tappe potrebbero essere già fatte.</small></p>{/if}
    {#if !preparation?.side || preparation.level === undefined}<p><small>Fazione o livello non disponibili. Verifica i requisiti prima di partire.</small></p>{/if}
    {#if plan.seconds !== undefined}
      <p><small>Circa {Math.max(1, Math.ceil(plan.seconds / 60))} min di viaggio. I tratti a piedi sono in linea d’aria. L’attesa dei mezzi può variare.</small></p>
    {:else}
      <p role="status">Tragitto fino all’ingresso non disponibile dai dati attuali.</p>
    {/if}
    <div class="tabs">
      <button onclick={onPreparationFit}>Mostra percorso</button>
      {#if origin || preparation?.currentPosition()}<button onclick={updateOrigin}>Ricalcola dal personaggio</button>{/if}
    </div>
    <ol class="preparation-stops" aria-label="Tappe per preparare le missioni">
      {#each plan.stops as stop}
        <li>
          <button onclick={() => onPreparationStop?.(stop.point)}>{stop.label}</button>
          {#if stop.actions.length}
            <ul>{#each stop.actions as action (action.id)}<li>{action.text}</li>{/each}</ul>
          {:else if onApproach}
            <button class="quest-location" onclick={() => tab = 'entrance'}>Indicazioni per l’ingresso</button>
          {/if}
        </li>
      {/each}
    </ol>
    {#if plan.legs.some(leg => leg.kind !== 'walk')}
      <details open>
        <summary>Navi e zeppelin</summary>
        <ul>
          {#each plan.legs.filter(leg => leg.kind !== 'walk') as leg}
            <li>
              {leg.kind === 'boat' ? 'Nave' : 'Zeppelin'}
              <button class="quest-location" onclick={() => onPreparationStop?.(leg.from.point)}>{leg.from.label}</button>
              →
              <button class="quest-location" onclick={() => onPreparationStop?.(leg.to.point)}>{leg.to.label}</button>
            </li>
          {/each}
        </ul>
      </details>
    {/if}
    {#if plan.unmapped.length}
      <details>
        <summary>{along ? 'Fuori tragitto o da verificare' : 'Missioni da verificare'} · {plan.unmapped.length}</summary>
        <p><small>Per queste missioni manca una tappa raggiungibile o un prerequisito verificabile.</small></p>
        <ul>{#each plan.unmapped as mission}<li>{mission}</li>{/each}</ul>
      </details>
    {/if}
  {:else if tab === 'quests'}
    {#if names.length > 1}<p>Missioni dell’intero dungeon, comprese le altre ali.</p>{/if}
    {#each quests as quest (quest.id)}
      {@const chain = questChain(quest, journal.questSteps)}
      <details>
        <summary>{quest.name}{#if completedQuests?.has(quest.id)}<small class="history-complete"> · ✓ Consegnata</small>{/if}{#if quest.level}<small> · Livello minimo {quest.level}</small>{/if}{#if quest.faction}<small> · {quest.faction === 'A' ? 'Alleanza' : 'Orda'}</small>{/if}</summary>
        {#if chain.before.length || chain.after.length}
          <h3>Catena di missioni</h3>
          <ol class="quest-chain">
            {#each chain.before as { reference, step } (reference.id)}{@render chainStep(reference, step, true)}{/each}
            <li><strong>{quest.name}</strong><small> · Missione selezionata</small>
              {@render prerequisites(chain.current)}
              {@render sources(chain.current.starts)}
            </li>
            {#each chain.after as { reference, step } (reference.id)}{@render chainStep(reference, step)}{/each}
          </ol>
        {:else}
          {@render sources(quest.starts)}
        {/if}
        {#if quest.objectives.length}
          <ul>{#each quest.objectives as objective}<li>{objective}</li>{/each}</ul>
        {/if}
        <a href="https://www.wowhead.com/forever/quest={quest.id}" target="_blank" rel="noreferrer">Apri missione su Wowhead</a>
      </details>
    {:else}
      <p role="status">Missioni non disponibili nei dati di questo dungeon.</p>
    {/each}
  {:else}
    <label class="selector" for="dungeon-loot-boss">Boss
      <select id="dungeon-loot-boss" bind:value={pickedBoss}>
        <option value="">Tutti i boss dell’ala</option>
        {#each bosses as boss}<option value={boss}>{boss}</option>{/each}
      </select>
    </label>
    <p>Oggetti registrati in QuestieDB Forever e AllTheThings.</p>
    {#each pickedBoss ? [pickedBoss] : bosses as boss (boss)}
      {@const items = loot?.[boss] ?? []}
      <details open={!!pickedBoss}>
        <summary>{boss}<small> · {items.length} {items.length === 1 ? 'oggetto' : 'oggetti'}</small></summary>
        {#if items.length}
          <DungeonLootList {items} details={lootDetails ?? {}} />
        {:else}
          <p>Bottino non disponibile per questo boss.</p>
        {/if}
      </details>
    {/each}
  {/if}
  {/if}
</aside>

<style>
  .dungeon-panel {position:absolute;z-index:1230;top:14px;left:14px;box-sizing:border-box;width:min(375px,calc(100% - 28px));max-height:calc(100% - 92px);overflow:auto;overscroll-behavior:contain;padding:12px;border:1px solid #c19b5a;border-radius:6px;background:#0e213bf5;color:#fff0cd;box-shadow:0 8px 26px #0009;font:16px var(--font)}
  .dungeon-panel.local-preview {width:min(680px,calc(100% - 28px))}
  .map-and-bosses.embedded {display:block}
  .floors {display:flex;align-items:center;gap:8px}
  .floors button {min-width:42px}
  button:disabled {opacity:.45;cursor:default}
  header {display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
  h2 {margin:0;font-size:23px}
  button, select {min-height:42px;border:1px solid #a68757;border-radius:4px;background:#1a3859;color:inherit;padding:6px 10px;font:600 16px var(--font)}
  button {cursor:pointer}
  button:hover, button[aria-pressed=true] {background:#30567f}
  .close {min-width:42px;font-size:24px}
  .back {margin-bottom:6px}
  .dungeon-directory {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:1fr;gap:7px;list-style:none;margin:0;padding:0}
  .dungeon-directory button {
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    gap:6px;
    box-sizing:border-box;
    width:100%;
    height:100%;
    padding:8px 10px;
    text-align:left;
    overflow-wrap:anywhere;
  }
  .directory-meta {display:flex;align-items:center;justify-content:space-between;gap:8px;color:#ffe0a0;font-size:14px;line-height:20px}
  .directory-check {color:#98eb8e;font:700 18px/20px system-ui,sans-serif}
  .preparation-modes button {flex:1}
  .preparation-stops {padding-left:25px}
  .preparation-stops > li {padding:5px 0 8px}
  .preparation-stops button {text-align:left}
  .preparation-stops ul {padding-left:18px;margin-top:4px}
  .history-list {list-style:none;margin:0;padding:0}
  .history-list > li {border-top:1px solid #a687575b;padding:10px 0}
  .history-links {display:flex;flex-wrap:wrap;gap:6px}
  .history-links button {text-align:left}
  .history-complete {color:#98eb8e}
  .history-list p {margin:6px 0 0}
  .history-list ul {padding-left:20px}
  .tabs {display:flex;flex-wrap:wrap;gap:7px;margin:12px 0}
  .selector {display:flex;align-items:center;gap:8px;margin:12px 0}
  select {min-width:0;flex:1}
  .map-and-bosses {display:grid;grid-template-columns:minmax(0,3fr) minmax(143px,1fr);gap:12px}
  .dungeon-map-frame {position:relative;min-height:290px;height:min(52vh,480px);border:1px solid #a6875780;overflow:hidden;border-radius:4px}
  .bosses {margin:0;padding-left:25px;max-height:min(52vh,480px);overflow:auto}
  .bosses li {padding:0 2px 5px}
  .bosses button {width:100%;text-align:left}
  details {border-top:1px solid #a687575b;padding:0 6px 8px}
  summary {cursor:pointer;padding:10px 0;font-weight:700}
  p, .source {margin:4px 0 9px}
  .locations {margin:3px 0;padding-left:24px;color:#dfd0b1}
  .quest-location {min-height:44px;padding:2px 7px;color:#ffe0a1;text-align:left}
  .quest-chain {padding-left:23px}
  .quest-chain > li {margin-bottom:9px}
  h3 {margin:9px 0 4px;font-size:17px}
  small {color:#dfd0b1}
  a {color:#b6dcff}
  @media (max-width:760px) {
    .dungeon-panel {top:auto;bottom:63px;left:10px;width:min(375px,calc(100% - 20px));max-height:36%;padding:8px}
  }
  @media (max-width:580px) {
    .dungeon-directory {grid-template-columns:1fr}
    .map-and-bosses {grid-template-columns:1fr}
    .bosses {max-height:none}
    .dungeon-map-frame {height:42vh}
  }
</style>
