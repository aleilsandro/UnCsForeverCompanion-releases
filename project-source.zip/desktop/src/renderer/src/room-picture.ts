import { roomPixels, type Piece } from '../../shared/inside'
import { TILES } from './web'

const roomCache = new Map<string, { image: Promise<HTMLCanvasElement | null>; bytes: number }>()
const byteLimit = 24 * 1024 * 1024
let cacheBytes = 0

export function roomPicture(piece: Piece): Promise<HTMLCanvasElement | null> {
  const key = `${piece.file}:${piece.width / piece.height}`
  const cached = roomCache.get(key)
  if (cached) {
    roomCache.delete(key)
    roomCache.set(key, cached)
    return cached.image
  }
  const entry = { image: decodeRoom(piece), bytes: 0 }
  roomCache.set(key, entry)
  void entry.image.then(canvas => {
    if (!canvas) { roomCache.delete(key); return }
    entry.bytes = canvas.width * canvas.height * 4
    cacheBytes += entry.bytes
    for (const [oldKey, old] of roomCache) {
      if (cacheBytes <= byteLimit) break
      if (!old.bytes) continue
      roomCache.delete(oldKey)
      cacheBytes -= old.bytes
    }
  })
  return entry.image
}

async function decodeRoom(piece: Piece): Promise<HTMLCanvasElement | null> {
  try {
    const response = await fetch(`${TILES}/rooms/${piece.file}.dxt`)
    if (!response.ok || !response.body) return null
    const dxt = new Uint8Array(await new Response(response.body.pipeThrough(new DecompressionStream('deflate'))).arrayBuffer())
    const width = Math.round(Math.sqrt(dxt.length * 2 * piece.width / piece.height)), height = dxt.length * 2 / width
    if (!Number.isInteger(height) || width < 1 || height < 1 || width > 4096 || height > 4096) return null
    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    canvas.getContext('2d')?.putImageData(new ImageData(roomPixels(dxt, width, height), width, height), 0, 0)
    return canvas
  } catch { return null }
}
