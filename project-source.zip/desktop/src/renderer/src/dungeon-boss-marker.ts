import L from 'leaflet'
import { nameOfBoss } from '../../shared/inside'

export function addDungeonBossMarker(
  layer: L.Map | L.LayerGroup, at: L.LatLngExpression, name: string, number: number, onClick: () => void, zIndexOffset = 0,
) {
  const label = document.createElement('span')
  label.textContent = name
  const ordinal = document.createElement('span')
  ordinal.className = 'dungeon-boss-number'
  ordinal.textContent = String(number)
  const marker = L.marker(at, {
    icon: L.divIcon({ className: 'dungeon-boss-pin', html: ordinal, iconSize: [26, 26] }),
    alt: name,
    zIndexOffset,
  }).bindTooltip(label, { direction: 'top' }).on('click', onClick).addTo(layer)
  return { marker, label, name, key: nameOfBoss(name) }
}

export function setDungeonBossDefeated(
  { marker, label, name, key }: ReturnType<typeof addDungeonBossMarker>, defeated: ReadonlySet<string>,
): void {
  const killed = defeated.has(key)
  const description = killed ? name + ' (sconfitto)' : name
  const element = marker.getElement()
  element?.classList.toggle('boss-defeated', killed)
  element?.setAttribute('aria-label', description)
  element?.setAttribute('title', description)
  label.textContent = description
}
