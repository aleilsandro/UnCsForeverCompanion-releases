import { expandDetailCoast, type Harbour } from './detail-coast-mask'

export async function detailCoast(image: HTMLImageElement, harbours: Harbour[], signal: AbortSignal): Promise<Blob | null> {
  if (typeof OffscreenCanvas !== 'undefined' && typeof createImageBitmap === 'function' && typeof Worker !== 'undefined') {
    try {
      const source = await createImageBitmap(image)
      if (signal.aborted) { source.close(); return null }
      const result = await new Promise<Blob | null>(resolve => {
        const worker = new Worker(new URL('./detail-coast.worker.ts', import.meta.url), { type: 'module' })
        const abort = () => finish(null)
        function finish(blob: Blob | null): void {
          signal.removeEventListener('abort', abort)
          worker.terminate()
          resolve(blob)
        }
        signal.addEventListener('abort', abort, { once: true })
        worker.onmessage = event => finish(event.data)
        worker.onerror = () => finish(null)
        worker.postMessage({ source, harbours }, [source])
      })
      if (result || signal.aborted) return result
    } catch { /* Use Canvas on browsers without a functional bitmap worker. */ }
  }
  if (signal.aborted) return null
  const canvas = document.createElement('canvas')
  canvas.width = image.naturalWidth
  canvas.height = image.naturalHeight
  const context = canvas.getContext('2d', { willReadFrequently: true })
  if (!context) return null
  context.drawImage(image, 0, 0)
  const pixels = context.getImageData(0, 0, canvas.width, canvas.height)
  expandDetailCoast(pixels.data, pixels.width, pixels.height, harbours)
  context.putImageData(pixels, 0, 0)
  return new Promise(resolve => canvas.toBlob(resolve, 'image/png'))
}
