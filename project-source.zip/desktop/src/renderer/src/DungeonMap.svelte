<script lang="ts">
  import { onMount } from 'svelte'
  import L from 'leaflet'
  import 'leaflet/dist/leaflet.css'
  import { OPENMAP, TILES } from './web'
  import type { Position } from '../../shared/game'
  import { boxOf, MIDDLE_YARDS, piecesIn, yardsInside, YARDS_PER_UNIT, type Interiors, type InteriorMap, type Piece } from '../../shared/inside'
  import { playerIcon, turnPlayer, type CursorStyle } from './player-icon'
  import { pictureOfBlock, tileOfPicture } from '../../shared/pixels'
  import type { DungeonPins } from '../../shared/dungeon-pins'
  import { dungeonGuides } from '../../shared/dungeon-journal'
  import { roomPicture } from './room-picture'
  import type { Companion } from '../../shared/group'
  import { classColour } from '../../shared/characters'
  import { roomFloor } from './dungeon-overlay'
  import { addDungeonBossMarker, setDungeonBossDefeated } from './dungeon-boss-marker'
  let {pos,cursor='a',guide,onBoss,players=[],defeatedBosses=new Set<string>()}:{defeatedBosses?:ReadonlySet<string>;pos?:Position;cursor?:CursorStyle;guide?:DungeonPins;onBoss?:(name:string)=>void;players?:Companion[]}=$props()
  let holder:HTMLDivElement
  let map:L.Map|undefined, marker:L.Marker|undefined, layer:L.GridLayer|undefined
  let interior:InteriorMap|undefined
  let markerStyle:CursorStyle|undefined
  let lastDetectedFloor:number|undefined
  const companions = L.layerGroup()
  const bossMarkers: ReturnType<typeof addDungeonBossMarker>[] = []
  const companionMarkers = new Map<string, L.CircleMarker>()
  let status=$state('Preparazione della mappa del dungeon...')
  let floor=$state(0), maxFloor=$state(0), follow=$state(true)
  const blocks=new Map<string,Promise<ReturnType<typeof pictureOfBlock>|null>>()
  const at=(u:number,v:number):L.LatLng=>L.latLng(-v/YARDS_PER_UNIT,u/YARDS_PER_UNIT)
  const Rooms=L.GridLayer.extend({
    createTile(this:L.GridLayer & {options:{pieces:Piece[]}},coords:L.Coords,done:L.DoneCallback) {
      const canvas=document.createElement('canvas'); canvas.width=canvas.height=256
      const scale=YARDS_PER_UNIT/2**coords.z, side=256*scale, u=coords.x*side, v=coords.y*side
      const pieces=piecesIn(this.options.pieces,[u,v,u+side,v+side])
      void Promise.all(pieces.map(roomPicture)).then(images=>{
        const ctx=canvas.getContext('2d')!
        pieces.forEach((p,i)=>{ const image=images[i]; if(!image)return; ctx.setTransform(1,0,0,1,0,0); ctx.translate((p.u-u)/scale,(p.v-v)/scale); ctx.rotate(-p.angle); ctx.drawImage(image,-p.width/2/scale,-p.height/2/scale,p.width/scale,p.height/scale) })
        done(undefined,canvas)
      }).catch(()=>done(undefined,canvas))
      return canvas
    },
  }) as unknown as new(options:L.GridLayerOptions & {pieces:Piece[]})=>L.GridLayer
  const Ground=L.GridLayer.extend({
    createTile(this:L.GridLayer & {options:{world:string}},coords:L.Coords,done:L.DoneCallback) {
      const canvas=document.createElement('canvas');canvas.width=canvas.height=256
      const top=coords.z===7,col=top ? coords.x>>1 : coords.x,row=top ? coords.y>>1 : coords.y
      const key=`${this.options.world}/${col}/${row}`
      let job=blocks.get(key)
      if(!job) {job=fetch(`${TILES}/${this.options.world}/blocks/${col}/${row}.dxt`).then(async r=>r.ok && r.body ? pictureOfBlock(new Uint8Array(await new Response(r.body.pipeThrough(new DecompressionStream('deflate'))).arrayBuffer())) : null).catch(()=>null);blocks.set(key,job)}
      void job.then(block=>{if(block){const rgb=tileOfPicture(block,top ? (coords.x&1)+(coords.y&1)*2 : undefined),image=new ImageData(256,256);for(let i=0,o=0;i<rgb.length;i+=3,o+=4){image.data[o]=rgb[i]!;image.data[o+1]=rgb[i+1]!;image.data[o+2]=rgb[i+2]!;image.data[o+3]=255}canvas.getContext('2d')!.putImageData(image,0,0)}done(undefined,canvas)}).catch(()=>done(undefined,canvas))
      return canvas
    },
  }) as unknown as new(options:L.GridLayerOptions & {world:string})=>L.GridLayer
  function showFloor():void {
    if (!map || !interior) return
    layer?.remove(); const pieces=interior.pieces.filter(p=>p.level<=floor), box=boxOf(pieces)
    if(box) layer=new Rooms({pieces,bounds:L.latLngBounds(at(box[0],box[1]),at(box[2],box[3])),keepBuffer:3,maxNativeZoom:8}).addTo(map)
  }
  function updatePosition():void {
    if(!map || !interior || !pos) return
    const where=pos.inst && yardsInside(pos.inst)
    const detected=pos.inst?.level ?? (where && roomFloor(interior.pieces, where.u, where.v))
    if(detected!==undefined && detected!==lastDetectedFloor && detected<=maxFloor) {lastDetectedFloor=detected;floor=detected;showFloor()}
    if(!where) { marker?.remove(); marker=undefined; status='Mappa disponibile · posizione nel dungeon non ancora rilevata'; return }
    status=''; const point=at(where.u,where.v)
    if(!marker) { marker=L.marker(point,{icon:playerIcon(cursor),interactive:false,zIndexOffset:1000}).addTo(map); markerStyle=cursor }
    if(markerStyle!==cursor) {marker.setIcon(playerIcon(cursor)); markerStyle=cursor}
    turnPlayer(marker,pos.facing); marker.setLatLng(point)
    if(follow && !map.getBounds().pad(-.1).contains(point)) map.panTo(point,{animate:false})
  }
  function showPlayers(members: Companion[], level: number): void {
    const present = new Set<string>()
    if (interior) for (const { name, cls, inst, wx, wy, floor: knownFloor } of members) {
      if (inst !== interior.id || wx === undefined || wy === undefined) continue
      const u = MIDDLE_YARDS - wy, v = MIDDLE_YARDS - wx
      const detected = knownFloor ?? roomFloor(interior.pieces, u, v)
      if (detected !== undefined && detected !== level) continue
      present.add(name)
      const point = at(u, v)
      const existing = companionMarkers.get(name)
      const colour = classColour(cls) ?? '#aab6c4'
      if (existing) { existing.setLatLng(point).setStyle({ fillColor: colour }); continue }
      const label = document.createElement('span')
      label.textContent = name
      const pin = L.circleMarker(point, { className: 'dungeon-party-marker', radius: 7, weight: 2, color: '#fdf4db', fillColor: colour, fillOpacity: 1 })
        .bindTooltip(label, { direction: 'top' })
        .on('click', event => (event.target as L.CircleMarker).openTooltip())
        .addTo(companions)
      companionMarkers.set(name, pin)
    }
    for (const [name, pin] of companionMarkers) if (!present.has(name)) { companions.removeLayer(pin); companionMarkers.delete(name) }
  }
  onMount(()=>{
    const instance=L.map(holder,{crs:L.CRS.Simple,minZoom:-1,maxZoom:8,zoomSnap:.25,zoomDelta:.5,zoomControl:false,attributionControl:false})
    map=instance; instance.setView([0,0],0); companions.addTo(instance); instance.on('dragstart',()=>follow=false)
    let closed=false, running=false
    const load=():void=>{
      if(running || interior) return; running=true
      fetch(`${TILES}/interiors.json`,{cache:'no-store'}).then(async r=>r.ok ? await r.json() as Interiors : null).then(list=>{
        if(closed || !list) return
        const found=list.maps.find(m=>m.id===(guide?.map ?? pos?.inst?.id) && m.kind!=='world' && (m.pieces.length || m.ground))
        if(!found) {status='Mappa interna non disponibile nel pacchetto cartografico.'; return}
        interior=found; maxFloor=Math.max(0,...found.pieces.map(p=>p.level)); floor=pos?.inst?.level!==undefined ? Math.min(pos.inst.level,maxFloor) : maxFloor
        if(found.ground) {
          const bounds:L.LatLngBoundsExpression=[[-256,0],[0,256]]
          L.tileLayer(`${TILES}/${found.ground}/{z}/{x}/{y}.png`,{minZoom:0,maxZoom:8,maxNativeZoom:5,bounds,keepBuffer:3,opacity:.7}).addTo(instance)
          new Ground({world:found.ground,minZoom:5.5,minNativeZoom:6,maxNativeZoom:7,maxZoom:8,bounds,keepBuffer:3,opacity:.7}).addTo(instance)
        }
        showFloor(); const full = boxOf(found.pieces)
        const mapGuides = dungeonGuides.filter(d=>d.map===found.id)
        const known = guide ? [guide.bounds, ...(mapGuides.length === 1 && full ? [full] : [])] : mapGuides.map(d=>d.bounds)
        const box=known.length ? known.reduce<[number,number,number,number]>((all,b)=>[Math.min(all[0],b[0]),Math.min(all[1],b[1]),Math.max(all[2],b[2]),Math.max(all[3],b[3])],[Infinity,Infinity,-Infinity,-Infinity]) : full
        if(box) instance.fitBounds(L.latLngBounds(at(box[0],box[1]),at(box[2],box[3])),{animate:false,padding:[30,30]})
        if (guide) {
          status = ''
          if (guide.entrance) {
            const entrance = document.createElement('span')
            entrance.textContent = 'Portale d’ingresso'
            L.marker(at(...guide.entrance), { icon: L.divIcon({ className: 'dungeon-entry-pin', html: `<img src="${TILES}/icons/dungeon.png" width="18" height="18" alt="">`, iconSize: [25, 25] }), alt: 'Portale d’ingresso' })
              .on('add', event => (event.target as L.Marker).getElement()?.setAttribute('aria-label', 'Portale d’ingresso'))
              .bindTooltip(entrance, { direction: 'top' })
              .on('click', event => (event.target as L.Marker).openTooltip())
              .addTo(instance)
          }
          guide.bosses.forEach(([name, u, v], index) => {
            const pin = addDungeonBossMarker(instance, at(u, v), name, index + 1, () => onBoss?.(name))
            bossMarkers.push(pin)
            setDungeonBossDefeated(pin, defeatedBosses)
          })
        }
        if (pos) { updatePosition(); showPlayers(players, floor) }
      }).catch(()=>{if(!closed)status=guide ? 'Mappa interna non disponibile nel pacchetto cartografico.' : 'Preparazione della mappa del dungeon...'}).finally(()=>{running=false; if(!interior && pos) void fetch(`${OPENMAP}/dungeon-status.json`,{cache:'no-store'}).then(r=>r.json()).then(value=>{if(!closed && value?.id===pos?.inst?.id && value.state==='failed')status='Mappa del dungeon non disponibile nei file locali del gioco.'}).catch(()=>{})})
    }
    load(); const timer=pos ? setInterval(load,10000) : undefined; const resize=new ResizeObserver(()=>instance.invalidateSize()); resize.observe(holder)
    return ()=>{closed=true;clearInterval(timer);resize.disconnect();instance.remove();map=undefined}
  })
  $effect(()=>{void pos;void cursor;updatePosition()})
  $effect(()=>showPlayers(players, floor))
  $effect(() => {
    const defeated = defeatedBosses
    for (const marker of bossMarkers) setDungeonBossDefeated(marker, defeated)
  })
  function selectFloor(n:number):void {floor=Math.max(0,Math.min(maxFloor,n));showFloor()}
  function followPlayer():void {follow=true; const where=pos?.inst && yardsInside(pos.inst); if(map && where)map.panTo(at(where.u,where.v))}
</script>
<div class="dungeon" bind:this={holder}></div>
<div class="controls">{#if pos}<button onclick={followPlayer} aria-pressed={follow}>Centrati sul giocatore</button>{/if}{#if maxFloor>0}<button onclick={()=>selectFloor(floor-1)} disabled={floor===0}>− piano</button><span>Piano {floor+1}/{maxFloor+1}</span><button onclick={()=>selectFloor(floor+1)} disabled={floor===maxFloor}>+ piano</button>{/if}</div>
{#if status}<p class="notice">{status}</p>{/if}
<style>
  .dungeon {position:absolute;inset:0;background:#101d2a}
  .controls {position:absolute;z-index:1000;left:10px;right:10px;bottom:10px;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:6px;align-items:center;color:#f8e8bd;pointer-events:none}
  .controls button {pointer-events:auto}
  button {border:1px solid #caa45f;background:linear-gradient(#1c426e,#0b203eef);color:#ffedc3;border-radius:3px;min-width:39px;height:39px;padding:0 12px;font:600 15px var(--font);cursor:pointer;box-shadow:0 2px 7px #0008} button:disabled{opacity:.45} button[aria-pressed=true]{background:linear-gradient(#315f96,#163860)}
  .notice {position:absolute;z-index:1000;bottom:66px;left:20px;right:20px;margin:0;padding:10px 14px;color:#fff2d5;background:#0a1b32ef;border:1px solid #cba66188;border-radius:3px;font:14px var(--font)}
  :global(.player-wrap){background:transparent;border:0}
  :global(.dungeon-entry-pin) {display:grid;place-items:center;background:#173b42;color:#fff5d8;border:2px solid #e6bf7c;border-radius:50%;box-shadow:0 2px 6px #000b;font:700 14px var(--font)}

</style>
