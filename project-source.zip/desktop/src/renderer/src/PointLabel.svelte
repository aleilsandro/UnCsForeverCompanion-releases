<script lang="ts">
  // The label on a point of the map: its name, where it is, how far and how long on foot. It opens
  // on the side with the most room, some way off, and a gold line ties it to the point. Send to game has the game's
  // arrow follow the point, and says Sent once the addon tells it has it; on the point the game
  // follows the same button is Stop following. Add to route puts it at the end of the route. Save keeps the point among My pins; a saved one is
  // renamed by writing over its name, and Remove takes it away. On the door of a dungeon, Dungeon Map opens its own map.
  import type { Point } from '../../shared/geo'
  import { labelPlace, type Size } from '../../shared/point-label'
  import { arrived, type Inbox } from '../../shared/send'
  import { fade, scale } from 'svelte/transition'
  import Glyph from './Glyph.svelte'
  import { gone, pop } from './motion'
  import { TILES } from './web'

  let {
    title,
    item, // an item found: its picture from the player's game stands beside the name
    notes = [], // what the point is, when it is a pin of the map: whose quest, what service
    where, // zone coordinates, or nothing
    way, // distance, direction and time from the character, when it is on this map
    spot, // the point, in pixels of the map's box
    ring = false, // the point is a pin of the map: a ring around it instead of a dot over it
    box, // the map's box
    sending, // whether the point can be sent to the game now, and why not
    acked, // what the addon tells of the sends it has
    onsend, // sends the point: gives back the number of the send, or what went wrong
    following = false, // the game's arrow follows this very point
    onunfollow, // asks the game to let it go: answers as onsend does
    routed, // the point is already a stop of the route
    onroute, // adds the point to the route
    saved, // the point is one of My pins
    onsave,
    onrename,
    onremove,
    onclose,
    dungeons = [], // on a door: the dungeons and raids behind it whose maps the app has
    ondungeon,
  }: {
    title: string
    ring?: boolean
    item?: number
    notes?: string[]
    where: string
    way: { far: string; time: string } | null
    spot: Point
    box: Size
    sending: { can: boolean; why: string }
    acked: Inbox | null
    onsend: () => Promise<{ seq: number } | { error: string }>
    following?: boolean
    onunfollow?: () => Promise<{ seq: number } | { error: string }>
    routed: boolean
    onroute: () => void
    saved: boolean
    onsave: () => void
    onrename: (name: string) => void
    onremove: () => void
    onclose: () => void
    dungeons?: { id: number; name: string; raid: boolean }[]
    ondungeon?: (id: number) => void
  } = $props()

  const SENT_FOR = 2000 // ms the button says Sent
  const GIVE_UP = 20_000 // ms without a word from the game: it reads nothing in combat
  let phase = $state<'rest' | 'sending' | 'sent'>('rest')
  let awaited = $state<number | null>(null)
  let note = $state('')
  async function go(): Promise<void> {
    if (phase !== 'rest') return
    phase = 'sending'
    note = ''
    const answer = await (following && onunfollow ? onunfollow() : onsend())
    if ('error' in answer) {
      phase = 'rest'
      note = answer.error
    } else awaited = answer.seq
  }
  $effect(() => {
    if (phase === 'sending' && awaited !== null && arrived(acked, awaited)) phase = 'sent'
  })
  $effect(() => {
    if (phase === 'rest') return
    const sent = phase === 'sent'
    const timer = setTimeout(() => {
      phase = 'rest'
      awaited = null
      if (!sent) note = 'No answer from the game yet. It takes the pin once you are out of combat.'
    }, sent ? SENT_FOR : GIVE_UP)
    return () => clearTimeout(timer)
  })

  // How far from the point the label opens: far enough for the line between them to be seen past the pin.
  const GAP = 40
  let width = $state(0), height = $state(0)
  const at = $derived(labelPlace(spot, box, { width, height }, GAP))
  // The line ends on the label's edge nearest to the point.
  const end = $derived({ x: Math.max(at.left, Math.min(spot.x, at.left + width)), y: Math.max(at.top, Math.min(spot.y, at.top + height)) })
  // The line leaves the ring's edge, not the pin's middle.
  const RING = 13
  const start = $derived.by(() => {
    const d = Math.hypot(end.x - spot.x, end.y - spot.y)
    return ring && d > RING ? { x: spot.x + ((end.x - spot.x) * RING) / d, y: spot.y + ((end.y - spot.y) * RING) / d } : spot
  })
</script>

<svg class="tie" aria-hidden="true" in:fade={gone} out:fade={gone}>
  <!-- Twice: a dark line under the gold one, so that it shows on any ground. -->
  <line class="rim" x1={start.x} y1={start.y} x2={end.x} y2={end.y} />
  <line x1={start.x} y1={start.y} x2={end.x} y2={end.y} />
  {#if ring}
    <circle class="ring rim" cx={spot.x} cy={spot.y} r={RING} />
    <circle class="ring" cx={spot.x} cy={spot.y} r={RING} />
  {:else}
    <circle cx={spot.x} cy={spot.y} r="5.5" />
  {/if}
</svg>
<div class="label" data-side={at.side} role="dialog" in:scale={pop()} out:fade={gone} aria-label={title} style:left="{at.left}px" style:top="{at.top}px" style:visibility={width ? 'visible' : 'hidden'} bind:offsetWidth={width} bind:offsetHeight={height}>
  <button class="close" aria-label="Close" onclick={onclose}><Glyph name="close" size={14} /></button>
  {#if saved}
    <input class="name" aria-label="Name of the pin" value={title} maxlength="60" spellcheck="false" onchange={(e) => onrename(e.currentTarget.value)} onkeydown={(e) => e.key === 'Enter' && e.currentTarget.blur()} />
  {:else}
    <h3>{#if item}<img class="pic" src="{TILES}/items/{item}.png" alt="" onerror={(e) => e.currentTarget.remove()} />{/if}{title}</h3>
  {/if}
  {#each notes as note}<p>{note}</p>{/each}
  {#if where}<p class="dim">{where}</p>{/if}
  {#if way}<p>{way.far}, {way.time}</p>{/if}
  <!-- The maps behind a door, on a row of their own above the others: one is Dungeon Map, or Raid Map; several, a button each by its name. -->
  {#if dungeons.length}
    <div class="go maps">
      {#each dungeons as d (d.id)}<button class="btn" onclick={() => ondungeon?.(d.id)}>{dungeons.length > 1 ? d.name : d.raid ? 'Raid Map' : 'Dungeon Map'}</button>{/each}
    </div>
  {/if}
  <div class="go">
    <button class="btn send" disabled={!sending.can} aria-busy={phase === 'sending'} onclick={go}>{phase === 'sending' ? 'Sending' : phase === 'sent' ? 'Sent' : following ? 'Stop following' : 'Send to game'}</button>
    <button class="btn" disabled={routed} onclick={onroute}>{routed ? 'In route' : 'Add to route'}</button>
    {#if saved}<button class="btn" onclick={onremove}>Remove</button>{:else}<button class="btn" onclick={onsave}>Save</button>{/if}
  </div>
  {#if note || !sending.can}<p class="dim why" role="status">{note || sending.why}</p>{/if}
</div>

<style>
  .tie {
    position: absolute;
    inset: 0;
    z-index: 1150;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }
  line {
    stroke: var(--gold);
    stroke-width: 3;
    stroke-linecap: round;
  }
  .rim {
    stroke: #000;
    stroke-width: 6;
  }
  circle {
    fill: var(--gold);
    stroke: #000;
    stroke-width: 2;
  }
  .ring {
    fill: none;
    stroke: var(--gold);
    stroke-width: 3;
  }
  .ring.rim {
    stroke: #000;
    stroke-width: 6;
  }

  .label {
    position: absolute;
    z-index: 1150;
    min-width: 236px;
    max-width: 344px;
    padding: 10px 12px;
    border: 2px solid var(--float-edge);
    border-radius: 7px;
    background: var(--grain), var(--float);
    box-shadow:
      0 0 0 1px #000,
      0 6px 16px #000000b3;
  }
  h3 {
    margin: 0 20px 0 0;
    font: 400 18px/22px var(--display);
    color: var(--gold);
    text-shadow: 0 1px 0 #000;
  }
  .pic {
    width: 22px;
    height: 22px;
    margin: 0 8px -5px 0;
    border-radius: 2px;
    box-shadow:
      0 0 0 1px #000,
      0 0 0 2px var(--bronze-700);
  }
  /* The name of a saved pin is written over: it looks like the title until it is pointed at or held. */
  .name {
    display: block;
    width: calc(100% - 24px);
    margin: -3px 0 -1px -5px;
    padding: 2px 4px;
    border: 1px solid transparent;
    border-radius: 3px;
    background: none;
    font: 400 18px/22px var(--display);
    color: var(--gold);
    text-shadow: 0 1px 0 #000;
  }
  .name:hover {
    border-color: var(--bronze-600);
  }
  .name:focus {
    border-color: var(--gold-pale);
    background: #0008;
    outline: none;
  }
  p {
    margin: 0;
  }
  .dim {
    color: var(--text-dim);
  }
  /* Sending and Sent are shorter words: the button keeps its width, so the one beside it stays put. */
  .send {
    min-width: 112px;
  }
  .why {
    margin-top: 7px;
    max-width: 296px;
  }
  .go {
    display: flex;
    gap: 8px;
    margin-top: 9px;
  }
  /* The maps take the whole row, and go on to the next one when there are many. */
  .maps {
    flex-wrap: wrap;
  }
  .maps .btn {
    flex: 1;
  }
  .close {
    position: absolute;
    top: 6px;
    right: 6px;
    display: grid;
    place-content: center;
    width: 24px;
    height: 24px;
    padding: 0;
    border: 0;
    background: none;
    color: var(--text-dim);
    cursor: pointer;
  }
  .close:hover {
    color: var(--text);
  }
</style>
