export interface Harbour {
  x: number
  y: number
  radiusX: number
  radiusY: number
}

export function expandDetailCoast(pixels: Uint8ClampedArray, width: number, height: number, harbours: Harbour[]): void {
  const size = width * height
  const distance = new Uint16Array(size)
  const scale = width / 1002
  const solid = 1.6 * scale * 3
  const feather = 4.5 * scale * 3
  const far = Math.ceil(feather) + 5
  for (let i = 0; i < size; i++) distance[i] = pixels[i * 4 + 3]! >= 128 ? 0 : far

  // Orthogonal and diagonal neighbours give an approximate distance from the original land.
  for (let y = 0; y < height; y++) {
    for (let x = 0, i = y * width; x < width; x++, i++) {
      if (!distance[i]) continue
      let best = distance[i]!
      if (x > 0) best = Math.min(best, distance[i - 1]! + 3)
      if (y > 0) {
        best = Math.min(best, distance[i - width]! + 3)
        if (x > 0) best = Math.min(best, distance[i - width - 1]! + 4)
        if (x + 1 < width) best = Math.min(best, distance[i - width + 1]! + 4)
      }
      distance[i] = best
    }
  }
  const fade = (from: number, to: number, value: number): number => {
    const t = Math.max(0, Math.min(1, (value - from) / (to - from)))
    return 255 * (1 - t * t * (3 - 2 * t))
  }
  for (let y = height - 1; y >= 0; y--) {
    for (let x = width - 1, i = y * width + x; x >= 0; x--, i--) {
      let best = distance[i]!
      if (best) {
        if (x + 1 < width) best = Math.min(best, distance[i + 1]! + 3)
        if (y + 1 < height) {
          best = Math.min(best, distance[i + width]! + 3)
          if (x > 0) best = Math.min(best, distance[i + width - 1]! + 4)
          if (x + 1 < width) best = Math.min(best, distance[i + width + 1]! + 4)
        }
        distance[i] = best
      }
      const alpha = i * 4 + 3
      if (best < feather) pixels[alpha] = Math.max(pixels[alpha]!, fade(solid, feather, best))
      pixels[alpha - 3] = pixels[alpha - 2] = pixels[alpha - 1] = 0
    }
  }

  // Piers can reach farther from the bank than the normal coastal margin.
  for (const harbour of harbours) {
    const x = harbour.x * width, y = harbour.y * height
    const rx = harbour.radiusX * width, ry = harbour.radiusY * height
    if (rx < 1 || ry < 1) continue
    for (let row = Math.max(0, Math.floor(y - ry)); row <= Math.min(height - 1, Math.ceil(y + ry)); row++) {
      for (let col = Math.max(0, Math.floor(x - rx)); col <= Math.min(width - 1, Math.ceil(x + rx)); col++) {
        const distance = ((col - x) / rx) ** 2 + ((row - y) / ry) ** 2
        const alpha = (row * width + col) * 4 + 3
        if (distance < 1) pixels[alpha] = Math.max(pixels[alpha]!, fade(.42, 1, distance))
      }
    }
  }
}
