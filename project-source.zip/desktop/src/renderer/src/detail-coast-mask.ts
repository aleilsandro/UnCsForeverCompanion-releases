export interface Harbour {
  x: number
  y: number
  radiusX: number
  radiusY: number
}

export interface CoastTile {
  url: string
  left: number
  top: number
  right: number
  bottom: number
}

export interface CoastMasks {
  coast: Blob | null
  detail: Blob | null
}

/** Remove dark terrain padding connected to the sea while keeping inland shadows. */
export function trimTerrainPadding(coast: Uint8ClampedArray, detail: Uint8ClampedArray, terrain: Uint8ClampedArray, width: number, height: number): void {
  const size = width * height
  const pending = new Uint8Array(size)
  const queue = new Uint32Array(size)
  let end = 0
  for (let i = 0; i < size; i++) {
    const pixel = i * 4
    // The packed minimap's open water also uses a flat green-grey in several regions.
    const r = terrain[pixel]!, g = terrain[pixel + 1]!, b = terrain[pixel + 2]!
    const dark = Math.max(r, g, b) <= 18
    const water = r <= 37 && g <= 46 && b <= 42 && g - r >= 3 && Math.abs(g - b) <= 16
    if (terrain[pixel + 3]! > 32 && !dark && !water) continue
    if (coast[pixel + 3]! <= 127) queue[end++] = i
    else pending[i] = 1
  }
  const visit = (i: number): void => {
    if (!pending[i]) return
    pending[i] = 0
    queue[end++] = i
  }
  for (let start = 0; start < end; start++) {
    const i = queue[start]!
    const column = i % width
    const alpha = i * 4 + 3
    coast[alpha] = 0
    // A gap in coarse tiles can still have terrain in the original close-up imagery.
    if (terrain[alpha]! > 32) detail[alpha] = 0
    if (column > 0) visit(i - 1)
    if (column + 1 < width) visit(i + 1)
    if (i >= width) visit(i - width)
    if (i + width < size) visit(i + width)
  }
}

export function expandDetailCoast(pixels: Uint8ClampedArray, width: number, height: number, harbours: Harbour[]): void {
  // Preserve the original shoreline alpha. Extending it along the entire coast
  // reveals rectangular patches of minimap water over the atlas sea.
  for (let i = 0; i < pixels.length; i += 4) pixels[i] = pixels[i + 1] = pixels[i + 2] = 0

  // Piers can reach farther from the bank than the normal coastal margin.
  for (const harbour of harbours) {
    const x = harbour.x * width, y = harbour.y * height
    const rx = harbour.radiusX * width, ry = harbour.radiusY * height
    if (rx < 1 || ry < 1) continue
    for (let row = Math.max(0, Math.floor(y - ry)); row <= Math.min(height - 1, Math.ceil(y + ry)); row++) {
      for (let col = Math.max(0, Math.floor(x - rx)); col <= Math.min(width - 1, Math.ceil(x + rx)); col++) {
        const distance = ((col - x) / rx) ** 2 + ((row - y) / ry) ** 2
        const alpha = (row * width + col) * 4 + 3
        if (distance >= 1) continue
        const t = Math.max(0, (distance - .42) / .58)
        const opacity = 255 * (1 - t * t * (3 - 2 * t))
        pixels[alpha] = Math.max(pixels[alpha]!, opacity)
      }
    }
  }
}
