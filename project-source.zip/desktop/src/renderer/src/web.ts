// The same page in two places. In the app's own window the preload script has put window.twinmap
// there. In the browser of a phone on the home network nothing has: this file puts one there
// that hears the app on /events and asks it things on /call/<name> (main/lan.ts answers both).
import type { LinkSnapshot } from '../../shared/link'
import { feedbackLink } from '../../shared/feedback'
import { pageOf } from '../../shared/setup'

/** The page runs in the app's own window, not in a browser on the home network. */
export const inApp = 'twinmap' in window

/** Where the map's files are asked for. */
export const TILES = inApp ? 'twinmap://tiles' : '/tiles'
export const OPENMAP = inApp ? 'twinmap://openmap' : '/openmap'
const events = inApp ? undefined : new EventSource('/events')

export function onGuildPinsChanged(listener: () => void): () => void {
  events?.addEventListener('guild-pins', listener)
  events?.addEventListener('open', listener)
  return () => {
    events?.removeEventListener('guild-pins', listener)
    events?.removeEventListener('open', listener)
  }
}

if (!inApp) {
  // No buttons of a window over the top row here: the page may use its whole width.
  document.documentElement.classList.add('web')
  // The code that let this browser in is kept by it now: off the address bar, and out of what gets shared or saved.
  if (location.search) history.replaceState(null, '', location.pathname + location.hash)
  const source = events!
  const on =
    <T>(channel: string) =>
    (listener: (told: T) => void): void =>
      source.addEventListener(channel, (e) => listener(JSON.parse((e as MessageEvent<string>).data) as T))
  // An app that does not answer (closed, or the phone left the house) gives what an empty answer would.
  const call =
    <T>(name: string, none: T) =>
    async (...args: unknown[]): Promise<T> => {
      try {
        const answer = await fetch(`/call/${name}`, { method: 'POST', body: JSON.stringify(args) })
        return answer.ok ? ((await answer.json()) as T) : none
      } catch {
        return none
      }
    }
  const unsent = { error: 'Twinmap on the computer did not answer.' }
  // The times in what the game told are the computer's, and the page compares them with its own
  // clock (is the link lost, where is the arrow now): they are moved onto this browser's clock.
  // ponytail: how far ahead this clock is, by the news that took least to come; a clock set anew while the page is open is not followed
  let ahead = Infinity
  const onLink = (listener: (snapshot: LinkSnapshot) => void): void =>
    source.addEventListener('link', (e) => {
      const { data, lastEventId } = e as MessageEvent<string>, snapshot = JSON.parse(data) as LinkSnapshot
      ahead = Math.min(ahead, Date.now() - Number(lastEventId))
      const times = snapshot.state.updatedAt
      for (const section of Object.keys(times)) times[section]! += ahead
      listener(snapshot)
    })
  window.twinmap = {
    onMapCache: () => {},
    toggleMapCache: async () => {},
    onLink,
    onTiles: on('tiles'),
    onSetup: on('setup'),
    onQuests: on('quests'),
    onKept: on('kept'),
    keep: call('keep', undefined),
    onSheets: on('sheets'),
    forgetSheet: call('forget-sheet', undefined),
    onPortraits: on('portraits'),
    retakePortrait: call('retake-portrait', undefined),
    savePortrait: () => Promise.resolve(), // a browser downloads the picture by itself (Items.svelte)
    onTips: on('tips'),
    itemSources: call('item-sources', { sold: [], drops: [], found: [] }),
    // What belongs to the computer stays on the computer.
    chooseGameFolder: () => Promise.resolve('Choose the game folder in Twinmap on the computer.'),
    openCurseForge: (addon?: string) => Promise.resolve(void window.open(pageOf(addon), '_blank', 'noopener')),
    openFeedback: (way, details) => {
      const link = feedbackLink(way, details)
      if (link) window.open(link, '_blank', 'noopener')
      return Promise.resolve()
    },
    setOnTop: () => Promise.resolve(),
    setLan: () => Promise.resolve(),
    drawn: () => {},
    onUpdate: () => {}, // the app updates itself on its computer, never from here
    retryTiles: call('retry-tiles', undefined),
    sendFeedback: call<string | null>('send-feedback', 'Twinmap on the computer did not answer.'),
    readLog: call('read-log', ''),
    search: call('search', []),
    walk: call('walk', null),
    walkFar: call('walk-far', []),
    walkTrack: call('walk-track', null),
    sendPin: call('send-pin', unsent),
    sendMarks: call('send-marks', undefined),
    sendUnfollow: call('send-unfollow', unsent),
    sendRoute: call('send-route', unsent),
    sendStep: call('send-step', unsent),
  }
}
