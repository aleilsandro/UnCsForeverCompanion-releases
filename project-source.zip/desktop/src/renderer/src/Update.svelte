<script lang="ts">
  import Logo from './Logo.svelte'
  import type { Updating } from '../../main/update'
  let updating = $state<Updating | null>(null)
  window.twinmap.onUpdate((told) => (updating = told))
</script>

<main>
  <Logo size={80} stacked forever />
  <p aria-live="polite">{updating?.message ?? 'Avvio del companion…'}</p>
  {#if updating?.percent !== undefined}
    <progress class="bar" value={updating.percent} max="100" aria-label="Avanzamento aggiornamento"></progress>
  {:else}
    <div class="loading" aria-hidden="true"></div>
  {/if}
</main>

<style>
  main { position: fixed; inset: 0; display: grid; place-content: center; justify-items: center; gap: 18px; background: radial-gradient(circle at 50% 20%, #173d69, #081526 70%); color: #e9d295; -webkit-app-region: drag; }
  p { margin: 4px 24px; color: #e1dfd3; text-align: center; line-height: 1.5; max-width: 350px; }
  .bar { width: 230px; accent-color: #d9b865; }
  .loading { width: 20px; height: 20px; border: 2px solid #365477; border-top-color: #e9cb78; border-radius: 50%; animation: spin .8s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
</style>
