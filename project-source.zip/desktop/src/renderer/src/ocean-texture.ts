import indigoTexture from './assets/ocean-indigo.png'

export async function createOceanTexture(): Promise<string | null> {
  const image = new Image()
  image.src = indigoTexture
  await image.decode()

  const tileSize = 512
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = tileSize * 2
  const ctx = canvas.getContext('2d')
  if (!ctx) return null
  ctx.imageSmoothingQuality = 'high'

  // Reflections line up the same edges inside the motif and at every repeat.
  for (const flipY of [false, true]) {
    for (const flipX of [false, true]) {
      ctx.setTransform(flipX ? -1 : 1, 0, 0, flipY ? -1 : 1, flipX ? canvas.width : 0, flipY ? canvas.height : 0)
      ctx.drawImage(image, 0, 0, tileSize, tileSize)
    }
  }
  const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve))
  return blob ? URL.createObjectURL(blob) : null
}
