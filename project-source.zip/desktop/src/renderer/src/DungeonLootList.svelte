<script lang="ts">
  import type { DungeonLoot, DungeonLootDetailsById } from '../../shared/dungeon-journal'
  import { QUALITY_COLORS } from '../../shared/items'
  import { piecesOf } from '../../shared/tips'
  import { OPENMAP } from './web'

  let { items, details }: { items: DungeonLoot[]; details: DungeonLootDetailsById } = $props()
  let selected = $state<DungeonLoot>()
  let hovered = $state<DungeonLoot>()
  let focused = $state<DungeonLoot>()
  const shown = $derived(hovered ?? focused ?? selected)
  const color = (id: number): string => QUALITY_COLORS[details[id]?.quality ?? 1] ?? '#fff'
  const decimal = new Intl.NumberFormat('it-IT', { minimumFractionDigits: 1, maximumFractionDigits: 2 })
</script>

{#snippet icon(item: DungeonLoot)}
  {#if details[item.id]?.icon}
    <img src={`${OPENMAP}/loot-icons/${details[item.id]?.icon}.png`} alt="" loading="lazy" width="36" height="36" />
  {/if}
{/snippet}

{#snippet text(value: string, defaultColor: string)}
  {#each piecesOf(value, defaultColor) as piece}
    <span style:color={piece.color}>{piece.text}</span>
  {/each}
{/snippet}

{#snippet card(item: DungeonLoot, pinned: boolean)}
  {@const data = details[item.id]}
  <section class="card" aria-label={`Dettagli di ${data?.name || item.name}`}>
    <div class="title">
      {@render icon(item)}
      <strong style:color={color(item.id)}>{data?.name || item.name}</strong>
    </div>
    {#if data?.level}<div class="level">Livello oggetto {data.level}</div>{/if}
    {#if data?.binding}<div>{data.binding}</div>{/if}
    {#if data?.type || data?.slot}<div class="pair"><span>{data.slot ?? data.type}</span>{#if data.slot && data.type}<span>{data.type}</span>{/if}</div>{/if}
    {#if data?.weapon}
      {@const weapon = data.weapon}
      <div class="pair"><span>{weapon.min}–{weapon.max} danni{weapon.school ? ` ${weapon.school}` : ''}</span><span>Velocità {decimal.format(weapon.speed)}</span></div>
      <div>({decimal.format(weapon.dps)} danni al secondo)</div>
    {/if}
    {#if data?.armor}<div>{data.armor} armatura</div>{/if}
    {#each data?.stats ?? [] as [label, amount]}
      <div>{amount > 0 ? '+' : ''}{amount} {label}</div>
    {/each}
    {#if data?.required}<div>Richiede il livello {data.required}</div>{/if}
    {#each data?.effects ?? [] as effect}
      <div class="effect">{effect.trigger}: {@render text(effect.text, '#9fff64')}</div>
    {/each}
    {#if data?.description}<div class="description">{@render text(data.description, '#ffd76c')}</div>{/if}
    {#if !data?.name}<div>Dati completi dell’oggetto non disponibili nel client locale.</div>{/if}
    {#if pinned}<a href="https://www.wowhead.com/forever/item={item.id}" target="_blank" rel="noreferrer">Apri scheda su Wowhead</a>{/if}
  </section>
{/snippet}

<div class="loot">
  <ul>
    {#each items as item (item.id)}
      <li>
        <button type="button" aria-expanded={selected?.id === item.id} onclick={() => selected = selected?.id === item.id ? undefined : item}
          onpointerenter={event => { if (event.pointerType !== 'touch') hovered = item }}
          onpointerleave={() => { if (hovered?.id === item.id) hovered = undefined }}
          onfocus={event => { if (event.currentTarget.matches(':focus-visible')) focused = item }}
          onblur={() => { if (focused?.id === item.id) focused = undefined }}>
          {@render icon(item)}
          <span style:color={color(item.id)}>{details[item.id]?.name || item.name}</span>
        </button>
        {#if selected?.id === item.id}
          <div class="inline">{@render card(item, true)}</div>
        {/if}
      </li>
    {/each}
  </ul>
  {#if shown}
    <div class="side">{@render card(shown, selected?.id === shown.id)}</div>
  {/if}
</div>

<style>
  .loot {display:grid;grid-template-columns:minmax(0,1fr) minmax(0,0.9fr);align-items:start;gap:8px}
  ul {list-style:none;margin:0;padding:0}
  li + li {margin-top:5px}
  button {display:flex;align-items:center;gap:10px;width:100%;min-height:46px;padding:4px 8px;border:1px solid #526380;border-radius:4px;background:#0b172b;color:inherit;text-align:left;font:600 16px var(--font);cursor:pointer}
  button:hover, button:focus-visible, button[aria-expanded=true] {border-color:#e3bc6f;background:#1a304c}
  img {flex:none;border:1px solid #a68757;border-radius:4px;background:#110e0c;box-sizing:border-box}
  .side {position:sticky;top:0}
  .inline {display:none}
  .card {padding:10px 12px;border:1px solid #a68757;border-radius:5px;background:#101020;color:#fff8de;font-size:15px;line-height:1.45;overflow-wrap:anywhere}
  .title {display:flex;align-items:center;gap:8px;margin-bottom:4px;font-size:17px}
  .pair {display:flex;justify-content:space-between;flex-wrap:wrap;column-gap:8px}
  .level, .description {color:#ffd76c}
  .description, .effect {white-space:pre-line}
  .effect {color:#9fff64}
  a {display:inline-block;margin-top:8px;color:#b6dcff}
  @media (max-width:600px), (hover:none) {
    .loot {grid-template-columns:1fr}
    .side {display:none}
    .inline {display:block;margin:5px 0 8px}
  }
</style>
