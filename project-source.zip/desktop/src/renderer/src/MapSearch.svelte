<script lang="ts">
  import { navigationKinds, nearestPlaces, searchPlaces, type NearestKind, type NavigationPlace, type WorldPoint } from '../../shared/map-navigation'
  import { professionFilters } from '../../shared/map-services'
  import { TILES } from './web'

  let { open = $bindable(false), places, position, loading, selected, onSelect, onClear }:
    { open?: boolean; places: NavigationPlace[]; position?: WorldPoint; loading: boolean; selected: boolean;
      onSelect: (place: NavigationPlace) => void; onClear: () => void } = $props()
  let dialog: HTMLDialogElement
  let mode = $state<'search' | 'nearest'>('search')
  let query = $state('')
  const searchTerm = $derived(query.trim())
  const wowheadUrl = $derived(`https://www.wowhead.com/forever/search?${new URLSearchParams({ q: searchTerm })}`)
  let kind = $state<NearestKind>('inn')
  const results = $derived(!open ? [] : mode === 'nearest'
    ? position ? nearestPlaces(places, position, kind) : []
    : searchPlaces(places, query).map(place => ({ place, yards: undefined })))
  const number = new Intl.NumberFormat('it-IT')

  function show(): void {
    open = true
    dialog.showModal()
  }

  function select(place: NavigationPlace): void {
    open = false
    dialog.close()
    onSelect(place)
  }

  function submitFirst(event: KeyboardEvent): void {
    if (event.key !== 'Enter' || !results[0]) return
    event.preventDefault()
    select(results[0].place)
  }
</script>

<button class="trigger" type="button" aria-haspopup="dialog" onclick={show}>Cerca</button>
<dialog bind:this={dialog} aria-labelledby="map-search-title" onclose={() => open = false}>
  <header>
    <h2 id="map-search-title">Cerca sulla mappa</h2>
    <form method="dialog"><button class="close" aria-label="Chiudi ricerca">×</button></form>
  </header>
  <div class="modes" role="group" aria-label="Modalità di ricerca">
    <button aria-pressed={mode === 'search'} onclick={() => mode = 'search'}>Per nome</button>
    <button aria-pressed={mode === 'nearest'} onclick={() => mode = 'nearest'}>Il più vicino</button>
  </div>
  {#if mode === 'search'}
    <label for="place-name">Nome, categoria o zona</label>
    <input id="place-name" type="search" bind:value={query} placeholder="Es. banca Stormwind" maxlength="100" onkeydown={submitFirst} />
    {#if searchTerm}
      <a class="wowhead" href={wowheadUrl} target="_blank" rel="noopener noreferrer">Cerca su Wowhead</a>
    {/if}
  {:else}
    <label for="nearest-kind">Categoria</label>
    <select id="nearest-kind" bind:value={kind}>
      {#each navigationKinds.filter(category => category.id !== 'profession') as category (category.id)}
        <option value={category.id}>{category.id === 'flight' ? 'Punti volo sbloccati' : category.label}</option>
      {/each}
      <optgroup label="Istruttori di professione">
        {#each professionFilters as profession (profession.id)}
          <option value={profession.id}>{profession.label}</option>
        {/each}
      </optgroup>
    </select>
    {#if position}<p>Distanze in linea d’aria sul tuo continente.</p>{/if}
  {/if}
  {#if selected}<button class="clear" onclick={() => { onClear(); dialog.close() }}>Rimuovi evidenziazione</button>{/if}
  {#if mode === 'nearest' && !position}
    <p role="status">In attesa della tua posizione da Pulser.</p>
  {:else if results.length}
    <ul aria-label="Risultati sulla mappa">
      {#each results as { place, yards } (place.key)}
        <li>
          <button class="result" onclick={() => select(place)}>
            <img src="{TILES}/icons/{place.image}.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />
            <span><strong>{place.name}</strong><small>{place.detail}{place.zone ? ` · ${place.zone}` : ''}</small></span>
            {#if yards !== undefined}<span class="distance">{number.format(Math.round(yards))} yd</span>{/if}
          </button>
        </li>
      {/each}
    </ul>
  {:else if mode === 'nearest' || searchTerm}
    <p role="status">{loading ? 'Caricamento dei punti sulla mappa…' : mode === 'nearest' ? 'Nessun punto disponibile di questa categoria sul tuo continente.' : 'Nessun risultato.'}</p>
  {/if}
</dialog>

<style>
  button, .wowhead { min-height:40px; border:1px solid #caa45f; border-radius:4px; background:#1a3859; color:#ffedc3; padding:5px 12px; font:600 16px var(--font); cursor:pointer; }
  button:hover, button[aria-pressed=true], .wowhead:hover { background:#30567f; }
  .trigger { pointer-events:auto; box-shadow:0 2px 7px #0008; }
  dialog { pointer-events:auto; box-sizing:border-box; width:min(490px, calc(100% - 28px)); max-height:calc(100% - 28px); overflow:auto; padding:14px 18px 18px; border:1px solid #c19b5a; border-radius:6px; background:#0e213b; color:#fff0cd; box-shadow:0 10px 40px #0009; font:16px var(--font); }
  dialog::backdrop { background:#040a16a6; }
  header { display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:12px; }
  h2 { margin:0; font-size:20px; }
  .close { min-width:40px; font-size:23px; }
  .modes { display:flex; gap:8px; margin-bottom:14px; }
  label { display:block; margin-bottom:4px; }
  input, select { box-sizing:border-box; display:block; width:100%; min-height:42px; padding:6px 9px; color:#fff0cd; background:#08192d; border:1px solid #a68757; border-radius:4px; font:inherit; }
  .wowhead { box-sizing:border-box; display:inline-flex; align-items:center; min-height:44px; margin-top:8px; text-decoration:none; }
  p { margin:8px 0 0; color:#d7cbb6; font-size:14px; }
  .clear { margin-top:8px; font-size:14px; }
  ul { display:grid; gap:5px; list-style:none; padding:0; margin:12px 0 0; }
  .result { width:100%; min-height:50px; display:flex; align-items:center; gap:9px; text-align:left; border-color:#a6875777; padding-block:7px; }
  .result img { flex:none; width:24px; height:24px; object-fit:contain; }
  .result span { min-width:0; overflow-wrap:anywhere; }
  .result strong, .result small { display:block; }
  .result small { color:#dfd0b1; line-height:1.2; font-size:13px; }
  .result .distance { margin-left:auto; white-space:nowrap; color:#ffe1a0; }
</style>
