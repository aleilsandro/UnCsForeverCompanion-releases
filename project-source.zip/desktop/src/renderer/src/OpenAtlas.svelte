<script lang="ts">
  import { onMount } from 'svelte'
  import L from 'leaflet'
  import 'leaflet/dist/leaflet.css'
  import { OPENMAP, inApp } from './web'
  import type { Position } from '../../shared/game'
  import { addFix, whereAt, BEHIND, type Fix } from '../../shared/glide'
  import { calibrate, detailOpacity, geometryOf, project, tileRange, type Calibrated } from '../../shared/map-detail'
  import { cityFrom } from '../../shared/city'
  import { playerIcon, turnPlayer, type CursorStyle } from './player-icon'
  import type { GuildMember } from '../../shared/guild'
  import type { CityMini } from '../../shared/city-mini'
  import { renderCityMini } from './city-mini-render'
  import {cityBannerBounds,type CityBanner} from '../../shared/city-banner'
  import { cursorCoordinates, type CursorCoordinates } from '../../shared/cursor-coordinates'
  import type { GameMap } from '../../shared/maps'
  import { createOceanTexture } from './ocean-texture'

  const overviewBounds = L.latLngBounds([[-668, 0], [0, 1002]])
  // Leaflet rounds each image's origin and size separately during zoom animation.
  // A one-pixel overlap hides the hairline, while pane opacity keeps the blend uniform.
  class AtlasTile extends L.ImageOverlay {
    _reset(): void {
      (L.ImageOverlay.prototype as L.ImageOverlay & { _reset(): void })._reset.call(this)
      const image = this.getElement()
      if (!image) return
      image.style.width = `${parseFloat(image.style.width) + 1}px`
      image.style.height = `${parseFloat(image.style.height) + 1}px`
      if (!inApp) {
        // Anchor the coastline to this image so Leaflet also transforms its mask on zoom.
        const start = this._map.latLngToLayerPoint(overviewBounds.getNorthWest())
        const end = this._map.latLngToLayerPoint(overviewBounds.getSouthEast())
        const tile = this._map.latLngToLayerPoint(this.getBounds().getNorthWest())
        const offset = start.subtract(tile)
        const size = end.subtract(start)
        image.classList.add('atlas-coast-tile')
        image.style.maskPosition = `${offset.x}px ${offset.y}px`
        image.style.maskSize = `${size.x}px ${size.y}px`
      }
    }
  }

  let { pos, geometry, cursor, guild=[], showPlayer=true, mapRevision, at: readAt, onCursor }: { pos?: Position; geometry?: unknown; cursor:CursorStyle; guild?:GuildMember[]; showPlayer?: boolean; mapRevision?: string; at?: number; onCursor: (value: CursorCoordinates | null) => void } = $props()
  let holder: HTMLDivElement
  let map = $state.raw<L.Map>()
  let overviewReady = false
  let overviewMissing = $state(false)
  let terrainEnabled = false
  let marker: L.Marker | undefined
  let markerStyle:CursorStyle|undefined
  let following = $state(true)
  let entries: [number, number][] = []
  let shown = new Map<string, L.ImageOverlay>()
  let detailEntries: [number, number, number][] = []
  let nativeEntries = new Map<string,number>()
  let natives = new Map<string, L.ImageOverlay>()
  let currentZoom = $state(0)
  let alignmentReady = $state(false)
  let details = new Map<string, L.ImageOverlay>()
  let calibrations = new Map<number, Calibrated>()
  let covered: L.LatLngBounds | undefined
  let coveredZoom = NaN
  let redrawTimer: ReturnType<typeof setTimeout> | undefined
  let motion = 0
  let trail: Fix[] = []
  let canvasWidth = 1002, canvasHeight = 668
  const alignmentKey = 'uncs-atlas-alignment-v1'
  let savedAlignment = ''
  function applyAlignment(saved: { width?: number; height?: number; worlds?: Record<number, Calibrated> }): boolean {
    if (typeof saved?.width !== 'number' || typeof saved.height !== 'number' || !Number.isFinite(saved.width) || !Number.isFinite(saved.height) || saved.width <= 0 || saved.height <= 0) return false
    const aligned = new Map<number, Calibrated>()
    for (const world of [0, 1]) {
      const entry = saved.worlds?.[world]
      const g = geometryOf({ [world]: entry?.g }, world)
      if (g && typeof entry?.swap === 'boolean') aligned.set(world, { g, swap: entry.swap })
    }
    if (!aligned.size) return false
    calibrations = aligned
    alignmentReady = true
    canvasWidth = saved.width
    canvasHeight = saved.height
    return true
  }
  function restoreAlignment(): void {
    if (!mapRevision) return
    try {
      const raw = localStorage.getItem(alignmentKey)
      if (!raw) return
      const saved = JSON.parse(raw)
      if (saved?.revision === mapRevision && applyAlignment(saved)) savedAlignment = raw
    } catch { /* The overview remains available if storage is missing or unreadable. */ }
  }
  function saveAlignment(): void {
    if (!mapRevision) return
    const value = JSON.stringify({ revision: mapRevision, width: canvasWidth, height: canvasHeight, worlds: Object.fromEntries(calibrations) })
    if (value === savedAlignment) return
    try {
      localStorage.setItem(alignmentKey, value)
      savedAlignment = value
    } catch { /* The current session can still use this alignment. */ }
  }
  let zoneMaps: GameMap[] = []
  let pointerPoint: L.Point | undefined
  let pointerFrame = 0
  let lastPointer = ''
  let noArt = $state(false)
  let initialized = false
  const cityBounds = new Map<number,L.LatLngBounds>()
  let bannerData:CityBanner[]=[]
  const banners=new Map<number,L.ImageOverlay>()
  let coveredCapital=false
  let undergroundData:CityMini[]=[]
  const underground=new Map<number,{tile:L.ImageOverlay;url:string}>()
  const undergroundPending=new Set<number>()
  let undergroundGeneration=0
  const guildMarkers = new Map<string, {
    marker: L.Marker
    target: L.LatLng
    changedAt: number
    label: string
    appearance: string
  }>()
  const guildMoves = new Map<L.Marker, [Fix, Fix]>()
  let guildFrame = 0
  const classColours:Record<string,string>={WARRIOR:'#c79c6e',PALADIN:'#f58cba',HUNTER:'#abd473',ROGUE:'#f9e954',PRIEST:'#f4f4ee',DEATHKNIGHT:'#c41f3b',SHAMAN:'#4a95ed',MAGE:'#69ccf0',WARLOCK:'#b49be4',DRUID:'#ff9c35',MONK:'#42d4a2'}
  const capitalFocused=():boolean=>!!map && [...cityBounds.values()].some(bounds=>bounds.contains(map!.getCenter()))
  const capitalMix=(zoom:number):number=>Math.max(0,Math.min(1,(zoom-4.5)/.5))
  const terrainOpacity=(zoom:number):number=>{const base=detailOpacity(zoom),mix=capitalFocused() ? capitalMix(zoom) : 0;return base+(1-base)*mix}
  const nativeOpacity=(zoom:number):number=>{const base=detailOpacity(zoom)*.7,mix=capitalFocused() ? capitalMix(zoom) : 0;return base+(1-base)*mix}
  const undergroundOpacity=(zoom:number):number=>Math.max(0,Math.min(1,(zoom-3.5)/1.5))
  const bannerOpacity=(zoom:number):number=>Math.max(0,Math.min(1,(5-zoom)/.8))
  function showBanners():void {
    if(!map)return
    for(const entry of bannerData) {
      const rect=entry.map.rect, world=entry.map.continent
      const c=world===null ? undefined : calibrations.get(world)
      if(!rect || !c)continue
      const box=cityBannerBounds(entry,c);if(!box)continue
      const [x0,y0,x1,y1]=box
      const bounds=L.latLngBounds([-y1,x0],[-y0,x1])
      let tile=banners.get(entry.id)
      if(!tile){tile=L.imageOverlay(`${OPENMAP}/banner/${entry.id}.png`,bounds,{interactive:false,pane:'atlas-landmarks',zIndex:370,opacity:bannerOpacity(map.getZoom()),className:'detail-tile'}).addTo(map);banners.set(entry.id,tile)}
      else tile.setBounds(bounds)
    }
  }
  const STEP = 510 / 16 // OpenMap MapZoneArt: world canvas units per tile.
  const isLocation = (p: Position | undefined): p is Position & { wx: number; wy: number; ww: number; wh: number } =>
    !!p && [p.wx, p.wy, p.ww, p.wh].every((n) => typeof n === 'number' && Number.isFinite(n)) && p.ww! > 0 && p.wh! > 0 && p.wx! >= 0 && p.wx! <= 100000 && p.wy! >= 0 && p.wy! <= 100000
  const where = (p: Position & { wx: number; wy: number; ww: number; wh: number }): L.LatLng => L.latLng(-p.wy * p.wh / 100000, p.wx * p.ww / 100000)
  function redraw(): void {
    if (!map || !terrainEnabled) return
    const visible = map.getBounds(), zoom = map.getZoom()
    const focus=capitalFocused()
    if (covered && coveredZoom === zoom && coveredCapital===focus && covered.contains(visible)) return
    const view = visible.pad(.35)
    covered = visible.pad(.18)
    coveredZoom = zoom
    coveredCapital=focus
    if(zoom>=3.5) for(const city of undergroundData) {
      const calibration=calibrations.get(city.world), bounds=cityBounds.get(city.id)
      if(!calibration || !bounds || !view.intersects(bounds) || underground.has(city.id) || undergroundPending.has(city.id))continue
      undergroundPending.add(city.id);const generation=undergroundGeneration
      void renderCityMini(city,calibration).then(result=>{
        if(!result)return
        if(!map || generation!==undergroundGeneration){URL.revokeObjectURL(result.url);return}
        const tile=L.imageOverlay(result.url,result.bounds,{interactive:false,pane:'atlas-landmarks',zIndex:360,opacity:undergroundOpacity(map.getZoom()),className:'detail-tile'}).addTo(map)
        underground.set(city.id,{tile,url:result.url})
      }).catch(()=>{}).finally(()=>{if(generation===undergroundGeneration)undergroundPending.delete(city.id)})
    }
    const needed = new Set<string>()
    for (const [x,y] of entries) {
      const bounds = L.latLngBounds([-(y + 1) * STEP, x * STEP], [-y * STEP, (x + 1) * STEP])
      const key = `${x}_${y}`
      needed.add(key)
      if (!shown.has(key)) shown.set(key, new AtlasTile(`${OPENMAP}/${key}.png`, bounds, { interactive: false, pane:'atlas-world' }).addTo(map))
    }
    for (const [key, tile] of shown) if (!needed.has(key)) { tile.remove(); shown.delete(key) }
    const opacity = terrainOpacity(zoom)
    map.getPane('atlas-detail')!.style.opacity = String(opacity)
    map.getPane('atlas-native')!.style.opacity = String(nativeOpacity(zoom))
    const wantedDetail = new Set<string>()
    if (opacity > .005 && calibrations.size) {
      for (const [world, col, row] of detailEntries) {
        const calibration = calibrations.get(world)
        if (!calibration) continue
        const {g, swap} = calibration
        const yards = 1600/3, per = 4
        const [u0,v0] = project(g,(32-row*per)*yards,(32-col*per)*yards,swap)
        const [u1,v1] = project(g,(32-(row+1)*per)*yards,(32-(col+1)*per)*yards,swap)
        const bounds = L.latLngBounds([-v0*canvasHeight,u0*canvasWidth],[-v1*canvasHeight,u1*canvasWidth])
        if (!view.intersects(bounds)) continue
        const key = `${world}_4_${col}_${row}`
        wantedDetail.add(key)
        let tile = details.get(key)
        if (!tile) {
          tile = new AtlasTile(`${OPENMAP}/detail/${key}.png`, bounds, { interactive: false, pane:'atlas-detail' }).addTo(map)
          details.set(key,tile)
        }
      }
    }
    for (const [key,tile] of details) if (!wantedDetail.has(key)) { tile.remove(); details.delete(key) }
    const wantedNative = new Set<string>()
    if (map.getZoom() >= 4.75 && calibrations.size) {
      const yards = 1600/3, centre = map.getCenter()
      const candidates: { key:string; file:number; bounds:L.LatLngBounds; distance:number }[] = []
      for (const [world,{g,swap}] of calibrations) {
        const range = tileRange(g,swap,canvasWidth,canvasHeight,{west:view.getWest(),east:view.getEast(),north:-view.getNorth(),south:-view.getSouth()})
        if (!range) continue
        for (let col=range.col0; col<=range.col1; col++) for (let row=range.row0; row<=range.row1; row++) {
          const key=`${world}_${col}_${row}`, file=nativeEntries.get(key)
          if (!file) continue
          const [u0,v0]=project(g,(32-row)*yards,(32-col)*yards,swap)
          const [u1,v1]=project(g,(31-row)*yards,(31-col)*yards,swap)
          const bounds=L.latLngBounds([-v0*canvasHeight,u0*canvasWidth],[-v1*canvasHeight,u1*canvasWidth])
          if (!view.intersects(bounds)) continue
          const c=bounds.getCenter()
          candidates.push({key,file,bounds,distance:(c.lat-centre.lat)**2+(c.lng-centre.lng)**2})
        }
      }
      candidates.sort((a,b) => a.distance-b.distance)
      for (const {key,file,bounds} of candidates.slice(0,48)) {
        wantedNative.add(key)
        let tile = natives.get(key)
        if (!tile) {
          tile = new AtlasTile(`${OPENMAP}/native/${file}.png`, bounds, { interactive:false, pane:'atlas-native' }).addTo(map)
          natives.set(key, tile)
        }
      }
    }
    for (const [key,tile] of natives) if (!wantedNative.has(key)) { tile.remove(); natives.delete(key) }
  }
  function invalidate(): void { covered=undefined; redraw() }
  function scheduleRedraw(): void {
    if (redrawTimer) return
    redrawTimer = setTimeout(() => { redrawTimer=undefined; redraw() }, 100)
  }
  function updateCursor(): void {
    pointerFrame = 0
    if (!map || !pointerPoint) return
    const point = map.containerPointToLatLng(pointerPoint)
    const value = cursorCoordinates(point.lng, -point.lat, canvasWidth, canvasHeight, zoneMaps, calibrations, pos?.world)
    const key = value ? `${value.zone}:${value.x.toFixed(1)}:${value.y.toFixed(1)}` : ''
    if (key !== lastPointer) { lastPointer = key; onCursor(value) }
  }
  function scheduleCursor(): void { if (!pointerFrame) pointerFrame = requestAnimationFrame(updateCursor) }
  onMount(() => {
    restoreAlignment()
    const instance = L.map(holder, { crs: L.CRS.Simple, minZoom: -1.5, maxZoom: 6, zoomSnap: .25, zoomDelta: .5, wheelPxPerZoomLevel: 90, zoomControl: false, attributionControl: false, scrollWheelZoom: true })
    const terrain = instance.createPane('atlas-terrain')
    terrain.style.zIndex = '400'
    terrain.style.pointerEvents = 'none'
    for (const [name, zIndex] of [['overview', 399], ['base', 400], ['world', 401], ['detail', 410], ['native', 411], ['landmarks', 420]] as const) {
      const isTerrain = name !== 'overview' && name !== 'landmarks'
      const pane = instance.createPane(`atlas-${name}`, isTerrain ? terrain : undefined)
      pane.style.zIndex = String(zIndex)
      pane.style.pointerEvents = 'none'
    }
    map = instance
    instance.setView([-334, 501], 0)
    const base = instance.getPane('atlas-base')!
    const world = instance.getPane('atlas-world')!
    const landmarks = instance.getPane('atlas-landmarks')!
    const url = `${OPENMAP}/overview.png?coast=2`
    const overview = inApp ? undefined : L.imageOverlay(url, overviewBounds, { interactive:false, pane:'atlas-overview' })
    let pendingBackdrop = 0

    function showScale(): void {
      if (!overviewReady || !overview) return
      const detailed = Math.max(0, Math.min(1, instance.getZoom() - 1.5))
      if (detailed > 0) enableTerrain()
      // Keep the finished overview visible while the first detailed tiles are fetched.
      const mix = pendingBackdrop === 0 ? detailed : 0
      terrain.style.visibility = mix > 0 ? '' : 'hidden'
      base.style.opacity = world.style.opacity = String(mix)
      overview.setOpacity(1 - mix)
    }

    function enableTerrain(): void {
      if (terrainEnabled) return
      terrainEnabled = true
      pendingBackdrop = 12
      for (let i = 0; i < 12; i++) {
        const x = (i % 4) * 256, y = Math.floor(i / 4) * 256
        const width = Math.min(256, 1002 - x), height = Math.min(256, 668 - y)
        const tile = new AtlasTile(`${OPENMAP}/base/${i+1}.png`, [[-y-height,x],[-y,x+width]], {interactive:false,pane:'atlas-base'})
        tile.once('load error', () => { if (--pendingBackdrop === 0) showScale() }).addTo(instance)
      }
      invalidate()
    }

    if (overview) {
      terrain.style.visibility = landmarks.style.visibility = 'hidden'
      overview.once('load', () => {
        overviewReady = true
        terrain.style.setProperty('--atlas-coast', `url("${url}")`)
        landmarks.style.visibility = ''
        showScale()
        void createOceanTexture().then(texture => {
          if (!texture) return
          if (map !== instance) { URL.revokeObjectURL(texture); return }
          holder.style.backgroundImage = `url("${texture}")`
          instance.once('unload', () => URL.revokeObjectURL(texture))
        }).catch(() => { /* keep the solid sea when the texture cannot load */ })
      })
      overview.once('error', () => {
        overview.remove()
        overviewMissing = true
        terrain.style.visibility = landmarks.style.visibility = ''
        enableTerrain()
      }).addTo(instance)
      instance.on('zoomend', showScale)
    } else enableTerrain()
    const pointerMove = (event: L.LeafletMouseEvent): void => { pointerPoint = event.containerPoint; scheduleCursor() }
    const pointerLeave = (): void => { pointerPoint = undefined; if (pointerFrame) cancelAnimationFrame(pointerFrame); pointerFrame = 0; lastPointer = ''; onCursor(null) }
    instance.on('mousemove', pointerMove)
    instance.on('move zoom', scheduleCursor)
    holder.addEventListener('mouseleave', pointerLeave)
    let mapsClosed = false, mapsLoading = false
    if (!inApp) void fetch(`${OPENMAP}/alignment.json`).then(r => r.ok ? r.json() : null).then(value => {
      if (!mapsClosed && !alignmentReady && value && applyAlignment(value)) {
        showBanners()
        invalidate()
        scheduleCursor()
      }
    }).catch(() => {})
    const loadMaps = (): void => {
      if (mapsLoading || zoneMaps.length) return
      mapsLoading = true
      fetch(`${OPENMAP}/maps.json`, { cache: 'no-store' }).then(r => r.ok ? r.json() as Promise<unknown> : null).then(value => {
        if (!mapsClosed && Array.isArray(value)) { zoneMaps = value as GameMap[]; scheduleCursor() }
      }).catch(() => {}).finally(() => { mapsLoading = false })
    }
    loadMaps()
    const mapsTimer = setInterval(loadMaps, 10000)
    instance.on('moveend zoomend', () => { currentZoom = instance.getZoom(); for(const c of underground.values()) c.tile.setOpacity(undergroundOpacity(currentZoom));for(const b of banners.values())b.setOpacity(bannerOpacity(currentZoom)); scheduleRedraw() })
    const loadCity = ():void => {
      fetch(`${OPENMAP}/city.json`, {cache:'no-store'}).then(r=>r.json()).then(value=>{
        if (!Array.isArray(value) || !map) return
        for (const item of value) {
          const city=cityFrom(item); if (!city) continue
          const bounds=L.latLngBounds([-city.b*668/100000,city.l*1002/100000],[-city.t*668/100000,city.r*1002/100000])
          const old=cityBounds.get(city.id);if(!old || !old.equals(bounds)){cityBounds.set(city.id,bounds);invalidate()}
        }
      }).catch(()=>{})
    }
    loadCity()
    let bannerTimer:ReturnType<typeof setTimeout>|undefined, closed=false
    const loadBanners=():void=>{
      fetch(`${OPENMAP}/banners.json`,{cache:'no-store'}).then(r=>r.ok ? r.json() as Promise<CityBanner[]> : null).then(list=>{
        if(closed)return
        if(Array.isArray(list) && list.length){bannerData=list;showBanners()}
        else if(inApp) bannerTimer=setTimeout(loadBanners,5000)
      }).catch(()=>{if(!closed && inApp)bannerTimer=setTimeout(loadBanners,5000)})
    }
    loadBanners()
    fetch(`${OPENMAP}/city-mini.json`).then(r=>r.ok ? r.json() as Promise<CityMini[]> : []).then(list=>{if(Array.isArray(list)){undergroundData=list;invalidate()}}).catch(()=>{})
    const cityTimer=inApp ? setInterval(loadCity,5000) : undefined
    const explore = (): void => { following = false }
    instance.on('dragstart', explore)
    holder.addEventListener('wheel', explore, { capture: true, passive: true })
    holder.addEventListener('dblclick', explore, { capture: true, passive: true })
    fetch(`${OPENMAP}/manifest.json`).then((r) => r.ok ? r.json() as Promise<unknown> : []).then((list) => {
      if (!Array.isArray(list)) return void (noArt = true)
      entries = list.filter((p): p is [number,number] => Array.isArray(p) && p.length === 2 && p.every((n) => Number.isInteger(n) && n >= 0 && n < 100))
      noArt = entries.length === 0
      invalidate()
    }).catch(() => { noArt = true })
    fetch(`${OPENMAP}/detail.json`).then((r) => r.ok ? r.json() as Promise<unknown> : []).then((list) => {
      if (!Array.isArray(list)) return
      detailEntries = list.filter((p): p is [number,number,number] => Array.isArray(p) && p.length === 3 && p.every((n) => Number.isInteger(n) && n >= 0 && n < 64))
      invalidate()
    }).catch(() => {})
    fetch(`${OPENMAP}/native.json`).then((r) => r.ok ? r.json() as Promise<unknown> : []).then((list) => {
      if (!Array.isArray(list)) return
      for (const p of list) if (Array.isArray(p) && p.length === 4 && p.every((n) => Number.isSafeInteger(n) && n >= 0) && p[0] <= 1 && p[1] < 64 && p[2] < 64 && p[3] > 0) nativeEntries.set(`${p[0]}_${p[1]}_${p[2]}`,p[3])
      invalidate()
    }).catch(() => {})
    const resize = new ResizeObserver(() => instance.invalidateSize())
    resize.observe(holder)
    return () => { mapsClosed=true;clearInterval(mapsTimer);holder.removeEventListener('mouseleave',pointerLeave);pointerLeave();closed=true;if(bannerTimer)clearTimeout(bannerTimer);banners.clear();undergroundGeneration++;for(const c of underground.values())URL.revokeObjectURL(c.url);underground.clear();undergroundPending.clear();clearInterval(cityTimer); resize.disconnect(); holder.removeEventListener('wheel', explore, true); holder.removeEventListener('dblclick', explore, true); if (redrawTimer) clearTimeout(redrawTimer); cancelAnimationFrame(motion); cancelAnimationFrame(guildFrame); guildMoves.clear(); instance.remove(); map = undefined; shown.clear(); details.clear(); natives.clear(); cityBounds.clear(); guildMarkers.clear() }
  })
  function animateGuild(now: number): void {
    guildFrame = 0
    for (const [pin, path] of guildMoves) {
      const next = whereAt(path, now)
      pin.setLatLng([next.y, next.x])
      if (next.arrived) guildMoves.delete(pin)
    }
    if (guildMoves.size) guildFrame = requestAnimationFrame(animateGuild)
  }
  $effect(() => {
    if (!map) return
    const groups = new Map<string, GuildMember[]>()
    for (const member of guild) {
      if (member.x === undefined || member.y === undefined) continue
      const key = member.exact ? `player:${member.name}` : `zone:${member.x}:${member.y}`
      const group = groups.get(key) ?? []
      group.push(member)
      groups.set(key, group)
    }
    for (const [key, entry] of guildMarkers) {
      if (groups.has(key)) continue
      guildMoves.delete(entry.marker)
      entry.marker.remove()
      guildMarkers.delete(key)
    }
    const now = performance.now()
    const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches
    for (const [key, members] of groups) {
      const first = members[0]!
      const target = L.latLng(-first.y! * 668 / 100000, first.x! * 1002 / 100000)
      let entry = guildMarkers.get(key)
      if (!entry) {
        const marker = L.marker(target, { interactive: true, zIndexOffset: 500 })
        entry = { marker, target, changedAt: now, label: '', appearance: '' }
        guildMarkers.set(key, entry)
      } else if (!entry.target.equals(target)) {
        const from = entry.marker.getLatLng()
        const distance = Math.hypot(target.lng - from.lng, target.lat - from.lat)
        if (first.exact && !reduceMotion && distance <= 20) {
          // Older Pulser clients still report every three seconds. Use their observed cadence.
          const gap = now - entry.changedAt
          const duration = gap <= 3400 ? Math.max(300, Math.min(2700, gap * 0.9)) : 900
          guildMoves.set(entry.marker, [
            { at: now, x: from.lng, y: from.lat },
            { at: now + duration, x: target.lng, y: target.lat }
          ])
        } else {
          guildMoves.delete(entry.marker)
          entry.marker.setLatLng(target)
        }
        entry.target = target
        entry.changedAt = now
      }
      const color = classColours[first.cls ?? ''] ?? '#7ddbb1'
      const symbol = first.exact ? '◆' : String(members.length)
      const appearance = `${color} ${symbol}`
      if (entry.appearance !== appearance) {
        const badge = document.createElement('span')
        badge.className = first.exact ? 'guild-pin exact' : 'guild-pin approximate'
        badge.style.setProperty('--guild-colour', color)
        badge.textContent = symbol
        entry.marker.setIcon(L.divIcon({ className: 'guild-wrap', html: badge, iconSize: [26, 26], iconAnchor: [13, 13] }))
        entry.appearance = appearance
      }
      const name = first.exact ? `${first.name}${first.level ? ` · ${first.level}` : ''}` : `Zona indicativa: ${members.map(m => m.name).join(', ')}`
      if (entry.label !== name) {
        const label = document.createElement('span')
        label.textContent = name
        entry.marker.unbindTooltip().bindTooltip(label, { direction: 'top', offset: [0, -12], permanent: first.exact, className: 'guild-label' })
        entry.label = name
      }
      if (!map.hasLayer(entry.marker)) entry.marker.addTo(map)
    }
    if (guildMoves.size && !guildFrame) guildFrame = requestAnimationFrame(animateGuild)
  })
  $effect(() => {
    if (!map) return
    if (!isLocation(pos)) { marker?.remove(); marker = undefined; return }
    const at = where(pos)
    const sizeChanged = canvasWidth !== pos.ww || canvasHeight !== pos.wh
    canvasWidth = pos.ww; canvasHeight = pos.wh
    const world = pos.world
    const g = world === undefined ? null : geometryOf(geometry, world)
    let next: Calibrated | null = null
    if (g && typeof pos.north === 'number' && typeof pos.west === 'number') next = calibrate(g, pos.north, pos.west, pos.wx, pos.wy, calibrations.get(world!)?.swap)
    if (next) {
      const nextCalibrations = new Map(calibrations)
      for (const continent of [0,1]) {
        const continentGeometry = geometryOf(geometry,continent)
        if (continentGeometry) nextCalibrations.set(continent,{g:continentGeometry,swap:next.swap})
      }
      const changed = JSON.stringify([...nextCalibrations]) !== JSON.stringify([...calibrations])
      calibrations = nextCalibrations
      alignmentReady = true
      saveAlignment()
      if (changed || sizeChanged) {
        scheduleCursor()
        showBanners()
        undergroundGeneration++; for(const c of underground.values()){c.tile.remove();URL.revokeObjectURL(c.url)} underground.clear();undergroundPending.clear()
        for (const tile of details.values()) tile.remove()
        for (const tile of natives.values()) tile.remove()
        details.clear(); natives.clear(); invalidate()
      }
    }
    if (!showPlayer) return
    if (!marker) {
      marker = L.marker(at, { icon:playerIcon(cursor), interactive: false, zIndexOffset: 1000 }).addTo(map); markerStyle=cursor
    }
    if (markerStyle!==cursor) { marker.setIcon(playerIcon(cursor)); markerStyle=cursor }
    turnPlayer(marker,pos.facing)
    const reading: Fix = {at:readAt ?? Date.now(),x:at.lng,y:at.lat}
    if (!initialized || !trail.length || Math.hypot(reading.x-trail[trail.length-1]!.x,reading.y-trail[trail.length-1]!.y)>20) {
      cancelAnimationFrame(motion); motion=0; trail=[reading]; marker.setLatLng(at)
      if (!initialized) { initialized=true; map.setView(at,1.5,{animate:false}) }
      else if (following) map.panTo(at,{animate:false,noMoveStart:true})
    } else {
      const updated=addFix(trail,reading)
      if (updated !== trail) {
        trail=updated
        if (!motion) motion=requestAnimationFrame(animatePosition)
      }
    }
  })
  function animatePosition(): void {
    motion=0
    if (!map || !marker || !trail.length) return
    const next=whereAt(trail,Date.now()-BEHIND), at=L.latLng(next.y,next.x)
    marker.setLatLng(at)
    if (following) map.panTo(at,{animate:false,noMoveStart:true})
    if (!next.arrived) motion=requestAnimationFrame(animatePosition)
  }
  function follow(): void { following = true; if (map && isLocation(pos)) map.panTo(where(pos)) }
</script>

<div class="atlas" class:sea-background={!inApp && !overviewMissing} bind:this={holder}></div>
<div class="controls">
  <button onclick={() => map?.zoomIn()} aria-label="Ingrandisci">+</button>
  <button onclick={() => map?.zoomOut()} aria-label="Riduci">−</button>
  {#if showPlayer}<button onclick={follow} aria-pressed={following}>Seguimi</button>{/if}
</div>
{#if noArt}<p class="notice">{inApp ? 'Non trovo le immagini di OpenMap. Installa e abilita OpenMap, poi riavvia il companion.' : 'La cartografia del mondo non è ancora disponibile sul server.'}</p>
{:else if pos && !isLocation(pos)}<p class="notice">Coordinate della mappa non disponibili. Aggiorna l’addon e usa /reload; alcune zone potrebbero non essere supportate.</p>
{:else if currentZoom >= 4 && !alignmentReady}
  <p class="notice">{!inApp ? 'Il dettaglio del terreno richiede i dati di allineamento della mappa.' : pos ? 'In attesa dei dati per allineare il dettaglio del terreno. Usa /reload se il messaggio persiste.' : 'Apri WoW con l’addon attivo una volta per preparare lo zoom dettagliato anche a gioco chiuso.'}</p>
{/if}

<style>
  .atlas { position:absolute; inset:0; background:#b8a582; }
  .atlas.sea-background { background:#263647 repeat 0 0 / 1024px 1024px; }
  .controls { position:absolute; z-index:1000; right:18px; bottom:18px; display:flex; gap:6px; }
  button { border:1px solid #caa45f; background:linear-gradient(#1c426e,#0b203eeF); color:#ffedc3; border-radius:3px; min-width:39px; height:39px; padding:0 12px; font:600 16px var(--font); cursor:pointer; box-shadow:0 2px 7px #0008,inset 0 1px #f7df9d33; }
  button:hover,button[aria-pressed=true] { background:linear-gradient(#315f96,#163860); }
  .notice { position:absolute; z-index:1000; bottom:66px; left:20px; right:20px; margin:0; padding:10px 14px; color:#fff2d5; background:#0a1b32ef; border:1px solid #cba66188; border-radius:3px; font:14px var(--font); }
  :global(.detail-tile), :global(.leaflet-atlas-detail-pane), :global(.leaflet-atlas-native-pane) { transition: opacity 180ms ease; }
  :global(.leaflet-atlas-overview-pane img), :global(.leaflet-atlas-base-pane), :global(.leaflet-atlas-world-pane) { transition: opacity 180ms ease; }
  :global(.atlas-coast-tile) { mask-image: var(--atlas-coast, none); mask-repeat: no-repeat; mask-mode: alpha; }
  :global(.player-wrap) { background:transparent; border:0; }
  :global(.guild-wrap){background:transparent;border:0}
  :global(.guild-pin){display:grid;place-items:center;width:24px;height:24px;border:2px solid #f7db9a;border-radius:50%;background:#0c2c52;color:var(--guild-colour);box-shadow:0 1px 7px #000b;font:700 16px sans-serif}
  :global(.guild-pin.approximate){border-style:dashed;color:#f9e4a9;font-size:12px;background:#112a49e8}
  :global(.guild-label){background:#0a1c35f2;border:1px solid #d7b873;color:#fff3d5;border-radius:3px;font:600 12px sans-serif;box-shadow:0 2px 5px #0008}
</style>
