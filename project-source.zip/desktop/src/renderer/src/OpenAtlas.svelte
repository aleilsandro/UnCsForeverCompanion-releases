<script lang="ts">
  import { onMount, untrack } from 'svelte'
  import L from 'leaflet'
  import 'leaflet/dist/leaflet.css'
  import { OPENMAP, TILES, inApp } from './web'
  import type { Position } from '../../shared/game'
  import { addFix, whereAt, BEHIND, type Fix } from '../../shared/glide'
  import { calibrate, geometryOf, project, tileRange, type Calibrated } from '../../shared/map-detail'
  import { cityFrom } from '../../shared/city'
  import { playerIcon, turnPlayer, type CursorStyle } from './player-icon'
  import type { GuildMember } from '../../shared/guild'
  import type { CityMini } from '../../shared/city-mini'
  import { renderCityMini } from './city-mini-render'
  import { cursorCoordinates, type CursorCoordinates } from '../../shared/cursor-coordinates'
  import type { GameMap } from '../../shared/maps'
  import { zoneLevelText } from '../../shared/zone-levels'
  import { GATHERING_FILE, gatheringProfessions, gatheringSkill, type GatheringByZone, type GatheringProfession } from '../../shared/gathering'
  import type { FlightStatus } from '../../shared/flight-points'
  import { flightCatalog } from '../../shared/flight-catalog'
  import { dungeonEntrances } from '../../shared/dungeon-entrances'
  import type { DungeonPins } from '../../shared/dungeon-pins'
  import { dungeonDirectory, dungeonGuideFor, type QuestPlace } from '../../shared/dungeon-journal'
  import { dungeonApproaches } from '../../shared/dungeon-approaches'
  import DungeonJournal from './DungeonJournal.svelte'
  import { dungeonOverlayBounds, dungeonRooms, renderDungeonOverlay, roomFloor } from './dungeon-overlay'
  import { transportRoutes } from '../../shared/transport-routes'
  import { mapServiceLayers, professionFilters, professionsOf, type MapServiceFilter, type MapServicePin } from '../../shared/map-services'
  import { dungeonLocation, navigationIndex, questWorldPoint, type NavigationPlace, type WorldPoint } from '../../shared/map-navigation'
  import MapSearch from './MapSearch.svelte'
  import AtlasPins from './AtlasPins.svelte'
  import { caveBounds, renderCave, type WorldCave } from './cave-minimap'
  import { boxOf, inPiece, MIDDLE_YARDS, type Box, type Interiors } from '../../shared/inside'
  import { serves } from '../../shared/services'
  import { createOceanTexture } from './ocean-texture'
  import { installAtlasWheelZoom } from './atlas-wheel'
  import { detailCoast } from './detail-coast'
  import type { Harbour } from './detail-coast-mask'

  const overviewBounds = L.latLngBounds([[-668, 0], [0, 1002]])
  class SmoothPlayerMarker extends L.Marker {
    update(): this {
      const marker = this as L.Marker & { _map?: L.Map; _setPos(point: L.Point): void }
      const atlas = marker._map
      if (atlas && this.getElement()) {
        marker._setPos(atlas.project(this.getLatLng()).subtract(atlas.getPixelOrigin()))
      }
      return this
    }
  }

  // Leaflet rounds each image's origin and size separately during zoom animation.
  // A one-pixel overlap hides the hairline, while pane opacity keeps the blend uniform.
  class AtlasTile extends L.ImageOverlay {
    _reset(): void {
      (L.ImageOverlay.prototype as L.ImageOverlay & { _reset(): void })._reset.call(this)
      const image = this.getElement()
      if (!image) return
      image.style.width = `${parseFloat(image.style.width) + 1}px`
      image.style.height = `${parseFloat(image.style.height) + 1}px`
      if (!inApp) {
        // Anchor the coastline to this image so Leaflet also transforms its mask on zoom.
        const start = this._map.latLngToLayerPoint(overviewBounds.getNorthWest())
        const end = this._map.latLngToLayerPoint(overviewBounds.getSouthEast())
        const tile = this._map.latLngToLayerPoint(this.getBounds().getNorthWest())
        const offset = start.subtract(tile)
        const size = end.subtract(start)
        image.classList.add('atlas-coast-tile')
        image.style.maskPosition = `${offset.x}px ${offset.y}px`
        image.style.maskSize = `${size.x}px ${size.y}px`
      }
    }
  }

  let { pos, ownPosition, geometry, cursor, guild=[], guildTarget, followedGuildName, questTarget, flights, showFlights, showDungeons, showBoats, showZeppelins, showCaves, serviceLayers, gathering, showPlayer=true, showGuildDirection=false, mapRevision, at: readAt, onCursor, directoryOpen = $bindable(false), searchOpen = $bindable(false) }: { pos?: Position; ownPosition?: WorldPoint; geometry?: unknown; cursor:CursorStyle; guild?:GuildMember[]; guildTarget?: { member: GuildMember }; followedGuildName?: string; questTarget?: { point: WorldPoint; name: string; zone: string }; flights?: FlightStatus; showFlights: boolean; showDungeons: boolean; showBoats: boolean; showZeppelins: boolean; showCaves: boolean; serviceLayers: MapServiceFilter[]; gathering: GatheringProfession[]; showPlayer?: boolean; showGuildDirection?: boolean; mapRevision?: string; at?: number; onCursor: (value: CursorCoordinates | null) => void; directoryOpen?: boolean; searchOpen?: boolean } = $props()
  let holder: HTMLDivElement
  let map = $state.raw<L.Map>()
  let coastReady = inApp
  let marker: L.Marker | undefined
  let markerStyle:CursorStyle|undefined
  let following = $state(true)
  let detailEntries = $state.raw<[number, number, number][]>([])
  let nativeEntries = new Map<string,number>()
  let natives = new Map<string, L.ImageOverlay>()
  let currentZoom = $state(0)
  const guildZoomKey = 'uncs.guild-follow-zoom'
  let guildStartZoom = 4.75
  let savedGuildZoom = $state(false)
  try {
    const saved = localStorage.getItem(guildZoomKey)
    if (saved !== null && Number.isFinite(Number(saved))) guildStartZoom = Number(saved)
  } catch { /* Keep the default when browser storage is unavailable. */ }
  function saveGuildZoom(): void {
    if (!map) return
    guildStartZoom = map.getZoom()
    try { localStorage.setItem(guildZoomKey, String(guildStartZoom)) } catch { /* Keep it for this session. */ }
    savedGuildZoom = true
  }
  let alignmentReady = $state(false)
  let details = new Map<string, L.ImageOverlay>()
  let calibrations = $state.raw(new Map<number, Calibrated>())
  let covered: L.LatLngBounds | undefined
  let coveredZoom = NaN
  let redrawTimer: ReturnType<typeof setTimeout> | undefined
  let motion = 0
  let trail: Fix[] = []
  let canvasWidth = 1002, canvasHeight = 668
  const alignmentKey = 'uncs-atlas-alignment-v1'
  let overviewImage = $state.raw<HTMLImageElement>()
  const coastUrls = new Map<string, string>()
  const detailTiles = $derived(detailEntries.flatMap(([world, col, row]) => {
    const calibration = calibrations.get(world)
    if (!calibration) return []
    const { g, swap } = calibration
    const yards = 4 * 1600 / 3
    const [u0, v0] = project(g, (8 - row) * yards, (8 - col) * yards, swap)
    const [u1, v1] = project(g, (7 - row) * yards, (7 - col) * yards, swap)
    const key = `${world}_4_${col}_${row}`
    return [{ key, url: `${OPENMAP}/detail/${key}.png`, left: Math.min(u0, u1), top: Math.min(v0, v1),
      right: Math.max(u0, u1), bottom: Math.max(v0, v1) }]
  }))
  $effect(() => {
    const atlas = map, image = overviewImage, tiles = detailTiles
    if (inApp || !atlas || !image || !tiles.length) return
    const harbours: Harbour[] = []
    for (const [kind, stops] of transportRoutes) {
      if (kind !== 'boat') continue
      for (const [, world, north, west] of stops) {
        const center = worldPoint(world, north, west)
        const edge = worldPoint(world, north + 225, west + 225)
        if (!center || !edge) continue
        harbours.push({ x: center[1] / 1002, y: -center[0] / 668,
          radiusX: Math.abs(edge[1] - center[1]) / 1002, radiusY: Math.abs(edge[0] - center[0]) / 668 })
      }
    }
    const request = new AbortController()
    void detailCoast(image, harbours, tiles, request.signal).then(masks => {
      if (!masks || request.signal.aborted) return
      const pane = atlas.getPane('atlas-terrain')
      if (!pane) return
      for (const [property, mask] of [['--atlas-coast', masks.coast], ['--atlas-detail-coast', masks.detail]] as const) {
        if (!mask) continue
        const url = URL.createObjectURL(mask)
        pane.style.setProperty(property, `url("${url}")`)
        const previous = coastUrls.get(property)
        if (previous) URL.revokeObjectURL(previous)
        coastUrls.set(property, url)
      }
    }).catch(() => { /* Keep the original mask if a browser cannot prepare a detail mask. */ })
    return () => request.abort()
  })
  let savedAlignment = ''
  function applyAlignment(saved: { width?: number; height?: number; worlds?: Record<number, Calibrated> }): boolean {
    if (typeof saved?.width !== 'number' || typeof saved.height !== 'number' || !Number.isFinite(saved.width) || !Number.isFinite(saved.height) || saved.width <= 0 || saved.height <= 0) return false
    const aligned = new Map<number, Calibrated>()
    for (const world of [0, 1]) {
      const entry = saved.worlds?.[world]
      const g = geometryOf({ [world]: entry?.g }, world)
      if (g && typeof entry?.swap === 'boolean') aligned.set(world, { g, swap: entry.swap })
    }
    if (!aligned.size) return false
    calibrations = aligned
    alignmentReady = true
    canvasWidth = saved.width
    canvasHeight = saved.height
    return true
  }
  function restoreAlignment(): void {
    if (!mapRevision) return
    try {
      const raw = localStorage.getItem(alignmentKey)
      if (!raw) return
      const saved = JSON.parse(raw)
      if (saved?.revision === mapRevision && applyAlignment(saved)) savedAlignment = raw
    } catch { /* The overview remains available if storage is missing or unreadable. */ }
  }
  function saveAlignment(): void {
    if (!mapRevision) return
    const value = JSON.stringify({ revision: mapRevision, width: canvasWidth, height: canvasHeight, worlds: Object.fromEntries(calibrations) })
    if (value === savedAlignment) return
    try {
      localStorage.setItem(alignmentKey, value)
      savedAlignment = value
    } catch { /* The current session can still use this alignment. */ }
  }
  let zoneMaps = $state.raw<GameMap[]>([])
  let services = $state.raw<MapServicePin[]>()
  let serviceBounds = $state.raw<L.LatLngBounds>()
  type Highlight = WorldPoint & Pick<NavigationPlace, 'name' | 'detail' | 'zone'> & Partial<Pick<NavigationPlace, 'image' | 'kind'>>
  let selectedPlace = $state.raw<{ place: Highlight }>()
  $effect(() => {
    if (questTarget) selectQuestNpc(questTarget.point, questTarget.name, questTarget.zone)
  })
  let lastSelection: typeof selectedPlace
  const wantServices = $derived(serviceLayers.length > 0 || searchOpen)
  const searchablePlaces = $derived(searchOpen
    ? navigationIndex(zoneMaps, services ?? [], flights).filter(place => calibrations.has(place.world))
    : [])
  const pinSize = matchMedia('(pointer: coarse)').matches ? 36 : 20
  const pinSpacing = pinSize + 6
  const pinOffsets = [{ x: 0, y: 0 }, ...[1, 1.6].flatMap(scale => Array.from({ length: 12 }, (_, index) => {
    const angle = index * Math.PI / 6
    return { x: Math.cos(angle) * pinSpacing * scale, y: Math.sin(angle) * pinSpacing * scale }
  }))]
  const servicePinOffsets = [...pinOffsets, ...[2.3, 3, 3.8, 4.6, 5.4].flatMap(scale => Array.from({ length: 20 }, (_, index) => {
    const angle = index * Math.PI / 10
    return { x: Math.cos(angle) * pinSpacing * scale, y: Math.sin(angle) * pinSpacing * scale }
  }))]
  const worldPinOrigins = new WeakMap<L.Marker, L.LatLngExpression>()
  const servicePins = new WeakSet<L.Marker>()
  let pointerPoint: L.Point | undefined
  let pointerFrame = 0
  let lastPointer = ''
  let hoveredZone = $state.raw<{ id: number; name: string; levels: string | undefined }>()
  let gatheringByZone = $state.raw<GatheringByZone>()
  const gatheringVisible = $derived(gathering.length > 0)
  const gatheringRows = $derived(gatheringProfessions.filter(({ id }) => gathering.includes(id)))
  $effect(() => {
    if (!gatheringVisible || gatheringByZone !== undefined) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/${GATHERING_FILE}`, { signal: request.signal })
      .then(response => response.ok ? response.json() : {})
      .catch(() => ({}))
      .then(data => { if (!request.signal.aborted) gatheringByZone = data ?? {} })
    return () => request.abort()
  })

  function worldPin(at: L.LatLngExpression, kind: string, label: string, { image, levels, lines = [label], route = false, pane = 'markerPane' }: { image?: string; levels?: string; lines?: string[]; route?: boolean; pane?: string }): L.Marker {
    const badge = document.createElement('span')
    badge.className = kind
    if (image) {
      const icon = new Image()
      icon.className = 'world-pin-image'
      icon.alt = ''
      icon.addEventListener('load', () => badge.classList.add('with-icon'), { once: true })
      icon.src = `${TILES}/icons/${image}.png`
      badge.append(icon)
    }
    if (levels) {
      const range = document.createElement('small')
      range.className = 'dungeon-levels'
      range.textContent = levels
      badge.append(range)
    }
    const tip = document.createElement('span')
    lines.forEach((text, index) => {
      if (index) tip.append(document.createElement('br'))
      const line = document.createElement(index ? 'span' : 'strong')
      line.textContent = text
      tip.append(line)
    })
    const pin = L.marker(at, {
      pane,
      bubblingMouseEvents: true,
      riseOnHover: true,
      icon: L.divIcon({ className: 'world-pin', html: badge, iconSize: [pinSize, pinSize], iconAnchor: [pinSize / 2, pinSize / 2] }),
    }).bindTooltip(tip, { direction: 'top', offset: [0, -pinSize / 2], className: route ? 'world-pin-label route-label' : 'world-pin-label' })
    worldPinOrigins.set(pin, at)
    pin.on('add', () => pin.getElement()?.setAttribute('aria-label', label))
    pin.on('tooltipopen', ({ tooltip }: L.TooltipEvent) => {
      const element = tooltip.getElement()
      if (!element) return
      element.style.removeProperty('margin-left')
      const mapBounds = holder.getBoundingClientRect()
      const anchor = pin.getElement()?.getBoundingClientRect()
      if (anchor) {
        const height = element.getBoundingClientRect().height
        const below = anchor.top - height < mapBounds.top + 6 && anchor.bottom + height < mapBounds.bottom - 6
        const direction = below ? 'bottom' : 'top'
        if (tooltip.options.direction !== direction) {
          tooltip.options.direction = direction
          tooltip.options.offset = L.point(0, below ? pinSize / 2 : -pinSize / 2)
          tooltip.setLatLng(pin.getLatLng())
        }
      }
      const bounds = element.getBoundingClientRect()
      const left = Math.max(mapBounds.left + 6, Math.min(bounds.left, mapBounds.right - bounds.width - 6))
      element.style.marginLeft = `${left - bounds.left}px`
      const arrow = Math.max(10, Math.min(bounds.width - 10, bounds.left + bounds.width / 2 - left))
      element.style.setProperty('--pin-tip-arrow', `${arrow}px`)
    })
    return pin
  }

  function worldPoint(continent: number, north: number, west: number): [number, number] | undefined {
    const calibration = calibrations.get(continent)
    if (!calibration) return undefined
    const [u, v] = project(calibration.g, north, west, calibration.swap)
    return [-v * canvasHeight, u * canvasWidth]
  }

  const DUNGEON_ZOOM = 4.75
  const entrances = $derived(dungeonEntrances.flatMap(([mapId, x, y, labels]) => {
    const point = dungeonLocation(mapId, x, y, zoneMaps)
    const at = point && worldPoint(point.world, point.north, point.west)
    return point && at ? [{ key: labels[0]![0], labels, names: labels.map(([name]) => name), point, at }] : []
  }))
  type Entrance = typeof entrances[number]
  let activeDungeon = $state<{ key: string; name: string }>()
  let selectedBoss = $state.raw<{ name: string }>()
  let floor = $state(0)
  let interiors = $state.raw<Interiors | null>()
  let emptyFloor = $state(false)
  let entranceOnly = $state(false)
  let dungeonReady = $state(false)
  let cityFocus = $state<'interior' | 'outdoor'>()
  let cityMask = $state('none')
  const entrance = $derived(showDungeons && currentZoom >= DUNGEON_ZOOM && activeDungeon
    ? entrances.find(entry => entry.key === activeDungeon?.key) : undefined)
  const guide = $derived(entrance && activeDungeon ? dungeonGuideFor(activeDungeon.name) : undefined)
  const focusedCity = $derived(entrance ? undefined : cityFocus)
  const approach = $derived(entrance && activeDungeon ? dungeonApproaches[activeDungeon.name] : undefined)
  const interior = $derived(guide && interiors?.maps.find(entry => entry.id === guide?.map && entry.kind !== 'world'))
  const rooms = $derived(interior && guide ? dungeonRooms(interior, guide) : [])
  const dungeonBox = $derived(guide ? dungeonOverlayBounds(guide, rooms, !!interior?.ground) : undefined)
  const dungeonFocus = $derived(!!entrance && dungeonReady && !emptyFloor && !entranceOnly)
  const maxFloor = $derived(Math.max(0, ...rooms.map(room => room.level)))
  const bossesOnMap = $derived(guide?.bosses.map(([name, u, v], index) => ({ name, u, v, index, floor: roomFloor(rooms, u, v) ?? 0 })) ?? [])
  const dungeonStatus = $derived(interiors === undefined ? 'Caricamento della mappa interna…'
    : !interior ? 'Mappa interna non disponibile nel pacchetto cartografico.'
    : emptyFloor ? 'Immagini non disponibili per questo piano.' : '')

  function projectDungeon(entry: Entrance, guide: DungeonPins) {
    const [u0, v0] = guide.entrance ?? [(guide.bounds[0] + guide.bounds[2]) / 2, (guide.bounds[1] + guide.bounds[3]) / 2]
    return (u: number, v: number): [number, number] => worldPoint(entry.point.world, entry.point.north - (v - v0), entry.point.west - (u - u0)) ?? entry.at
  }
  function chooseDungeon(entry: Entrance, name: string): void {
    if (activeDungeon?.key !== entry.key || activeDungeon.name !== name) {
      activeDungeon = { key: entry.key, name }
      selectedBoss = undefined
      floor = 0
      entranceOnly = false
      dungeonReady = false
    }
    directoryOpen = false
    if (!map) return
    following = false
    const chosen = dungeonGuideFor(name)
    const center = chosen ? caveBounds(chosen.bounds, projectDungeon(entry, chosen)).getCenter() : L.latLng(entry.at)
    map.setView(center, Math.max(map.getZoom(), 5), { animate: false })
  }
  function selectDungeon(entry: typeof dungeonDirectory[number]): void {
    const found = entrances.find(pin => pin.names.includes(entry.name))
    if (found) chooseDungeon(found, entry.name)
  }
  function closeDungeon(): void {
    if (directoryOpen) { directoryOpen = false; return }
    activeDungeon = undefined
    entranceOnly = false
    dungeonReady = false
  }
  function locateQuestNpc(name: string, place: QuestPlace): (() => void) | undefined {
    const point = questWorldPoint(place, zoneMaps)
    if (!point || !calibrations.has(point.world)) return
    return () => {
      closeDungeon()
      selectQuestNpc(point, name, place.zone)
    }
  }
  function selectQuestNpc(point: WorldPoint, name: string, zone: string): void {
    selectedPlace = { place: { ...point, name, detail: 'PNG della missione', zone } }
  }
  function showBoss(name: string): void {
    const boss = bossesOnMap.find(row => row.name === name)
    if (boss) floor = boss.floor
    selectedBoss = { name }
  }
  function showApproach(show: boolean): void {
    const atlas = map, entry = entrance, info = approach
    if (entranceOnly === show) return
    entranceOnly = show
    if (!show || !atlas || !entry || !info) return
    const start = dungeonLocation(info.map, ...info.start, zoneMaps)
    const at = start && worldPoint(start.world, start.north, start.west)
    if (!at) return
    const points = info.routes?.flatMap(route => route.points.flatMap(([north, west]) => {
      const location = worldPoint(info.map, north, west)
      return location ? [location] : []
    })) ?? []
    const bounds = L.latLngBounds([at, entry.at, ...points])
    if (atlas.getBounds().pad(-.12).contains(bounds)) return
    following = false
    atlas.setView(bounds.getCenter(), Math.max(DUNGEON_ZOOM, Math.min(atlas.getZoom(), atlas.getBoundsZoom(bounds, false, L.point(70, 70)))), { animate: false })
  }
  $effect(() => {
    const view = serviceBounds, entry = entrance
    if (!activeDungeon || !view) return
    if (entry && (view.contains(entry.at) || guide && dungeonBox && view.intersects(caveBounds(dungeonBox, projectDungeon(entry, guide))))) return
    activeDungeon = undefined
    dungeonReady = false
  })
  $effect(() => {
    if (!entrance || interiors !== undefined) return
    const request = new AbortController()
    void fetch(`${TILES}/interiors.json`, { signal: request.signal })
      .then(response => response.ok ? response.json() : null)
      .catch(() => null)
      .then(result => { if (!request.signal.aborted) interiors = result })
    return () => request.abort()
  })
  $effect(() => {
    const atlas = map, target = entrance, layout = guide, data = interior, pieces = rooms, box = dungeonBox, level = floor
    if (!atlas || !target || !layout || !data || !box || entranceOnly) return
    const at = projectDungeon(target, layout)
    const request = new AbortController()
    let url: string | null = null
    const layer = L.layerGroup().addTo(atlas)
    const bounds = caveBounds(box, at)
    emptyFloor = false
    void renderDungeonOverlay(data, box, pieces, level, at, layout, request.signal).then(image => {
      if (request.signal.aborted) { if (image) URL.revokeObjectURL(image); return }
      if (!image) { emptyFloor = true; return }
      url = image
      L.imageOverlay(image, bounds, { pane: 'atlas-dungeons', className: 'atlas-dungeon-floor' })
        .once('load', () => { if (!request.signal.aborted) dungeonReady = true })
        .addTo(layer)
    }).catch(() => { if (!request.signal.aborted) emptyFloor = true })
    for (const boss of bossesOnMap.filter(row => row.floor === level)) {
      const label = document.createElement('span')
      label.textContent = boss.name
      L.marker(at(boss.u, boss.v), { icon: L.divIcon({ className: 'dungeon-boss-pin', html: String(boss.index + 1), iconSize: [26, 26] }), alt: boss.name, zIndexOffset: 800 })
        .on('add', event => (event.target as L.Marker).getElement()?.setAttribute('aria-label', boss.name))
        .bindTooltip(label, { direction: 'top' })
        .on('click', () => { directoryOpen = false; showBoss(boss.name) })
        .addTo(layer)
    }
    return () => { request.abort(); layer.remove(); if (url) URL.revokeObjectURL(url) }
  })
  $effect(() => {
    const atlas = map, entry = entrance, info = approach, focus = entranceOnly
    if (!atlas || !entry) return
    if (!info) {
      if (!focus) return
      const title = 'Portale del dungeon'
      const pin = worldPin(entry.at, 'dungeon-approach-portal', title, { image: 'dungeon', pane: 'dungeon-access' })
      worldPinOrigins.delete(pin)
      pin.setZIndexOffset(1200).addTo(atlas).openTooltip()
      return () => { pin.remove() }
    }
    const start = dungeonLocation(info.map, ...info.start, zoneMaps)
    const at = start && worldPoint(start.world, start.north, start.west)
    if (!at) return
    const layer = L.layerGroup().addTo(atlas)
    const label = document.createElement('span')
    label.textContent = info.label
    const access = L.marker(at, { pane: 'dungeon-access', alt: info.label,
      icon: L.divIcon({ className: 'dungeon-access-pin', html: '↳', iconSize: [30, 30] }) })
      .bindTooltip(label, { direction: 'top' })
      .on('add', event => (event.target as L.Marker).getElement()?.setAttribute('aria-label', info.label))
      .on('click', event => (event.target as L.Marker).openTooltip())
      .addTo(layer)
    if (focus) access.openTooltip()
    for (const route of info.routes ?? []) {
      const points = route.points.flatMap(([north, west]) => {
        const point = worldPoint(info.map, north, west)
        return point ? [L.latLng(point)] : []
      })
      if (points.length < 2) continue
      L.polyline(points, { pane: 'dungeon-approaches', color: '#16120b', opacity: 1, weight: 8, interactive: false }).addTo(layer)
      L.polyline(points, { pane: 'dungeon-approaches', color: '#ffd55b', opacity: 1, weight: 4, interactive: false, className: 'dungeon-approach-line' }).addTo(layer)
      let distance = 40
      for (let i = 1; i < points.length; i++) {
        const from = points[i - 1]!, to = points[i]!
        distance += atlas.project(from).distanceTo(atlas.project(to))
        if (distance < 65) continue
        distance = 0
        const angle = Math.atan2(from.lat - to.lat, to.lng - from.lng) * 180 / Math.PI
        L.marker([(from.lat + to.lat) / 2, (from.lng + to.lng) / 2], {
          pane: 'dungeon-approaches', keyboard: false, interactive: false,
          icon: L.divIcon({ className: 'dungeon-approach-arrow', iconSize: [14, 14], html: `<span style="transform:rotate(${angle}deg)">➤</span>` }),
        }).addTo(layer)
      }
      const portal = worldPin(points[points.length - 1]!, 'dungeon-approach-portal', route.label, { image: 'dungeon', pane: 'dungeon-access' })
      worldPinOrigins.delete(portal)
      portal.setZIndexOffset(1200).on('click', () => portal.openTooltip()).addTo(layer)
    }
    return () => layer.remove()
  })

  $effect(() => {
    if (!wantServices || services !== undefined) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/services.json`, { signal: request.signal })
      .then(response => response.ok ? response.json() : [])
      .then(result => { if (!request.signal.aborted) services = Array.isArray(result) ? result : [] })
      .catch(() => { if (!request.signal.aborted) services = [] })
    return () => request.abort()
  })

  $effect(() => {
    const atlas = map, selection = selectedPlace
    if (!atlas || !selection) return
    const { place } = selection
    const at = worldPoint(place.world, place.north, place.west)
    if (!at) return
    return untrack(() => {
      const lines = [place.name, place.detail, place.zone].filter(Boolean)
      const pin = worldPin(at, place.image ? 'navigation-pin' : 'navigation-pin quest-source-pin', lines.join('\n'), { image: place.image, lines }).setZIndexOffset(1500)
      if (place.kind === 'dungeon') pin.on('click', () => {
        const entry = entrances.find(pin => pin.names.includes(place.name))
        if (entry) chooseDungeon(entry, place.name)
      })
      worldPinOrigins.delete(pin)
      if (lastSelection !== selection) {
        lastSelection = selection
        following = false
        atlas.setView(at, Math.max(atlas.getZoom(), 4.5), { animate: false })
      }
      pin.addTo(atlas).openTooltip()
      const frame = requestAnimationFrame(() => pin.getElement()?.focus({ preventScroll: true }))
      return () => { cancelAnimationFrame(frame); pin.remove() }
    })
  })

  $effect(() => {
    const atlas = map
    if (!atlas || !services?.length || !serviceBounds) return
    const showProfession = professionFilters.some(({ id }) => serviceLayers.includes(id))
    const visible = mapServiceLayers.filter(({ id, zoom }) => currentZoom >= zoom && (id === 'profession' ? showProfession : serviceLayers.includes(id)))
    if (!visible.length) return
    const layer = L.layerGroup()
    const added = new Set<string>()
    let active: L.Marker | undefined
    for (const service of services) {
      if (!serves(service, flights?.side)) continue
      const at = worldPoint(service.world, service.north, service.west)
      if (!at || !serviceBounds.contains(at)) continue
      for (const kind of visible) {
        if (!service.layers.includes(kind.id)) continue
        if (kind.id === 'profession' && !professionsOf(service.sub).some(({ id }) => serviceLayers.includes(id))) continue
        const key = JSON.stringify([kind.id, service.name, ...at])
        if (added.has(key)) continue
        added.add(key)
        const lines = kind.id === 'mailbox' ? [service.name] : [service.name, service.sub || kind.label]
        const pin = worldPin(at, `service-point service-${kind.id}`, lines.join(' · '), { image: kind.id, lines })
        servicePins.add(pin)
        pin.on('tooltipopen', () => {
          if (active !== pin) active?.closeTooltip()
          active = pin
        })
        layer.addLayer(pin)
      }
    }
    const closeTooltip = (): void => { active?.closeTooltip(); active = undefined }
    atlas.on('preclick', closeTooltip)
    layer.addTo(atlas)
    return () => { atlas.off('preclick', closeTooltip); layer.remove() }
  })

  $effect(() => {
    if (!map || !showFlights || !flights) return
    const pins: L.Marker[] = []
    const faction = flights.side === 'A' ? 1 : 2
    for (const [id, name, world, north, west, sides] of flightCatalog) {
      if (!(sides & faction)) continue
      const at = worldPoint(world, north, west)
      if (!at) continue
      const known = flights.known.includes(id), checked = flights.checked.includes(world)
      const status = known ? 'Sbloccato' : checked ? 'Bloccato' : 'Da verificare al maestro di volo'
      const style = known ? 'unlocked' : checked ? 'locked' : 'unverified'
      pins.push(worldPin(at, `flight-point ${style}`, `${name} · ${status}`, { image: known ? 'flight-known' : 'flight-locked', lines: [name, status] }))
    }
    const layer = L.layerGroup(pins).addTo(map)
    return () => { layer.remove() }
  })

  $effect(() => {
    if (!map || !showDungeons) return
    const pins: L.Marker[] = []
    for (const entry of entrances) {
      const { at, labels: dungeons } = entry
      const formatRange = (min: number, max: number) => min === max ? String(min) : `${min}–${max}`
      const details = dungeons.map(([name, min, max]) => [name, `Liv. ${formatRange(min, max)}`])
      const entries = details.map(entry => entry.join(' · '))
      const lines = details.length === 1 ? details[0] : entries
      const levels = formatRange(Math.min(...dungeons.map(([, min]) => min)), Math.max(...dungeons.map(([, , max]) => max)))
      const pin = worldPin(at, 'dungeon-entrance', entries.join('\n'), { image: 'dungeon', levels, lines })
      pin.on('click', () => chooseDungeon(entry, activeDungeon?.key === entry.key ? activeDungeon.name : entry.key))
      pins.push(pin)
    }
    const layer = L.layerGroup(pins).addTo(map)
    return () => { layer.remove() }
  })

  $effect(() => {
    const instance = map
    if (!instance || (!showBoats && !showZeppelins)) return
    const stopsLayer = L.layerGroup().addTo(instance)
    const routeLayer = L.layerGroup().addTo(instance)
    let active: L.Marker | undefined
    for (const [kind, stops, legs] of transportRoutes) {
      if (kind === 'boat' ? !showBoats : !showZeppelins) continue
      const colour = kind === 'boat' ? '#73deff' : '#ffc068'
      for (let i = 0; i < stops.length; i++) {
        const [from, world, north, west] = stops[i]!
        const [to, targetWorld, targetNorth, targetWest] = stops[(i + 1) % stops.length]!
        const origin = worldPoint(world, north, west)
        const destination = worldPoint(targetWorld, targetNorth, targetWest)
        if (!origin) continue
        const pin = worldPin(origin, `transport-stop ${kind}`, `Da ${from} a ${to}`, { image: kind, route: true, lines: [`Da ${from}`, `a ${to}`] }).addTo(stopsLayer)
        pin.on('tooltipopen', () => {
          if (active && active !== pin) active.closeTooltip()
          active = pin
          routeLayer.clearLayers()
          const line = { pane: 'transport-route', interactive: false }
          let previous: { world: number; end: L.LatLngTuple } | undefined
          for (const [continent, points] of legs[i]!) {
            const track: L.LatLngTuple[] = []
            for (let j = 0; j < points.length; j += 2) {
              const point = worldPoint(continent, points[j]!, points[j + 1]!)
              if (point) track.push(point)
            }
            if (track.length < 2) { previous = undefined; continue }
            if (previous && previous.world !== continent) {
              L.polyline([previous.end, track[0]!], { ...line, color: colour, weight: 2, dashArray: '5 7' }).addTo(routeLayer)
            }
            L.polyline(track, { ...line, color: '#142136', weight: 6 }).addTo(routeLayer)
            L.polyline(track, { ...line, color: colour, weight: 3 }).addTo(routeLayer)
            previous = { world: continent, end: track.at(-1)! }
          }
          if (destination) L.circleMarker(destination, { ...line, radius: 12, color: colour, weight: 2, fill: false }).addTo(routeLayer)
        })
        pin.on('tooltipclose', () => {
          if (active === pin) { active = undefined; routeLayer.clearLayers() }
        })
      }
    }
    const closeRoute = (): void => {
      const stop = active
      active = undefined
      stop?.closeTooltip()
      routeLayer.clearLayers()
    }
    instance.on('preclick', closeRoute)
    return () => { instance.off('preclick', closeRoute); stopsLayer.remove(); routeLayer.remove() }
  })
  let noArt = $state(false)
  let initialized = false
  const cityBounds = new Map<number,L.LatLngBounds>()
  let coveredCapital=false
  let undergroundData:CityMini[]=[]
  const underground=new Map<number,{tile:L.ImageOverlay;url:string}>()
  const undergroundPending=new Set<number>()
  let undergroundGeneration=0
  let caveData = $state.raw<{ cave: WorldCave; box: Box }[]>([])
  let cavesLoaded = $state(false)
  const caveImages = new Map<string, { tile: L.ImageOverlay; url: string }>()
  const cavePending = new Set<string>()
  let caveWanted = new Set<string>()
  const approachCaves = $derived.by(() => {
    const info = approach, entry = entrance
    const selected = new Set<string>()
    if (!info || !entry) return selected
    const start = dungeonLocation(info.map, ...info.start, zoneMaps)
    const routes = info.routes?.map(route => route.points.map(([north, west]) => ({ world: info.map, north, west })))
      ?? [[entry.point]]
    for (const route of routes) {
      const points = start ? [start, ...route] : route
      let best: WorldCave | undefined, matches = 0
      for (const { cave, box } of caveData) {
        const count = points.filter(({ world, north, west }) => {
          if (world !== cave.world) return false
          const u = MIDDLE_YARDS - west, v = MIDDLE_YARDS - north
          return u >= box[0] && u <= box[2] && v >= box[1] && v <= box[3] && cave.pieces.some(piece => inPiece(piece, u, v))
        }).length
        if (count > matches) { best = cave; matches = count }
      }
      if (best) selected.add(`${best.world}:${best.id}`)
    }
    return selected
  })

  function removeCaveImages(): void {
    for (const { tile, url } of caveImages.values()) { tile.remove(); URL.revokeObjectURL(url) }
    caveImages.clear()
    cavePending.clear()
    caveWanted.clear()
  }

  function drawCaves(view: L.LatLngBounds, zoom: number): void {
    const atlas = map
    if (!atlas) return
    const wanted = new Set<string>()
    const showWorldCaves = showCaves && zoom >= 4.75
    if (showWorldCaves || approachCaves.size) {
      for (const { cave, box } of caveData) {
        const key = `${cave.world}:${cave.id}`
        const isApproach = approachCaves.has(key)
        if (!showWorldCaves && !isApproach) continue
        const calibration = calibrations.get(cave.world)
        if (!calibration) continue
        const { g, swap } = calibration
        const width = canvasWidth, height = canvasHeight
        const at = (u: number, v: number): L.LatLngTuple => {
          const [x, y] = project(g, MIDDLE_YARDS - v, MIDDLE_YARDS - u, swap)
          return [-y * height, x * width]
        }
        const bounds = caveBounds(box, at)
        if (!view.intersects(bounds)) continue
        wanted.add(key)
        const existing = caveImages.get(key)?.tile
        const pane = isApproach ? 'dungeon-access-cave' : 'atlas-landmarks'
        if (existing) {
          if (existing.options.pane !== pane) {
            existing.remove()
            existing.options.pane = pane
            existing.addTo(atlas)
          }
          continue
        }
        if (cavePending.has(key)) continue
        cavePending.add(key)
        const generation = undergroundGeneration
        void renderCave(cave, at).then(url => {
          if (!url) return
          if (map !== atlas || generation !== undergroundGeneration || !caveWanted.has(key)) { URL.revokeObjectURL(url); return }
          const pane = approachCaves.has(key) ? 'dungeon-access-cave' : 'atlas-landmarks'
          const tile = L.imageOverlay(url, bounds, { pane, zIndex: 350, opacity: .9, className: 'cave-minimap' }).addTo(atlas)
          caveImages.set(key, { tile, url })
        }).catch(() => {}).finally(() => { if (generation === undergroundGeneration) cavePending.delete(key) })
      }
    }
    caveWanted = wanted
    for (const [key, { tile, url }] of caveImages) if (!wanted.has(key)) {
      tile.remove()
      URL.revokeObjectURL(url)
      caveImages.delete(key)
    }
  }
  $effect(() => { void showCaves; void approachCaves; untrack(invalidate) })
  const wantCaves = $derived(!!approach || (showCaves && currentZoom >= 4.75))
  $effect(() => {
    if (!wantCaves || cavesLoaded) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/caves.json`, { signal: request.signal })
      .then(response => response.ok ? response.json() : [])
      .then(value => {
        if (request.signal.aborted || !Array.isArray(value)) return
        caveData = (value as WorldCave[]).flatMap(cave => {
          const box = boxOf(cave.pieces)
          return box ? [{ cave, box }] : []
        })
        cavesLoaded = true
        invalidate()
      }).catch(() => {})
    return () => request.abort()
  })
  const guildMarkers = new Map<string, {
    marker: L.Marker
    target: L.LatLng
    changedAt: number
    cadence?: number
    label: string
    appearance: string
    facing?: number
  }>()
  const guildMoves = new Map<L.Marker, [Fix, Fix]>()
  let guildFrame = 0
  let guildSampleTick = $state(0)
  let guildSampleTimer: ReturnType<typeof setTimeout> | undefined
  const classColours:Record<string,string>={WARRIOR:'#c79c6e',PALADIN:'#f58cba',HUNTER:'#abd473',ROGUE:'#f9e954',PRIEST:'#f4f4ee',DEATHKNIGHT:'#c41f3b',SHAMAN:'#4a95ed',MAGE:'#69ccf0',WARLOCK:'#b49be4',DRUID:'#ff9c35',MONK:'#42d4a2'}
  function capitalBounds(id: number): L.LatLngBounds | undefined {
    const saved = cityBounds.get(id)
    if (saved) return saved
    const city = zoneMaps.find(zone => zone.id === id)
    if (!city?.rect || city.continent === null) return undefined
    const { minX, minY, maxX, maxY } = city.rect
    const first = worldPoint(city.continent, minX, minY)
    const last = worldPoint(city.continent, maxX, maxY)
    if (first && last) return L.latLngBounds(first, last)
  }
  const capitals = [1453, 1454, 1455, 1456, 1457, 1458]
  function capitalAtCenter(atlas: L.Map): { id: number; bounds: L.LatLngBounds } | undefined {
    const center = atlas.getCenter()
    for (const id of capitals) {
      const bounds = capitalBounds(id)
      if (bounds?.contains(center)) return { id, bounds }
    }
  }
  const undergroundCapitals = new Set([1455, 1458])
  function updateCityFocus(atlas: L.Map): void {
    const capital = atlas.getZoom() >= 4.5 ? capitalAtCenter(atlas) : undefined
    const interior = capital && underground.get(capital.id)?.tile.getElement()
    cityFocus = interior?.complete && interior.naturalWidth > 0 ? 'interior'
      : capital && !undergroundCapitals.has(capital.id) && nativeEntries.size ? 'outdoor' : undefined
    for (const [id, {tile}] of underground) {
      const focused = id === capital?.id && cityFocus === 'interior'
      tile.getElement()?.classList.toggle('city-focused', focused)
      tile.setOpacity(focused ? 1 : undergroundOpacity(atlas.getZoom()))
    }
    if (!capital || cityFocus !== 'outdoor') return
    const northwest = atlas.latLngToContainerPoint(capital.bounds.getNorthWest())
    const southeast = atlas.latLngToContainerPoint(capital.bounds.getSouthEast())
    const midpoint = northwest.add(southeast).divideBy(2)
    const radius = southeast.subtract(northwest).divideBy(2)
    cityMask = `radial-gradient(ellipse ${radius.x}px ${radius.y}px at ${midpoint.x}px ${midpoint.y}px, transparent 70%, black 110%)`
  }
  const undergroundOpacity=(zoom:number):number=>Math.max(0,Math.min(1,(zoom-3.5)/1.5))
  const isLocation = (p: Position | undefined): p is Position & { wx: number; wy: number; ww: number; wh: number } =>
    !!p && [p.wx, p.wy, p.ww, p.wh].every((n) => typeof n === 'number' && Number.isFinite(n)) && p.ww! > 0 && p.wh! > 0 && p.wx! >= 0 && p.wx! <= 100000 && p.wy! >= 0 && p.wy! <= 100000
  const where = (p: Position & { wx: number; wy: number; ww: number; wh: number }): L.LatLng => L.latLng(-p.wy * p.wh / 100000, p.wx * p.ww / 100000)
  function redraw(): void {
    if (!map || !coastReady) return
    const visible = map.getBounds(), zoom = map.getZoom()
    const capital = capitalAtCenter(map)
    const focus = !!capital
    updateCityFocus(map)
    if (covered && coveredZoom === zoom && coveredCapital===focus && covered.contains(visible)) return
    const view = visible.pad(.35)
    covered = visible.pad(.10)
    coveredZoom = zoom
    coveredCapital=focus
    drawCaves(view, zoom)
    if(zoom>=3.5) for(const city of undergroundData) {
      const calibration=calibrations.get(city.world), bounds=capitalBounds(city.id)
      if(!calibration || !bounds || !view.intersects(bounds) || underground.has(city.id) || undergroundPending.has(city.id))continue
      undergroundPending.add(city.id);const generation=undergroundGeneration
      void renderCityMini(city,calibration).then(result=>{
        if(!result)return
        if(!map || generation!==undergroundGeneration){URL.revokeObjectURL(result.url);return}
        const atlas = map
        const tile=L.imageOverlay(result.url,result.bounds,{interactive:false,pane:'atlas-cities',opacity:undergroundOpacity(atlas.getZoom()),className:'detail-tile'})
          .once('load', () => { if (map === atlas) updateCityFocus(atlas) }).addTo(atlas)
        underground.set(city.id,{tile,url:result.url})
      }).catch(()=>{}).finally(()=>{if(generation===undergroundGeneration)undergroundPending.delete(city.id)})
    }
    const wantedDetail = new Set<string>()
    for (const { key, url, left, top, right, bottom } of detailTiles) {
      const bounds = L.latLngBounds([-top*canvasHeight,left*canvasWidth],[-bottom*canvasHeight,right*canvasWidth])
      if (!view.intersects(bounds)) continue
      wantedDetail.add(key)
      if (!details.has(key)) details.set(key, new AtlasTile(url, bounds, { interactive: false, pane:'atlas-detail' }).addTo(map))
    }
    for (const [key,tile] of details) if (!wantedDetail.has(key)) { tile.remove(); details.delete(key) }
    const wantedNative = new Set<string>()
    const nativeThreshold = focus ? 4.5 : 4.75
    const nativePane = map.getPane('atlas-native')
    if (nativePane) nativePane.style.opacity = String(Math.max(0, Math.min(1, (zoom - 3.25) / (nativeThreshold - 3.25))))
    // Warm nearby high-resolution tiles before they become visible. The detail layer stays underneath.
    if (zoom >= 2.75 && calibrations.size) {
      const yards = 1600/3, centre = map.getCenter()
      const candidates: { key:string; file:number; bounds:L.LatLngBounds; distance:number }[] = []
      for (const [world,{g,swap}] of calibrations) {
        const range = tileRange(g,swap,canvasWidth,canvasHeight,{west:view.getWest(),east:view.getEast(),north:-view.getNorth(),south:-view.getSouth()})
        if (!range) continue
        for (let col=range.col0; col<=range.col1; col++) for (let row=range.row0; row<=range.row1; row++) {
          const key=`${world}_${col}_${row}`, file=nativeEntries.get(key)
          if (!file) continue
          const [u0,v0]=project(g,(32-row)*yards,(32-col)*yards,swap)
          const [u1,v1]=project(g,(31-row)*yards,(31-col)*yards,swap)
          const bounds=L.latLngBounds([-v0*canvasHeight,u0*canvasWidth],[-v1*canvasHeight,u1*canvasWidth])
          if (!view.intersects(bounds)) continue
          const c=bounds.getCenter()
          candidates.push({key,file,bounds,distance:(c.lat-centre.lat)**2+(c.lng-centre.lng)**2})
        }
      }
      candidates.sort((a,b) => a.distance-b.distance)
      for (const {key,file,bounds} of candidates.slice(0,48)) {
        wantedNative.add(key)
        let tile = natives.get(key)
        if (!tile) {
          tile = new AtlasTile(`${OPENMAP}/native/${file}.png`, bounds, { interactive:false, pane:'atlas-native' }).addTo(map)
          natives.set(key, tile)
        }
      }
    }
    for (const [key,tile] of natives) if (!wantedNative.has(key)) { tile.remove(); natives.delete(key) }
  }
  function invalidate(): void { covered=undefined; scheduleRedraw() }
  function scheduleRedraw(): void {
    if (redrawTimer) return
    redrawTimer = setTimeout(() => { redrawTimer=undefined; redraw() }, 100)
  }
  function updateCursor(): void {
    pointerFrame = 0
    if (!map || !pointerPoint) return
    const point = map.containerPointToLatLng(pointerPoint)
    const value = cursorCoordinates(point.lng, -point.lat, canvasWidth, canvasHeight, zoneMaps, calibrations, pos?.world)
    if (value?.mapId !== hoveredZone?.id) {
      hoveredZone = value ? { id: value.mapId, name: value.zone, levels: zoneLevelText(value.mapId) } : undefined
    }
    const key = value ? `${value.mapId}:${value.x.toFixed(1)}:${value.y.toFixed(1)}` : ''
    if (key !== lastPointer) { lastPointer = key; onCursor(value) }
  }
  function scheduleCursor(): void { if (!pointerFrame) pointerFrame = requestAnimationFrame(updateCursor) }
  onMount(() => {
    restoreAlignment()
    const instance = L.map(holder, { crs: L.CRS.Simple, minZoom: -1.5, maxZoom: 8, zoomSnap: 0, zoomDelta: .5, zoomControl: false, attributionControl: false, scrollWheelZoom: false })
    let placementFrame = 0
    const placeWorldPins = (): void => {
      // Nearby markers get distinct targets at world zoom. Geographic routes keep the dock positions.
      if (placementFrame) return
      placementFrame = requestAnimationFrame(() => {
        placementFrame = 0
        const grid = new Map<string, L.Point[]>()
        const cell = (value: number): number => Math.floor(value / pinSpacing)
        const available = (candidate: L.Point): boolean => {
          const x = cell(candidate.x), y = cell(candidate.y)
          for (let column = x - 1; column <= x + 1; column++) {
            for (let row = y - 1; row <= y + 1; row++) {
              if (grid.get(`${column},${row}`)?.some(previous => candidate.distanceTo(previous) < pinSpacing - .01)) return false
            }
          }
          return true
        }
        instance.eachLayer(layer => {
          if (!(layer instanceof L.Marker)) return
          const origin = worldPinOrigins.get(layer)
          if (!origin) return
          const point = instance.project(origin)
          const offsets = servicePins.has(layer) ? servicePinOffsets : pinOffsets
          const offset = offsets.find(({ x, y }) => available(L.point(point.x + x, point.y + y)))
          const at = offset ? L.point(point.x + offset.x, point.y + offset.y) : point
          const key = `${cell(at.x)},${cell(at.y)}`
          const neighbors = grid.get(key) ?? []
          neighbors.push(at)
          grid.set(key, neighbors)
          layer.setLatLng(instance.unproject(at))
        })
      })
    }
    const worldPinsChanged = ({ layer }: L.LayerEvent): void => {
      if (layer instanceof L.Marker && worldPinOrigins.has(layer)) placeWorldPins()
    }
    instance.on('zoomend', placeWorldPins)
    instance.on('layeradd layerremove', worldPinsChanged)
    const scenery = instance.createPane('atlas-scenery')
    scenery.style.zIndex = '400'
    const cities = instance.createPane('atlas-cities')
    cities.style.zIndex = '430'
    cities.style.pointerEvents = 'none'
    const routes = instance.createPane('transport-route', scenery)
    const dungeons = instance.createPane('atlas-dungeons')
    dungeons.style.zIndex = '460'
    dungeons.style.pointerEvents = 'none'
    const approaches = instance.createPane('dungeon-approaches')
    approaches.style.zIndex = '470'
    approaches.style.pointerEvents = 'none'
    const accessCave = instance.createPane('dungeon-access-cave')
    accessCave.style.zIndex = '455'
    accessCave.style.pointerEvents = 'none'
    const access = instance.createPane('dungeon-access')
    access.style.zIndex = '610'
    access.style.pointerEvents = 'none'
    routes.style.zIndex = '450'
    routes.style.pointerEvents = 'none'
    const terrain = instance.createPane('atlas-terrain', scenery)
    terrain.style.zIndex = '400'
    terrain.style.pointerEvents = 'none'
    for (const [name, zIndex] of [['detail', 410], ['native', 411], ['landmarks', 420]] as const) {
      const pane = instance.createPane(`atlas-${name}`, name === 'landmarks' ? scenery : terrain)
      pane.style.zIndex = String(zIndex)
      pane.style.pointerEvents = 'none'
    }
    map = instance
    instance.setView([-334, 501], 0)
    if (!inApp) {
      const coast = new Image()
      coast.src = `${OPENMAP}/overview.png?coast=2`
      // The alpha channel defines the coastline. The illustrated image is never displayed.
      void coast.decode().then(() => {
        if (map !== instance) return
        overviewImage = coast
        terrain.style.setProperty('--atlas-coast', `url("${coast.src}")`)
      }).catch(() => { /* Older packages can supply terrain without a coast mask. */ }).finally(() => {
        if (map !== instance) return
        coastReady = true
        invalidate()
      })
      void createOceanTexture().then(texture => {
        if (!texture) return
        if (map !== instance) { URL.revokeObjectURL(texture); return }
        holder.style.setProperty('--atlas-ocean', `url("${texture}")`)
        instance.once('unload', () => URL.revokeObjectURL(texture))
      }).catch(() => { /* Keep the solid sea when the texture cannot load. */ })
    }
    let tapInput = false
    const notePointer = (event: PointerEvent): void => { tapInput = event.pointerType === 'touch' || event.pointerType === 'pen' }
    const pointerMove = (event: L.LeafletMouseEvent): void => {
      if (tapInput) return
      pointerPoint = event.containerPoint
      scheduleCursor()
    }
    const tapZone = (event: L.LeafletMouseEvent): void => {
      if (!tapInput) return
      pointerPoint = event.containerPoint
      scheduleCursor()
    }
    const clearPointer = (): void => {
      pointerPoint = undefined
      if (pointerFrame) cancelAnimationFrame(pointerFrame)
      pointerFrame = 0
      lastPointer = ''
      hoveredZone = undefined
      onCursor(null)
    }
    const pointerLeave = (): void => { if (!tapInput) clearPointer() }
    instance.on('mousemove', pointerMove)
    instance.on('click', tapZone)
    instance.on('move zoom', () => { if (!tapInput) scheduleCursor() })
    holder.addEventListener('pointerdown', notePointer, true)
    holder.addEventListener('pointerenter', notePointer)
    holder.addEventListener('mouseleave', pointerLeave)
    let mapsClosed = false, mapsLoading = false
    if (!inApp) void fetch(`${OPENMAP}/alignment.json`).then(r => r.ok ? r.json() : null).then(value => {
      if (!mapsClosed && !alignmentReady && value && applyAlignment(value)) {

        invalidate()
        scheduleCursor()
      }
    }).catch(() => {})
    const loadMaps = (): void => {
      if (mapsLoading || zoneMaps.length) return
      mapsLoading = true
      fetch(`${OPENMAP}/maps.json`, { cache: 'no-store' }).then(r => r.ok ? r.json() as Promise<unknown> : null).then(value => {
        if (mapsClosed || !Array.isArray(value)) return
        const firstMaps = !zoneMaps.length
        zoneMaps = value as GameMap[]
        if (firstMaps && zoneMaps.length) invalidate()
        scheduleCursor()
      }).catch(() => {}).finally(() => { mapsLoading = false })
    }
    loadMaps()
    const mapsTimer = setInterval(loadMaps, 10000)
    instance.on('moveend', () => { if (!followingGuildFrame) serviceBounds = instance.getBounds().pad(.12) })
    serviceBounds = instance.getBounds().pad(.12)
    instance.on('move', () => { if (cityFocus) updateCityFocus(instance) })
    instance.on('move', () => {
      const zoom = instance.getZoom()
      const threshold = capitalAtCenter(instance) ? 4.5 : 4.75
      const previous = coveredZoom ?? -Infinity
      if (!covered?.contains(instance.getBounds()) ||
          (zoom >= 2.75) !== (previous >= 2.75) || (zoom >= 3.25 && previous < threshold && Math.floor(zoom * 4) !== Math.floor(previous * 4)) ||
          (zoom >= threshold) !== (previous >= threshold)) scheduleRedraw()
    })
    instance.on('moveend zoomend', () => { if (followingGuildFrame) return; currentZoom = instance.getZoom(); updateCityFocus(instance); scheduleRedraw() })
    const loadCity = ():void => {
      fetch(`${OPENMAP}/city.json`, {cache:'no-store'}).then(r=>r.json()).then(value=>{
        if (!Array.isArray(value) || !map) return
        for (const item of value) {
          const city=cityFrom(item); if (!city) continue
          const bounds=L.latLngBounds([-city.b*668/100000,city.l*1002/100000],[-city.t*668/100000,city.r*1002/100000])
          const old=cityBounds.get(city.id);if(!old || !old.equals(bounds)){cityBounds.set(city.id,bounds);invalidate()}
        }
      }).catch(()=>{})
    }
    loadCity()
    fetch(`${OPENMAP}/city-mini.json`).then(r=>r.ok ? r.json() as Promise<CityMini[]> : []).then(list=>{if(Array.isArray(list)){undergroundData=list;invalidate()}}).catch(()=>{})
    const cityTimer=inApp ? setInterval(loadCity,5000) : undefined
    const explore = (): void => { following = false }
    const stopWheelZoom = installAtlasWheelZoom(instance, explore, () => !!followedGuildName)
    instance.on('moveend zoomend', () => { if (!followingGuildFrame) layoutGuildLabels(instance) })
    instance.on('dragstart', explore)
    holder.addEventListener('dblclick', explore, { capture: true, passive: true })
    fetch(`${OPENMAP}/detail.json`).then((r) => r.ok ? r.json() as Promise<unknown> : []).then((list) => {
      if (!Array.isArray(list)) return void (noArt = true)
      detailEntries = list.filter((p): p is [number,number,number] => Array.isArray(p) && p.length === 3 && p.every((n) => Number.isInteger(n) && n >= 0 && n < 64))
      noArt = detailEntries.length === 0
      invalidate()
    }).catch(() => { noArt = true })
    fetch(`${OPENMAP}/native.json`).then((r) => r.ok ? r.json() as Promise<unknown> : []).then((list) => {
      if (!Array.isArray(list)) return
      for (const p of list) if (Array.isArray(p) && p.length === 4 && p.every((n) => Number.isSafeInteger(n) && n >= 0) && p[0] <= 1 && p[1] < 64 && p[2] < 64 && p[3] > 0) nativeEntries.set(`${p[0]}_${p[1]}_${p[2]}`,p[3])
      invalidate()
    }).catch(() => {})
    const resize = new ResizeObserver(() => instance.invalidateSize())
    resize.observe(holder)
    instance.once('unload', () => { for (const url of coastUrls.values()) URL.revokeObjectURL(url) })
    return () => { mapsClosed=true;clearInterval(mapsTimer);holder.removeEventListener('pointerdown',notePointer,true);holder.removeEventListener('pointerenter',notePointer);holder.removeEventListener('mouseleave',pointerLeave);clearPointer();undergroundGeneration++;removeCaveImages();for(const c of underground.values())URL.revokeObjectURL(c.url);underground.clear();undergroundPending.clear();clearInterval(cityTimer); resize.disconnect(); stopWheelZoom(); holder.removeEventListener('dblclick', explore, true); if (redrawTimer) clearTimeout(redrawTimer); cancelAnimationFrame(motion); cancelAnimationFrame(guildFrame); clearTimeout(guildSampleTimer); guildMoves.clear(); instance.off('zoomend',placeWorldPins);instance.off('layeradd layerremove',worldPinsChanged);cancelAnimationFrame(placementFrame);instance.remove(); map = undefined; details.clear(); natives.clear(); cityBounds.clear(); guildMarkers.clear() }
  })
  let lockHint = $state(false)
  $effect(() => {
    const atlas = map
    if (!atlas || !followedGuildName) return
    const container = atlas.getContainer()
    const wasDraggable = atlas.dragging.enabled()
    const { touchZoom, doubleClickZoom } = atlas.options
    atlas.dragging.disable()
    atlas.options.touchZoom = 'center'
    atlas.options.doubleClickZoom = 'center'
    const pointers = new Map<number, { x: number; y: number }>()
    let timer: ReturnType<typeof setTimeout> | undefined
    function explain(): void {
      lockHint = true
      clearTimeout(timer)
      timer = setTimeout(() => lockHint = false, 2600)
    }
    const start = (event: PointerEvent) => {
      if (event.button === 0) pointers.set(event.pointerId, { x: event.clientX, y: event.clientY })
    }
    const end = (event: PointerEvent) => { pointers.delete(event.pointerId) }
    const move = (event: PointerEvent) => {
      const point = pointers.get(event.pointerId)
      if (pointers.size !== 1 || !point || !event.buttons) return
      if (Math.hypot(event.clientX - point.x, event.clientY - point.y) > 6) {
        end(event)
        explain()
      }
    }
    const key = (event: KeyboardEvent) => {
      if (event.target !== container || !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return
      event.preventDefault()
      event.stopPropagation()
      explain()
    }
    container.addEventListener('pointerdown', start, true)
    window.addEventListener('pointermove', move, true)
    window.addEventListener('pointerup', end, true)
    window.addEventListener('pointercancel', end, true)
    container.addEventListener('keydown', key, true)
    return () => {
      container.removeEventListener('pointerdown', start, true)
      window.removeEventListener('pointermove', move, true)
      window.removeEventListener('pointerup', end, true)
      window.removeEventListener('pointercancel', end, true)
      container.removeEventListener('keydown', key, true)
      clearTimeout(timer)
      lockHint = false
      atlas.options.touchZoom = touchZoom
      atlas.options.doubleClickZoom = doubleClickZoom
      if (wasDraggable) atlas.dragging.enable()
    }
  })
  const followedMember = $derived(guild.find(member =>
    member.name === followedGuildName && member.x !== undefined && member.y !== undefined))
  function followedGuildMarker(): L.Marker | undefined {
    const member = followedMember
    if (!member) return
    const key = member.exact ? 'player:' + member.name : 'zone:' + member.x + ':' + member.y
    return guildMarkers.get(key)?.marker
  }
  function centerGuildMarker(atlas: L.Map, marker: L.Marker): void {
    const center = marker.getLatLng()
    if (!atlas.getCenter().equals(center)) atlas.panTo(center, { animate: false, noMoveStart: true })
  }
  let followingGuildFrame = false
  let lastGuildLayout = -Infinity
  function layoutGuildLabels(atlas: L.Map): void {
    const priority = followedGuildMarker()
    const entries = [...guildMarkers.values()].map(entry => entry.marker)
    if (priority) entries.sort((a, b) => Number(b === priority) - Number(a === priority))
    const viewport = atlas.getContainer().getBoundingClientRect()
    const occupied: DOMRect[] = []
    const labels: { element: HTMLElement; hidden: boolean }[] = []
    for (const marker of entries) {
      const tooltip = marker.getTooltip()
      const element = tooltip?.getElement()
      if (!tooltip?.options.permanent || !element) continue
      const box = element.getBoundingClientRect()
      const visible = box.right > viewport.left && box.left < viewport.right &&
        box.bottom > viewport.top && box.top < viewport.bottom
      const hidden = !visible || occupied.some(other =>
        box.left < other.right + 3 && box.right + 3 > other.left &&
        box.top < other.bottom + 3 && box.bottom + 3 > other.top)
      if (!hidden) occupied.push(box)
      labels.push({ element, hidden })
    }
    for (const { element, hidden } of labels) element.classList.toggle('guild-label-colliding', hidden)
  }
  function animateGuild(now: number): void {
    guildFrame = 0
    const target = followedGuildMarker()
    for (const [pin, path] of guildMoves) {
      const [start, end] = path
      const progress = (now - start.at) / (end.at - start.at)
      // Slow gently into the last known position if a fresh sample is late.
      const tail = Math.max(0, (progress - .75) / .25)
      const eased = progress < 1 && tail > 0 ? .75 + .25 * (tail + tail * tail - tail * tail * tail) : progress
      const next = whereAt(path, start.at + eased * (end.at - start.at))
      pin.setLatLng([next.y, next.x])
      if (pin === target) guideGuildCamera()
      if (next.arrived) guildMoves.delete(pin)
    }
    if (map && (now - lastGuildLayout >= 100 || !guildMoves.size)) {
      lastGuildLayout = now
      if (target) {
        const bounds = map.getBounds()
        if (!serviceBounds?.contains(bounds)) serviceBounds = bounds.pad(.12)
        updateCityFocus(map)
        scheduleRedraw()
      }
      layoutGuildLabels(map)
    }
    if (guildMoves.size) guildFrame = requestAnimationFrame(animateGuild)
  }
  $effect(() => {
    if (!map) return
    void guildSampleTick
    clearTimeout(guildSampleTimer)
    let nextSample = Infinity
    const groups = new Map<string, GuildMember[]>()
    for (const member of guild) {
      if (member.x === undefined || member.y === undefined) continue
      const key = member.exact ? `player:${member.name}` : `zone:${member.x}:${member.y}`
      const group = groups.get(key) ?? []
      group.push(member)
      groups.set(key, group)
    }
    for (const [key, entry] of guildMarkers) {
      if (groups.has(key)) continue
      guildMoves.delete(entry.marker)
      entry.marker.remove()
      guildMarkers.delete(key)
    }
    const now = performance.now()
    const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches
    for (const [key, members] of groups) {
      const first = members[0]!
      const target = L.latLng(-first.y! * 668 / 100000, first.x! * 1002 / 100000)
      const sampleInterval = 110 + 490 * guildOverviewWeight(map.getZoom())
      let entry = guildMarkers.get(key)
      if (!entry) {
        const marker = new SmoothPlayerMarker(target, { interactive: true, zIndexOffset: 500 })
        entry = { marker, target, changedAt: now, label: '', appearance: '' }
        guildMarkers.set(key, entry)
      } else if (!entry.target.equals(target) && first.exact && !reduceMotion &&
          now - entry.changedAt < sampleInterval && Math.hypot(target.lng - entry.target.lng, target.lat - entry.target.lat) <= 20) {
        nextSample = Math.min(nextSample, entry.changedAt + sampleInterval)
      } else if (!entry.target.equals(target)) {
        const from = entry.marker.getLatLng()
        const distance = Math.hypot(target.lng - from.lng, target.lat - from.lat)
        if (first.exact && !reduceMotion && distance <= 20) {
          // Older Pulser clients still report every three seconds. Use their observed cadence.
          const gap = now - entry.changedAt
          // Ignore long pauses; ordinary jitter should not reset the animation speed.
          if (gap <= 3400) entry.cadence = (entry.cadence ?? gap) * .65 + gap * .35
          const overview = guildOverviewWeight(map.getZoom())
          const duration = gap <= 3400
            ? Math.max(260 + 220 * overview, Math.min(3400, Math.max(gap, entry.cadence ?? gap) * (1.03 + .22 * overview)))
            : 900
          guildMoves.set(entry.marker, [
            { at: now, x: from.lng, y: from.lat },
            { at: now + duration, x: target.lng, y: target.lat }
          ])
        } else {
          guildMoves.delete(entry.marker)
          entry.marker.setLatLng(target)
        }
        entry.target = target
        entry.changedAt = now
      }
      const color = classColours[first.cls ?? ''] ?? '#7ddbb1'
      const symbol = first.exact ? '◆' : String(members.length)
      const facing = showGuildDirection && first.exact ? first.facing : undefined
      const directional = facing !== undefined
      const appearance = directional ? cursor : `${color} ${symbol}`
      const iconChanged = entry.appearance !== appearance
      if (iconChanged) {
        if (directional) entry.marker.setIcon(playerIcon(cursor, 36))
        else {
          const badge = document.createElement('span')
          badge.className = first.exact ? 'guild-pin exact' : 'guild-pin approximate'
          badge.style.setProperty('--guild-colour', color)
          badge.textContent = symbol
          entry.marker.setIcon(L.divIcon({ className: 'guild-wrap', html: badge, iconSize: [26, 26], iconAnchor: [13, 13] }))
        }
        entry.appearance = appearance
      }
      const name = first.exact ? `${first.name}${first.level ? ` · ${first.level}` : ''}` : `Zona indicativa: ${members.map(m => m.name).join(', ')}`
      const labelKey = `${directional}:${name}`
      if (entry.label !== labelKey) {
        const label = document.createElement('span')
        label.textContent = name
        entry.marker.unbindTooltip().bindTooltip(label, { direction: 'top', offset: [0, directional ? -19 : -12], permanent: first.exact, className: 'guild-label' })
        entry.label = labelKey
      }
      if (!map.hasLayer(entry.marker)) entry.marker.addTo(map)
      if (directional && (iconChanged || entry.facing !== facing)) turnPlayer(entry.marker, facing)
      entry.facing = facing
    }
    if (Number.isFinite(nextSample)) {
      guildSampleTimer = setTimeout(() => guildSampleTick++, Math.max(1, nextSample - performance.now()))
    }
    layoutGuildLabels(map)
    if (guildMoves.size && !guildFrame) guildFrame = requestAnimationFrame(animateGuild)
  })
  $effect(() => {
    if (!map) return
    if (!isLocation(pos)) { marker?.remove(); marker = undefined; return }
    const at = where(pos)
    const sizeChanged = canvasWidth !== pos.ww || canvasHeight !== pos.wh
    canvasWidth = pos.ww; canvasHeight = pos.wh
    const world = pos.world
    const g = world === undefined ? null : geometryOf(geometry, world)
    let next: Calibrated | null = null
    if (g && typeof pos.north === 'number' && typeof pos.west === 'number') next = calibrate(g, pos.north, pos.west, pos.wx, pos.wy, calibrations.get(world!)?.swap)
    if (next) {
      const nextCalibrations = new Map(calibrations)
      for (const continent of [0,1]) {
        const continentGeometry = geometryOf(geometry,continent)
        if (continentGeometry) nextCalibrations.set(continent,{g:continentGeometry,swap:next.swap})
      }
      const changed = JSON.stringify([...nextCalibrations]) !== JSON.stringify([...calibrations])
      if (changed || sizeChanged) calibrations = nextCalibrations
      alignmentReady = true
      saveAlignment()
      if (changed || sizeChanged) {
        scheduleCursor()

        undergroundGeneration++; for(const c of underground.values()){c.tile.remove();URL.revokeObjectURL(c.url)} underground.clear();undergroundPending.clear()
        removeCaveImages()
        for (const tile of details.values()) tile.remove()
        for (const tile of natives.values()) tile.remove()
        details.clear(); natives.clear(); invalidate()
      }
    }
    if (!showPlayer) return
    if (!marker) {
      marker = new SmoothPlayerMarker(at, { icon:playerIcon(cursor), interactive: false, zIndexOffset: 1000 }).addTo(map); markerStyle=cursor
    }
    if (markerStyle!==cursor) { marker.setIcon(playerIcon(cursor)); markerStyle=cursor }
    turnPlayer(marker,pos.facing)
    const reading: Fix = {at:readAt ?? Date.now(),x:at.lng,y:at.lat}
    if (!initialized || !trail.length || Math.hypot(reading.x-trail[trail.length-1]!.x,reading.y-trail[trail.length-1]!.y)>20) {
      cancelAnimationFrame(motion); motion=0; trail=[reading]; marker.setLatLng(at)
      if (!initialized) { initialized=true; map.setView(at,1.5,{animate:false}) }
      else if (following) map.panTo(at,{animate:false,noMoveStart:true})
    } else {
      const updated=addFix(trail,reading)
      if (updated !== trail) {
        trail=updated
        if (!motion) motion=requestAnimationFrame(animatePosition)
      }
    }
  })
  function animatePosition(): void {
    motion=0
    if (!map || !marker || !trail.length) return
    const next=whereAt(trail,Date.now()-BEHIND), at=L.latLng(next.y,next.x)
    marker.setLatLng(at)
    if (following) map.panTo(at,{animate:false,noMoveStart:true})
    if (!next.arrived) motion=requestAnimationFrame(animatePosition)
  }
  $effect(() => {
    const member = guildTarget?.member, atlas = map
    if (!atlas || !member || member.x === undefined || member.y === undefined) return
    const point = L.latLng(-member.y * 668 / 100000, member.x * 1002 / 100000)
    const key = member.exact ? `player:${member.name}` : `zone:${member.x}:${member.y}`
    untrack(() => {
      following = false
      atlas.panTo(point, { animate: false })
    })
    const frame = requestAnimationFrame(() => guildMarkers.get(key)?.marker.openTooltip())
    return () => cancelAnimationFrame(frame)
  })
  let centeredGuildName: string | undefined
  let guildFlyUntil = 0
  let guildCameraFrame = 0
  let guildCameraTime = 0

  function guideGuildCamera(): void {
    if (guildCameraFrame) return
    guildCameraTime = performance.now()
    guildCameraFrame = requestAnimationFrame(stepGuildCamera)
  }

  function guildOverviewWeight(zoom: number): number {
    return Math.max(0, Math.min(1, (5.5 - zoom) / 2.5))
  }

  function stepGuildCamera(now: number): void {
    guildCameraFrame = 0
    const atlas = map, marker = followedGuildMarker()
    if (!atlas || !marker || !followedGuildName) return
    if (now < guildFlyUntil) {
      guildCameraTime = now
      guildCameraFrame = requestAnimationFrame(stepGuildCamera)
      return
    }

    const center = atlas.project(atlas.getCenter())
    const target = atlas.project(marker.getLatLng())
    const offset = target.subtract(center)
    const distance = offset.distanceTo(L.point(0, 0))
    const overview = guildOverviewWeight(atlas.getZoom())
    if (distance < 1 + .75 * overview) return
    const elapsed = Math.min(50, Math.max(1, now - guildCameraTime))
    guildCameraTime = now
    const weight = 1 - Math.exp(-elapsed / (540 + 1110 * overview))
    // Leaflet's public panBy rounds each step. Move its pane with fractional pixels
    // and refresh the viewport on the slower layout cadence below.
    const camera = atlas as L.Map & { _rawPanBy(offset: L.Point): void }
    camera._rawPanBy(offset.multiplyBy(weight))

    if (now - lastGuildLayout >= 100) {
      lastGuildLayout = now
      atlas.fire('move')
      const bounds = atlas.getBounds()
      if (!serviceBounds?.contains(bounds)) serviceBounds = bounds.pad(.12)
      updateCityFocus(atlas)
      scheduleRedraw()
      layoutGuildLabels(atlas)
    }
    guildCameraFrame = requestAnimationFrame(stepGuildCamera)
  }
  $effect(() => {
    const atlas = map
    const name = followedGuildName
    if (!atlas || !name) {
      if (atlas && guildFlyUntil > performance.now()) atlas.stop()
      guildFlyUntil = 0
      centeredGuildName = undefined
      cancelAnimationFrame(guildCameraFrame)
      guildCameraFrame = 0
      return
    }
    const marker = followedGuildMarker()
    untrack(() => {
      following = false
      if (!marker) return
      if (centeredGuildName !== name) {
        centeredGuildName = name
        const zoom = Math.max(atlas.getMinZoom(), Math.min(atlas.getMaxZoom(), guildStartZoom))
        if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
          atlas.setView(marker.getLatLng(), zoom, { animate: false })
          return
        }
        guildFlyUntil = performance.now() + 700
        atlas.flyTo(marker.getLatLng(), zoom, { duration: .65 })
      }
      if (matchMedia('(prefers-reduced-motion: reduce)').matches) centerGuildMarker(atlas, marker)
      else guideGuildCamera()
    })
  })
</script>

<div class="atlas" class:sea-background={!inApp} class:dungeon-ranges={currentZoom >= 2.5}
  class:dungeon-focus={dungeonFocus} class:city-interior={focusedCity === 'interior'} bind:this={holder}></div>
{#if lockHint && followedGuildName}
  <div class="guild-lock-hint" role="status">Disattiva il mirino prima di spostare la mappa.</div>
{/if}
<div class="city-veil" class:visible={focusedCity === 'outdoor'} style:mask-image={cityMask} aria-hidden="true"></div>
{#if directoryOpen || entrance}
  <DungeonJournal initialNames={directoryOpen ? [] : entrance?.names ?? []}
    selectedName={directoryOpen ? undefined : activeDungeon?.name}
    overlay selectedBoss={directoryOpen ? undefined : selectedBoss} {floor} {maxFloor}
    mapStatus={dungeonStatus} onSelect={selectDungeon} onClose={closeDungeon} onBoss={showBoss} onFloor={value => floor = value}
    {approach} onApproach={showApproach} {locateQuestNpc} />
{/if}
{#if hoveredZone && !dungeonFocus}
  <div class="zone-tooltip" class:with-gathering={gatheringVisible} role="tooltip">
    <strong>{hoveredZone.name}</strong>
    {#if hoveredZone.levels}<span>{hoveredZone.levels}</span>{/if}
    {#if gatheringVisible}
      {#if gatheringByZone === undefined}
        <span>Caricamento dei requisiti di raccolta…</span>
      {:else}
        <dl class="zone-gathering">
          {#each gatheringRows as profession (profession.id)}
            <div><dt>{profession.label}</dt><dd>{gatheringSkill(profession.id, gatheringByZone[hoveredZone.id]?.[profession.id])}</dd></div>
          {/each}
        </dl>
      {/if}
    {/if}
  </div>
{/if}
<button class="guild-zoom-preset" type="button" onclick={saveGuildZoom} title="Usa lo zoom attuale quando agganci un gildano">{savedGuildZoom ? 'Zoom mirino salvato' : 'Fissa zoom mirino'}</button>
<AtlasPins {map} />
<div class="controls">
  <MapSearch bind:open={searchOpen} places={searchablePlaces} position={ownPosition} loading={!alignmentReady || services === undefined}
    selected={!!selectedPlace} onSelect={(place) => selectedPlace = { place }} onClear={() => selectedPlace = undefined} />
</div>
{#if noArt}<p class="notice">{inApp ? 'Non trovo le immagini di OpenMap. Installa e abilita OpenMap, poi riavvia il companion.' : 'La cartografia del mondo non è ancora disponibile sul server.'}</p>
{:else if pos && !isLocation(pos)}<p class="notice">Coordinate della mappa non disponibili. Aggiorna l’addon e usa /reload; alcune zone potrebbero non essere supportate.</p>
{:else if currentZoom >= 4 && !alignmentReady}
  <p class="notice">{!inApp ? 'Il dettaglio del terreno richiede i dati di allineamento della mappa.' : pos ? 'In attesa dei dati per allineare il dettaglio del terreno. Usa /reload se il messaggio persiste.' : 'Apri WoW con l’addon attivo una volta per preparare lo zoom dettagliato anche a gioco chiuso.'}</p>
{/if}

<style>
  .guild-zoom-preset {position:absolute;right:12px;bottom:78px;z-index:1000;padding:6px 10px;border:1px solid #c3a264;border-radius:4px;background:#132d49;color:#ffedc3;cursor:pointer;font:inherit}
  .guild-lock-hint {position:absolute;bottom:72px;left:50%;transform:translateX(-50%);z-index:1100;max-width:calc(100% - 32px);padding:8px 13px;border:1px solid #ffda78;border-radius:5px;background:#10253b;color:#ffe398;box-shadow:0 3px 12px #0009;text-align:center;pointer-events:none}
  .atlas { position:absolute; inset:0; background:#b8a582; }
  .atlas.sea-background { background:#263647; }
  .atlas.sea-background::before { content:''; position:absolute; inset:0; pointer-events:none; background:var(--atlas-ocean, none) repeat 0 0 / 1024px 1024px; }
  .atlas::before, .atlas :global(.leaflet-atlas-scenery-pane), .atlas :global(.leaflet-atlas-cities-pane img) { transition:filter 220ms ease, opacity 180ms ease; }
  .atlas.dungeon-focus::before, .atlas.city-interior::before,
  .atlas.dungeon-focus :global(.leaflet-atlas-scenery-pane), .atlas.dungeon-focus :global(.leaflet-atlas-cities-pane img),
  .atlas.city-interior :global(.leaflet-atlas-scenery-pane), .atlas.city-interior :global(.leaflet-atlas-cities-pane img:not(.city-focused)) { filter:brightness(.48) blur(5px); }
  .city-veil { position:absolute; inset:0; z-index:990; pointer-events:none; opacity:0; backdrop-filter:brightness(.48) blur(5px); transition:opacity 220ms ease; }
  .city-veil.visible { opacity:1; }
  .atlas :global(.leaflet-marker-pane > :not(.dungeon-boss-pin)) { transition:opacity 220ms ease; }
  .atlas.dungeon-focus :global(.leaflet-marker-pane > :not(.dungeon-boss-pin)) { opacity:.28; }
  @media (prefers-reduced-motion: reduce) {
    .atlas::before, .atlas :global(.leaflet-atlas-scenery-pane), .atlas :global(.leaflet-atlas-cities-pane img),
    .city-veil,
    .atlas :global(.leaflet-marker-pane > :not(.dungeon-boss-pin)) { transition:none; }
  }
  .zone-tooltip { position:absolute; z-index:1210; top:18px; left:50%; transform:translateX(-50%); pointer-events:none; display:grid; gap:2px; width:max-content; max-width:min(240px, 42%); padding:6px 10px; border:1px solid #caa45f; border-radius:4px; background:#0a1b32f5; color:#fff0cd; box-shadow:0 2px 7px #0008; font:14px var(--font); overflow-wrap:anywhere; text-align:center; }
  .zone-tooltip span { color:#e8d29c; font-size:12px; }
  .zone-tooltip.with-gathering {max-width:min(340px,calc(100% - 38px))}
  @media(max-width:640px) { .zone-tooltip {top:72px} }
  .zone-gathering {display:grid;gap:3px;margin:4px 0 0;padding-top:4px;border-top:1px solid #caa45f66;text-align:left;font-size:13px}
  .zone-gathering div {display:grid;grid-template-columns:minmax(90px,1fr) minmax(0,1.3fr);gap:8px}
  .zone-gathering dt {font-weight:700}
  .zone-gathering dd {margin:0;color:#f4db9a}
  :global(.world-pin) { display:grid; place-items:center; background:transparent; border:0; }
  :global(.dungeon-access-pin) {display:grid;place-items:center;background:#74501a;border:2px solid #ffd77a;border-radius:50%;color:#fff3c4;font:700 20px var(--font);box-shadow:0 2px 7px #000b}
  :global(.dungeon-approach-portal) {position:relative;display:grid;place-items:center;width:24px;height:24px;border:2px solid #ffd77a;border-radius:50%;background:#192234;box-shadow:0 2px 6px #000b}
  :global(.dungeon-approach-portal .world-pin-image) {width:24px;height:24px}
  :global(.dungeon-approach-arrow span) {display:block;text-align:center;color:#fff1a1;text-shadow:0 1px 3px #000,0 -1px 3px #000;font-size:14px;line-height:14px}
  :global(.flight-point), :global(.dungeon-entrance), :global(.transport-stop) { position:relative; display:grid; place-items:center; width:18px; height:18px; border:1px solid currentColor; border-radius:50%; box-shadow:0 0 0 2px #131722, 0 2px 4px #000a; }
  :global(.flight-point) { background:#292e37; color:#b7bac1; }
  :global(.flight-point.unlocked) { background:#173b2b; color:#80ec9a; }
  :global(.flight-point.unverified) { border-style:dashed; }
  :global(.flight-point)::before { content:''; width:12px; height:7px; background:currentColor; border-radius:75% 15% 75% 15%; transform:rotate(-35deg); }
  :global(.flight-point)::after { content:''; position:absolute; width:12px; height:1px; background:#18202a; transform:translate(-1px, 1px) rotate(-35deg); }
  :global(.dungeon-entrance) { background:#172b46; color:#84d7ec; }
  :global(.dungeon-entrance)::before { content:''; width:8px; height:8px; border:1px solid #ecc674; border-radius:50%; background:#20708d; }
  :global(.transport-stop.boat) { background:#153544; color:#84e4f8; }
  :global(.transport-stop.boat)::before { content:'⚓︎'; font:700 15px/1 'Segoe UI Symbol',sans-serif; }
  :global(.transport-stop.zeppelin) { background:#442e20; color:#ffd08b; }
  :global(.transport-stop.zeppelin)::before { content:''; width:12px; height:6px; border-radius:50%; background:currentColor; }
  :global(.transport-stop.zeppelin)::after { content:''; position:absolute; width:5px; height:2px; top:11px; border-radius:0 0 2px 2px; background:currentColor; }
  :global(.world-pin .with-icon) { background:transparent; border-color:transparent; box-shadow:none; }
  :global(.world-pin .with-icon)::before, :global(.world-pin .with-icon)::after { display:none; }
  :global(.world-pin-image) { display:none; position:absolute; top:50%; left:50%; width:26px; height:26px; transform:translate(-50%,-50%); pointer-events:none; }
  :global(.service-point) { position:relative; display:grid; place-items:center; width:20px; height:20px; border-radius:50%; background:#192234dd; box-shadow:0 0 0 1px #d7b873, 0 2px 5px #000b; }
  :global(.service-point .world-pin-image) { width:22px; height:22px; }
  :global(.world-pin .navigation-pin) { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); width:30px; height:30px; border:2px solid #ffe0a1; border-radius:50%; background:#112944e8; box-shadow:0 0 0 3px #151b28aa, 0 2px 9px #000c; }
  :global(.quest-source-pin)::before { content:'!'; display:grid; place-items:center; height:100%; color:#ffe0a1; font:700 23px var(--font); }
  :global(.with-icon .world-pin-image) { display:block; }
  :global(.transport-stop .world-pin-image) { width:30px; height:30px; }
  :global(.flight-point.unverified .world-pin-image) { opacity:.65; }
  :global(.dungeon-levels) { display:none; position:absolute; top:17px; left:50%; transform:translateX(-50%); pointer-events:none; white-space:nowrap; color:#ffe1a0; font:700 12px var(--font); text-shadow:0 1px 2px #000,1px 0 2px #000,-1px 0 2px #000; }
  .dungeon-ranges :global(.dungeon-levels) { display:block; }
  :global(.world-pin-label) { box-sizing:border-box; width:max-content; max-width:min(340px, calc(100vw - 24px)); padding:5px 10px; white-space:normal; overflow-wrap:anywhere; background:#0a1c35f2; border:1px solid #d7b873; color:#e9dcbe; border-radius:4px; font:600 14px/1.25 var(--font); box-shadow:0 2px 7px #0008; }
  :global(.world-pin-label strong) { color:#fff4d7; font-weight:700; }
  :global(.world-pin-label.route-label) { white-space:pre; }
  :global(.world-pin-label.leaflet-tooltip-top::before), :global(.world-pin-label.leaflet-tooltip-bottom::before) { left:var(--pin-tip-arrow, 50%); }
  :global(.world-pin-label.leaflet-tooltip-top::before) { border-top-color:#d7b873; }
  :global(.world-pin-label.leaflet-tooltip-bottom::before) { border-bottom-color:#d7b873; }
  .controls { position:absolute; z-index:1000; left:18px; right:18px; bottom:18px; display:flex; flex-wrap:wrap; justify-content:flex-end; gap:6px; pointer-events:none; }
  .controls button { pointer-events:auto; }
  button { border:1px solid #caa45f; background:linear-gradient(#1c426e,#0b203eeF); color:#ffedc3; border-radius:3px; min-width:39px; height:39px; padding:0 12px; font:600 16px var(--font); cursor:pointer; box-shadow:0 2px 7px #0008,inset 0 1px #f7df9d33; }
  button:hover:enabled { background:linear-gradient(#315f96,#163860); }
  button:disabled { opacity:.5; cursor:default; }
  .notice { position:absolute; z-index:1000; bottom:66px; left:20px; right:20px; margin:0; padding:10px 14px; color:#fff2d5; background:#0a1b32ef; border:1px solid #cba66188; border-radius:3px; font:14px var(--font); }
  :global(.detail-tile), :global(.leaflet-atlas-detail-pane), :global(.leaflet-atlas-native-pane) { transition: opacity 180ms ease; }
  :global(.atlas-coast-tile) { mask-image: var(--atlas-coast, none); mask-repeat: no-repeat; mask-mode: alpha; }
  :global(.leaflet-atlas-native-pane .atlas-coast-tile) { mask-image: var(--atlas-detail-coast, var(--atlas-coast, none)); }
  :global(.player-wrap) { background:transparent; border:0; }
  :global(.guild-wrap){background:transparent;border:0}
  :global(.guild-pin){display:grid;place-items:center;width:24px;height:24px;border:2px solid #f7db9a;border-radius:50%;background:#0c2c52;color:var(--guild-colour);box-shadow:0 1px 7px #000b;font:700 16px sans-serif}
  :global(.guild-pin.approximate){border-style:dashed;color:#f9e4a9;font-size:12px;background:#112a49e8}
  :global(.guild-label.guild-label-colliding){visibility:hidden}
  :global(.guild-label){background:#0a1c35f2;border:1px solid #d7b873;color:#fff3d5;border-radius:3px;font:600 12px sans-serif;box-shadow:0 2px 5px #0008}
</style>
