<script lang="ts">
  import { onMount } from 'svelte'

  let { canShare, onSave, onClose }:
    { canShare: boolean; onSave: (name: string, note: string, shared: boolean) => Promise<void>; onClose: () => void } = $props()
  let dialog: HTMLDialogElement
  let name = $state('')
  let note = $state('')
  let shared = $state(false)
  let saving = $state(false)
  let error = $state('')
  onMount(() => { dialog.showModal() })

  async function save(event: SubmitEvent): Promise<void> {
    event.preventDefault()
    if (saving || !name.trim() && !note.trim()) return
    saving = true
    error = ''
    try { await onSave(name.trim(), note.trim(), shared && canShare); dialog.close() }
    catch (issue) { error = issue instanceof Error ? issue.message : 'Salvataggio del pin non riuscito.' }
    finally { saving = false }
  }
</script>

<dialog bind:this={dialog} aria-labelledby="pin-editor-title" onclose={onClose} oncancel={event => { if (saving) event.preventDefault() }}>
  <form onsubmit={save}>
    <h2 id="pin-editor-title">Nuovo pin sulla mappa</h2>
    <label for="pin-name">Nome</label>
    <input id="pin-name" type="text" bind:value={name} maxlength="80" />
    <label for="pin-note">Nota</label>
    <textarea id="pin-note" bind:value={note} maxlength="500" rows="3"></textarea>
    {#if canShare}<label class="share"><input type="checkbox" bind:checked={shared} /> Condividi con la gilda</label>{/if}
    <small>{shared && canShare ? 'Visibile nei browser collegati alla gilda.' : 'Nota personale salvata in questo browser.'}</small>
    {#if error}<p role="alert">{error}</p>{/if}
    <footer>
      <button type="button" disabled={saving} onclick={() => dialog.close()}>Annulla</button>
      <button type="submit" disabled={saving || !name.trim() && !note.trim()}>{shared && canShare ? 'Condividi pin' : 'Salva nota'}</button>
    </footer>
  </form>
</dialog>

<style>
  dialog {pointer-events:auto;box-sizing:border-box;width:min(420px,calc(100% - 24px));max-height:calc(100% - 24px);overflow:auto;padding:16px;border:1px solid #c19b5a;border-radius:6px;background:#0e213b;color:#fff0cd;font:16px var(--font)}
  dialog::backdrop {background:#040a16a6}
  form {display:grid;gap:8px}
  h2 {margin:0 0 4px;font-size:21px}
  input[type='text'], textarea {box-sizing:border-box;width:100%;min-height:42px;font:inherit;color:inherit;background:#08192d;border:1px solid #a68757;border-radius:4px;padding:7px}
  textarea {resize:vertical}
  .share {display:flex;align-items:center;gap:7px;min-height:44px}
  .share input {width:18px;height:18px;accent-color:#c19b5a}
  small {color:#e0d0b0}
  p {margin:0}
  footer {display:flex;justify-content:flex-end;gap:8px;margin-top:4px}
  button {min-height:44px;padding:7px 12px;background:#1a3859;color:inherit;border:1px solid #c19b5a;border-radius:4px;font:600 16px var(--font);cursor:pointer}
  button:disabled {opacity:.5;cursor:default}
</style>
