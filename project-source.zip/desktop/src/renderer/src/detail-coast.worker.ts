import { expandDetailCoast, type Harbour } from './detail-coast-mask'

self.onmessage = async (event: MessageEvent<{ source: ImageBitmap; harbours: Harbour[] }>) => {
  const { source, harbours } = event.data
  try {
    const canvas = new OffscreenCanvas(source.width, source.height)
    const context = canvas.getContext('2d', { willReadFrequently: true })
    if (!context) { self.postMessage(null); return }
    context.drawImage(source, 0, 0)
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height)
    expandDetailCoast(pixels.data, pixels.width, pixels.height, harbours)
    context.putImageData(pixels, 0, 0)
    self.postMessage(await canvas.convertToBlob({ type: 'image/png' }))
  } catch {
    self.postMessage(null)
  } finally {
    source.close()
  }
}
