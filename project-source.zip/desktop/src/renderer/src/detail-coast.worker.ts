import { expandDetailCoast, trimTerrainPadding, type CoastTile, type Harbour } from './detail-coast-mask'

self.onmessage = async (event: MessageEvent<{ source: ImageBitmap; harbours: Harbour[]; tiles: CoastTile[] }>) => {
  const { source, harbours, tiles } = event.data
  try {
    const { width, height } = source
    const canvas = new OffscreenCanvas(width, height)
    const context = canvas.getContext('2d', { willReadFrequently: true })
    if (!context) { self.postMessage(null); return }
    context.drawImage(source, 0, 0)
    const pixels = context.getImageData(0, 0, width, height)
    const detailPixels = new ImageData(new Uint8ClampedArray(pixels.data), width, height)
    context.clearRect(0, 0, width, height)
    context.imageSmoothingEnabled = false
    let index = 0
    // Decode only a few tiles at once and keep one mosaic so padding crossing a tile seam stays connected.
    const load = async (): Promise<void> => {
      while (index < tiles.length) {
        const tile = tiles[index++]!
        try {
          const response = await fetch(tile.url)
          if (!response.ok) continue
          const image = await createImageBitmap(await response.blob())
          const x = Math.round(tile.left * width), y = Math.round(tile.top * height)
          context.drawImage(image, x, y, Math.round(tile.right * width) - x, Math.round(tile.bottom * height) - y)
          image.close()
        } catch { /* Other tiles still contribute to the mask. */ }
      }
    }
    await Promise.all(Array.from({ length: 6 }, load))
    trimTerrainPadding(pixels.data, detailPixels.data, context.getImageData(0, 0, width, height).data, width, height)
    expandDetailCoast(pixels.data, width, height, [])
    context.putImageData(pixels, 0, 0)
    const coast = await canvas.convertToBlob({ type: 'image/png' })
    expandDetailCoast(detailPixels.data, width, height, harbours)
    context.putImageData(detailPixels, 0, 0)
    const detail = await canvas.convertToBlob({ type: 'image/png' })
    self.postMessage({ coast, detail })
  } catch {
    self.postMessage(null)
  } finally {
    source.close()
  }
}
