import L from 'leaflet'
import { boxOf, type Box, type Piece } from '../../shared/inside'
import { roomPicture } from './room-picture'

export interface WorldCave {
  id: number
  world: number
  pieces: Piece[]
}

type Project = (u: number, v: number) => L.LatLngTuple

export function caveBounds(box: Box, project: Project): L.LatLngBounds {
  return L.latLngBounds([project(box[0], box[1]), project(box[2], box[3])])
}

/** Composite the original room minimaps using the same world-yard geometry as the atlas. */
export async function renderCave(cave: WorldCave, project: Project): Promise<string | null> {
  const box = boxOf(cave.pieces)
  if (!box) return null
  return renderRooms(cave.pieces, project, box)
}

export async function renderRooms(pieces: Piece[], project: Project, box: Box,
  ground: { image: HTMLImageElement; u: number; v: number; size: number }[] = [],
  selectedFloor?: number, signal?: AbortSignal): Promise<string | null> {
  const bounds = caveBounds(box, project)
  const du = bounds.getEast() - bounds.getWest(), dv = bounds.getNorth() - bounds.getSouth()
  if (!(du > 0 && dv > 0)) return null
  const resolution = Math.min(2, 1536 / Math.max(box[2] - box[0], box[3] - box[1]))
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round((box[2] - box[0]) * resolution))
  canvas.height = Math.max(1, Math.round((box[3] - box[1]) * resolution))
  const context = canvas.getContext('2d')
  if (!context) return null
  const at = (u: number, v: number): [number, number] => {
    const [lat, lng] = project(u, v)
    return [(lng - bounds.getWest()) / du * canvas.width, (bounds.getNorth() - lat) / dv * canvas.height]
  }
  const [x0, y0] = at(0, 0), [xu, yu] = at(1, 0), [xv, yv] = at(0, 1)
  const transform = (u: number, v: number) => {
    const [x, y] = at(u, v)
    context.setTransform(xu - x0, yu - y0, xv - x0, yv - y0, x, y)
  }
  context.globalAlpha = .72
  for (const { image, u, v, size } of ground) {
    transform(u, v)
    context.drawImage(image, 0, 0, size, size)
  }
  let painted = ground.length > 0
  for (let offset = 0; offset < pieces.length; offset += 4) {
    if (signal?.aborted) return null
    const batch = pieces.slice(offset, offset + 4)
    const images = await Promise.all(batch.map(roomPicture))
    if (signal?.aborted) return null
    batch.forEach((piece, index) => {
      const image = images[index]
      if (!image) return
      painted = true
      context.globalAlpha = selectedFloor !== undefined && piece.level < selectedFloor ? .66 : 1
      transform(piece.u, piece.v)
      context.rotate(-piece.angle)
      context.drawImage(image, -piece.width / 2, -piece.height / 2, piece.width, piece.height)
    })
  }
  if (!painted) return null
  const png = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'))
  return png ? URL.createObjectURL(png) : null
}
