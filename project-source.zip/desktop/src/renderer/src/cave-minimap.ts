import L from 'leaflet'
import { boxOf, type Box, type Piece } from '../../shared/inside'
import { roomPicture } from './room-picture'

export interface WorldCave {
  id: number
  world: number
  pieces: Piece[]
}

type Project = (u: number, v: number) => L.LatLngTuple
type GroundTile = { image: HTMLImageElement; u: number; v: number; size: number }

export function caveBounds(box: Box, project: Project): L.LatLngBounds {
  return L.latLngBounds([project(box[0], box[1]), project(box[2], box[3])])
}

/** Composite the original room minimaps using the same world-yard geometry as the atlas. */
export async function renderCave(cave: WorldCave, project: Project): Promise<string | null> {
  const box = boxOf(cave.pieces)
  if (!box) return null
  return renderRooms(cave.pieces, project, box)
}

export async function renderRooms(pieces: Piece[], project: Project, box: Box,
  { ground = [], landmarks = [], openGround = false, selectedFloor, signal }: {
    ground?: GroundTile[]; landmarks?: readonly (readonly [number, number])[]; openGround?: boolean; selectedFloor?: number; signal?: AbortSignal
  } = {}): Promise<string | null> {
  const bounds = caveBounds(box, project)
  const du = bounds.getEast() - bounds.getWest(), dv = bounds.getNorth() - bounds.getSouth()
  if (!(du > 0 && dv > 0)) return null
  const resolution = Math.min(2, 1536 / Math.max(box[2] - box[0], box[3] - box[1]))
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round((box[2] - box[0]) * resolution))
  canvas.height = Math.max(1, Math.round((box[3] - box[1]) * resolution))
  const context = canvas.getContext('2d')
  if (!context) return null
  const at = (u: number, v: number): [number, number] => {
    const [lat, lng] = project(u, v)
    return [(lng - bounds.getWest()) / du * canvas.width, (bounds.getNorth() - lat) / dv * canvas.height]
  }
  const [x0, y0] = at(0, 0), [xu, yu] = at(1, 0), [xv, yv] = at(0, 1)
  const transform = (layer: CanvasRenderingContext2D, u: number, v: number) => {
    const [x, y] = at(u, v)
    layer.setTransform(xu - x0, yu - y0, xv - x0, yv - y0, x, y)
  }
  let painted = false
  for (let offset = 0; offset < pieces.length; offset += 4) {
    if (signal?.aborted) return null
    const batch = pieces.slice(offset, offset + 4)
    const images = await Promise.all(batch.map(roomPicture))
    if (signal?.aborted) return null
    batch.forEach((piece, index) => {
      const image = images[index]
      if (!image) return
      painted = true
      context.globalAlpha = selectedFloor !== undefined && piece.level < selectedFloor ? .66 : 1
      transform(context, piece.u, piece.v)
      context.rotate(-piece.angle)
      context.drawImage(image, -piece.width / 2, -piece.height / 2, piece.width, piece.height)
    })
  }
  if (ground.length && (painted || landmarks.length)) {
    // Ground tiles include terrain outside the dungeon. Fade their edges around the playable area.
    const mask = document.createElement('canvas')
    const terrain = document.createElement('canvas')
    mask.width = terrain.width = canvas.width
    mask.height = terrain.height = canvas.height
    const outline = mask.getContext('2d'), background = terrain.getContext('2d')
    if (outline && background) {
      for (const { image, u, v, size } of ground) {
        transform(background, u, v)
        background.drawImage(image, 0, 0, size, size)
      }
      if (openGround) {
        // Keep connected terrain between the rooms and bosses in mostly open-air instances.
        outline.setTransform(canvas.width * .47, 0, 0, canvas.height * .47, canvas.width / 2, canvas.height / 2)
        const fade = outline.createRadialGradient(0, 0, .60, 0, 0, 1)
        fade.addColorStop(0, '#fff')
        fade.addColorStop(1, '#fff0')
        outline.fillStyle = fade
        outline.fillRect(-1, -1, 2, 2)
        outline.resetTransform()
      }
      const margin = Math.round(12 * resolution)
      for (const x of [-margin, 0, margin]) {
        for (const y of [-margin, 0, margin]) outline.drawImage(canvas, x, y)
      }
      const radius = 36 * resolution
      for (const [u, v] of landmarks) {
        const [x, y] = at(u, v)
        const fade = outline.createRadialGradient(x, y, 0, x, y, radius)
        fade.addColorStop(0, '#fff')
        fade.addColorStop(1, '#fff0')
        outline.fillStyle = fade
        outline.fillRect(x - radius, y - radius, radius * 2, radius * 2)
      }
      background.resetTransform()
      background.globalCompositeOperation = 'destination-in'
      background.filter = `blur(${8 * resolution}px)`
      background.drawImage(mask, 0, 0)
      context.resetTransform()
      context.globalCompositeOperation = 'destination-over'
      context.globalAlpha = openGround ? .92 : .68
      context.drawImage(terrain, 0, 0)
      painted = true
    }
  }
  if (!painted) return null
  const png = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'))
  return png ? URL.createObjectURL(png) : null
}
