import { createGame } from '../../shared/game'
import { readStrip } from '../../shared/strip'

/** Read the addon strip from a user-selected game window, entirely in the browser. */
export async function shareGameWindow(key: string, onStatus: (message: string) => void): Promise<() => void> {
  const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: 60 } }, audio: false })
  const track = stream.getVideoTracks()[0]!
  const video = document.createElement('video')
  video.muted = true
  video.srcObject = stream
  try { await video.play() } catch (error) { track.stop(); throw error }
  const canvas = document.createElement('canvas')
  canvas.height = 1
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!
  const game = createGame()
  let active = true, timer = 0, rowHint: number | undefined, widthHint: number | undefined
  let nextUpload = 0, pending = false, lastPosition = 0
  const stop = (): void => {
    active = false
    window.clearTimeout(timer)
    track.stop()
    video.srcObject = null
    onStatus('Condivisione terminata')
  }
  track.addEventListener('ended', stop, { once: true })
  onStatus('Cerco il segnale dell’addon nella finestra condivisa…')
  function sample(): void {
    const width = video.videoWidth, height = video.videoHeight
    if (!active) return
    if (width && height) {
      if (canvas.width !== width) { canvas.width = width; rowHint = undefined; widthHint = undefined }
      const now = Date.now()
      const rows = rowHint === undefined ? [0, height - 1, 1, height - 2, 2, height - 3] : [rowHint]
      let hit = false
      for (const row of rows) {
        if (row < 0 || row >= height) continue
        ctx.drawImage(video, 0, row, width, 1, 0, 0, width, 1)
        const rgba = ctx.getImageData(0, 0, width, 1).data
        for (let i = 0; i < rgba.length; i += 4) {
          const red = rgba[i]!
          rgba[i] = rgba[i + 2]!
          rgba[i + 2] = red
        }
        const decoded = readStrip(new Uint8Array(rgba.buffer), widthHint)
        if (decoded.reading.kind !== 'block') continue
        rowHint = row
        widthHint = decoded.drew
        game.feed(decoded.reading, now)
        hit = true
        break
      }
      if ((!hit && now - (game.state.updatedAt.pos ?? 0) > 5000)) rowHint = undefined
      const at = game.state.updatedAt.pos ?? 0
      if (!pending && at > lastPosition && now >= nextUpload && now - at < 10000) {
        lastPosition = at
        nextUpload = now + 1500
        pending = true
        const { pos, guild, geometry } = game.state.sections
        void fetch('/publish', {
          method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ pos, guild, geometry, guildAge: now - (game.state.updatedAt.guild ?? 0) }),
          signal: AbortSignal.timeout(5000),
        }).then(result => {
          if (active) onStatus(result.ok ? 'Posizioni condivise con il server' : `Invio rifiutato dal server (${result.status})`)
          if (result.status === 401 || result.status === 403) {
            stop()
            onStatus('La chiave di pubblicazione non è valida')
          }
        }).catch(() => { if (active) onStatus('Server non raggiungibile') }).finally(() => { pending = false })
      }
    }
    timer = window.setTimeout(sample, 25)
  }
  sample()
  return stop
}
