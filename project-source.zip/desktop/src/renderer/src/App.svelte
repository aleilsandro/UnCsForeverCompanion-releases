<script lang="ts">
  import { onMount } from 'svelte'
  import { linkStatus, type LinkSnapshot } from '../../shared/link'
  import type { TilesStatus } from '../../shared/tiles-status'
  import type { SetupStatus } from '../../shared/setup'
  import type { MapCacheStatus } from '../../shared/map-cache'
  import OpenAtlas from './OpenAtlas.svelte'
  import DungeonMap from './DungeonMap.svelte'
  import type { CursorStyle } from './player-icon'
  import { guildFrom } from '../../shared/guild'
  import crest from './alliance-crest.svg'
  import type { CursorCoordinates } from '../../shared/cursor-coordinates'
  import { inApp } from './web'
  import { shareGameWindow } from './browser-capture'

  const brandName = inApp ? 'UnCs Forever Companion' : 'UnCs Foreve WebCompanion'

  let link = $state<LinkSnapshot | null>(null)
  let tiles = $state<TilesStatus | null>(null)
  let setup = $state<SetupStatus | null>(null)
  let now = $state(Date.now())
  let error = $state('')
  let cache = $state<MapCacheStatus | null>(null)
  let guildOpen=$state(false)
  let pointer=$state<CursorCoordinates | null>(null)
  let publishKey = $state('')
  let sharing = $state(false)
  let publishMessage = $state('')
  let stopSharing: (() => void) | undefined
  async function share(): Promise<void> {
    if (sharing) { stopSharing?.(); return }
    sharing = true
    try {
      stopSharing = await shareGameWindow(publishKey, message => {
        publishMessage = message
        if (message === 'Condivisione terminata') sharing = false
      })
      publishKey = ''
    } catch {
      publishMessage = 'Condivisione della finestra di WoW non avviata.'
      sharing = false
    }
  }
  const previousCursor=localStorage.getItem('uncs-player-cursor')
  let cursor=$state<CursorStyle>(previousCursor==='b' || previousCursor==='c' ? previousCursor : 'a')
  $effect(()=>{localStorage.setItem('uncs-player-cursor',cursor)})
  window.twinmap.onMapCache((value) => { cache = value })
  window.twinmap.onLink((snapshot) => { link = snapshot; now = Date.now() })
  window.twinmap.onTiles((value) => { tiles = value })
  window.twinmap.onSetup((value) => { setup = value })
  onMount(() => { window.twinmap.drawn() })
  const status = $derived(link ? linkStatus(link, now) : null)
  const live = $derived(status?.kind === 'connected' || status?.kind === 'combat')
  const freshPosition = $derived(live && now - (link?.state.updatedAt.pos ?? 0) < 25000)
  const pos = $derived(freshPosition ? link?.state.sections.pos : undefined)
  const guild=$derived(live ? guildFrom(link?.state.sections.guild,now-(link?.state.updatedAt.guild ?? 0)) : [])
  const exactCount=$derived(guild.filter(m=>m.exact).length)
  const guildSharing=$derived((link?.state.sections.guild as {share?:boolean}|undefined)?.share)
  const ready = $derived(!!setup?.gameFolder)
  async function choose(): Promise<void> { error = (await window.twinmap.chooseGameFolder()) ?? '' }
</script>

<svelte:head>
  <title>{brandName}</title>
</svelte:head>

<div class="shell">
  <header class="header" class:web-header={!inApp}>
    <div class="brand" aria-label={brandName}>
      <img class="brand-crest" src={crest} alt="" />
      <span>
        {#if inApp}
          <b>UnCs <em>Forever</em></b>
          <small>COMPANION · ALLIANCE</small>
        {:else}
          <b>UnCs <em>Foreve</em> <span class="web-brand-name">WebCompanion</span></b>
        {/if}
        <small class="version">Versione {setup?.version ?? '…'}</small>
      </span>
    </div>
  </header>
  <main>
    <div class="map-frame">
      {#if ready}
        {#if pos?.inst && (pos.inst.kind==='party' || pos.inst.kind==='raid')}
          {#key pos.inst.id}<DungeonMap {pos} {cursor} />{/key}
        {:else}
          {#key setup?.mapRevision}
            <OpenAtlas {pos} {cursor} {guild} showPlayer={!setup?.webBridge} mapRevision={setup?.mapRevision} at={link?.state.updatedAt.pos} geometry={link?.state.sections.geometry} onCursor={(value) => pointer = value} />
          {/key}
        {/if}
        {#if pos && !setup?.webBridge}
          <div class="location"><span>LA TUA POSIZIONE</span><strong>{pos.zone ?? 'Zona sconosciuta'}</strong><small>{pos.sub ?? ''}{pos.x !== undefined && pos.y !== undefined ? ` · ${pos.x.toFixed(1)}, ${pos.y.toFixed(1)}` : ''}</small><small class="pointer-coordinates">Cursore: {#if pos.inst && (pos.inst.kind === 'party' || pos.inst.kind === 'raid')}non disponibile nel dungeon{:else if pointer}{pointer.zone} · {pointer.x.toFixed(1)}, {pointer.y.toFixed(1)}{:else}—{/if}</small>{#if typeof pos.facing !== 'number'}<small>Direzione non disponibile</small>{/if}</div>
        {/if}
        <div class="guild-panel">
          <button class="guild-toggle" aria-expanded={guildOpen} onclick={()=>guildOpen=!guildOpen}><span class="guild-symbol" aria-hidden="true">✦</span><span>{setup?.webBridge ? 'Gildani sulla mappa' : 'Gilda online'} <b>{guild.length}</b><small>{exactCount} posizioni condivise</small></span><span class="guild-chevron" aria-hidden="true">{guildOpen ? '−' : '+'}</span></button>
          {#if guildOpen}
            <div class="guild-list">
              {#if setup?.webBridge}
                <p>Qui compaiono i gildani con il ponte attivo che condividono la posizione.</p>
              {:else}
                <p>◆ Posizione condivisa · cerchio tratteggiato: solo zona indicativa</p>
                <p>Addon UnCs: posizione {guildSharing===true ? 'condivisa con la gilda' : guildSharing===false ? 'non condivisa' : 'in attesa'}. Usa /uncs guild per cambiare.</p>
              {/if}
              {#each guild as member (member.name)}
                <div><strong>{member.name}</strong><span>{member.level ? `Liv. ${member.level} · ` : ''}{member.zone || 'Zona non disponibile'}{member.exact ? ' · posizione condivisa' : member.x!==undefined ? ' · zona indicativa' : ''}</span></div>
              {:else}<p>{setup?.webBridge ? 'Nessuna posizione live ricevuta.' : 'Nessun membro online rilevato. Verifica di essere in gilda e usa /reload.'}</p>{/each}
            </div>
          {/if}
        </div>
      {:else}
        <div class="welcome">
          <img class="welcome-crest" src={crest} alt="" />
          <p class="eyebrow">{inApp ? 'UNCS FOREVER · PER L’ALLEANZA' : brandName}</p>
          <h1>Il mondo ti aspetta.</h1>
          <p class="description">La tua mappa prende forma dai file del gioco. La tua posizione apparirà qui, mentre esplori.</p>
          <div class="loading" role="status">{tiles?.state === 'no-game' ? 'Cartella di WoW non trovata.' : tiles?.state === 'converting' ? `Preparazione della mappa: ${tiles.percent}%` : tiles?.state === 'failed' ? 'Impossibile preparare la mappa.' : 'Preparazione della mappa...'}</div>
          {#if tiles?.state === 'converting'}<progress max="100" value={tiles.percent} aria-label="Preparazione mappa"></progress>{/if}
          {#if tiles?.state === 'no-game'}<p class="hint">Seleziona la cartella che contiene _forever_.</p>{:else if tiles?.state === 'converting'}<p class="hint">La prima preparazione può richiedere qualche minuto.</p>{:else if tiles?.state === 'failed'}<p class="hint">{tiles.message}</p>{/if}
          {#if inApp && (!setup?.gameFolder || tiles?.state === 'no-game')}<button class="action" onclick={choose}>Seleziona la cartella di WoW</button>{/if}
          {#if tiles?.state === 'failed'}<button class="action" onclick={() => window.twinmap.retryTiles()}>Riprova</button>{/if}
          {#if error}<p class="hint">{error}</p>{/if}
        </div>
      {/if}
    </div>
  </main>
  <footer>
    {#if !inApp && setup?.webPublishing}
      <details class="publisher">
        <summary>Sorgente WoW</summary>
        <div>
          {#if !sharing}<input type="password" bind:value={publishKey} aria-label="Chiave di pubblicazione" placeholder="Chiave di pubblicazione" />{/if}
          <button disabled={!sharing && !publishKey} onclick={share}>{sharing ? 'Interrompi' : 'Condividi finestra di WoW'}</button>
          <small role="status">{publishMessage}</small>
        </div>
      </details>
    {/if}
    <span>{ready ? 'Rotella per zoom · Trascina per esplorare' : 'Una finestra sul tuo mondo'}</span>
    <label class="cursor-choice">Cursore <select bind:value={cursor} aria-label="Stile del cursore"><option value="a">A · Bussola dorata</option><option value="b">B · Freccia runica</option><option value="c">C · Scudo e punta</option></select></label>
    {#if cache?.available}
      <span class="cache" role="status">
        {#if cache.processed >= cache.total && !cache.running}
          {cache.failed ? `Preparazione: ${cache.failed} immagini non riuscite` : 'Mappa precaricata'}
          {#if cache.failed}<button onclick={() => window.twinmap.toggleMapCache()}>Riprova</button>{/if}
        {:else}
          {cache.running ? 'Precaricamento' : 'Precaricamento in pausa'} {cache.processed}/{cache.total}
          <button onclick={() => window.twinmap.toggleMapCache()}>{cache.running ? 'Pausa' : 'Riprendi'}</button>
        {/if}
      </span>
    {/if}
  </footer>
</div>

<style>
  .shell { height:100%; display:grid; grid-template-rows:76px minmax(0,1fr) 38px; background:#091831 url('./alliance-landscape.svg') center/cover no-repeat; color:#f3e6c6; font-family:var(--font); }
  .header { display:flex; align-items:center; gap:27px; padding:0 150px 0 24px; background:linear-gradient(105deg,#071428f5,#102b51f5 55%,#09192ff5); border-bottom:1px solid #c49a4a99; box-shadow:inset 0 -3px #08162a,0 4px 16px #0008; -webkit-app-region:drag; }
  .brand { display:flex; align-items:center; gap:11px; flex:none; }
  .brand-crest { width:47px; height:55px; object-fit:contain; filter:drop-shadow(0 2px 3px #0009); }
  .brand b { display:block; font:400 22px/24px var(--display); letter-spacing:.025em; color:#fff0c8; white-space:nowrap; }
  .brand em { font-style:normal; color:#d8b369; }
  .brand small { display:block; font:600 9px/14px var(--font); letter-spacing:.18em; color:#aabbd1; }
  .brand small.version { letter-spacing:.04em; color:#c5d4df; font-size:10px; }
  main { min-height:0; padding:12px 16px 5px; }
  .map-frame { height:100%; position:relative; overflow:hidden; border:2px solid #ad8649; border-radius:5px; background:#0b1931; box-shadow:0 0 0 1px #2a1b10,0 0 0 4px #112b49,0 8px 24px #0009,inset 0 0 0 1px #f6daa655; }
  .location { position:absolute; z-index:1200; top:18px; left:18px; display:grid; gap:3px; pointer-events:none; padding:12px 18px 12px 16px; border-radius:3px; background:linear-gradient(115deg,#0a1a33f2,#102d50eb); border:1px solid #d4b36b99; border-left:3px solid #e7c472; box-shadow:0 4px 16px #0009,inset 0 0 0 1px #6284a126; }
  .location span,.eyebrow { color:#dfc18a; font-size:10px; font-weight:600; letter-spacing:.17em; }.location strong { color:#fff0cd; font:400 21px var(--display); }.location small { color:#c6d5e0; }
  .location small.pointer-coordinates { color:#e8d29c; padding-top:3px; }
  .publisher { position:relative; z-index:1300; }
  .publisher summary { cursor:pointer; white-space:nowrap; }
  .publisher div { position:absolute; bottom:24px; left:0; width:230px; display:grid; gap:8px; padding:10px; background:#091831; border:1px solid #ad8649; }
  .welcome { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:25px; background:linear-gradient(#08172b55,#07152cc9),url('./alliance-landscape.svg') center/cover; }
  .welcome-crest {width:100px;height:115px;filter:drop-shadow(0 4px 12px #0009)}.eyebrow { margin:17px 0 8px; }h1 { font:400 clamp(30px,4vw,50px) var(--display); margin:0; color:#fff0ca;text-shadow:0 2px 8px #000; }.description { max-width:410px; color:#cfdae3; margin:12px 0 20px; }.loading { font-size:14px; color:#efd3a1; }.hint { max-width:480px; color:#cad7e0; }progress { width:220px; margin:12px; accent-color:#d3ae69; }
  .action { margin-top:16px; padding:10px 15px; border-radius:3px; background:linear-gradient(#28578d,#102a50); color:#fff0c9; border:1px solid #d4b46d; cursor:pointer; font:600 14px var(--font); }.action:hover { background:linear-gradient(#3770aa,#173d6c); }
  footer { display:flex; justify-content:space-between; gap:14px; align-items:center; padding:0 22px; background:#08182df2; border-top:1px solid #c29d5944; color:#b4c6d6; font-size:11px; letter-spacing:.04em; }
  .cache { display:flex; gap:8px; align-items:center; white-space:nowrap; } .cache button { background:#132f52; border:1px solid #b49358; border-radius:3px; color:#f4dfb2; padding:3px 8px; font:inherit; cursor:pointer; }
  .cursor-choice {display:flex;align-items:center;gap:6px;white-space:nowrap}.cursor-choice select{background:#112a49;color:#f4e8cc;border:1px solid #b49358aa;border-radius:3px;font:inherit;padding:4px}
  .guild-panel{position:absolute;right:18px;top:18px;z-index:1200;width:min(286px,calc(100% - 36px));color:#f3e8cb}.guild-toggle{display:flex;align-items:center;gap:11px;width:100%;text-align:left;background:linear-gradient(110deg,#0b1b32f5,#15355af2);border:1px solid #d1ad6899;border-radius:3px;padding:10px 12px;color:inherit;font:600 14px var(--font);cursor:pointer;box-shadow:0 4px 14px #0008}.guild-toggle:hover{background:linear-gradient(110deg,#132c4df5,#1a436cf2)}.guild-toggle span:nth-child(2){flex:1}.guild-toggle b{color:#f7d98d}.guild-symbol{font-size:20px;color:#eac67b}.guild-chevron{color:#e6c884;font-size:20px}.guild-toggle small{display:block;color:#aec4d7;font-size:11px;font-weight:400}.guild-list{max-height:45vh;overflow:auto;background:#0a1b32f7;border:1px solid #caa56088;border-radius:3px;margin-top:4px;padding:8px 12px;font:13px var(--font);box-shadow:0 5px 15px #0008}.guild-list p{color:#b7cbda;font-size:12px}.guild-list div{display:grid;gap:2px;padding:7px 0;border-top:1px solid #c5aa7938}.guild-list strong{color:#f3dfb7}.guild-list span{color:#b7cbda;font-size:12px}
  @media(max-width:840px){.header{padding-left:14px}main{padding:8px}.location{left:12px;top:12px}footer>span:first-child{display:none}}
  @media(max-width:580px){.shell{grid-template-rows:70px minmax(0,1fr) 38px}.brand b{font-size:18px}.brand-crest{width:38px;height:47px}.guild-panel{right:10px;top:10px;width:200px}.location{max-width:42%;padding:8px 10px}.location strong{font-size:16px}.cache{font-size:10px}footer{padding:0 10px;gap:6px}}
  @media(max-width:420px){.web-header{padding-right:14px}.web-header .brand b{line-height:19px}.web-brand-name{display:block;font-size:16px}}
</style>
