<script lang="ts">
  import { onMount } from 'svelte'
  import { linkStatus, LOST_AFTER, type LinkSnapshot } from '../../shared/link'
  import type { TilesStatus } from '../../shared/tiles-status'
  import type { SetupStatus } from '../../shared/setup'
  import type { MapCacheStatus } from '../../shared/map-cache'
  import OpenAtlas from './OpenAtlas.svelte'
  import DungeonMap from './DungeonMap.svelte'
  import DungeonJournal from './DungeonJournal.svelte'
  import type { CursorStyle } from './player-icon'
  import { guildFrom, type GuildMember } from '../../shared/guild'
  import crest from './alliance-crest.svg'
  import discordIcon from './assets/uncs-discord-icon.png'
  import type { CursorCoordinates } from '../../shared/cursor-coordinates'
  import { inApp, OPENMAP, TILES } from './web'
  import { shareGameWindow } from './browser-capture'
  import { flightStatusFrom } from '../../shared/flight-points'
  import { professionFilters, standardServiceLayers, type MapServiceFilter } from '../../shared/map-services'
  import { questWorldPoint, worldPointFrom, type WorldPoint } from '../../shared/map-navigation'
  import type { GameMap } from '../../shared/maps'
  import { groupFrom } from '../../shared/group'
  import { gatheringFilter, gatheringProfessions, type GatheringProfession } from '../../shared/gathering'
  import { dungeonGuides, type QuestPlace } from '../../shared/dungeon-journal'
  import { yardsInside } from '../../shared/inside'

  const brandName = inApp ? 'UnCs Forever Companion' : 'UnCs Forever WebCompanion'
  const brandIcon = inApp ? crest : discordIcon

  let link = $state<LinkSnapshot | null>(null)
  let tiles = $state<TilesStatus | null>(null)
  let setup = $state<SetupStatus | null>(null)
  let now = $state(Date.now())
  let error = $state('')
  let cache = $state<MapCacheStatus | null>(null)
  let guildOpen=$state(false)
  let guildSort = $state<'name' | 'level'>('name')
  const guildNames = new Intl.Collator('it', { sensitivity: 'base' })
  let followedGuildName = $state<string>()
  let guildTarget = $state.raw<{ member: GuildMember }>()
  let questTarget = $state.raw<{ point: WorldPoint; name: string; zone: string }>()
  let liveZoneMaps = $state.raw<GameMap[]>()
  let searchOpen = $state(false)
  let browseAtlas = $state(false)
  let layerMenu: HTMLDialogElement
  let dungeonDirectoryOpen = $state(false)
  let showFlights = $state(true)
  let showDungeons = $state(true)
  let showBoats = $state(true)
  let showZeppelins = $state(true)
  let showCaves = $state(true)
  const gatheringFilterKey = 'uncs-map-gathering'
  function savedGathering(): GatheringProfession[] {
    try { return gatheringFilter(JSON.parse(localStorage.getItem(gatheringFilterKey) ?? '[]')) }
    catch { return [] }
  }
  let gathering = $state<GatheringProfession[]>(savedGathering())
  $effect(() => {
    try { localStorage.setItem(gatheringFilterKey, JSON.stringify(gathering)) }
    catch { /* The filter is still available for this session. */ }
  })
  const serviceFilterKey = 'uncs-map-service-layers'
  function savedServices(): MapServiceFilter[] {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem(serviceFilterKey) ?? '[]')
      if (!Array.isArray(saved)) return []
      return [
        ...standardServiceLayers.filter(({ id }) => saved.includes(id)).map(({ id }) => id),
        ...professionFilters.filter(({ id }) => saved.includes('profession') || saved.includes(id)).map(({ id }) => id),
      ]
    } catch { return [] }
  }
  let serviceLayers = $state<MapServiceFilter[]>(savedServices())
  $effect(() => {
    try { localStorage.setItem(serviceFilterKey, JSON.stringify(serviceLayers)) }
    catch { /* The selection still works for this session. */ }
  })
  let pointer=$state<CursorCoordinates | null>(null)
  let publishKey = $state('')
  let sharing = $state(false)
  let publishMessage = $state('')
  let stopSharing: (() => void) | undefined
  async function share(): Promise<void> {
    if (sharing) { stopSharing?.(); return }
    sharing = true
    try {
      stopSharing = await shareGameWindow(publishKey, message => {
        publishMessage = message
        if (message === 'Condivisione terminata') sharing = false
      })
      publishKey = ''
    } catch {
      publishMessage = 'Condivisione della finestra di WoW non avviata.'
      sharing = false
    }
  }
  const previousCursor=localStorage.getItem('uncs-player-cursor')
  let cursor=$state<CursorStyle>(previousCursor==='b' || previousCursor==='c' ? previousCursor : 'a')
  $effect(()=>{localStorage.setItem('uncs-player-cursor',cursor)})
  window.twinmap.onMapCache((value) => { cache = value })
  window.twinmap.onLink((snapshot) => { link = snapshot; now = Date.now() })
  window.twinmap.onTiles((value) => { tiles = value })
  window.twinmap.onSetup((value) => { setup = value })
  onMount(() => { window.twinmap.drawn() })
  const status = $derived(link ? linkStatus(link, now) : null)
  const live = $derived(status?.kind === 'connected' || status?.kind === 'combat')
  const freshPosition = $derived(live && now - (link?.state.updatedAt.pos ?? 0) < 25000)
  const pos = $derived(freshPosition ? link?.state.sections.pos : undefined)
  const dungeonPlayers = $derived(live ? groupFrom(link?.state.sections.group, now - (link?.state.updatedAt.group ?? 0)) : [])
  const liveGuides = $derived(dungeonGuides.filter(guide => guide.map === pos?.inst?.id))
  const liveGuide = $derived.by(() => {
    const point = pos?.inst && yardsInside(pos.inst)
    return (point && liveGuides.find(({ part }) => part && point.u >= part[0] && point.u <= part[2] && point.v >= part[1] && point.v <= part[3])) || liveGuides[0]
  })
  let liveBoss = $state.raw<{ name: string }>()
  let livePanelClosed = $state(false)
  const inDungeon = $derived(pos?.inst && (pos.inst.kind === 'party' || pos.inst.kind === 'raid') ? pos.inst : undefined)
  const instanceId = $derived(inDungeon?.id)
  $effect(() => { void instanceId; livePanelClosed = false; liveBoss = undefined; guildTarget = undefined; questTarget = undefined; browseAtlas = false; searchOpen = false })
  $effect(() => {
    if (instanceId === undefined || liveZoneMaps !== undefined) return
    const request = new AbortController()
    void fetch(`${OPENMAP}/maps.json`, { signal: request.signal }).then(response => response.json()).then(value => {
      if (!request.signal.aborted && Array.isArray(value)) liveZoneMaps = value
    }).catch(() => {})
    return () => request.abort()
  })
  function locateLiveQuestNpc(name: string, place: QuestPlace): (() => void) | undefined {
    const point = liveZoneMaps && questWorldPoint(place, liveZoneMaps)
    if (!point) return
    return () => {
      guildTarget = undefined
      questTarget = { point, name, zone: place.zone }
      dungeonDirectoryOpen = false
      browseAtlas = true
    }
  }
  const ownPosition = $derived(setup?.webBridge
    ? live && now - (link?.state.updatedAt.ownPosition ?? 0) < LOST_AFTER ? worldPointFrom(link?.state.sections.ownPosition) : undefined
    : worldPointFrom(pos))
  const guild=$derived(live ? guildFrom(link?.state.sections.guild,now-(link?.state.updatedAt.guild ?? 0)) : [])
  const ownGuildName = $derived(setup?.webBridge ? link?.state.sections.ownCharacter : link?.state.sections.char?.name)
  const sortedGuild = $derived.by(() => {
    const ownName = typeof ownGuildName === 'string' ? ownGuildName : ''
    const isOwn = (name: string) => ownName !== '' && guildNames.compare(name, ownName) === 0
    return [...guild].sort((a, b) =>
      Number(isOwn(b.name)) - Number(isOwn(a.name)) ||
      (guildSort === 'level' ? (b.level ?? 0) - (a.level ?? 0) : 0) ||
      guildNames.compare(a.name, b.name))
  })
  const flightData = $derived(JSON.stringify(link?.state.sections.flights ?? null))
  const flights = $derived(flightStatusFrom(JSON.parse(flightData)))
  const ready = $derived(!!setup?.gameFolder)
  async function choose(): Promise<void> { error = (await window.twinmap.chooseGameFolder()) ?? '' }
</script>

<svelte:head>
  <title>{brandName}</title>
  {#if !inApp}<link rel="icon" type="image/png" href={discordIcon} />{/if}
</svelte:head>

<div class="shell">
  <header class="header" class:web-header={!inApp}>
    <div class="brand" aria-label={brandName}>
      <img class="brand-crest" class:discord-emblem={!inApp} src={brandIcon} alt="" />
      <span>
        {#if inApp}
          <b>UnCs <em>Forever</em></b>
          <small>COMPANION · ALLIANCE</small>
        {:else}
          <b>UnCs <em>Forever</em> <span class="web-brand-name">WebCompanion</span></b>
        {/if}
        <small class="version">Versione {setup?.version ?? '…'}</small>
      </span>
    </div>
    {#if ready}
      <div class="map-menu">
        <button class="layers-toggle" aria-expanded={dungeonDirectoryOpen} onclick={() => { showDungeons = true; dungeonDirectoryOpen = !dungeonDirectoryOpen }}>Dungeon</button>
        <button class="layers-toggle" aria-haspopup="dialog" onclick={() => layerMenu.showModal()}>Livelli mappa</button>
        <button class="layers-toggle" aria-haspopup="dialog" onclick={() => { guildOpen = false; if (inDungeon) browseAtlas = true; searchOpen = true }}>Cerca</button>
        <div class="guild-panel">
          <button class="layers-toggle" type="button" aria-expanded={guildOpen} aria-controls="guild-list" onclick={() => guildOpen = !guildOpen}>Gildani sulla mappa <b>{guild.length}</b></button>
          {#if guildOpen}
            <div class="guild-list" id="guild-list">
              <div class="guild-sort" role="group" aria-label="Ordina gildani">
                <button type="button" aria-pressed={guildSort === 'name'} onclick={() => guildSort = 'name'}>Nome</button>
                <button type="button" aria-pressed={guildSort === 'level'} onclick={() => guildSort = 'level'}>Livello</button>
              </div>
              {#each sortedGuild as member (member.name)}
                  {@const active = followedGuildName === member.name}
                  {@const available = member.x !== undefined && member.y !== undefined}
                  {@const tip = active ? `Smetti di seguire ${member.name}` : available ? `Centra e segui ${member.name}` : 'Posizione non disponibile'}
                <div>
                  <div class="guild-member-heading">
                    <button class="guild-follow" class:active type="button" aria-label={tip} title={tip} aria-pressed={active}
                      disabled={!active && !available} onclick={() => {
                        followedGuildName = active ? undefined : member.name
                        guildTarget = undefined
                        if (!active && inDungeon) browseAtlas = true
                      }}>
                      <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                        <circle cx="12" cy="12" r="7" />
                        <path d="M12 2v6m0 8v6M2 12h6m8 0h6" />
                        <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
                      </svg>
                    </button>
                    {#if available}
                      <button class="locate-member" aria-label="Trova {member.name} sulla mappa" onclick={() => { followedGuildName = undefined; guildTarget = { member }; guildOpen = false; if (inDungeon) browseAtlas = true }}>{member.name}</button>
                    {:else}<strong>{member.name}</strong>{/if}
                    <span class="guild-level" title="Livello">{member.level ?? '—'}</span>
                    <span class="guild-zone" title={member.zone || 'Zona non disponibile'}>{member.zone || '—'}</span>
                  </div>
                </div>
              {:else}<p>Nessuna posizione live ricevuta.</p>{/each}
            </div>
          {/if}
        </div>
      </div>
    {/if}
  </header>
  <dialog class="layers-dialog" aria-labelledby="layers-title" bind:this={layerMenu}>
    <div class="layers-heading">
      <h2 id="layers-title">Livelli mappa</h2>
      <form method="dialog"><button class="layer-close" aria-label="Chiudi livelli mappa">×</button></form>
    </div>
    <div class="layer-grid">
      <label><input type="checkbox" bind:checked={showFlights} /><img src="{TILES}/icons/flight-known.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />Punti volo</label>
      <label><input type="checkbox" bind:checked={showDungeons} /><img src="{TILES}/icons/dungeon.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />Dungeon</label>
      <label><input type="checkbox" bind:checked={showBoats} /><img src="{TILES}/icons/boat.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />Navi</label>
      <label><input type="checkbox" bind:checked={showZeppelins} /><img src="{TILES}/icons/zeppelin.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />Zeppelin</label>
      <label><input type="checkbox" bind:checked={showCaves} />Caverne e miniere</label>
    </div>
    <h3 id="gathering-layers-title">Abilità di raccolta</h3>
    <p id="gathering-layers-help">Passa su una zona o toccala per vedere i requisiti selezionati.</p>
    <div class="layer-grid" role="group" aria-labelledby="gathering-layers-title" aria-describedby="gathering-layers-help">
      {#each gatheringProfessions as { id, label } (id)}
        <label><input type="checkbox" value={id} bind:group={gathering} />{label}</label>
      {/each}
    </div>
    <h3 id="service-layers-title">Servizi</h3>
    <p id="service-zoom-help">Avvicina la mappa per vedere i servizi selezionati.</p>
    <div class="layer-grid" role="group" aria-labelledby="service-layers-title" aria-describedby="service-zoom-help">
      {#each standardServiceLayers as { id, label } (id)}
        <label><input type="checkbox" value={id} bind:group={serviceLayers} /><img src="{TILES}/icons/{id}.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />{label}</label>
      {/each}
    </div>
    <details class="profession-layers">
      <summary><img src="{TILES}/icons/profession.png" alt="" onerror={(event) => event.currentTarget.setAttribute('hidden', '')} />Istruttori di professione</summary>
      <div class="layer-grid" role="group" aria-label="Professioni">
        {#each professionFilters as { id, label } (id)}
          <label><input type="checkbox" value={id} bind:group={serviceLayers} />{label}</label>
        {/each}
      </div>
    </details>
  </dialog>
  <main>
    <div class="map-frame">
      {#if ready}
        {#if inDungeon && !browseAtlas}
          {#key liveGuide?.name ?? inDungeon.id}
            <DungeonMap {pos} {cursor} guide={liveGuide} players={dungeonPlayers} onBoss={name => { dungeonDirectoryOpen = false; livePanelClosed = false; liveBoss = { name } }} />
            {#if dungeonDirectoryOpen}
              <DungeonJournal initialNames={[]} locateQuestNpc={locateLiveQuestNpc} onClose={() => dungeonDirectoryOpen = false} />
            {:else if liveGuide && !livePanelClosed}
              <DungeonJournal initialNames={[liveGuide.name]} overlay selectedBoss={liveBoss} locateQuestNpc={locateLiveQuestNpc} onClose={() => livePanelClosed = true} />
            {/if}
          {/key}
        {:else}
          {#key setup?.mapRevision}
            <OpenAtlas {pos} {ownPosition} {cursor} {guild} {guildTarget} {followedGuildName} {questTarget} {flights} {showFlights} {showDungeons} {showBoats} {showZeppelins} {showCaves} {serviceLayers} {gathering} showPlayer={!setup?.webBridge} showGuildDirection={setup?.webBridge} mapRevision={setup?.mapRevision} at={link?.state.updatedAt.pos} geometry={link?.state.sections.geometry} onCursor={(value) => pointer = value} bind:directoryOpen={dungeonDirectoryOpen} bind:searchOpen />
          {/key}
          {#if inDungeon}<button class="return-dungeon" onclick={() => { browseAtlas = false; guildTarget = undefined; followedGuildName = undefined; questTarget = undefined; searchOpen = false }}>Torna al dungeon</button>{/if}
        {/if}
        {#if pos && !setup?.webBridge}
          <div class="location" class:atlas-location={!inDungeon || browseAtlas}><span>LA TUA POSIZIONE</span><strong>{pos.zone ?? 'Zona sconosciuta'}</strong><small>{pos.sub ?? ''}{pos.x !== undefined && pos.y !== undefined ? ` · ${pos.x.toFixed(1)}, ${pos.y.toFixed(1)}` : ''}</small><small class="pointer-coordinates">Cursore: {#if pos.inst && (pos.inst.kind === 'party' || pos.inst.kind === 'raid')}non disponibile nel dungeon{:else if pointer}{pointer.zone} · {pointer.x.toFixed(1)}, {pointer.y.toFixed(1)}{:else}—{/if}</small>{#if typeof pos.facing !== 'number'}<small>Direzione non disponibile</small>{/if}</div>
        {/if}
      {:else}
        <div class="welcome">
          <img class="welcome-crest" class:discord-emblem={!inApp} src={brandIcon} alt="" />
          <p class="eyebrow">{inApp ? 'UNCS FOREVER · PER L’ALLEANZA' : brandName}</p>
          <h1>Il mondo ti aspetta.</h1>
          <p class="description">La tua mappa prende forma dai file del gioco. La tua posizione apparirà qui, mentre esplori.</p>
          <div class="loading" role="status">{tiles?.state === 'no-game' ? 'Cartella di WoW non trovata.' : tiles?.state === 'converting' ? `Preparazione della mappa: ${tiles.percent}%` : tiles?.state === 'failed' ? 'Impossibile preparare la mappa.' : 'Preparazione della mappa...'}</div>
          {#if tiles?.state === 'converting'}<progress max="100" value={tiles.percent} aria-label="Preparazione mappa"></progress>{/if}
          {#if tiles?.state === 'no-game'}<p class="hint">Seleziona la cartella che contiene _forever_.</p>{:else if tiles?.state === 'converting'}<p class="hint">La prima preparazione può richiedere qualche minuto.</p>{:else if tiles?.state === 'failed'}<p class="hint">{tiles.message}</p>{/if}
          {#if inApp && (!setup?.gameFolder || tiles?.state === 'no-game')}<button class="action" onclick={choose}>Seleziona la cartella di WoW</button>{/if}
          {#if tiles?.state === 'failed'}<button class="action" onclick={() => window.twinmap.retryTiles()}>Riprova</button>{/if}
          {#if error}<p class="hint">{error}</p>{/if}
        </div>
      {/if}
    </div>
  </main>
  <footer>
    {#if !inApp && setup?.webPublishing}
      <details class="publisher">
        <summary>Sorgente WoW</summary>
        <div>
          {#if !sharing}<input type="password" bind:value={publishKey} aria-label="Chiave di pubblicazione" placeholder="Chiave di pubblicazione" />{/if}
          <button disabled={!sharing && !publishKey} onclick={share}>{sharing ? 'Interrompi' : 'Condividi finestra di WoW'}</button>
          <small role="status">{publishMessage}</small>
        </div>
      </details>
    {/if}
    <span>{ready ? 'Rotella per zoom · Trascina per esplorare' : 'Una finestra sul tuo mondo'}</span>
    <label class="cursor-choice">Cursore <select bind:value={cursor} aria-label={setup?.webBridge ? 'Stile del cursore dei gildani' : 'Stile del cursore'}><option value="a">A · Bussola dorata</option><option value="b">B · Freccia runica</option><option value="c">C · Scudo e punta</option></select></label>
    {#if cache?.available}
      <span class="cache" role="status">
        {#if cache.processed >= cache.total && !cache.running}
          {cache.failed ? `Preparazione: ${cache.failed} immagini non riuscite` : 'Mappa precaricata'}
          {#if cache.failed}<button onclick={() => window.twinmap.toggleMapCache()}>Riprova</button>{/if}
        {:else}
          {cache.running ? 'Precaricamento' : 'Precaricamento in pausa'} {cache.processed}/{cache.total}
          <button onclick={() => window.twinmap.toggleMapCache()}>{cache.running ? 'Pausa' : 'Riprendi'}</button>
        {/if}
      </span>
    {/if}
  </footer>
</div>

<style>
  .locate-member {min-height:44px;text-align:left;padding:5px 8px;border:1px solid #a68757;background:#1a3859;color:#ffedc3;border-radius:4px;cursor:pointer;font:600 15px var(--font)}
  .return-dungeon {position:absolute;z-index:1100;left:12px;bottom:12px;min-height:44px;border:1px solid #a68757;border-radius:4px;background:#1a3859;color:#ffedc3;padding:6px 10px;cursor:pointer}
  .shell { height:100%; display:grid; grid-template-rows:76px minmax(0,1fr) 38px; background:#091831 url('./alliance-landscape.svg') center/cover no-repeat; color:#f3e6c6; font-family:var(--font); }
  .header { position:relative;z-index:1300;display:flex; align-items:center; gap:27px; padding:0 150px 0 24px; background:linear-gradient(105deg,#071428f5,#102b51f5 55%,#09192ff5); border-bottom:1px solid #c49a4a99; box-shadow:inset 0 -3px #08162a,0 4px 16px #0008; -webkit-app-region:drag; }
  .web-header { padding-right:24px; }
  .layers-toggle, .layer-close { flex:none; min-height:44px; border:1px solid #b48c4f; border-radius:4px; padding:0 13px; background:#163656; color:#ffedca; font:600 16px var(--font); cursor:pointer; -webkit-app-region:no-drag; }
  .map-menu { display:flex; align-items:center; flex-wrap:wrap; gap:8px; margin-left:auto; -webkit-app-region:no-drag; }
  .layers-toggle:hover, .layer-close:hover { background:#254a71; }
  .layers-dialog { box-sizing:border-box; width:min(530px, calc(100% - 28px)); max-height:calc(100% - 28px); padding:14px 18px 18px; background:#0e213b; color:#fff0cd; border:1px solid #c19b5a; border-radius:6px; box-shadow:0 10px 40px #0009; }
  .layers-dialog::backdrop { background:#040a16a6; }
  .layers-heading { display:flex; align-items:center; justify-content:space-between; gap:12px; padding-bottom:7px; border-bottom:1px solid #a287564d; }
  .layers-heading h2 { margin:0; font:400 20px var(--display); }
  .layer-close { min-width:44px; padding:0; font-size:22px; }
  .layers-dialog h3 { margin:14px 0 2px; color:#e6be6f; font:700 16px var(--font); }
  .layers-dialog p { margin:0 0 8px; color:#d3ccba; font:400 14px var(--font); }
  .layer-grid { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); column-gap:14px; }
  .profession-layers { margin-top:10px; border-top:1px solid #a2875633; }
  .profession-layers summary { min-height:46px; line-height:46px; cursor:pointer; color:#fff0cd; font-weight:600; }
  .profession-layers summary img { vertical-align:middle; margin:0 7px; }
  .layers-dialog label { display:flex; align-items:center; gap:7px; min-height:46px; padding-block:3px; border-top:1px solid #a2875633; font:600 16px var(--font); cursor:pointer; }
  .layers-dialog input { flex:none; width:20px; height:20px; margin:0 2px; accent-color:#e6be6f; }
  .layers-dialog img { flex:none; width:23px; height:23px; object-fit:contain; }
  .brand { display:flex; align-items:center; gap:11px; flex:none; }
  .brand-crest { width:47px; height:55px; object-fit:contain; filter:drop-shadow(0 2px 3px #0009); }
  img.discord-emblem { height:auto; aspect-ratio:1; border-radius:14%; }
  .brand b { display:block; font:400 22px/24px var(--display); letter-spacing:.025em; color:#fff0c8; white-space:nowrap; }
  .brand em { font-style:normal; color:#d8b369; }
  .brand small { display:block; font:600 9px/14px var(--font); letter-spacing:.18em; color:#aabbd1; }
  .brand small.version { letter-spacing:.04em; color:#c5d4df; font-size:10px; }
  main { min-height:0; padding:12px 16px 5px; }
  .map-frame { height:100%; position:relative; overflow:hidden; border:2px solid #ad8649; border-radius:5px; background:#0b1931; box-shadow:0 0 0 1px #2a1b10,0 0 0 4px #112b49,0 8px 24px #0009,inset 0 0 0 1px #f6daa655; }
  .location { position:absolute; z-index:1200; top:18px; left:18px; display:grid; gap:3px; pointer-events:none; padding:12px 18px 12px 16px; border-radius:3px; background:linear-gradient(115deg,#0a1a33f2,#102d50eb); border:1px solid #d4b36b99; border-left:3px solid #e7c472; box-shadow:0 4px 16px #0009,inset 0 0 0 1px #6284a126; }
  .location span,.eyebrow { color:#dfc18a; font-size:10px; font-weight:600; letter-spacing:.17em; }.location strong { color:#fff0cd; font:400 21px var(--display); }.location small { color:#c6d5e0; }
  .location small.pointer-coordinates { color:#e8d29c; padding-top:3px; }
  .publisher { position:relative; z-index:1300; }
  .publisher summary { cursor:pointer; white-space:nowrap; }
  .publisher div { position:absolute; bottom:24px; left:0; width:230px; display:grid; gap:8px; padding:10px; background:#091831; border:1px solid #ad8649; }
  .welcome { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:25px; background:linear-gradient(#08172b55,#07152cc9),url('./alliance-landscape.svg') center/cover; }
  .welcome-crest {width:100px;height:115px;filter:drop-shadow(0 4px 12px #0009)}.eyebrow { margin:17px 0 8px; }h1 { font:400 clamp(30px,4vw,50px) var(--display); margin:0; color:#fff0ca;text-shadow:0 2px 8px #000; }.description { max-width:410px; color:#cfdae3; margin:12px 0 20px; }.loading { font-size:14px; color:#efd3a1; }.hint { max-width:480px; color:#cad7e0; }progress { width:220px; margin:12px; accent-color:#d3ae69; }
  .action { margin-top:16px; padding:10px 15px; border-radius:3px; background:linear-gradient(#28578d,#102a50); color:#fff0c9; border:1px solid #d4b46d; cursor:pointer; font:600 14px var(--font); }.action:hover { background:linear-gradient(#3770aa,#173d6c); }
  footer { display:flex; justify-content:space-between; gap:14px; align-items:center; padding:0 22px; background:#08182df2; border-top:1px solid #c29d5944; color:#b4c6d6; font-size:11px; letter-spacing:.04em; }
  .cache { display:flex; gap:8px; align-items:center; white-space:nowrap; } .cache button { background:#132f52; border:1px solid #b49358; border-radius:3px; color:#f4dfb2; padding:3px 8px; font:inherit; cursor:pointer; }
  .cursor-choice {display:flex;align-items:center;gap:6px;white-space:nowrap}.cursor-choice select{background:#112a49;color:#f4e8cc;border:1px solid #b49358aa;border-radius:3px;font:inherit;padding:4px}
  .guild-panel {position:relative;color:#f3e8cb}
  .guild-panel .layers-toggle b {color:#f7d98d}
  .guild-list {position:absolute;top:100%;right:0;box-sizing:border-box;width:min(390px,calc(100vw - 24px));max-height:45vh;overflow:auto;background:#0a1b32f7;border:1px solid #caa56088;border-radius:3px;margin-top:4px;padding:8px 12px;font:13px var(--font);box-shadow:0 5px 15px #0008}
  .guild-list p,.guild-list span {color:#b7cbda;font-size:12px}
  .guild-list > div {display:grid;gap:2px;padding:7px 0;border-top:1px solid #c5aa7938}
  .guild-list > .guild-sort {display:flex;gap:6px;border-top:0;padding:0 0 8px}
  .guild-sort button {padding:5px 11px;border:1px solid #6885a0;border-radius:999px;background:#122b46;color:#dceafb;cursor:pointer;font:inherit}
  .guild-sort button[aria-pressed="true"] {border-color:#ffda78;background:#594019;color:#ffe398}
  .guild-sort button:focus-visible {outline:2px solid #fff0bc;outline-offset:2px}
  .guild-member-heading {display:grid;grid-template-columns:36px minmax(0,1.25fr) max-content minmax(0,.8fr);align-items:center;gap:8px}
  .guild-member-heading .guild-level {margin-left:10px;color:#ffdf91;font-size:20px;font-weight:700;text-align:center;line-height:1}
  .guild-member-heading .guild-zone {font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .guild-member-heading .locate-member,.guild-member-heading strong {min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .guild-member-heading .locate-member {min-height:36px}
  .guild-follow {width:36px;height:36px;display:grid;place-items:center;border:1px solid #6885a0;border-radius:5px;background:#122b46;color:#dceafb;cursor:pointer}
  .guild-follow:hover:not(:disabled),.guild-follow:focus-visible {background:#264866}
  .guild-follow.active {border:2px solid #ffda78;background:#594019;color:#ffe398;box-shadow:0 0 8px #eebc5ab0}
  .guild-follow:disabled {opacity:.45;cursor:default}
  .guild-list strong {color:#f3dfb7}
  @media(max-width:840px){.header{padding-left:14px}main{padding:8px}.location{left:12px;top:12px}footer>span:first-child{display:none}}
  .location.atlas-location {top:72px}
  @media(max-width:750px){.shell{grid-template-rows:auto minmax(0,1fr) 38px}.header{flex-wrap:wrap;gap:7px;padding-block:7px}.map-menu{position:relative;width:100%;margin-left:0}.guild-panel{position:static}.guild-list{width:min(390px,calc(100vw - 24px))}}
  @media(max-width:580px){.layers-toggle{font-size:14px;padding:0 9px}.brand b{font-size:18px}.brand-crest{width:38px;height:47px}.location{max-width:42%;padding:8px 10px}.location strong{font-size:16px}.cache{font-size:10px}footer{padding:0 10px;gap:6px}}
  @media(max-width:420px){.web-header{padding-right:12px;gap:8px}.web-header .brand{gap:7px}.web-header .brand b{line-height:19px}.web-header .brand-crest{width:34px}.web-brand-name{display:block;font-size:15px}.map-menu{gap:4px}.layers-toggle{padding:0 7px}}
</style>
