import L from 'leaflet'
import {project,type Calibrated} from '../../shared/map-detail'
import type {CityMini} from '../../shared/city-mini'
import { OPENMAP } from './web'

/** Assemble the local minimap pictures in their world positions, lowest floor first. */
export async function renderCityMini(city:CityMini, calibration:Calibrated):Promise<{url:string;bounds:L.LatLngBounds}|null> {
  const {g,swap}=calibration
  const origin=project(g,0,0,swap), n=project(g,1000,0,swap), w=project(g,0,1000,swap)
  const ku=Math.max(Math.abs(n[0]-origin[0]),Math.abs(w[0]-origin[0]))/1000
  const kv=Math.max(Math.abs(n[1]-origin[1]),Math.abs(w[1]-origin[1]))/1000
  if(!ku || !kv || !city.pieces.length)return null
  const laid=city.pieces.map(piece=>{const [u,v]=project(g,piece.north,piece.west,swap);return {piece,u,v,hu:piece.side*ku/2,hv:piece.side*kv/2}})
  // The rotated minimap pictures can extend beyond their unrotated square. Leave room for
  // every corner, otherwise the canvas itself cuts off rooms at the edge of the city.
  const rotatedExtent=Math.SQRT2
  const left=Math.min(...laid.map(p=>p.u-p.hu*rotatedExtent)),right=Math.max(...laid.map(p=>p.u+p.hu*rotatedExtent)),top=Math.min(...laid.map(p=>p.v-p.hv*rotatedExtent)),bottom=Math.max(...laid.map(p=>p.v+p.hv*rotatedExtent))
  if(!(right>left && bottom>top))return null
  const width=2048, height=Math.max(128,Math.min(3072,Math.round(width*(bottom-top)*668/((right-left)*1002))))
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height
  const ctx=canvas.getContext('2d');if(!ctx)return null
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high'
  const pictures:(HTMLImageElement|null)[]=new Array(laid.length).fill(null)
  let index=0
  const load=async():Promise<void>=>{
    while(index<laid.length) {
      const i=index++, image=new Image(); image.crossOrigin='anonymous'
      pictures[i]=await new Promise<HTMLImageElement|null>(resolve=>{image.onload=()=>resolve(image);image.onerror=()=>resolve(null);image.src=`${OPENMAP}/city-mini/${laid[i]!.piece.file}.png`})
    }
  }
  await Promise.all(Array.from({length:6},load))
  if(pictures.filter(Boolean).length<laid.length*.8)return null
  for(let i=0;i<laid.length;i++) {
    const img=pictures[i],p=laid[i];if(!img || !p)continue
    const x=(p.u-left)/(right-left)*width,y=(p.v-top)/(bottom-top)*height
    const pw=2*p.hu/(right-left)*width,ph=2*p.hv/(bottom-top)*height
    ctx.save();ctx.translate(x,y);ctx.scale(pw,ph)
    // Rotate the actual visible portion without cutting it to the former axis-aligned square.
    ctx.rotate(-p.piece.angle)
    const imageWidth=1/p.piece.u1,imageHeight=1/(1-p.piece.v0)
    ctx.drawImage(img,-.5,-.5-p.piece.v0*imageHeight,imageWidth,imageHeight)
    ctx.restore()
  }
  const blob=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,'image/png'))
  if(!blob)return null
  return {url:URL.createObjectURL(blob),bounds:L.latLngBounds([-bottom*668,left*1002],[-top*668,right*1002])}
}
