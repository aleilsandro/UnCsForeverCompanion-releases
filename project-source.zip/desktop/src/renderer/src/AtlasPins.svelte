<script lang="ts">
  import { onMount } from 'svelte'
  import L from 'leaflet'
  import { inApp, onGuildPinsChanged } from './web'
  import MapPinEditor from './MapPinEditor.svelte'

  let { map }: { map?: L.Map } = $props()
  interface PinPosition { x: number; y: number }
  interface Pin extends PinPosition { id: string; name: string; note: string; removable: boolean }
  const key = 'uncs-atlas-personal-notes'
  function localNotes(): Pin[] {
    try {
      const value: unknown = JSON.parse(localStorage.getItem(key) ?? '[]')
      if (Array.isArray(value)) return value.filter(pin => pin && typeof pin.id === 'string' &&
        typeof pin.name === 'string' && typeof pin.note === 'string' &&
        [pin.x, pin.y].every(n => Number.isInteger(n) && n >= 0 && n <= 100000))
    } catch { /* Storage can be unavailable in a private browser. */ }
    return []
  }
  let personal = $state.raw(localNotes())
  let shared = $state.raw<Pin[]>([])
  let canShare = $state(false)
  let placing = $state(false)
  let position = $state.raw<PinPosition>()
  let notice = $state('')

  async function refresh(): Promise<void> {
    try {
      const response = await fetch('/guild-pins')
      if (response.ok) {
        shared = (await response.json()).pins
        canShare = true
      } else if (response.status === 401 || response.status === 403 || response.status === 404) {
        canShare = false
        shared = []
      }
    } catch { /* Retain the last list if the connection is interrupted. */ }
  }
  onMount(() => {
    if (inApp) return
    void refresh()
    return onGuildPinsChanged(() => { void refresh() })
  })
  function replacePersonal(items: Pin[]): void {
    try { localStorage.setItem(key, JSON.stringify(items)) }
    catch { throw Error('Il browser non può salvare le note personali.') }
    personal = items
  }
  async function save(name: string, note: string, share: boolean): Promise<void> {
    if (!position) return
    const draft = { ...position, name, note }
    if (share) {
      const response = await fetch('/guild-pins', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(draft)
      })
      if (!response.ok) throw Error(response.status === 409 ? 'La gilda ha raggiunto il limite di pin.' : 'Impossibile condividere il pin.')
      shared = (await response.json()).pins
    } else {
      const id = crypto.randomUUID?.() ?? (Date.now().toString(36) + Math.random().toString(36))
      replacePersonal([...personal, { ...draft, id, removable: true }])
    }
  }
  async function remove(pin: Pin, share: boolean): Promise<void> {
    notice = ''
    try {
      if (share) {
        const response = await fetch('/guild-pins/' + encodeURIComponent(pin.id), { method: 'DELETE' })
        if (!response.ok) throw Error('Impossibile rimuovere il pin condiviso.')
        shared = (await response.json()).pins
      } else replacePersonal(personal.filter(item => item.id !== pin.id))
    } catch (error) { notice = error instanceof Error ? error.message : 'Rimozione del pin non riuscita.' }
  }

  $effect(() => {
    const atlas = map
    if (!atlas || !placing) return
    const container = atlas.getContainer()
    const choose = (event: MouseEvent): void => {
      event.stopPropagation()
      const at = atlas.mouseEventToLatLng(event)
      const x = Math.round(at.lng / 1002 * 100000), y = Math.round(-at.lat / 668 * 100000)
      if (x < 0 || x > 100000 || y < 0 || y > 100000) return
      placing = false
      position = { x, y }
    }
    const escape = (event: KeyboardEvent): void => { if (event.key === 'Escape') placing = false }
    container.classList.add('placing-atlas-pin')
    container.addEventListener('click', choose, true)
    window.addEventListener('keydown', escape)
    return () => {
      container.classList.remove('placing-atlas-pin')
      container.removeEventListener('click', choose, true)
      window.removeEventListener('keydown', escape)
    }
  })
  $effect(() => {
    if (!map) return
    const layer = L.layerGroup()
    for (const [items, share] of [[personal, false], [shared, true]] as const) for (const pin of items) {
      const label = pin.name || (share ? 'Pin della gilda' : 'Nota personale')
      const badge = document.createElement('span')
      badge.textContent = share ? '◆' : '✎'
      badge.setAttribute('aria-hidden', 'true')
      const popup = document.createElement('div')
      popup.className = 'atlas-pin-popup'
      const name = document.createElement('strong')
      name.textContent = label
      popup.append(name)
      if (pin.note) {
        const note = document.createElement('p')
        note.textContent = pin.note
        popup.append(note)
      }
      if (pin.removable) {
        const button = document.createElement('button')
        button.type = 'button'
        button.textContent = share ? 'Rimuovi pin' : 'Rimuovi nota'
        button.onclick = () => { void remove(pin, share) }
        popup.append(button)
      }
      const icon = L.divIcon({ className: share ? 'atlas-note-pin guild-note-pin' : 'atlas-note-pin', html: badge, iconSize: [30, 30], iconAnchor: [15, 15] })
      L.marker([-pin.y * 668 / 100000, pin.x * 1002 / 100000], { icon, title: label, zIndexOffset: 560 })
        .bindPopup(popup, { offset: [0, -10] }).addTo(layer)
    }
    layer.addTo(map)
    return () => { layer.remove() }
  })
</script>

<div class="pin-controls">
  <button class="trigger" type="button" aria-pressed={placing} disabled={!map} onclick={() => { placing = !placing; notice = '' }}>
    {placing ? 'Annulla pin' : 'Aggiungi pin'}
  </button>
  {#if placing}<span class="pin-instruction" role="status">Tocca o clicca un punto sulla mappa.</span>{/if}
  {#if notice}<span class="pin-instruction" role="alert">{notice}</span>{/if}
</div>
{#if position}<MapPinEditor {canShare} onSave={save} onClose={() => position = undefined} />{/if}

<style>
  .pin-controls {position:absolute;z-index:1220;top:18px;inset-inline:18px;display:grid;justify-items:start;gap:8px;pointer-events:none}
  .trigger {pointer-events:auto;min-height:44px;padding:5px 11px;color:#ffedc3;background:#1a3859;border:1px solid #caa45f;border-radius:4px;font:600 16px var(--font);cursor:pointer}
  .trigger[aria-pressed=true] {background:#30567f}
  .pin-instruction {box-sizing:border-box;max-width:100%;border:1px solid #caa45f;border-radius:4px;background:#0e213b;color:#ffedc3;padding:6px 9px}
  :global(.placing-atlas-pin), :global(.placing-atlas-pin .leaflet-interactive) {cursor:crosshair}
  :global(.atlas-note-pin) {display:grid;place-items:center;border-radius:50%;border:2px solid #ffe0a1;background:#173551;color:#ffe0a1;box-shadow:0 2px 5px #0009;font-size:19px}
  :global(.guild-note-pin) {background:#275844;color:#f8edc9}
  :global(.atlas-pin-popup p) {white-space:pre-wrap;overflow-wrap:anywhere;max-width:260px;margin:6px 0}
  :global(.atlas-pin-popup button) {display:block;min-height:40px;margin-top:6px}
</style>
