import L from 'leaflet'

// Use the same move lifecycle as Leaflet's touch zoom. A wheel gesture can span
// several frames without running the atlas's zoomend work for each frame.
type WheelMap = L.Map & {
  _animatingZoom: boolean
  _stop(): void
  _moveStart(zoomChanged: boolean): void
  _move(center: L.LatLng, zoom: number): void
  _moveEnd(zoomChanged: boolean): void
}

export function installAtlasWheelZoom(map: L.Map, explore: () => void): () => void {
  const atlas = map as WheelMap
  const container = atlas.getContainer()
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)')
  let motion: { target: number; point: L.Point; anchor: L.LatLng; time: number } | undefined
  let frame = 0
  let starting = false

  function finish(): void {
    if (starting || !motion) return
    cancelAnimationFrame(frame)
    frame = 0
    motion = undefined
    atlas._moveEnd(true)
  }

  function step(time: number): void {
    frame = 0
    if (!motion) return
    const current = atlas.getZoom()
    const remaining = motion.target - current
    const elapsed = Math.max(1, time - motion.time)
    const zoom = reducedMotion.matches || Math.abs(remaining) < .003
      ? motion.target : current + remaining * (1 - Math.exp(-elapsed / 38))
    const offset = motion.point.subtract(atlas.getSize().divideBy(2))
    const center = atlas.unproject(atlas.project(motion.anchor, zoom).subtract(offset), zoom)
    motion.time = time
    if (zoom !== current) atlas._move(center, zoom)
    if (!motion) return
    if (zoom === motion.target) finish()
    else frame = requestAnimationFrame(step)
  }

  function wheel(event: WheelEvent): void {
    const delta = L.DomEvent.getWheelDelta(event) / 125
    if (!Number.isFinite(delta) || delta === 0) return
    event.preventDefault()
    event.stopPropagation()
    if (atlas._animatingZoom) return
    const current = atlas.getZoom()
    const pending = (motion?.target ?? current) - current
    // Reversing the wheel cancels the remaining motion in the old direction.
    const next = current + (pending * delta > 0 ? pending : 0) + delta
    const target = Math.max(atlas.getMinZoom(), Math.min(atlas.getMaxZoom(), next))
    if (target === current && !motion) return

    const continuing = !!motion
    if (!continuing) {
      explore()
      atlas._stop()
    }
    const point = atlas.mouseEventToContainerPoint(event)
    const now = performance.now()
    motion = { target, point, anchor: atlas.containerPointToLatLng(point), time: motion?.time ?? now }
    if (!continuing) {
      starting = true
      atlas._moveStart(true)
      starting = false
    }
    if (!frame) frame = requestAnimationFrame(step)
  }

  container.addEventListener('wheel', wheel, { passive: false })
  container.addEventListener('pointerdown', finish, true)
  atlas.on('movestart', finish)
  return () => {
    container.removeEventListener('wheel', wheel)
    container.removeEventListener('pointerdown', finish, true)
    atlas.off('movestart', finish)
    cancelAnimationFrame(frame)
    motion = undefined
  }
}
