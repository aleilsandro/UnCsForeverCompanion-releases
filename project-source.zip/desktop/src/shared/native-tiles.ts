/** MapMinimap is read as data: never execute code from an addon. */
export function parseNativeTileList(lua: string): [number,number,number,number][] {
  const chunks = [...lua.matchAll(/(?:^|\n)\s*\[([01])\]\s*=\s*\{([\s\S]*?)\n\s*\}/g)]
  const out: [number,number,number,number][] = []
  for (const m of chunks) {
    const world=Number(m[1])
    for (const hit of m[2]!.matchAll(/\[(\d+)\]\s*=\s*(\d+)/g)) {
      const k=Number(hit[1]), file=Number(hit[2]), col=Math.floor(k/64), row=k%64
      if (k>=0 && k<4096 && file>0 && Number.isSafeInteger(file)) out.push([world,col,row,file])
    }
  }
  return out
}
