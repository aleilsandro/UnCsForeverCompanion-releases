import { expect, test } from 'vitest'
import { cursorCoordinates } from './cursor-coordinates'
import { project, type Geometry } from './map-detail'
import type { GameMap } from './maps'

const geometry: Geometry = { l: 10000, r: 60000, t: 20000, b: 80000, ax: -1000, zx: 1000, ay: -2000, zy: 2000 }
const maps: GameMap[] = [{ id: 1, name: 'Zona', parent: 0, level: 'zone', continent: 0, rect: { minX: -500, maxX: 500, minY: -1000, maxY: 1000 }, area: 0 }]

test.each([false, true])('converts map pointer to zone coordinates with swap=%s', swap => {
  const [u, v] = project(geometry, 250, -500, swap)
  const point = cursorCoordinates(u * 1002, v * 668, 1002, 668, maps, new Map([[0, { g: geometry, swap }]]))
  expect(point?.zone).toBe('Zona')
  expect(point?.x).toBeCloseTo(75)
  expect(point?.y).toBeCloseTo(25)
})
test('returns no coordinates when there is no valid calibration or zone', () => {
  expect(cursorCoordinates(100, 100, 1002, 668, maps, new Map())).toBeNull()
  expect(cursorCoordinates(0, 0, 1002, 668, maps, new Map([[0, { g: geometry, swap: false }]]))).toBeNull()
})
