import { unitsOfWorld } from './geo'
import type { Continent, GameMap } from './maps'
import { zoneAt } from './point-label'
import type { Calibrated } from './map-detail'

export type CursorCoordinates = { zone: string; x: number; y: number }

/** Convert the point under the pointer from OpenMap canvas to game zone coordinates. */
export function cursorCoordinates(x: number, y: number, width: number, height: number, maps: GameMap[], calibrations: ReadonlyMap<number, Calibrated>, preferred?: number): CursorCoordinates | null {
  if (![x, y, width, height].every(Number.isFinite) || width <= 0 || height <= 0) return null
  const order: Continent[] = preferred === 1 ? [1, 0] : [0, 1]
  for (const world of order) {
    const calibration = calibrations.get(world)
    if (!calibration) continue
    const { g, swap } = calibration
    const u = x / width * 100000, v = y / height * 100000
    if (u < g.l || u > g.r || v < g.t || v > g.b) continue
    const a = (u - g.l) / (g.r - g.l), b = (v - g.t) / (g.b - g.t)
    const north = g.ax + (swap ? a : b) * (g.zx - g.ax)
    const west = g.ay + (swap ? b : a) * (g.zy - g.ay)
    const found = zoneAt(maps, world, unitsOfWorld(north, west))
    if (found && Number.isFinite(found.place.x) && Number.isFinite(found.place.y)) return { zone: found.zone.name, ...found.place }
  }
  return null
}
