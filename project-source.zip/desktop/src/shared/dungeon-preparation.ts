import type { DungeonJournalData, DungeonQuest, QuestPlace, QuestReference, QuestSource } from './dungeon-journal'
import type { WorldPoint } from './map-navigation'
import { transportRoutes } from './transport-routes'

export interface PreparationStop {
  point: WorldPoint
  label: string
  actions: { id: number; text: string }[]
}
interface TransportStop { label: string; point: WorldPoint }
interface TravelLeg {
  from: TransportStop
  to: TransportStop
  kind: 'walk' | 'boat' | 'zeppelin'
  seconds: number
  tracks?: WorldPoint[][]
}
export interface PreparationPlan {
  stops: PreparationStop[]
  legs: TravelLeg[]
  unmapped: string[]
  seconds?: number
}
interface PreparationOptions {
  entrance: PreparationStop
  origin?: WorldPoint
  quests: DungeonQuest[]
  steps: DungeonJournalData['questSteps']
  completed?: ReadonlySet<number>
  active?: ReadonlySet<number>
  side?: 'A' | 'H'
  level?: number
  along: boolean
  locate: (place: QuestPlace) => WorldPoint | undefined
}
interface Task {
  id: number
  choices: TransportStop[]
  requires: number[]
  text: string
}
type Travel = { cost: number; legs: TravelLeg[] }
const unreachable: Travel = { cost: Infinity, legs: [] }
const yards = (a: WorldPoint, b: WorldPoint) => a.world === b.world
  ? Math.hypot(a.north - b.north, a.west - b.west) : Infinity

function transportNetwork(side: PreparationOptions['side']) {
  const stops: TransportStop[] = []
  const links = new Map<TransportStop, TravelLeg>()
  for (const [kind, docks, legs] of transportRoutes) {
    const names = docks.map(([name]) => name)
    const neutral = names.includes('Ratchet') || names.includes('Steamwheedle Port')
    if (!neutral && (kind === 'zeppelin' ? side !== 'H' : side !== 'A')) continue
    if (docks.some(([, world]) => world !== 0 && world !== 1)) continue
    const route = docks.map(([label, world, north, west]): TransportStop => ({
      label, point: { world: world === 0 ? 0 : 1, north, west },
    }))
    stops.push(...route)
    for (const [index, from] of route.entries()) {
      const to = route[(index + 1) % route.length]
      const tracks = legs[index]?.flatMap(([world, points]) => {
        if (world !== 0 && world !== 1) return []
        const track: WorldPoint[] = []
        for (let i = 0; i + 1 < points.length; i += 2) track.push({ world, north: points[i], west: points[i + 1] })
        return track.length > 1 ? [track] : []
      })
      if (!tracks?.length) continue
      const distance = tracks.reduce((sum, track) =>
        sum + track.slice(1).reduce((length, point, i) => length + yards(point, track[i]), 0), 0)
      links.set(from, { from, to, tracks, kind, seconds: 90 + distance / 18 })
    }
  }
  return { stops, links }
}

function travelBetween(side: PreparationOptions['side']) {
  const network = transportNetwork(side)
  const cache = new Map<string, Travel>()
  return (from: TransportStop, to: TransportStop): Travel => {
    if (from === to) return { cost: 0, legs: [] }
    const key = JSON.stringify([from, to])
    const cached = cache.get(key)
    if (cached) return cached
    const open = new Set([from, ...network.stops, to])
    const costs = new Map([[from, 0]])
    const prior = new Map<TransportStop, TravelLeg>()
    function relax(leg: TravelLeg, base: number): void {
      const cost = base + leg.seconds
      if (!open.has(leg.to) || cost >= (costs.get(leg.to) ?? Infinity)) return
      costs.set(leg.to, cost)
      prior.set(leg.to, leg)
    }
    for (let current = from; current !== to;) {
      open.delete(current)
      const base = costs.get(current)!
      const transport = network.links.get(current)
      if (transport) relax(transport, base)
      let next: TransportStop | undefined
      let cheapest = Infinity
      for (const point of open) {
        relax({ from: current, to: point, kind: 'walk', seconds: yards(current.point, point.point) / 7 }, base)
        const cost = costs.get(point) ?? Infinity
        if (cost < cheapest) { cheapest = cost; next = point }
      }
      if (!next) { cache.set(key, unreachable); return unreachable }
      current = next
    }
    const legs: TravelLeg[] = []
    for (let current = to; current !== from;) {
      const leg = prior.get(current)!
      if (leg.seconds > 0) legs.unshift(leg)
      current = leg.from
    }
    const result = { cost: costs.get(to)!, legs }
    cache.set(key, result)
    return result
  }
}

function questSources(source: QuestSource): QuestSource[] {
  return source.kind === 'item' ? [source, ...(source.drops ?? []).flatMap(questSources)] : [source]
}

export function prepareDungeon(options: PreparationOptions): PreparationPlan {
  const { entrance, quests, steps, completed, active, side, level, along, locate } = options
  const start = { label: 'Partenza', point: options.origin ?? entrance.point }
  const travel = travelBetween(side)
  const baseline = travel(start, entrance).cost
  const planned = new Map<number, Task>()
  const unmapped: string[] = []
  const roots = new Map(quests.map(quest => [quest.id, quest]))
  const bypass = (id: number) => completed?.has(id) || active?.has(id)
  const allowed = (quest: DungeonQuest | undefined) =>
    (!quest?.faction || !side || quest.faction === side) && (!quest?.level || level === undefined || quest.level <= level)
  const detour = (place: TransportStop) => travel(start, place).cost + travel(place, entrance).cost
  const choiceLimit = along ? baseline + Math.max(120, baseline / 4) : Infinity

  function requirements(ref: QuestReference, prerequisite: boolean, visiting: Set<number>): Task[] | undefined {
    if (completed?.has(ref.id)) return []
    if (active?.has(ref.id)) {
      // Prerequisites in progress still have to be handed in before the next quest can be picked up.
      return prerequisite ? undefined : []
    }
    if (visiting.has(ref.id) || !allowed(roots.get(ref.id))) return
    const step = steps?.[ref.id] ?? roots.get(ref.id)
    if (!step) return
    const choices = step.starts.flatMap(questSources).flatMap(source => source.places.flatMap(place => {
      const point = locate(place)
      return point ? [{ point, label: source.name }] : []
    })).filter(candidate => {
      const cost = detour(candidate)
      return Number.isFinite(cost) && cost <= choiceLimit
    })
    if (!choices.length) return
    const next = new Set(visiting).add(ref.id)
    const results: Task[] = []
    const requires = new Set<number>()
    for (const required of [...step.required, ...(step.previous ?? [])]) {
      const parts = requirements(required, true, next)
      if (!parts) return
      if (parts.length) requires.add(required.id)
      results.push(...parts)
    }
    if (step.alternatives.length) {
      const alternatives = step.alternatives.flatMap(option => {
        const tasks = requirements(option, true, next)
        return tasks ? [{ option, tasks, cost: tasks.reduce((total, task) =>
          total + Math.min(...task.choices.map(detour)), 0) }] : []
      }).sort((a, b) => a.cost - b.cost)
      const best = alternatives[0]
      if (!best) return
      if (best.tasks.length) requires.add(best.option.id)
      results.push(...best.tasks)
    }
    const text = prerequisite ? 'Completa il prerequisito: ' + ref.name : 'Prendi: ' + ref.name
    return [...results, { id: ref.id, choices, requires: [...requires], text }]
  }

  for (const quest of quests) {
    if (bypass(quest.id) || !allowed(quest)) continue
    const tasks = requirements(quest, false, new Set())
    if (!tasks) { unmapped.push(quest.name); continue }
    for (const task of tasks) {
      const existing = planned.get(task.id)
      if (!existing || task.text.startsWith('Completa')) planned.set(task.id, task)
    }
  }

  const stops: PreparationStop[] = []
  const legs: TravelLeg[] = []
  let current: TransportStop = start
  let seconds = 0
  while (planned.size) {
    const available = [...planned.values()].filter(task => task.requires.every(id => !planned.has(id)))
    const next = available.flatMap(task => task.choices.map(choice => ({
      task, choice, cost: travel(current, choice).cost,
    }))).sort((a, b) => a.cost - b.cost || detour(a.choice) - detour(b.choice))[0]
    if (!next || !Number.isFinite(next.cost)) {
      unmapped.push(...[...planned.values()].map(task => task.text))
      break
    }
    const previous = stops.at(-1)
    const action = { id: next.task.id, text: next.task.text }
    if (previous?.label === next.choice.label && next.cost === 0) previous.actions.push(action)
    else {
      legs.push(...travel(current, next.choice).legs)
      stops.push({ ...next.choice, actions: [action] })
      seconds += next.cost
    }
    current = next.choice
    planned.delete(next.task.id)
  }
  const ending = travel(current, entrance)
  legs.push(...ending.legs)
  stops.push(entrance)
  return {
    stops, legs, unmapped: [...new Set(unmapped)],
    seconds: Number.isFinite(ending.cost) ? seconds + ending.cost : undefined,
  }
}
