// Suggested player levels by UiMapID, from OpenMap's WoW Forever data (MIT).
// https://github.com/openmap-world/openmap/blob/6c2299f6e1f9bdce1bbd92145f84a05b0c6c05a7/OpenMap/Data/Forever/Levels.lua
const zoneLevels: Partial<Record<number, readonly [number, number]>> = {
  1416: [30, 40], // Alterac Mountains
  1417: [30, 40], // Arathi Highlands
  1418: [35, 45], // Badlands
  1419: [45, 55], // Blasted Lands
  1420: [1, 10], // Tirisfal Glades
  1421: [10, 20], // Silverpine Forest
  1422: [51, 58], // Western Plaguelands
  1423: [53, 60], // Eastern Plaguelands
  1424: [20, 30], // Hillsbrad Foothills
  1425: [40, 50], // The Hinterlands
  1426: [1, 10], // Dun Morogh
  1427: [45, 50], // Searing Gorge
  1428: [50, 58], // Burning Steppes
  1429: [1, 10], // Elwynn Forest
  1430: [55, 60], // Deadwind Pass
  1431: [18, 30], // Duskwood
  1432: [10, 20], // Loch Modan
  1433: [15, 25], // Redridge Mountains
  1434: [30, 45], // Stranglethorn Vale
  1435: [35, 45], // Swamp of Sorrows
  1436: [10, 20], // Westfall
  1437: [20, 30], // Wetlands
  1411: [1, 10], // Durotar
  1412: [1, 10], // Mulgore
  1413: [10, 25], // The Barrens
  1438: [1, 10], // Teldrassil
  1439: [10, 20], // Darkshore
  1440: [18, 30], // Ashenvale
  1441: [25, 35], // Thousand Needles
  1442: [15, 27], // Stonetalon Mountains
  1443: [30, 40], // Desolace
  1444: [40, 50], // Feralas
  1445: [35, 45], // Dustwallow Marsh
  1446: [40, 50], // Tanaris
  1447: [45, 55], // Azshara
  1448: [48, 55], // Felwood
  1449: [48, 55], // Un'Goro Crater
  1450: [55, 60], // Moonglade
  1451: [55, 60], // Silithus
  1452: [55, 60], // Winterspring
  2548: [35, 45], // Riverglades
  2521: [1, 12], // Zephras Isle
}

export function zoneLevelText(mapId: number): string | undefined {
  const range = zoneLevels[mapId]
  if (!range) return undefined
  const [min, max] = range
  return min === max ? `Livello ${min}` : `Livelli ${min}–${max}`
}
