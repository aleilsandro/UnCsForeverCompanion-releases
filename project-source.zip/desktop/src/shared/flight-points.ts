export interface FlightStatus {
  side: 'A' | 'H'
  known: number[]
  checked: number[]
}

export function flightStatusFrom(value: unknown): FlightStatus | undefined {
  if (!value || typeof value !== 'object' || !('side' in value) || (value.side !== 'A' && value.side !== 'H')) return
  const known = 'known' in value && Array.isArray(value.known) ? value.known.slice(0, 200).filter(id => Number.isSafeInteger(id) && id > 0) : []
  const checked = 'checked' in value && Array.isArray(value.checked) ? value.checked.filter(id => id === 0 || id === 1) : []
  return { side: value.side, known, checked }
}
