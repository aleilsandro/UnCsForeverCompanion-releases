import {expect,test} from 'vitest'
import {guildFrom} from './guild'
test('keeps online guild names, marks exact and approximate locations, rejects stale or invalid coordinates',()=>{
  const list=[{n:'Aria',c:'MAGE',l:42,z:'Elwynn',x:30000,y:40000,exact:true,facing:135},{n:'Bryn',z:'Elwynn',x:31000,y:41000,facing:90},{n:'Cora',x:-1,y:0,exact:true}]
  const result=guildFrom({list})
  expect(result).toHaveLength(3)
  expect(result[0]).toMatchObject({name:'Aria',exact:true,x:30000,y:40000,facing:135})
  expect(result[1]).toMatchObject({name:'Bryn',exact:false,x:31000})
  expect(result[1]?.facing).toBeUndefined()
  expect(result[2]).toMatchObject({name:'Cora',exact:false})
  expect(result[2]?.x).toBeUndefined()
  expect(guildFrom({list},60001)).toEqual([])
})
