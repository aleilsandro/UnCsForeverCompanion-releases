export interface MapCacheStatus {
  running:boolean
  processed:number
  total:number
  failed:number
  available:boolean
}
