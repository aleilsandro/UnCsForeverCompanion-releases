import { DUNGEON_PINS, type DungeonPins } from './dungeon-pins'
import { dungeonEntrances } from './dungeon-entrances'
import { NEW_DUNGEON_PINS } from './new-dungeon-pins'
import { nameOfBoss } from './inside'

export const dungeonGuides = [...DUNGEON_PINS, ...NEW_DUNGEON_PINS]
export const dungeonDirectory = dungeonEntrances.flatMap(([, , , dungeons]) => {
  const wings = dungeons.map(([name]) => name)
  return dungeons.map(([name, min, max], index) => ({ name, min, max, wings, index }))
}).sort((a, b) => a.min - b.min || a.name.localeCompare(b.name))

export function dungeonGuideFor(name: string): DungeonPins | undefined {
  const key = nameOfBoss(name).replace(/^the /, '').replace(/^stormwind stockade$/, 'stockade')
    .replace(/^sunken temple$/, 'temple of atal hakkar')
  return dungeonGuides.find(guide => nameOfBoss(guide.name).replace(/^the /, '') === key)
}

export interface QuestPlace { zone: string; x?: number; y?: number }
export interface QuestSource {
  id: number
  kind: 'npc' | 'object' | 'item'
  name: string
  places: QuestPlace[]
  drops?: QuestSource[]
}
export interface DungeonQuest {
  id: number
  name: string
  level?: number
  faction?: 'A' | 'H'
  starts: QuestSource[]
  required: { id: number; name: string }[]
  alternatives: { id: number; name: string }[]
  objectives: string[]
}
export interface DungeonLoot { id: number; name: string }
export const DUNGEON_LOOT_FILE = 'loot-items-v1.json'
export interface DungeonLootDetails {
  name?: string
  icon?: number
  quality?: number
  level?: number
  required?: number
  binding?: string
  slot?: string
  type?: string
  weapon?: { min: number; max: number; speed: number; dps: number; school?: string }
  armor?: number
  stats?: [label: string, amount: number][]
  effects?: { trigger: string; text: string }[]
  description?: string
}
export type DungeonLootDetailsById = Record<number, DungeonLootDetails>
export interface DungeonJournalData {
  quests: Record<number, DungeonQuest[]>
  loot: Record<number, Record<string, DungeonLoot[]>>
}
