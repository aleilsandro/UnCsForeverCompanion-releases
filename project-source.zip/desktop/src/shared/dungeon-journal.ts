import { DUNGEON_PINS, type DungeonPins } from './dungeon-pins'
import { dungeonEntrances } from './dungeon-entrances'
import { NEW_DUNGEON_PINS } from './new-dungeon-pins'
import { nameOfBoss } from './inside'

export const dungeonGuides = [...DUNGEON_PINS, ...NEW_DUNGEON_PINS]
export const dungeonDirectory = dungeonEntrances.flatMap(([, , , dungeons]) => {
  const wings = dungeons.map(([name]) => name)
  return dungeons.map(([name, min, max], index) => ({ name, min, max, wings, index }))
}).sort((a, b) => a.min - b.min || a.name.localeCompare(b.name))

export function dungeonGuideFor(name: string): DungeonPins | undefined {
  const key = nameOfBoss(name).replace(/^the /, '').replace(/^stormwind stockade$/, 'stockade')
    .replace(/^sunken temple$/, 'temple of atal hakkar')
  return dungeonGuides.find(guide => nameOfBoss(guide.name).replace(/^the /, '') === key)
}

export function dungeonCompletionLabel(
  name: string,
  completedDungeons: ReadonlySet<number>,
  legacyDungeons: ReadonlySet<number>,
): string | undefined {
  const guide = dungeonGuideFor(name)
  if (!guide) return
  if (completedDungeons.has(guide.map)) return 'Completato'
  if (legacyDungeons.has(guide.map)) return 'Completato · Legacy (account)'
}

export interface DungeonProgress {
  maps: number[]
  legacy: number[]
  quests?: number[]
  active?: number[]
}

export function dungeonProgressFrom(value: unknown, name: unknown): DungeonProgress | undefined {
  if (typeof name !== 'string' || !name || !value || typeof value !== 'object') return
  const report = value as { name?: unknown; maps?: unknown; legacy?: unknown; quests?: unknown; active?: unknown }
  if (report.name !== name || !Array.isArray(report.maps)) return
  const positiveIds = (data: unknown, limit: number): number[] => Array.isArray(data)
    ? [...new Set(data.slice(0, limit).filter(
      (id): id is number => typeof id === 'number' && Number.isSafeInteger(id) && id > 0,
    ))]
    : []
  return {
    maps: positiveIds(report.maps, 128),
    legacy: positiveIds(report.legacy, 128),
    ...(Array.isArray(report.quests) && { quests: positiveIds(report.quests, 1024) }),
    ...(Array.isArray(report.active) && { active: positiveIds(report.active, 1024) }),
  }
}

export interface QuestPlace { zone: string; x?: number; y?: number }
export interface QuestSource {
  id: number
  kind: 'npc' | 'object' | 'item'
  name: string
  places: QuestPlace[]
  drops?: QuestSource[]
}
export interface QuestReference { id: number; name: string }
export interface QuestStep extends QuestReference {
  starts: QuestSource[]
  required: QuestReference[]
  alternatives: QuestReference[]
  previous?: QuestReference[]
  next?: QuestReference
}
export interface DungeonQuest extends QuestStep {
  level?: number
  faction?: 'A' | 'H'
  objectives: string[]
}
export interface DungeonLoot { id: number; name: string }
export const DUNGEON_LOOT_FILE = 'loot-items-v1.json'
export interface DungeonLootDetails {
  name?: string
  icon?: number
  quality?: number
  level?: number
  required?: number
  binding?: string
  slot?: string
  type?: string
  weapon?: { min: number; max: number; speed: number; dps: number; school?: string }
  armor?: number
  stats?: [label: string, amount: number][]
  effects?: { trigger: string; text: string }[]
  description?: string
}
export type DungeonLootDetailsById = Record<number, DungeonLootDetails>
export interface DungeonJournalData {
  quests: Record<number, DungeonQuest[]>
  loot: Record<number, Record<string, DungeonLoot[]>>
  questSteps?: Record<number, QuestStep>
}

export function questChain(quest: DungeonQuest, steps: DungeonJournalData['questSteps']) {
  const current = steps?.[quest.id] ?? quest
  const seen = new Set([quest.id])
  const before: { reference: QuestReference; step?: QuestStep }[] = []
  function visit(reference: QuestReference): void {
    if (seen.has(reference.id)) return
    seen.add(reference.id)
    const step = steps?.[reference.id]
    if (step) for (const prior of [...step.required, ...step.alternatives, ...(step.previous ?? [])]) visit(prior)
    before.push({ reference, step })
  }
  for (const prior of [...current.required, ...current.alternatives, ...(current.previous ?? [])]) visit(prior)
  const after: typeof before = []
  let next = current.next
  while (next && !seen.has(next.id)) {
    seen.add(next.id)
    const step = steps?.[next.id]
    after.push({ reference: next, step })
    next = step?.next
  }
  return { before, current, after }
}
