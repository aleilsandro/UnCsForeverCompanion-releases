export interface CityPiece {file:number;north:number;west:number;side:number;angle:number;u1:number;v0:number}
export interface CityMini {id:number;world:number;pieces:CityPiece[]}
/** Only the two underground capitals' numeric minimap records from the locally installed addon. */
export function parseCityMinis(source:string):CityMini[] {
  const out:CityMini[]=[]
  for(const match of source.matchAll(/^\s*\[(1455|1458)\]\s*=\s*\{\s*([01])\s*,[^{}]*\{\s*([^{}]+)\}/gm)) {
    const values=match[3]!.split(',').map(s=>s.trim()).filter(Boolean).map(Number)
    if(!values.length || values.length%7 || values.length>3500 || values.some(v=>!Number.isFinite(v)))continue
    const pieces:CityPiece[]=[]
    for(let i=0;i<values.length;i+=7) {
      const [file,north,west,side,angle,u1,v0]=values.slice(i,i+7) as [number,number,number,number,number,number,number]
      if(!Number.isSafeInteger(file) || file<=0 || file>=1_000_000_000 || side<=0 || side>512 || u1<1 || u1>4 || v0>0 || v0 < -3) {pieces.length=0;break}
      pieces.push({file,north,west,side,angle,u1,v0})
    }
    if(pieces.length)out.push({id:Number(match[1]),world:Number(match[2]),pieces})
  }
  return out
}
export const isUndergroundCity=(id:number):boolean=>id===1455 || id===1458
