import {expect,test} from 'vitest'
import {cityBannerBounds,parseCityBanners} from './city-banner'
import type {GameMap} from './maps'
test('places original banner over the matching zone and rejects unrecognized cutouts',()=>{
  const map:GameMap={id:1411,name:'Durotar',parent:1414,level:'zone',continent:1,rect:{minX:0,minY:0,maxX:100,maxY:100},area:14}
  const rows='[1454] = { 1411, 276, 7, 512, 128 },\n[9999] = { 1411, 0, 0, 512, 128 },'
  const banners=parseCityBanners(rows,[map]);expect(banners).toHaveLength(1)
  const geometry={l:0,r:100000,t:0,b:100000,ax:100,ay:100,zx:0,zy:0}
  expect(cityBannerBounds(banners[0]!,{g:geometry,swap:false})).toEqual([276,7,788,135])
})
