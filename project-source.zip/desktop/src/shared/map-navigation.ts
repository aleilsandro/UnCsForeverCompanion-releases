import { dungeonEntrances } from './dungeon-entrances'
import type { QuestPlace } from './dungeon-journal'
import { flightCatalog } from './flight-catalog'
import type { FlightStatus } from './flight-points'
import { unitsOfWorld } from './geo'
import { mapServiceLayers, professionFilters, professionsOf, type MapServiceLayer, type MapServicePin, type ProfessionFilter } from './map-services'
import type { Continent, GameMap } from './maps'
import { zoneAt } from './point-label'
import { fold, wordsMatch } from './search'
import { serves } from './services'
import { transportRoutes } from './transport-routes'

export interface WorldPoint { world: Continent; north: number; west: number }

export function worldPointFrom(value: unknown): WorldPoint | undefined {
  if (!value || typeof value !== 'object') return
  const { world, north, west } = value as Partial<WorldPoint>
  if ((world === 0 || world === 1) && typeof north === 'number' && typeof west === 'number' &&
      Number.isFinite(north) && Number.isFinite(west)) return { world, north, west }
}

export const navigationKinds = [
  ...mapServiceLayers,
  { id: 'flight', label: 'Punti volo' },
  { id: 'dungeon', label: 'Dungeon' },
  { id: 'boat', label: 'Navi' },
  { id: 'zeppelin', label: 'Zeppelin' },
] as const
export type NavigationKind = MapServiceLayer | 'flight' | 'dungeon' | 'boat' | 'zeppelin'
export type NearestKind = Exclude<NavigationKind, 'profession'> | ProfessionFilter

const terms: Record<NavigationKind, string> = {
  inn: 'locanda taverna inn innkeeper', mailbox: 'posta mail mailbox cassetta',
  vendor: 'venditore mercante vendor shop', repair: 'riparazione riparatore repair',
  profession: 'istruttore trainer professione', class: 'istruttore trainer classe',
  bank: 'banca banker bank', auction: 'casa asta auction auctioneer',
  flight: 'punto volo maestro flight master', dungeon: 'dungeon istanza',
  boat: 'nave barca boat ship porto', zeppelin: 'zeppelin dirigibile',
}
const stopWords = new Set(['a', 'da', 'di', 'del', 'della', 'delle', 'il', 'la', 'in', 'per', 'of', 'the'])

export interface NavigationPlace extends WorldPoint {
  key: string
  kind: NavigationKind
  name: string
  detail: string
  zone: string
  image: string
  known?: boolean
  words: string
}

export function dungeonLocation(id: number, x: number, y: number, maps: GameMap[]): WorldPoint | undefined {
  if (id === 0 || id === 1) return { world: id, north: x, west: y }
  const map = maps.find(zone => zone.id === id)
  if (!map?.rect || map.continent === null) return
  const { minX, maxX, minY, maxY } = map.rect
  return { world: map.continent, north: maxX - y * (maxX - minX), west: maxY - x * (maxY - minY) }
}

export function questWorldPoint(place: QuestPlace, maps: GameMap[]): WorldPoint | undefined {
  const { x, y } = place
  if (x === undefined || y === undefined || !Number.isFinite(x) || !Number.isFinite(y) || x < 0 || x > 100 || y < 0 || y > 100) return
  const zone = maps.find(zone => zone.name === place.zone && zone.level === 'zone' && zone.rect && zone.continent !== null)
  if (zone) return dungeonLocation(zone.id, x / 100, y / 100, maps)
}

export function navigationIndex(maps: GameMap[], services: MapServicePin[], flights?: FlightStatus): NavigationPlace[] {
  const places = new Map<string, NavigationPlace>()
  const add = ({ world, north, west }: WorldPoint, kind: NavigationKind, name: string, detail = '', known?: boolean): void => {
    const key = JSON.stringify([kind, name, world, north, west])
    if (places.has(key)) return
    const zone = zoneAt(maps, world, unitsOfWorld(north, west))?.zone.name ?? ''
    const category = navigationKinds.find(value => value.id === kind)!.label
    const professions = kind === 'profession' ? professionsOf(detail).map(({ label }) => label) : []
    const words = fold([name, detail, zone, category, terms[kind], ...professions].join(' '))
    const image = kind === 'flight' ? (known ? 'flight-known' : 'flight-locked') : kind
    places.set(key, { world, north, west, key, kind, name, detail: detail || category, zone, image, known, words })
  }
  for (const entry of services) {
    if (!serves(entry, flights?.side)) continue
    for (const kind of entry.layers) add(entry, kind, entry.name, entry.sub)
  }
  const faction = flights?.side === 'A' ? 1 : flights?.side === 'H' ? 2 : 3
  for (const [id, name, world, north, west, sides] of flightCatalog) {
    if (!(sides & faction) || (world !== 0 && world !== 1)) continue
    const known = flights?.known.includes(id)
    const detail = known ? 'Punto volo sbloccato' : flights?.checked.includes(world) ? 'Punto volo bloccato' : 'Punto volo da verificare'
    add({ world, north, west }, 'flight', name, detail, known)
  }
  for (const [id, x, y, entrances] of dungeonEntrances) {
    const point = dungeonLocation(id, x, y, maps)
    if (!point) continue
    for (const [name, min, max] of entrances) add(point, 'dungeon', name, `Dungeon · Liv. ${min === max ? min : `${min}–${max}`}`)
  }
  for (const [kind, stops] of transportRoutes) {
    stops.forEach(([from, world, north, west], i) => {
      if (world !== 0 && world !== 1) return
      const [to] = stops[(i + 1) % stops.length]!
      add({ world, north, west }, kind, `Da ${from} a ${to}`, kind === 'boat' ? 'Tratta in nave' : 'Tratta in zeppelin')
    })
  }
  return [...places.values()]
}

export function searchPlaces(places: NavigationPlace[], typed: string): NavigationPlace[] {
  const query = fold(typed).split(' ').filter(word => word && !stopWords.has(word)).join(' ')
  if (!query) return []
  const score = (name: string): number => name === query ? 0 : name.startsWith(query) ? 1 : 2
  return places.filter(place => wordsMatch(place.words, query))
    .map(place => ({ place, order: score(fold(place.name)) }))
    .sort((a, b) => a.order - b.order || a.place.name.localeCompare(b.place.name))
    .slice(0, 12).map(({ place }) => place)
}

export function nearestPlaces(places: NavigationPlace[], origin: WorldPoint, filter: NearestKind): { place: NavigationPlace; yards: number }[] {
  const profession = professionFilters.find(({ id }) => id === filter)
  const kind = profession ? 'profession' : filter
  return places.filter(place => place.kind === kind && place.world === origin.world &&
      (kind !== 'flight' || place.known) && (!profession || profession.trainer.test(place.detail)))
    .map(place => ({ place, yards: Math.hypot(place.north - origin.north, place.west - origin.west) }))
    .sort((a, b) => a.yards - b.yards)
    .slice(0, 8)
}
