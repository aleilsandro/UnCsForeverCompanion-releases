import { expect, test } from 'vitest'
import { parseNativeTileList } from './native-tiles'
test('parses continent and tile keys without executing addon code', () => {
  const t = 'ns.MapMinimap = {\n [0] = {\n [65] = 456, [4096] = 123\n },\n [1] = {\n [130] = 789\n },\n}'
  expect(parseNativeTileList(t)).toEqual([[0,1,1,456],[1,2,2,789]])
})
