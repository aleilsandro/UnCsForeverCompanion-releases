import type {GameMap} from './maps'
import {project,type Calibrated} from './map-detail'
export interface CityBanner {id:number; zone:number; x:number;y:number;w:number;h:number; map:GameMap}
/** Position each locally installed banner using the corresponding zone's game coordinates. */
export function parseCityBanners(source:string,maps:GameMap[]):CityBanner[] {
  const selected=new Set([1454,1456,1457,1458]),out:CityBanner[]=[]
  for(const m of source.matchAll(/^\s*\[(\d+)\]\s*=\s*\{\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\}/gm)) {
    const [id,zone,x,y,w,h]=m.slice(1).map(Number) as [number,number,number,number,number,number]
    const map=maps.find(r=>r.id===zone)
    if(!selected.has(id)||!map?.rect || (map.continent!==0 && map.continent!==1) || w<=0 || h<=0 || x+w>1002 || y+h>668)continue
    if(![map.rect.minX,map.rect.minY,map.rect.maxX,map.rect.maxY].every(Number.isFinite))continue
    out.push({id,zone,x,y,w,h,map})
  }
  return out
}
/** Bounds on the 1002×668 world artwork, using the zone art's pixel placement. */
export function cityBannerBounds(entry:CityBanner,calibration:Calibrated):[number,number,number,number]|null {
  const rect=entry.map.rect;if(!rect)return null
  const {g,swap}=calibration
  const a=project(g,rect.maxX,rect.maxY,swap),z=project(g,rect.minX,rect.minY,swap)
  const left=Math.min(a[0],z[0]),top=Math.min(a[1],z[1]),w=Math.abs(z[0]-a[0]),h=Math.abs(z[1]-a[1])
  return [(left+w*entry.x/1002)*1002,(top+h*entry.y/668)*668,(left+w*(entry.x+entry.w)/1002)*1002,(top+h*(entry.y+entry.h)/668)*668]
}
