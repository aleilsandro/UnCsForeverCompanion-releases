import { expect, test } from 'vitest'
import { cityFrom } from './city'

test('accepts a bounded Ironforge tile manifest and rejects malformed data', () => {
  const city={id:1455,l:100,r:200,t:300,b:400,w:500,h:300,tw:256,th:256,files:[1,2,3,4]}
  expect(cityFrom(city)).toEqual(city)
  expect(cityFrom({...city,files:[1]})).toBeNull()
  expect(cityFrom({...city,files:[1,2,3,-4]})).toBeNull()
  expect(cityFrom({...city,w:100000})).toBeNull()
  expect(cityFrom({...city,id:1454})).not.toBeNull()
  expect(cityFrom({...city,id:42})).toBeNull()
})
