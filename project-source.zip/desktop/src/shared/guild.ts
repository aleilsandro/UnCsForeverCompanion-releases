export interface GuildMember { name:string; cls?:string; level?:number; zone?:string; x?:number; y?:number; exact:boolean }
/** Online roster from the addon. Coordinates are on the world canvas, in hundred-thousandths. */
export function guildFrom(section:unknown,age=0):GuildMember[] {
  if(age>60_000 || !section || typeof section!=='object') return []
  const list=(section as {list?:unknown}).list
  if(!Array.isArray(list)) return []
  return list.flatMap((value):GuildMember[]=>{
    if(!value || typeof value!=='object')return []
    const e=value as Record<string,unknown>
    if(typeof e.n!=='string' || !e.n.trim() || e.n.length>128)return []
    const placed=typeof e.x==='number' && Number.isFinite(e.x) && e.x>=0 && e.x<=100000 && typeof e.y==='number' && Number.isFinite(e.y) && e.y>=0 && e.y<=100000
    return [{name:e.n,cls:typeof e.c==='string' ? e.c : undefined,level:typeof e.l==='number' && Number.isFinite(e.l) ? e.l : undefined,zone:typeof e.z==='string' ? e.z : undefined,...(placed ? {x:e.x as number,y:e.y as number} : {}),exact:placed && e.exact===true}]
  })
}
