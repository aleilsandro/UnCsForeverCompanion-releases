export const GATHERING_FILE = 'gathering-v1.json'
export const gatheringProfessions = [
  { id: 'mining', label: 'Estrazione mineraria' },
  { id: 'herbalism', label: 'Erbalismo' },
  { id: 'fishing', label: 'Pesca' },
  { id: 'skinning', label: 'Scuoiatura' },
] as const

export type GatheringProfession = (typeof gatheringProfessions)[number]['id']
export type SkillRange = [min: number, max: number]
export type ZoneGathering = Partial<Record<GatheringProfession, SkillRange>>
export type GatheringByZone = Record<number, ZoneGathering>

export function gatheringFilter(value: unknown): GatheringProfession[] {
  return Array.isArray(value) ? gatheringProfessions.flatMap(({ id }) => value.includes(id) ? [id] : []) : []
}

export function gatheringSkill(profession: GatheringProfession, range?: SkillRange): string {
  if (!range) return 'Dati non disponibili'
  const [min, max] = range
  if (profession === 'fishing') return `Min. ${min} · senza fughe ${max} (Classic)`
  const value = min === max ? String(min) : `${min}–${max}`
  return profession === 'skinning' ? `Stima ${value} (Classic)` : value
}
