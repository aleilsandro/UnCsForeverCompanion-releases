import { expect, test } from 'vitest'
import { prepareDungeon } from './dungeon-preparation'
import type { DungeonQuest, QuestPlace } from './dungeon-journal'
import type { WorldPoint } from './map-navigation'

const point = (north: number, world: 0 | 1 = 0, west = 0): WorldPoint => ({ world, north, west })
const locate = ({ zone, x }: QuestPlace) => x === undefined ? undefined : point(x, zone === 'Kalimdor' ? 1 : 0)
const source = (x: number, name = 'NPC') => ({ id: 1, name, kind: 'npc' as const, places: [{ zone: 'Eastern Kingdoms', x }] })
const quest = (id: number, x: number, fields: Partial<DungeonQuest> = {}): DungeonQuest => ({
  id, name: 'Quest ' + id, starts: [source(x)], required: [], alternatives: [], objectives: [], ...fields,
})
const options = {
  origin: point(0), entrance: { point: point(1000), label: 'Portale', actions: [] },
  along: false, side: 'A' as const, level: 30, locate, steps: {},
}

test('quest stops respect chains, choose a nearby alternative, and skip progress or ineligible quests', () => {
  const first = quest(1, 300)
  const alternatives = [quest(2, 8000), quest(3, 310)]
  const root = quest(4, 150, { required: [first], alternatives })
  const result = prepareDungeon({
    ...options, quests: [root, quest(5, 12), quest(6, 13), quest(7, 14, { faction: 'H' }), quest(8, 15, { level: 40 })],
    steps: Object.fromEntries([first, ...alternatives].map(entry => [entry.id, entry])),
    completed: new Set([5]), active: new Set([6]),
  })
  expect(result.stops.flatMap(stop => stop.actions.map(action => action.id))).toEqual([1, 3, 4])
  expect(result.stops.at(-1)?.label).toBe('Portale')
  expect(result.unmapped).toEqual([])
})

test('the nearby mode omits large detours and an in-progress prerequisite does not unlock its quest', () => {
  const first = quest(1, 330)
  const root = quest(2, 150, { required: [first] })
  const far = quest(3, 10000)
  const result = prepareDungeon({
    ...options, along: true, quests: [root, far, quest(4, 430)], steps: { 1: first }, active: new Set([1]),
  })
  expect(result.stops.flatMap(stop => stop.actions.map(action => action.id))).toEqual([4])
  expect(result.unmapped).toEqual(['Quest 2', 'Quest 3'])
})

test('cross-continent routes use a recorded transport leg and never link continents by walking', () => {
  const result = prepareDungeon({
    ...options, origin: point(-1005.6, 1, -3841.6),
    entrance: { point: point(-14277.7, 0, 582.9), label: 'Portale', actions: [] }, quests: [],
  })
  const boat = result.legs.find(leg => leg.kind === 'boat')
  expect(boat?.from.label).toBe('Ratchet')
  expect(boat?.to.label).toBe('Booty Bay')
  expect(boat?.tracks?.length).toBe(2)
  expect(result.legs.filter(leg => leg.kind === 'walk').every(leg => leg.from.point.world === leg.to.point.world)).toBe(true)
})
