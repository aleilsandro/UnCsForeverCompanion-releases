export interface WalletBalance {
  name: string
  realm: string
  money: number
  seen: number
}

type Expense = [timestamp: number, copper: number]

export interface FarmingSession {
  name: string
  seconds: number
  earned: number
  spent: number
  balance?: number
  vendor: number
  auction: number
  wallets: WalletBalance[]
  expenses?: Expense[]
  loot?: { value: number; count: number; unpriced: number }
}

const amount = (value: unknown): value is number =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value <= 1e12

export function farmingFrom(value: unknown, owner: unknown, walletReport?: unknown, expenseReport?: unknown): FarmingSession | undefined {
  if (!value || typeof value !== 'object' || typeof owner !== 'string' || !owner) return
  const { name, seconds, earned, spent, vendor, auction, loot, balance } = value as Partial<FarmingSession>
  if (name !== owner || !amount(seconds) || !amount(earned) || !amount(spent)
    || !amount(vendor) || !amount(auction) || vendor + auction > earned) return
  const ledger = (walletReport ?? value) as Partial<FarmingSession>
  const wallets = ledger.name === name ? ledger.wallets : undefined
  const balances = Array.isArray(wallets) ? wallets.slice(0, 100).filter(wallet =>
    wallet && typeof wallet.name === 'string' && wallet.name.length > 0 && wallet.name.length <= 128
    && typeof wallet.realm === 'string' && wallet.realm.length <= 128 && amount(wallet.money) && amount(wallet.seen),
  ).map(({ name, realm, money, seen }) => ({ name, realm, money, seen })) : []
  const history = (expenseReport ?? value) as Partial<FarmingSession>
  const expenses = history.name === name && Array.isArray(history.expenses)
    ? history.expenses.slice(0, 100).flatMap((entry): Expense[] =>
      Array.isArray(entry) && entry.length === 2 && amount(entry[0]) && amount(entry[1]) && entry[1] > 0
        ? [[entry[0], entry[1]]] : [])
    : undefined
  const estimate = amount(loot?.value) && amount(loot?.count) && amount(loot?.unpriced) && loot.unpriced <= loot.count
    ? { value: loot.value, count: loot.count, unpriced: loot.unpriced } : undefined
  return { name, seconds, earned, spent, vendor, auction, wallets: balances,
    ...(amount(balance) && { balance }), ...(expenses && { expenses }), ...(estimate && { loot: estimate }) }
}

export function formatCopper(copper: number): string {
  const absolute = Math.floor(Math.abs(copper))
  return (copper < 0 ? '−' : '') + Math.floor(absolute / 10_000).toLocaleString('it-IT')
    + 'o ' + String(Math.floor(absolute / 100) % 100).padStart(2, '0')
    + 'a ' + String(absolute % 100).padStart(2, '0') + 'r'
}
