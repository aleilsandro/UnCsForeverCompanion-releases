import type { Continent } from './maps'

export const mapServiceLayers = [
  { id: 'inn', label: 'Locande', zoom: 3 },
  { id: 'mailbox', label: 'Cassette della posta', zoom: 4 },
  { id: 'vendor', label: 'Venditori', zoom: 4.5 },
  { id: 'repair', label: 'Riparazioni', zoom: 4 },
  { id: 'profession', label: 'Istruttori di professione', zoom: 4.5 },
  { id: 'class', label: 'Istruttori di classe', zoom: 4 },
  { id: 'bank', label: 'Banche', zoom: 4 },
  { id: 'auction', label: "Case d’asta", zoom: 4 },
] as const

export type MapServiceLayer = typeof mapServiceLayers[number]['id']
export const standardServiceLayers = mapServiceLayers.filter(layer => layer.id !== 'profession')

export const professionFilters = [
  { id: 'alchemy', label: 'Alchimia', trainer: /alchem/i },
  { id: 'cooking', label: 'Cucina', trainer: /\bcook(?:ing)?\b/i },
  { id: 'herbalism', label: 'Erboristeria', trainer: /herbal/i },
  { id: 'blacksmithing', label: 'Forgiatura', trainer: /blacksmith|armorsmith|weaponsmith/i },
  { id: 'enchanting', label: 'Incantamento', trainer: /enchant/i },
  { id: 'engineering', label: 'Ingegneria', trainer: /engineer/i },
  { id: 'leatherworking', label: 'Conciatura', trainer: /leatherwork|leathercraft/i },
  { id: 'mining', label: 'Estrazione mineraria', trainer: /\b(?:miner|mining)\b/i },
  { id: 'fishing', label: 'Pesca', trainer: /fisher|fishing/i },
  { id: 'first-aid', label: 'Primo soccorso', trainer: /first aid|physician|trauma surgeon/i },
  { id: 'skinning', label: 'Scuoiatura', trainer: /skinn/i },
  { id: 'tailoring', label: 'Sartoria', trainer: /tailor/i },
] as const

export type ProfessionFilter = typeof professionFilters[number]['id']
export type MapServiceFilter = Exclude<MapServiceLayer, 'profession'> | ProfessionFilter
export const professionsOf = (subtitle = '') => professionFilters.filter(({ trainer }) => trainer.test(subtitle))

export interface MapServicePin {
  world: Continent
  north: number
  west: number
  name: string
  sub?: string
  side?: string
  layers: MapServiceLayer[]
}
