export interface City { id:number; l:number; r:number; t:number; b:number; w:number; h:number; tw:number; th:number; files:number[] }
export function cityFrom(value:unknown):City|null {
  if (!value || typeof value !== 'object') return null
  const c=value as City
  if (![1453,1454,1455,1456,1457,1458].includes(c.id) || ![c.l,c.r,c.t,c.b,c.w,c.h,c.tw,c.th].every(Number.isSafeInteger)) return null
  if (c.l<0 || c.t<0 || c.r>100000 || c.b>100000 || c.r<=c.l || c.b<=c.t) return null
  if (c.w<1 || c.h<1 || c.w>2048 || c.h>2048 || c.tw<1 || c.th<1 || c.tw>1024 || c.th>1024) return null
  if (!Array.isArray(c.files) || c.files.length!==Math.ceil(c.w/c.tw)*Math.ceil(c.h/c.th) || c.files.length>64 || !c.files.every(n=>Number.isSafeInteger(n) && n>0 && n<1_000_000_000)) return null
  return {id:c.id,l:c.l,r:c.r,t:c.t,b:c.b,w:c.w,h:c.h,tw:c.tw,th:c.th,files:c.files}
}
