import { expect, test } from 'vitest'
import { transportRoutes } from './transport-routes'

test('the seven boat routes have the right departure ports at Auberdine and Stormwind', () => {
  const boats = transportRoutes.filter(([kind]) => kind === 'boat')
  expect(boats).toHaveLength(7)
  const destinations = (port: string) => boats.flatMap(([, stops]) => stops
    .flatMap(([name], index) => name === port ? [stops[(index + 1) % stops.length]![0]] : []))
  expect(destinations('Stormwind Harbor')).toEqual(['Auberdine'])
  expect(destinations('Auberdine').sort()).toEqual(['Menethil Harbor', 'Rut’theran Village', 'Stormwind Harbor'])
})

test('each recorded leg begins at its dock and ends at the next stop', () => {
  for (const [, stops, legs] of transportRoutes) {
    expect(legs).toHaveLength(stops.length)
    for (const [index, segments] of legs.entries()) {
      const [, fromWorld, fromX, fromY] = stops[index]!
      const [, toWorld, toX, toY] = stops[(index + 1) % stops.length]!
      const [firstWorld, first] = segments[0]!
      const [lastWorld, last] = segments.at(-1)!
      expect(firstWorld).toBe(fromWorld)
      expect([first[0], first[1]]).toEqual([fromX, fromY])
      expect(lastWorld).toBe(toWorld)
      // Some vessels stop a few yards farther along the same dock on the return leg.
      expect(Math.hypot(last.at(-2)! - toX, last.at(-1)! - toY)).toBeLessThan(60)
      for (const [, points] of segments) {
        expect(points.length).toBeGreaterThanOrEqual(4)
        expect(points.length % 2).toBe(0)
      }
    }
  }
})
