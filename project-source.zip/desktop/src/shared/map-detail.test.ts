import { expect, test } from 'vitest'
import { calibrate, detailOpacity, geometryOf, project, tileRange } from './map-detail'
const g = {l:20000,r:60000,t:10000,b:50000,ax:1000,ay:2000,zx:-1000,zy:-2000}
test('projects the player and chooses only a verified axis order', () => {
  expect(project(g, 500,0,false)).toEqual([.4,.2])
  expect(calibrate(g,500,0,40000,20000)?.swap).toBe(false)
  expect(calibrate(g,500,0,30000,30000)?.swap).toBe(true)
  expect(calibrate(g,500,1000,90000,90000)).toBeNull()
})
test('rejects missing or degenerate calibration and fades smoothly', () => {
  expect(geometryOf({'0':g},0)).toEqual(g)
  expect(geometryOf({'0':{...g,zx:g.ax}},0)).toBeNull()
  expect(detailOpacity(3)).toBe(0)
  expect(detailOpacity(6)).toBe(.85)
  expect(detailOpacity(4.25)).toBeCloseTo(.425)
})

test('limits the terrain search to the visible part of the world in both axis orders', () => {
  for (const swap of [false,true]) {
    const [u,v] = project(g,500,0,swap)
    const r = tileRange(g,swap,1000,600,{west:(u-.001)*1000,east:(u+.001)*1000,north:(v-.001)*600,south:(v+.001)*600})!
    expect(r.col0).toBeLessThanOrEqual(32)
    expect(r.col1).toBeGreaterThanOrEqual(32)
    expect(r.row0).toBeLessThanOrEqual(31)
    expect(r.row1).toBeGreaterThanOrEqual(31)
    expect((r.col1-r.col0+1)*(r.row1-r.row0+1)).toBeLessThan(20)
  }
  expect(tileRange(g,false,1000,600,{west:5000,east:5100,north:5000,south:5100})).toBeNull()
})
