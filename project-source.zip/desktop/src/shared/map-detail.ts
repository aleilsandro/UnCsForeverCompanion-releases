/** Geometry in OpenMap's world canvas and game-world yards. */
export type Geometry = {l:number;r:number;t:number;b:number;ax:number;ay:number;zx:number;zy:number}
export type Calibrated = {g:Geometry; swap:boolean}
export function geometryOf(input: unknown, world: number): Geometry | null {
  if (!input || typeof input !== 'object' || (world !== 0 && world !== 1)) return null
  const value = (input as Record<string, unknown>)[String(world)]
  if (!value || typeof value !== 'object') return null
  const g = value as Geometry
  if (!(['l','r','t','b','ax','ay','zx','zy'] as const).every(k => typeof g[k] === 'number' && Number.isFinite(g[k]))) return null
  return g.r > g.l && g.b > g.t && g.ax !== g.zx && g.ay !== g.zy ? g : null
}
export function project(g: Geometry, north: number, west: number, swap: boolean): [number,number] {
  const x = swap ? (north-g.ax)/(g.zx-g.ax) : (west-g.ay)/(g.zy-g.ay)
  const y = swap ? (west-g.ay)/(g.zy-g.ay) : (north-g.ax)/(g.zx-g.ax)
  return [(g.l+x*(g.r-g.l))/100000, (g.t+y*(g.b-g.t))/100000]
}
/** Reject an uncertain projection: an incorrectly aligned map is worse than no detail. */
export function calibrate(g: Geometry, north:number, west:number, wx:number, wy:number, preferred?:boolean): Calibrated | null {
  if (![north,west,wx,wy].every(Number.isFinite)) return null
  const distance = (swap:boolean):number => { const [u,v] = project(g,north,west,swap); return Math.hypot(u-wx/100000,v-wy/100000) }
  const normal = distance(false), swapped = distance(true)
  if (Math.min(normal,swapped) > .002) return null
  // Near the diagonal both axis orders can appear correct; keep a validated choice.
  const swap = preferred !== undefined && (preferred ? swapped : normal) <= .002 ? preferred : swapped + .0001 < normal
  return {g,swap}
}
export function detailOpacity(zoom:number):number {
  const t = Math.max(0,Math.min(1,(zoom-3.5)/1.5))
  return .85*t*t*(3-2*t)
}
/** Project a game-world north/west point into map-canvas coordinates. */
export function tileRange(g:Geometry, swap:boolean, canvasWidth:number, canvasHeight:number, view:{west:number;east:number;north:number;south:number}): { col0:number;col1:number;row0:number;row1:number } | null {
  const [u0,v0]=project(g,0,0,swap), [un,vn]=project(g,1,0,swap), [uw,vw]=project(g,0,1,swap)
  const a=un-u0,b=uw-u0,c=vn-v0,d=vw-v0,det=a*d-b*c
  if (!Number.isFinite(det) || Math.abs(det)<1e-16 || canvasWidth<=0 || canvasHeight<=0) return null
  const points = [[view.west,view.north],[view.east,view.north],[view.west,view.south],[view.east,view.south]].map(([x,y]) => {
    const du=x!/canvasWidth-u0, dv=y!/canvasHeight-v0
    return {north:(du*d-b*dv)/det,west:(a*dv-du*c)/det}
  })
  const tile=1600/3
  const cols=points.map(p=>32-p.west/tile),rows=points.map(p=>32-p.north/tile)
  const clamp=(x:number)=>Math.max(0,Math.min(63,x))
  if (Math.max(...cols)<0 || Math.min(...cols)>=64 || Math.max(...rows)<0 || Math.min(...rows)>=64) return null
  return {col0:clamp(Math.floor(Math.min(...cols))),col1:clamp(Math.floor(Math.max(...cols))),row0:clamp(Math.floor(Math.min(...rows))),row1:clamp(Math.floor(Math.max(...rows)))}
}
