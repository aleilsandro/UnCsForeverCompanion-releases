import {expect,test} from 'vitest'
import {isUndergroundCity,parseCityMinis} from './city-mini'
test('reads only validated underground city minimap pieces',()=>{
  const source='ns.MapCityMinimap = {\n [1455] = { 0, -10, -20, 10, 20, { 8113682, -4, -9, 128, 3.831, 1, 0, 8113689, -5, -8, 64, 3.831, 2, -1 } },\n [1458] = { 0, 0, 0, 10, 10, { 0, 0, 0, 128, 0, 1, 0 } },\n}'
  const result=parseCityMinis(source)
  expect(result).toHaveLength(1)
  expect(result[0]?.pieces).toHaveLength(2)
  expect(result[0]?.pieces[1]).toMatchObject({file:8113689,u1:2,v0:-1})
  expect([1453,1454,1455,1456,1457,1458].filter(isUndergroundCity)).toEqual([1455,1458])
})
