// Dungeon entrances and Group Finder ranges from the OpenMap data for Forever (MIT).
// https://github.com/openmap-world/openmap/blob/6c2299f6e1f9bdce1bbd92145f84a05b0c6c05a7/OpenMap/Data/Forever/Places.lua
// The map ID is 0 or 1 for world yards (north, west), otherwise a zone (x, y from 0 to 1).
type Dungeon = [name: string, min: number, max: number]
export const dungeonEntrances: [map: number, x: number, y: number, dungeons: Dungeon[]][] = [
  [0, -231.0, 1571.6, [["Shadowfang Keep", 20, 30]]],
  [0, -8762.4, 848.0, [["Stormwind Stockade", 24, 32]]],
  [0, -11207.8, 1681.2, [["Deadmines", 17, 26]]],
  [1, -751.1, -2209.2, [["Wailing Caverns", 15, 24]]],
  [1, -4459.4, -1660.2, [["Razorfen Kraul", 29, 38]]],
  [1, 4249.1, 748.4, [["Blackfathom Deeps", 24, 32]]],
  [0, -6060.2, -2955.0, [["Uldaman", 41, 51]]],
  [0, -5162.7, 931.6, [["Gnomeregan", 29, 38]]],
  [0, -10170.1, -3996.0, [["Sunken Temple", 50, 60]]],
  [1, -4662.9, -2535.9, [["Razorfen Downs", 37, 46]]],
  [0, 2892.2, -811.3, [["Scarlet Monastery - Graveyard", 30, 38], ["Scarlet Monastery - Library", 33, 41], ["Scarlet Monastery - Armory", 36, 44], ["Scarlet Monastery - Cathedral", 38, 46]]],
  [1, -6790.6, -2891.3, [["Zul'Farrak", 44, 54]]],
  [0, -7522.5, -1233.0, [["Lower Blackrock Spire", 55, 60], ["Upper Blackrock Spire", 59, 60]]],
  [0, -7178.1, -928.6, [["Blackrock Depths", 52, 60]]],
  [0, 1274.8, -2552.6, [["Scholomance", 58, 60]]],
  [0, 3392.3, -3378.5, [["Stratholme", 58, 60]]],
  [1, -1432.7, 2925.0, [["Maraudon", 46, 55]]],
  [1, 1816.8, -4423.4, [["Ragefire Chasm", 13, 18]]],
  [1, -3908.0, 1130.0, [["Dire Maul - East", 54, 60], ["Dire Maul - West", 56, 60], ["Dire Maul - North", 56, 60]]],
  [1416, 0.085, 0.593, [["City of Dalaran", 28, 35]]],
  [1434, 0.213, 0.278, [["The Drowned City", 35, 42]]],
  [1447, 0.386, 0.332, [["Blackmaw Hold", 55, 60]]],
  [1445, 0.753, 0.141, [["Alcaz Prison", 48, 55]]],
  [1437, 0.478, 0.562, [["Excavation Site: Wetlands", 26, 33]]],
  [1458, 0.725, 0.114, [["Ruins of Lordaeron", 15, 22]]],
  [1449, 0.481, 0.061, [["Shaper's Terrace", 58, 60]]],
  [2548, 0.375, 0.373, [["Krol'dok Stronghold", 40, 47]]],
  [1455, 0.277, 0.479, [["The Hall of Thanes", 13, 20]]],
]
