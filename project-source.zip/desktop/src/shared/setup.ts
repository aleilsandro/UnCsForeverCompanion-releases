// The first run: its pages, one thing each, and what each says.
import type { LinkStatus } from './link'
import { BUILT_ONCE, tilesHelp, type TilesStatus } from './tiles-status'

/** What the main process tells the window about the game folder and the addons in it. */
export interface SetupStatus {
  /** The folder of World of Warcraft: Forever, or null while none is found. */
  gameFolder: string | null
  /** Identifies the local map data used to validate saved alignment. */
  mapRevision?: string
  webPublishing?: boolean
  webBridge?: boolean
  /** The version of the UnCs Forever Companion addon found in it, or null. */
  addon: string | null
  /** QuestieDB is among the addons: the data the app reads, with or without Questie itself. */
  questie: boolean
  /** Shortest Path Forever is among the addons. */
  shortestPath: boolean
  /** The first run was gone through once, in this run or an earlier one. */
  done: boolean
  /** The version of this app. */
  version: string
  /** The player asked for the window to stay over the others. */
  onTop: boolean
  /** The map on the home network: the address a phone opens, or why it cannot be had. Absent or null while it is off. */
  lan?: { url: string } | { error: string } | null
}

/** Where the addon is published. The app never installs it itself: every install is one CurseForge counts. */
export const CURSEFORGE = 'https://www.curseforge.com/wow/addons/twinmap-forever'

/** Said on the map when the game is found and the addon is not in it: without it no position ever comes. */
export const ADDON_MISSING = 'UnCs Forever Companion non e installato: copia la cartella addon in Interface/AddOns e riavvia WoW.'

/** The optional addons the app points to, each with its name and its page on CurseForge. */
export const OPTIONAL = {
  questie: { name: 'QuestieDB', page: 'https://www.curseforge.com/wow/addons/questiedb' },
  shortestPath: { name: 'Shortest Path', page: 'https://www.curseforge.com/wow/addons/shortest-path-forever' },
} as const
export type Optional = keyof typeof OPTIONAL

/** The page on CurseForge the window may open: the one of an optional addon it names, else the one of UnCs Forever Companion. */
export const pageOf = (asked: unknown): string => (typeof asked === 'string' && Object.hasOwn(OPTIONAL, asked) ? OPTIONAL[asked as Optional].page : CURSEFORGE)

export type PageState = 'done' | 'todo' | 'working' | 'problem'
export interface Page {
  id: 'game' | 'map' | 'addon' | 'extras' | 'play'
  title: string
  /** Why this page is there, in a sentence or two. */
  intro: string
  state: PageState
  /** What is true now, and what to do when something is to be done. The first line is the one that matters. */
  lines: string[]
  /** Percent done, while the app is working on it. */
  progress?: number
  action?: 'choose-folder' | 'curseforge' | 'retry'
  /** The optional addons that are not installed: each gets a button to its page on CurseForge. */
  get?: Optional[]
  /** Said on the page whatever its state: it must be read before the thing it warns of is on. */
  warning?: string
}

/** The addon's strip flickers. Said where the addon is taken and where the game is started. */
export const PHOTOSENSITIVITY =
  'Photosensitivity warning: the addon sends data by changing the colors of a one pixel line at the edge of the game window, many times per second. Its settings in the game can slow it down or pause it.'

const count = (n: number): string => n.toLocaleString('en-US')

/** The five pages of the first run, in order. */
export function setupPages(setup: SetupStatus, tiles: TilesStatus | null, link: LinkStatus | null): Page[] {
  const game: Page = {
    id: 'game',
    title: 'Find the game',
    intro: 'Twinmap needs to know where World of Warcraft: Forever is installed. It only reads from that folder; it never changes anything in it.',
    action: 'choose-folder',
    ...(setup.gameFolder
      ? { state: 'done', lines: ['Found.', setup.gameFolder] }
      : { state: 'todo', lines: ['The game was not found on this PC.', 'Choose the folder it is installed in: the one that holds _forever_.'] }),
  }

  const map: Page = {
    id: 'map',
    title: 'Build the map',
    intro: "Twinmap draws its map from your own game's files, so it always matches your version of the game. This is done once, and again only after the game updates. Nothing is downloaded.",
    ...(!setup.gameFolder || !tiles || tiles.state === 'no-game'
      ? { state: 'todo', lines: ['Waiting for the game folder.'] }
      : tiles.state === 'looking'
        ? { state: 'working', lines: ["Opening the game's files."], progress: 0 }
        : tiles.state === 'converting'
          ? { state: 'working', lines: ["Reading the game's own pictures of the world.", BUILT_ONCE], progress: tiles.percent }
          : tiles.state === 'failed'
            ? { state: 'problem', lines: ['The map could not be built.', tiles.message, tilesHelp(tiles)!], action: 'retry' }
            : { state: 'done', lines: ['The map is ready.', `${count(tiles.tiles)} tiles from game version ${tiles.version}.`] }),
  }

  const addon: Page = {
    id: 'addon',
    title: 'Get the addon',
    intro: "L'addon UnCs Forever Companion comunica la posizione al programma. Installa la cartella inclusa in Interface/AddOns.",
    warning: PHOTOSENSITIVITY,
    ...(setup.addon
      ? { state: 'done', lines: ['Installed.', `UnCs Forever Companion ${setup.addon} is in the game's AddOns folder.`] }
      : {
          state: 'todo',
          lines: [
            'Not installed yet.',
            'Copy the included UnCsForeverCompanion folder into _forever_\\Interface\\AddOns.',
            'This page notices by itself when the addon is there.',
          ],
        }),
  }

  const extras: Page = {
    id: 'extras',
    title: 'Optional addons',
    intro: 'None of these is needed. When one is installed, Twinmap shows more.',
    state: 'done',
    lines: [
      setup.questie
        ? 'QuestieDB: installed. The map shows who offers a service, ore, herbs and the quests of your log. With Questie running too, it shows the same quests Questie shows, the ones to take as well.'
        : 'QuestieDB: not installed. It comes with UnCs Forever Companion from the CurseForge app. Without it the map has no NPCs, no services and no quests.',
      setup.shortestPath
        ? 'Shortest Path: installed. The map will show its journey, and what you send to the game is reached along the roads.'
        : 'Shortest Path: not installed. With it, the map shows the journey it plans, and what you send to the game is reached along the roads.',
    ],
    get: (['questie', 'shortestPath'] as const).filter((addon) => !setup[addon]),
  }

  const live = link?.kind === 'connected' || link?.kind === 'combat'
  const play: Page = {
    id: 'play',
    title: 'Start the game',
    intro: 'Start World of Warcraft: Forever and log in with a character. Your position appears here on its own.',
    warning: PHOTOSENSITIVITY,
    ...(live
      ? { state: 'done', lines: ['Connected. Your position is coming through.'] }
      : link?.kind === 'update-app' || link?.kind === 'update-addon'
        ? { state: 'problem', lines: [link.line ?? link.word] }
        : {
            state: 'todo',
            lines: [
              link?.kind === 'lost' || link?.kind === 'waiting'
                ? 'The game is open, but nothing comes from the addon yet.'
                : link?.kind === 'minimized'
                  ? 'The game is minimized. Bring its window back on screen.'
                  : 'Waiting for the game.',
              'At the character list, open AddOns and make sure UnCs Forever Companion is ticked.',
            ],
          }),
  }
  return [game, map, addon, extras, play]
}

/** Game found, map built, addon installed, position coming: nothing is left to do. */
export const setupComplete = (pages: Page[]): boolean => pages.every((p) => p.state === 'done')

/**
 * How long the map still takes, in words, from when the work was first seen and how far it was
 * then. Nothing in the first seconds, or while nothing has moved: a guess from too little jumps about.
 */
export function timeLeft(startedAt: number, startedPercent: number, now: number, percent: number): string {
  const elapsed = (now - startedAt) / 1000, gained = percent - startedPercent
  if (elapsed < 3 || gained <= 0 || percent >= 100) return ''
  const seconds = Math.max(1, Math.round(((100 - percent) / gained) * elapsed))
  return seconds < 60 ? `about ${Math.ceil(seconds / 5) * 5} seconds left` : `about ${Math.round(seconds / 60)} min left`
}
