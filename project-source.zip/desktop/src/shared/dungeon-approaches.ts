// Waypoints checked against the Forever approach maps and the atlas portal coordinates.
// Approach maps: https://wowbocho.com/forever/dungeon/ ; the classic portal references
// for split entrances were checked against https://github.com/mangoszero/database/blob/master/World/Setup/FullDB/areatrigger_teleport.sql
// The original world and cave images are loaded from the map package.
type Point = [north: number, west: number]
export interface DungeonApproach { map: number; start: Point; label: string; directions: string; routes?: { label: string; points: Point[] }[] }

export const dungeonApproaches: Record<string, DungeonApproach> = {
  "Deadmines": {
    map: 0, start: [-11074.8,1521.2], label: "Ingresso delle miniere",
    directions: "Entra nell’edificio di Moonbrook. Segui i passaggi interni e scendi lungo le rampe della miniera fino al portale.",
    routes: [
      { label: "Portale del dungeon", points: [[-11074.8,1521.2],[-11079.8,1517.7],[-11077.3,1496.2],[-11090.3,1496.2],[-11096.3,1509.2],[-11099.3,1487.2],[-11105.3,1485.7],[-11103.3,1494.2],[-11100.3,1489.7],[-11115.3,1479.7],[-11124.8,1478.2],[-11130.8,1482.7],[-11130.8,1491.7],[-11125.3,1501.7],[-11103.3,1515.2],[-11098.8,1512.2],[-11100.8,1502.7],[-11106.8,1499.2],[-11139.8,1518.2],[-11140.3,1537.7],[-11159.3,1563.2],[-11172.8,1570.2],[-11198.8,1567.2],[-11227.3,1555.2],[-11246.8,1561.2],[-11250.8,1569.2],[-11248.8,1577.2],[-11229.8,1597.7],[-11226.8,1617.2],[-11226.8,1637.7],[-11233.3,1653.2],[-11243.8,1647.7],[-11235.8,1638.2],[-11219.8,1634.2],[-11207.8,1681.2]] },
    ],
  },
  "Wailing Caverns": {
    map: 1, start: [-835.6,-2033.7], label: "Imbocco della grotta",
    directions: "Entra a Lushwater Oasis, aggira la caverna a nord e scendi lungo il lato ovest della grande sala orientale.",
    routes: [
      { label: "Portale del dungeon", points: [[-837.6,-2035.2],[-796.6,-2029.2],[-758.1,-2060.7],[-658.1,-2035.7],[-636.6,-2025.2],[-614.1,-2032.2],[-590.1,-2047.7],[-585.6,-2064.7],[-585.6,-2103.7],[-607.1,-2170.7],[-632.6,-2192.7],[-669.1,-2191.7],[-707.6,-2197.2],[-724.6,-2209.2],[-747.6,-2212.2],[-751.1,-2209.2]] },
    ],
  },
  "Blackfathom Deeps": {
    map: 1, start: [4123.6,872.9], label: "Ingresso delle rovine",
    directions: "Dalla spiaggia di Zoram Strand entra nelle rovine sommerse e segui le gallerie fino al portale.",
    routes: [
      { label: "Portale del dungeon", points: [[4124.1,872.9],[4152.6,870.4],[4152.6,903.4],[4152.6,898.9],[4168.6,925.9],[4175.1,926.4],[4245.1,894.4],[4304.1,898.9],[4313.1,881.4],[4314.1,868.9],[4275.6,837.4],[4232.6,775.9],[4226.6,751.9],[4227.6,740.4],[4232.6,735.9],[4241.1,736.9],[4249.1,748.4]] },
    ],
  },
  "Gnomeregan": {
    map: 0, start: [-5182.2,606.1], label: "Ingresso e ascensore",
    directions: "Prendi l’ascensore, poi tieni la sinistra nei tunnel verso il portale.",
    routes: [
      { label: "Portale del dungeon", points: [[-5172.7,630.6],[-5145.2,711.6],[-5088.7,716.1],[-5074.7,726.1],[-5060.2,795.1],[-5065.2,815.1],[-5075.7,833.1],[-5135.7,863.6],[-5158.2,904.1],[-5162.7,931.6]] },
    ],
  },
  "Uldaman": {
    map: 0, start: [-6091.7,-3129.5], label: "Ingresso dello scavo",
    directions: "Entra nello scavo a nord di Angor Fortress e segui la galleria fino alla porta di pietra.",
    routes: [
      { label: "Portale del dungeon", points: [[-6091.2,-3129.5],[-6094.2,-3123.5],[-6094.2,-3017.5],[-6088.2,-3011.5],[-6088.2,-2999.5],[-6094.2,-2992.5],[-6091.2,-2987.5],[-6096.2,-2979.5],[-6102.2,-2979.5],[-6109.2,-2972.5],[-6123.2,-2970.5],[-6123.2,-2959.5],[-6120.2,-2956.5],[-6060.2,-2955.5]] },
    ],
  },
  "Sunken Temple": {
    map: 0, start: [-10437.1,-3826], label: "Accesso sommerso",
    directions: "Immergiti nel Pool of Tears e scendi lungo la scalinata del tempio.",
    routes: [
      { label: "Portale del dungeon", points: [[-10437.1,-3825.5],[-10398.1,-3836.5],[-10331.6,-3837.5],[-10311.6,-3857.5],[-10278.6,-3864.5],[-10270.6,-3875.5],[-10283.6,-3930],[-10307.6,-3955],[-10315.6,-3960],[-10326.1,-3960.5],[-10349.6,-4018.5],[-10353.1,-4019.5],[-10366.6,-4008],[-10375.6,-4018],[-10385.6,-4052],[-10381.1,-4058.5],[-10353.6,-4063],[-10288.6,-4085],[-10279.1,-4083.5],[-10258.6,-4031],[-10229.1,-4030.5],[-10221.1,-3999],[-10229.1,-3990],[-10227.6,-3985.5],[-10205.6,-3987],[-10170.6,-3996]] },
    ],
  },
  "Blackrock Depths": {
    map: 0, start: [-7741.1,-1101.1], label: "Ingresso di Blackrock Mountain",
    directions: "Scendi usando la catena e segui il percorso inferiore fino al portale.",
    routes: [
      { label: "Portale del dungeon", points: [[-7740.6,-1101.1],[-7737.1,-1103.1],[-7731.1,-1097.1],[-7731.1,-1089.6],[-7717.6,-1076.1],[-7709.1,-1074.1],[-7694.6,-1086.6],[-7673.1,-1087.6],[-7663.6,-1075.1],[-7663.6,-1068.1],[-7654.1,-1058.6],[-7654.1,-1045.1],[-7615.1,-1009.1],[-7574.6,-1002.6],[-7544.6,-1005.6],[-7538.1,-1012.1],[-7525.6,-1014.1],[-7485.1,-1060.6],[-7482.1,-1094.1],[-7485.1,-1124.1],[-7491.6,-1135.1],[-7504.1,-1125.1],[-7522.6,-1124.1],[-7532.1,-1114.6],[-7545.6,-1114.6],[-7555.6,-1109.6],[-7571.6,-1091.6],[-7544.6,-1067.1],[-7537.1,-1067.1],[-7494.6,-1024.6],[-7479.1,-1027.6],[-7477.1,-1022.1],[-7462.6,-1020.1],[-7407.6,-964.1],[-7337.1,-901.1],[-7242.6,-899.1],[-7231.1,-910.6],[-7202.1,-911.6],[-7194.1,-907.1],[-7179.6,-917.6],[-7178.6,-928.1]] },
    ],
  },
  "Lower Blackrock Spire": {
    map: 0, start: [-7755,-1114], label: "Ingresso di Blackrock Mountain",
    directions: "Sali alla balconata superiore e segui il passaggio verso il portale della Spire.",
    routes: [
      { label: "Portale del dungeon", points: [[-7754.5,-1114],[-7751,-1116],[-7745,-1110],[-7745,-1102.5],[-7731.5,-1089],[-7723,-1087],[-7708.5,-1099.5],[-7687,-1100.5],[-7677.5,-1088],[-7677.5,-1081],[-7668,-1071.5],[-7668,-1058],[-7629,-1022],[-7588.5,-1015.5],[-7558.5,-1018.5],[-7552,-1025],[-7539.5,-1027],[-7499,-1073.5],[-7496,-1107],[-7499,-1134],[-7508.5,-1144],[-7508.5,-1156.5],[-7539.5,-1186.5],[-7536.5,-1208.5],[-7522,-1233]] },
    ],
  },
  "Maraudon": {
    map: 1, start: [-1420.8,2935.4], label: "Imbocco di Maraudon",
    directions: "Scendi dalla Valley of Spears. Al bivio segui i cristalli viola verso nord o quelli arancioni verso sud-est.",
    routes: [
      { label: "Portale viola", points: [[-1420.8,2935.4],[-1418.3,2986.9],[-1413.3,2989.4],[-1410.8,2983.9],[-1481.3,2970.9],[-1489.3,2979.9],[-1440.8,3009.4],[-1400.8,3001.9],[-1400.8,2998.4],[-1420.3,2990.9],[-1426.3,2978.4],[-1414.3,2956.9],[-1393.8,2941.9],[-1369.3,2890.4],[-1354.8,2868.9],[-1325.8,2874.4],[-1323.8,2891.9],[-1288.8,2938.4],[-1272.8,2926.9],[-1220.8,2913.4],[-1182.8,2877.4]] },
      { label: "Portale arancione", points: [[-1420.8,2935.4],[-1418.3,2986.9],[-1413.3,2989.4],[-1410.8,2983.9],[-1481.3,2970.9],[-1489.3,2979.9],[-1440.8,3009.4],[-1400.8,3001.9],[-1400.8,2998.4],[-1420.3,2990.9],[-1472.8,2923.4],[-1488.8,2911.9],[-1493.8,2899.4],[-1483.8,2872.4],[-1475.3,2824.9],[-1479.3,2813.9],[-1493.3,2808.9],[-1531.3,2774.9],[-1534.8,2766.4],[-1529.3,2738.4],[-1516.8,2717.9],[-1437.3,2692.4],[-1430.3,2686.4],[-1430.3,2676.9],[-1446.3,2649.9],[-1468.2,2614.2]] },
    ],
  },
  "Scarlet Monastery - Graveyard": {
    map: 0, start: [2834.8,-695.6], label: "Portone del monastero",
    directions: "Entra nel monastero e vai al portale del cimitero sulla destra.",
    routes: [
      { label: "Portale del dungeon", points: [[2834.8,-695.6],[2857.8,-755.6],[2880.8,-779.6],[2880.8,-788.6],[2897.8,-805.6],[2904.8,-806.6],[2914.8,-801.6]] },
    ],
  },
  "Scarlet Monastery - Cathedral": {
    map: 0, start: [2834.1,-695.1], label: "Portone del monastero",
    directions: "Attraversa il complesso e raggiungi il portale della cattedrale.",
    routes: [
      { label: "Portale del dungeon", points: [[2834.1,-695.1],[2860.1,-761.1],[2880.1,-779.1],[2880.1,-792.1],[2889.1,-801.1],[2889.1,-810.1],[2904.1,-827.1],[2915.1,-823.1]] },
    ],
  },
  "Scarlet Monastery - Library": { map: 1420, start: [0.826, 0.336], label: "Portone del monastero",
    directions: "Supera il portone e segui il passaggio che conduce all’ala della biblioteca." },
  "Scarlet Monastery - Armory": { map: 1420, start: [0.826, 0.336], label: "Portone del monastero",
    directions: "Attraversa il monastero e cerca la porta dell’armeria." },
  "City of Dalaran": { map: 1416, start: [0.085, 0.593], label: "Accesso alle fogne",
    directions: "Scendi da una grata e percorri la condotta verso il portale." },
  "The Drowned City": { map: 1434, start: [0.214, 0.279], label: "Imbocco sommerso",
    directions: "Dal Vile Reef nuota verso Sunken Hollow. Cerca l’apertura subacquea accanto alla grande tavola di pietra." },
  "Krol'dok Stronghold": { map: 2548, start: [0.375, 0.373], label: "Accesso dalla grotta",
    directions: "Sulla collina sopra Sunnyglade, cerca la piccola grotta a ovest dei cancelli della fortezza." },
  "Alcaz Prison": { map: 1445, start: [0.753, 0.141], label: "Edificio della prigione",
    directions: "Dal molo sali fino all’edificio sul lato nord dell’isola. Il portale è nella cantina." },
  "Blackmaw Hold": { map: 1447, start: [0.386, 0.332], label: "Imbocco della galleria",
    directions: "Entra dal vecchio cancello dei furbolg e segui la galleria sotto il passo verso Winterspring." },
  "Shaper's Terrace": { map: 1449, start: [0.481, 0.061], label: "Scalinata del tempio",
    directions: "Da Marshal’s Refuge risali il pendio verso nord e prendi le scale del tempio dei titani." },
  "The Hall of Thanes": { map: 1455, start: [0.435, 0.52], label: "Accesso sotto Ironforge",
    directions: "Raggiungi il passaggio sotterraneo di Ironforge e segui il tunnel fino alla sala." },
  "Dire Maul - East": { map: 1444, start: [0.588, 0.442], label: "Ingresso delle rovine",
    directions: "Attraversa il Broken Commons e cerca l’accesso dell’ala est." },
  "Dire Maul - West": { map: 1444, start: [0.588, 0.442], label: "Ingresso delle rovine",
    directions: "Dal Broken Commons cerca la porta dell’ala ovest." },
  "Dire Maul - North": { map: 1444, start: [0.588, 0.442], label: "Ingresso delle rovine",
    directions: "Attraversa il Broken Commons verso la porta dei Gordok a nord." },
  "Razorfen Kraul": { map: 1413, start: [0.429, 0.902], label: "Corridoio di rovi",
    directions: "Nelle Southern Barrens segui il passaggio tra i rovi fino al portale." },
  "Razorfen Downs": { map: 1413, start: [0.500, 0.920], label: "Galleria di rovi",
    directions: "Al confine con Thousand Needles, segui la galleria di spine fino all’ingresso dell’istanza." },
  "Ruins of Lordaeron": { map: 1420, start: [0.634, 0.674], label: "Accesso dalle rovine",
    directions: "Entra dalle Ruins of Lordaeron sopra Undercity e cerca il passaggio verso l’istanza." },
}

dungeonApproaches['Upper Blackrock Spire'] = { ...dungeonApproaches['Lower Blackrock Spire']!,
  directions: 'Usa il portale di Blackrock Spire. All’interno segui il passaggio verso l’ala superiore.' }
