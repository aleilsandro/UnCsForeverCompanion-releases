// Reads a table of the game (a .db2 file in the WDC5 format). The file says by itself how each
// column is stored, so no outside definition is needed: only which column means what, which the
// caller knows. Sections the game keeps encrypted are skipped and counted, unless the caller says
// they came opened (the server has sent this PC their key: main/keys.ts).
//
// Layout: header, section headers, field sizes, field storage, pallet data, common data, then
// for each section its records, texts, id list, copy table and parent ids.
//
// A sparse table (ItemSparse) keeps each row at its own size: the columns one after the other at
// their full width, texts inside the row ending with a zero, and a list of where each row starts.
// The file does not say which columns are texts: the caller does.

const HEADER = 204
const SECTION = 40
const STORAGE = 24

export interface Row {
  id: number
  /** The id of the row this one belongs to, in tables that have one (a "relationship"). */
  parent: number | undefined
  /** A whole number: element `at` of column `field`. */
  int(field: number, at?: number): number
  /** A decimal number: element `at` of column `field`. */
  float(field: number, at?: number): number
  /** A text. */
  text(field: number): string
}

export interface Table {
  /** Columns in a row. */
  fields: number
  rows: Row[]
  /** Rows the game keeps encrypted and this PC has no key for: not read. */
  encryptedRows: number
  /** A row given apart, as the server sends it (hotfixes), read like the table's own: sparse tables only. */
  rowOf?: (id: number, record: Buffer) => Row
}

interface Field {
  offset: number // bits from the start of the record
  bits: number // bits in the record, all elements together
  elementBits: number // bits of one element, for a column stored plainly
  kind: number // 0 plain, 1 packed, 2 common, 3 pallet, 4 pallet array, 5 packed and signed
  a: number
  c: number
  block: number // where its pallet or common data starts
  common: Map<number, number> | undefined
}

const float32 = new Float32Array(1), bits32 = new Uint32Array(float32.buffer)

/**
 * opens: whether the sections locked with the key of this name came opened; by default none did.
 * texts: in a sparse table, the columns that are texts.
 */
export function readTable(b: Buffer, opens: (keyName: string) => boolean = () => false, texts: number[] = []): Table {
  if (b.toString('latin1', 0, 4) !== 'WDC5') throw new Error('not a WDC5 table')
  const u32 = (at: number): number => b.readUInt32LE(at)
  const recordSize = u32(144), flags = b.readUInt16LE(172), idIndex = b.readUInt16LE(174)
  const totalFields = u32(176), storageSize = u32(188), palletSize = u32(196), sectionCount = u32(200)
  const sparse = (flags & 1) !== 0

  let at = HEADER
  const sections = Array.from({ length: sectionCount }, (_, i) => {
    const p = at + i * SECTION
    const key = b.readBigUInt64LE(p)
    return { encrypted: key !== 0n && !opens(key.toString(16).padStart(16, '0')), offset: u32(p + 8), rows: u32(p + 12), texts: u32(p + 16), end: u32(p + 20), ids: u32(p + 24), parents: u32(p + 28), offsetMap: u32(p + 32), copies: u32(p + 36) }
  })
  at += sectionCount * SECTION
  const sizes = Array.from({ length: totalFields }, (_, i) => 32 - b.readInt16LE(at + i * 4))
  at += totalFields * 4
  const fields: Field[] = Array.from({ length: storageSize / STORAGE }, (_, i) => {
    const p = at + i * STORAGE
    return { offset: b.readUInt16LE(p), bits: b.readUInt16LE(p + 2), elementBits: sizes[i] ?? 32, kind: u32(p + 8), a: u32(p + 12), c: u32(p + 20), block: u32(p + 4), common: undefined }
  })
  at += storageSize
  let pallet = at, common = at + palletSize
  for (const f of fields) {
    const size = f.block
    if (f.kind === 3 || f.kind === 4) {
      f.block = pallet
      pallet += size
    } else if (f.kind === 2) {
      f.common = new Map()
      for (let i = 0; i < size; i += 8) f.common.set(u32(common + i), u32(common + i + 4))
      common += size
    }
  }

  // Up to 32 bits from any bit of the file.
  const bitsAt = (byte: number, bit: number, count: number): number => {
    let value = 0n
    for (let i = 7; i >= 0; i--) {
      const p = byte + (bit >> 3) + i
      value = (value << 8n) | BigInt(p < b.length ? b[p]! : 0)
    }
    return Number((value >> BigInt(bit & 7)) & ((1n << BigInt(Math.min(count, 32))) - 1n))
  }

  // A row of a sparse table: where each column starts is found walking the row, the first time it is asked.
  const bytes = fields.map((f) => Math.max(1, f.elementBits >> 3))
  const sparseRow = (r: Buffer, start: number, id: number): Row => {
    let starts: number[] | undefined
    const at = (field: number): number => {
      if (!starts) {
        starts = []
        for (let f = 0, q = start; f < fields.length; f++) {
          starts.push(q)
          q = texts.includes(f) ? r.indexOf(0, q) + 1 : q + bytes[f]! * Math.max(1, fields[f]!.bits / fields[f]!.elementBits)
        }
      }
      if (starts[field] === undefined) throw new Error(`no column ${field}`)
      return starts[field]!
    }
    const raw = (field: number, k: number): number => {
      const w = bytes[field]!, p = at(field) + k * w
      return w >= 4 ? r.readUInt32LE(p) : w === 2 ? r.readUInt16LE(p) : r[p]!
    }
    return {
      id,
      parent: undefined,
      int: (field, k = 0) => raw(field, k) | 0,
      float: (field, k = 0) => {
        bits32[0] = raw(field, k)
        return float32[0]!
      },
      text: (field) => r.toString('utf8', at(field), r.indexOf(0, at(field))),
    }
  }

  const allRows = sections.reduce((n, s) => n + s.rows, 0)
  const rows: Row[] = []
  let encryptedRows = 0, rowsBefore = 0, textsBefore = 0
  for (const s of sections) {
    const firstRow = rowsBefore, firstText = textsBefore
    rowsBefore += s.rows
    textsBefore += s.texts
    if (s.encrypted) {
      encryptedRows += s.rows
      continue
    }
    const strings = s.offset + s.rows * recordSize, idList = sparse ? s.end : strings + s.texts
    const copyTable = idList + s.ids, offsetMap = copyTable + s.copies * 8, parentsAt = offsetMap + s.offsetMap * 6
    const parents = new Map<number, number>()
    if (s.parents) for (let i = 0, n = u32(parentsAt); i < n; i++) parents.set(u32(parentsAt + 12 + i * 8 + 4), u32(parentsAt + 12 + i * 8))

    const made = new Map<number, Row>()
    for (let i = 0; sparse && i < s.rows; i++) {
      const row = sparseRow(b, u32(offsetMap + i * 6), u32(idList + i * 4))
      rows.push(row)
      made.set(row.id, row)
    }
    for (let i = 0; !sparse && i < s.rows; i++) {
      const record = s.offset + i * recordSize
      const raw = (field: number, k: number, id: number): number => {
        const f = fields[field]
        if (!f) throw new Error(`no column ${field}`)
        if (f.kind === 2) return f.common!.get(id) ?? f.a
        if (f.kind === 3) return u32(f.block + bitsAt(record, f.offset, f.bits) * 4)
        if (f.kind === 4) return u32(f.block + (bitsAt(record, f.offset, f.bits) * f.c + k) * 4)
        if (f.kind === 0) return bitsAt(record, f.offset + k * f.elementBits, f.elementBits)
        const value = bitsAt(record, f.offset, f.bits)
        // Sign of a packed number: its top bit.
        return (f.kind === 5 || f.c & 1) && f.bits < 32 && value >= 2 ** (f.bits - 1) ? value - 2 ** f.bits : value
      }
      const id = s.ids ? u32(idList + i * 4) : raw(idIndex, 0, 0)
      const row: Row = {
        id,
        parent: parents.get(i),
        int: (field, k = 0) => raw(field, k, id) | 0,
        float: (field, k = 0) => {
          bits32[0] = raw(field, k, id)
          return float32[0]!
        },
        // A text is stored as the distance from its own column to its place among the texts, counted
        // as if the rows of every section came first and the texts of every section after them.
        text: (field) => {
          const f = fields[field]
          if (!f) throw new Error(`no column ${field}`)
          const distance = raw(field, 0, id)
          if (!distance) return ''
          const start = strings + ((firstRow + i) * recordSize + (f.offset >> 3) + distance - allRows * recordSize - firstText)
          const end = b.indexOf(0, start)
          return b.toString('utf8', start, end < 0 ? b.length : end)
        },
      }
      rows.push(row)
      made.set(id, row)
    }
    // A copy is a row with another id and the same values.
    for (let i = 0; i < s.copies; i++) {
      const source = made.get(u32(copyTable + i * 8 + 4))
      if (source) rows.push({ ...source, id: u32(copyTable + i * 8) })
    }
  }
  return { fields: fields.length, rows, encryptedRows, ...(sparse && { rowOf: (id: number, record: Buffer) => sparseRow(record, 0, id) }) }
}

/**
 * The rows the server has sent for one table, kept in the game's cache (_forever_/Cache/ADB/<language>/DBCache.bin):
 * the row's number -> its record, or null where the server took the row away. table: the game's number for the table.
 * The latest sent wins.
 */
export function readHotfixes(cache: Buffer, table: number): Map<number, Buffer | null> {
  const best = new Map<number, { push: number; record: Buffer | null }>()
  // After the head (XFTH, version, build, a 32 byte hash) the rows: XFTH, region, push, unique id, table, row, size, state (1 = the row as sent), the record.
  for (let p = 44; p + 32 <= cache.length; ) {
    if (cache.toString('latin1', p, p + 4) !== 'XFTH') break
    const push = cache.readInt32LE(p + 8), size = cache.readUInt32LE(p + 24)
    if (cache.readUInt32LE(p + 16) === table) {
      const id = cache.readUInt32LE(p + 20), was = best.get(id)
      if (!was || push >= was.push) best.set(id, { push, record: cache[p + 28] === 1 ? cache.subarray(p + 32, p + 32 + size) : null })
    }
    p += 32 + size
  }
  return new Map([...best].map(([id, e]) => [id, e.record]))
}
