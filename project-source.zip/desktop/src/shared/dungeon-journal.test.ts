import { expect, test } from 'vitest'
import { questChain, type DungeonQuest, type QuestStep } from './dungeon-journal'

test('orders prerequisite branches before the dungeon quest and follows explicit successors once', () => {
  const ref = (id: number) => ({ id, name: 'Quest ' + id })
  const step = (id: number, required: number[] = [], alternatives: number[] = [], next?: number): QuestStep =>
    ({ ...ref(id), required: required.map(ref), alternatives: alternatives.map(ref), starts: [], ...(next && { next: ref(next) }) })
  const quest: DungeonQuest = { ...step(4, [2], [3], 5), objectives: [] }
  const root = { ...step(1), starts: [{ id: 7, name: 'Starter', kind: 'npc' as const, places: [] }] }
  const chain = questChain(quest, { 1: root, 2: step(2, [1]), 3: step(3, [1]), 5: step(5, [], [], 4) })
  expect(chain.before.map(row => row.reference.id)).toEqual([1, 2, 3])
  expect(chain.before[0]?.step?.starts[0]?.name).toBe('Starter')
  expect(chain.current.alternatives).toEqual([ref(3)])
  expect(chain.after.map(row => row.reference.id)).toEqual([5])
})
