/** Feather the city's existing cutout into the surrounding map, without a rectangular edge. */
export function cityBlend(rgba:Uint8Array,width:number,height:number,mask?:{width:number;height:number;rgba:Uint8Array}):void {
  // A small separable blur removes the stair steps of the 256px source mask.
  let smooth:Float32Array|undefined
  if (mask) {
    const w=mask.width,h=mask.height,radius=3, horizontal=new Float32Array(w*h)
    smooth=new Float32Array(w*h)
    for(let y=0;y<h;y++) for(let x=0;x<w;x++) {
      let sum=0,count=0
      for(let dx=-radius;dx<=radius;dx++) {const xx=x+dx;if(xx>=0 && xx<w){sum+=mask.rgba[(y*w+xx)*4+3]!;count++}}
      horizontal[y*w+x]=sum/count
    }
    for(let y=0;y<h;y++) for(let x=0;x<w;x++) {
      let sum=0,count=0
      for(let dy=-radius;dy<=radius;dy++) {const yy=y+dy;if(yy>=0 && yy<h){sum+=horizontal[yy*w+x]!;count++}}
      smooth[y*w+x]=sum/count/255
    }
  }
  const ease=(v:number):number=>{const t=Math.max(0,Math.min(1,v));return t*t*(3-2*t)}
  for(let y=0;y<height;y++) for(let x=0;x<width;x++) {
    const u=(x+.5)/width,v=(y+.5)/height
    const edge=Math.min(u,1-u,v,1-v)
    // Rounded corners prevent the city artwork from looking like a sheet of paper.
    const a=Math.abs(2*u-1),b=Math.abs(2*v-1)
    const rounded=Math.pow(a**4+b**4,.25)
    const feather=ease(edge/.12)*ease((1.07-rounded)/.30)
    let cut=1
    if(mask && smooth) {
      const sx=Math.max(0,Math.min(mask.width-1,u*mask.width-.5)),sy=Math.max(0,Math.min(mask.height-1,v*mask.height-.5))
      const x0=Math.floor(sx),y0=Math.floor(sy),x1=Math.min(mask.width-1,x0+1),y1=Math.min(mask.height-1,y0+1),fx=sx-x0,fy=sy-y0
      cut=(smooth[y0*mask.width+x0]!*(1-fx)+smooth[y0*mask.width+x1]!*fx)*(1-fy)+(smooth[y1*mask.width+x0]!*(1-fx)+smooth[y1*mask.width+x1]!*fx)*fy
    }
    const p=(y*width+x)*4+3
    rgba[p]=Math.round(rgba[p]!*cut*feather)
  }
}
