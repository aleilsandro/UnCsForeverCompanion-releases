import { existsSync, readFileSync, realpathSync, renameSync, writeFileSync } from 'node:fs'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'
import { gameFolderFrom, openClientFiles, registryInstallPath } from './client-files'
import { writeMapServiceIcons } from './icons'
import { sentKeys } from './keys'
import { NPC, OBJECT, openQuestie, type Questie } from './questie'
import { mapServiceLayers, professionsOf, type MapServiceLayer, type MapServicePin } from '../shared/map-services'
import { gameMaps, UI_MAP_ASSIGNMENT_FILE, UI_MAP_FILE, type GameMap } from '../shared/maps'
import { servicesOf, type ServiceLayer } from '../shared/services'
import { readTable } from '../shared/wdc5'

const CLASS = /\b(?:warrior|paladin|hunter|rogue|priest|shaman|mage|warlock|druid)\b/i
const SPECIAL_TRAINER = /\b(?:pet|demon|weapon|riding|mount|portal)\b/i
const NPC_LAYER: Partial<Record<ServiceLayer, MapServiceLayer>> = {
  inn: 'inn', vendors: 'vendor', repair: 'repair', bank: 'bank', auction: 'auction',
}

function pinsFor(db: Questie, maps: GameMap[], factions: Map<number, number>): MapServicePin[] {
  const zones = new Map(maps.filter(map => map.level === 'zone' && map.area && map.rect && map.continent !== null)
    .map(map => [map.area, map]))
  const pins: MapServicePin[] = []
  const add = (kind: 'Npc' | 'Object', id: number, pin: Omit<MapServicePin, 'world' | 'north' | 'west'>): void => {
    for (const [area, points] of Object.entries(db.places(kind, id))) {
      const map = zones.get(+area)
      if (!map?.rect || map.continent === null) continue
      const { minX, minY, maxX, maxY } = map.rect
      const coords = points.filter(([x, y]) => x >= 0 && x <= 100 && y >= 0 && y <= 100)
      // Patrols with many recorded spawns get one marker at a real point on the path.
      const spawns = kind === 'Npc' && coords.length > 6 ? [coords[Math.floor(coords.length / 2)]!] : coords
      for (const [x, y] of spawns) pins.push({
        ...pin, world: map.continent,
        north: +(maxX - y / 100 * (maxX - minX)).toFixed(2),
        west: +(maxY - x / 100 * (maxY - minY)).toFixed(2),
      })
    }
  }

  for (const id of db.ids.Npc) {
    const flags = db.get('Npc', id, NPC.flags)
    if (typeof flags !== 'number' || !flags) continue
    const side = db.get('Npc', id, NPC.friendly)
    const name = db.get('Npc', id, NPC.name)
    if (typeof name !== 'string' || typeof side !== 'string' || !/[AH]/.test(side)) continue
    const subtitle = db.get('Npc', id, NPC.sub)
    const sub = typeof subtitle === 'string' && subtitle ? subtitle : undefined
    const layers = servicesOf(flags).flatMap((layer): MapServiceLayer[] => {
      const mapped = NPC_LAYER[layer]
      if (mapped) return [mapped]
      if (layer !== 'trainers' || SPECIAL_TRAINER.test(sub ?? '')) return []
      if (CLASS.test(sub ?? '')) return ['class']
      return professionsOf(sub).length ? ['profession'] : []
    })
    if (layers.length) add('Npc', id, { name, sub, side, layers })
  }

  for (const id of db.ids.Object) {
    if (db.get('Object', id, OBJECT.name) !== 'Mailbox') continue
    const faction = db.get('Object', id, OBJECT.faction)
    const enemies = factions.get(Number(faction)) ?? 0
    const allianceHostile = (enemies & 10) !== 0, hordeHostile = (enemies & 12) !== 0
    const side = allianceHostile === hordeHostile ? undefined : allianceHostile ? 'H' : 'A'
    add('Object', id, { name: 'Cassetta della posta', side, layers: ['mailbox'] })
  }
  return pins
}

function generate(mapFolder: string, gamePath?: string): void {
  const target = join(mapFolder, 'openmap', 'services.json')
  const tiles = join(mapFolder, 'tiles')
  if (existsSync(target) && mapServiceLayers.every(({ id }) => existsSync(join(tiles, 'icons', `${id}.png`)))) return
  const defaultPath = join(process.env['ProgramFiles(x86)'] ?? 'C:/Program Files (x86)', 'World of Warcraft')
  const game = gameFolderFrom([gamePath || defaultPath]) ?? gameFolderFrom([registryInstallPath()])
  const db = game && openQuestie(game)
  if (!game || !db) throw Error('Serve una copia locale di WoW Forever con QuestieDB per preparare i servizi.')
  const destination = relative(realpathSync(game), realpathSync(mapFolder))
  if (!isAbsolute(destination) && destination !== '..' && !destination.startsWith(`..${sep}`)) {
    throw Error('Scegli una cartella della mappa esterna all’installazione di WoW.')
  }
  const files = openClientFiles(game, sentKeys(game))
  const uiMaps = files.read(UI_MAP_FILE, true), assignments = files.read(UI_MAP_ASSIGNMENT_FILE, true)
  if (!uiMaps || !assignments) throw Error('Tabelle delle zone di WoW Forever non trovate.')
  const maps = gameMaps(readTable(uiMaps), readTable(assignments))
  const factionFile = join(game, '_forever_', 'Interface', 'AddOns', 'QuestieDB', 'support', 'Forever', 'FactionTemplates', 'factionTemplateClassic.lua')
  const factions = new Map([...readFileSync(factionFile, 'utf8').matchAll(/^\s*\[(\d+)\]\s*=\s*(\d+),/gm)]
    .map(([, id, enemies]) => [Number(id), Number(enemies)]))
  const pins = pinsFor(db, maps, factions)
  if (!pins.length) throw Error('Nessun servizio di Forever trovato nelle zone del pacchetto.')
  writeMapServiceIcons(files, tiles)
  writeFileSync(target + '.new', JSON.stringify(pins))
  renameSync(target + '.new', target)
  console.log(`Servizi della mappa di Forever: ${pins.length} posizioni.`)
}

const [mapFolder, gameFolder] = process.argv.slice(2)
if (!mapFolder) throw Error('Uso: node map-services.js <cartella-mappa> [cartella-wow]')
generate(resolve(mapFolder), gameFolder)
