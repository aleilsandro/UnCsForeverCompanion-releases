import { dungeonGuides, type DungeonJournalData, type DungeonQuest, type QuestPlace, type QuestSource } from '../shared/dungeon-journal'
import { nameOfBoss } from '../shared/inside'
import type { GameMap } from '../shared/maps'
import type { Table } from '../shared/wdc5'
import { at, keyed, list, NPC, OBJECT, ITEM, QUEST, type Kind, type Questie } from './questie'
import supplementRows from './dungeon-source-supplement.json'

// Normalized quest and loot facts from the Forever instance files at
// https://github.com/ATTWoWAddon/AllTheThings/tree/6486f88fede2f8d1641d07c494d93573fe993d7a/.contrib/.db/forever
const supplement = supplementRows as DungeonJournalData

// QuestieDB meta fields and AreaTable's area name, continent (instance map) and parent columns.
const REQUIRED_QUESTS = 12, ALTERNATIVE_QUESTS = 13, AREA_OR_SORT = 17, OBJECTIVE_TEXT = 8
const numbers = (value: unknown): number[] => [...new Set(list(value).filter((id): id is number => typeof id === 'number' && id > 0))]
const names = (value: unknown): string[] => list(value).filter((text): text is string => typeof text === 'string' && !!text.trim())
const guidable = new Set(dungeonGuides.map(guide => guide.map))
// QuestieDB also uses the original outdoor area IDs for these instance categories.
const legacyInstanceAreas = new Map([[1583, 229], [1584, 230], [2159, 249], [16985, 3001]])
type Entity = [kind: 'Npc' | 'Object' | 'Item', id: number]

function entities(value: unknown): Entity[] {
  return (['Npc', 'Object', 'Item'] as const).flatMap((kind, index) =>
    numbers(at(value, index + 1)).map(id => [kind, id] as Entity))
}

const sourceKind = { Npc: 'npc', Object: 'object', Item: 'item' } as const
const fieldName = (db: Questie, kind: Kind, id: number): string | undefined => {
  const name = db.get(kind, id, 1)
  return typeof name === 'string' && name.trim() ? name : undefined
}

export function dungeonJournal(db: Questie, areas: Table, maps: GameMap[]): DungeonJournalData {
  const areaById = new Map(areas.rows.map(row => [row.id, { map: row.int(2), parent: row.int(3), name: row.text(1) }]))
  const zoneNames = new Map(maps.filter(map => map.level === 'zone' && map.area > 0).map(map => [map.area, map.name]))
  const instance = (area: number): number | undefined => {
    const info = areaById.get(area)
    return info && guidable.has(info.map) ? info.map : legacyInstanceAreas.get(area)
  }
  function sourceMaps([kind, id]: Entity): Set<number> {
    if (kind === 'Item') {
      const sources = itemSources(id)
      if (!sources.length) return new Set()
      const ids = sources.map(source => sourceMaps(source))
      // Sources in the open world or with an unknown location are not dungeon-exclusive.
      if (ids.some(matches => matches.size !== 1 || matches.has(0))) return new Set()
      const all = new Set(ids.flatMap(matches => [...matches]))
      return all.size === 1 ? all : new Set()
    }
    const areas = keyed(db.get(kind, id, kind === 'Npc' ? NPC.spawns : OBJECT.spawns)).map(([area]) => Number(area))
    const fallback = db.get(kind, id, kind === 'Npc' ? NPC.zone : 5)
    if (!areas.length && typeof fallback === 'number' && fallback > 0) areas.push(fallback)
    return new Set(areas.map(area => instance(area) ?? 0))
  }
  function itemSources(id: number): Entity[] {
    return [
      ...numbers(db.get('Item', id, ITEM.npcDrops)).map((npc): Entity => ['Npc', npc]),
      ...numbers(db.get('Item', id, ITEM.objectDrops)).map((object): Entity => ['Object', object]),
    ]
  }
  function where(kind: 'Npc' | 'Object', id: number): QuestPlace[] {
    const results: QuestPlace[] = []
    const starts = db.places(kind, id)
    const areas = new Set([...Object.keys(starts).map(Number), ...keyed(db.get(kind, id, kind === 'Npc' ? NPC.spawns : OBJECT.spawns)).map(([area]) => Number(area))])
    const fallback = db.get(kind, id, kind === 'Npc' ? NPC.zone : 5)
    if (!areas.size && typeof fallback === 'number' && fallback > 0) areas.add(fallback)
    for (const area of areas) {
      const data = areaById.get(area)
      const zone = zoneNames.get(area) || data?.name || zoneNames.get(data?.parent ?? 0)
      if (!zone) continue
      const positions = (starts[area] ?? []).slice(0, 3)
      if (positions.length) for (const [x, y] of positions) results.push({ zone, x, y })
      else results.push({ zone })
    }
    return results.slice(0, 8)
  }
  function questSource([kind, id]: Entity): QuestSource | undefined {
    const name = fieldName(db, kind, id)
    if (!name) return
    return { id, name, kind: sourceKind[kind], places: kind === 'Item' ? [] : where(kind, id),
      ...(kind === 'Item' && { drops: itemSources(id).slice(0, 8).flatMap(source => questSource(source) ?? []) }) }
  }
  const requirements = (value: unknown) => numbers(value).map(id => ({ id, name: fieldName(db, 'Quest', id) ?? `Quest ${id}` }))

  const quests: DungeonJournalData['quests'] = {}
  for (const id of db.ids.Quest) {
    const category = db.get('Quest', id, AREA_OR_SORT), name = fieldName(db, 'Quest', id)
    if (!name) continue
    const declared = typeof category === 'number' ? instance(category) : undefined
    const starts = entities(db.get('Quest', id, QUEST.startedBy))
    const objective = db.get('Quest', id, QUEST.objectives)
    const targets = (['Npc', 'Object', 'Item'] as const).flatMap((kind, index) =>
      list(at(objective, index + 1)).flatMap(row => numbers([at(row, 1)]).map((target): Entity => [kind, target])))
    const locations = new Set(declared ? [declared] : [...targets, ...starts].flatMap(source => [...sourceMaps(source)].filter(map => map > 0)))
    if (!locations.size) continue
    const level = db.get('Quest', id, QUEST.reqLevel)
    const quest: DungeonQuest = {
      id, name, ...(typeof level === 'number' && level > 0 && { level }),
      starts: starts.flatMap(source => questSource(source) ?? []),
      required: requirements(db.get('Quest', id, REQUIRED_QUESTS)),
      alternatives: requirements(db.get('Quest', id, ALTERNATIVE_QUESTS)),
      objectives: names(db.get('Quest', id, OBJECTIVE_TEXT)),
    }
    for (const map of locations) (quests[map] ??= []).push(quest)
  }
  for (const [map, entries] of Object.entries(supplement.quests)) {
    const current = quests[+map] ??= []
    for (const entry of entries) {
      const known = current.find(quest => quest.id === entry.id)
      if (!known) current.push(entry)
      else {
        known.faction ??= entry.faction
        if (!known.starts.length) known.starts = entry.starts
        if (!known.objectives.length) known.objectives = entry.objectives
        if (!known.required.length && !known.alternatives.length) known.required = entry.required
      }
    }
  }
  for (const entries of Object.values(quests)) entries.sort((a, b) => (a.level ?? 0) - (b.level ?? 0) || a.name.localeCompare(b.name))

  const byName = new Map<string, number[]>()
  for (const id of db.ids.Npc) {
    const name = fieldName(db, 'Npc', id)
    if (name) (byName.get(nameOfBoss(name)) ?? byName.set(nameOfBoss(name), []).get(nameOfBoss(name))!).push(id)
  }
  const wanted = new Map<number, { map: number; boss: string }[]>()
  for (const guide of dungeonGuides) for (const [boss] of guide.bosses) {
    const candidates = byName.get(nameOfBoss(boss)) ?? []
    const matches = candidates.filter(id => sourceMaps(['Npc', id]).has(guide.map))
    // Some clients mark dungeon spawns without an area. Accept only an unambiguous exact name.
    for (const id of matches.length ? matches : candidates.length === 1 ? candidates : []) {
      const entries = wanted.get(id) ?? []
      if (!entries.some(entry => entry.map === guide.map && entry.boss === boss)) entries.push({ map: guide.map, boss })
      wanted.set(id, entries)
    }
  }
  const loot: DungeonJournalData['loot'] = {}
  for (const id of db.ids.Item) {
    for (const npc of numbers(db.get('Item', id, ITEM.npcDrops))) for (const { map, boss } of wanted.get(npc) ?? []) {
      const name = fieldName(db, 'Item', id)
      if (!name) continue
      const bosses = loot[map] ??= {}, items = bosses[boss] ??= []
      if (!items.some(item => item.id === id)) items.push({ id, name })
    }
  }
  for (const [map, sources] of Object.entries(supplement.loot)) {
    const bosses = loot[+map] ??= {}
    const names = dungeonGuides.filter(guide => guide.map === +map).flatMap(guide => guide.bosses.map(([name]) => name))
    for (const [boss, items] of Object.entries(sources)) {
      const name = names.find(name => nameOfBoss(name) === nameOfBoss(boss))
      if (!name) continue
      const current = bosses[name] ??= []
      for (const item of items) if (!current.some(existing => existing.id === item.id)) current.push(item)
    }
  }
  for (const bosses of Object.values(loot)) for (const items of Object.values(bosses)) items.sort((a, b) => a.name.localeCompare(b.name))
  return { quests, loot }
}
