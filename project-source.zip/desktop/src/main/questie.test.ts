import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { expect, test } from 'vitest'
import { logFrom, shownFrom } from '../shared/quests'
import { gameItemFacts, shopRows } from '../shared/items'
import { gameFolderFrom, openClientFiles, registryInstallPath } from './client-files'
import { sentKeys } from './keys'
import { cbor, doerIndex, fixedPins, ITEM, NPC, OBJECT, openQuestie, QUEST, questLog, questPins, search, searchIndex, shops, shownFromLog } from './questie'

// Writes a value the way QuestieDB does: CBOR, then base64. Only what these tests need.
function enc(v: unknown): Buffer {
  const head = (major: number, n: number): Buffer => (n < 24 ? Buffer.from([(major << 5) | n]) : n < 256 ? Buffer.from([(major << 5) | 24, n]) : Buffer.from([(major << 5) | 25, n >> 8, n & 255]))
  if (v === null) return Buffer.from([0xf6])
  if (typeof v === 'boolean') return Buffer.from([v ? 0xf5 : 0xf4])
  if (typeof v === 'number') {
    if (Number.isInteger(v)) return v >= 0 ? head(0, v) : head(1, -1 - v)
    const b = Buffer.alloc(9)
    b[0] = 0xfb
    b.writeDoubleBE(v, 1)
    return b
  }
  if (typeof v === 'string') return Buffer.concat([head(3, Buffer.byteLength(v)), Buffer.from(v)])
  if (Array.isArray(v)) return Buffer.concat([head(4, v.length), ...v.map(enc)])
  const entries = Object.entries(v as object)
  return Buffer.concat([head(5, entries.length), ...entries.flatMap(([k, x]) => [enc(+k), enc(x)])])
}
const b64 = (v: unknown): string => enc(v).toString('base64')

// A game folder with a QuestieDB of two quests, three NPCs and an object, all invented.
function game(lines: string[]): string {
  const folder = mkdtempSync(join(tmpdir(), 'twinmap-questie-'))
  const db = join(folder, '_forever_', 'Interface', 'AddOns', 'QuestieDB')
  mkdirSync(db, { recursive: true })
  writeFileSync(join(db, 'QuestieDB_Forever.toc'), ['## Interface: 16001', '## Version: 1.2.3', ...lines, 'src\\config.lua'].join('\r\n'))
  return folder
}
const long = b64({ 12: Array.from({ length: 40 }, (_, i) => [10.5 + i, 20.25]) })
const LINES = [
  `## X-Quest-7-S: ${b64({ [QUEST.name]: 'A Parcel for the Miller', [QUEST.level]: 12, [QUEST.reqLevel]: 9 })}`,
  `## X-Quest-7-${QUEST.startedBy}: ${b64([[101]])}`,
  `## X-Quest-7-${QUEST.finishedBy}: ${b64([[102], [900]])}`,
  `## X-Quest-8-S: ${b64({ [QUEST.name]: 'Rats in the Cellar', [QUEST.level]: 3 })}`,
  // An NPC standing in two zones; one place is inside an instance, which QuestieDB writes as -1.
  `## X-Npc-101-S: ${b64({ [NPC.name]: 'Miller Odo', [NPC.friendly]: 'A', [NPC.flags]: 4 })}`,
  `## X-Npc-101-${NPC.spawns}: ${b64({ 12: [[42.5, 65.25], [-1, -1]], 40: [[10, 20]] })}`,
  // A long value, cut in two pieces.
  `## X-Npc-102-S: ${b64({ [NPC.name]: 'Cellar Rat' })}`,
  `## X-Npc-102-${NPC.spawns}: ~2~`,
  `## X-Npc-102-${NPC.spawns}-1: ${long.slice(0, 200)}`,
  `## X-Npc-102-${NPC.spawns}-2: ${long.slice(200)}`,
  // A patrol: no spawn, only the path it walks.
  `## X-Npc-103-S: ${b64({ [NPC.name]: 'Road Warden' })}`,
  `## X-Npc-103-${NPC.waypoints}: ${b64({ 40: [[[33.5, 44.5], [34, 45]]] })}`,
  `## X-Object-900-S: ${b64({ [OBJECT.name]: 'Mill Notice Board' })}`,
  `## X-Object-900-${OBJECT.spawns}: ${b64({ 12: [[50, 50]] })}`,
  `## X-Item-55-${ITEM.npcDrops}: ${b64([102])}`,
  // A quest that starts from a thing the rats drop, and one to do at a place.
  `## X-Quest-9-S: ${b64({ [QUEST.name]: 'The Strange Key', [QUEST.level]: 5 })}`,
  `## X-Quest-9-${QUEST.startedBy}: ${b64([null, null, [55]])}`,
  `## X-Quest-10-S: ${b64({ [QUEST.name]: 'Scout the Ford' })}`,
]

// What the pins of one kind say, shortest first to read.
const told = (pins: ReturnType<typeof questPins>, type: string): string[] => pins.filter((p) => p.type === type).map((p) => `${p.area} ${p.x},${p.y} ${p.name}: ${p.quests.join(' + ')}`).sort()
// What Questie shows: icons as quest, area, x, y.
type Icon = [number, number, number, number]
const shown = (icons: { available?: Icon[]; turnin?: Icon[]; objective?: Icon[] }, active: { id: number; targets: string[] }[] = []): Parameters<typeof questPins>[1] => {
  const of = (list: Icon[] = []) => list.map(([quest, area, x, y]) => ({ quest, area, x, y }))
  return { icons: { available: of(icons.available), turnin: of(icons.turnin), objective: of(icons.objective) }, active: active.map((q) => ({ ...q, done: false })) }
}

test('an icon of a quest on offer is a pin on the same spot, named after who stands there', () => {
  const db = openQuestie(game(LINES))!
  // Questie shows the miller in one of the two zones he stands in: so does the app, and no more.
  expect(told(questPins(db, shown({ available: [[7, 12, 42.5, 65.25]] })), 'available')).toEqual(['12 42.5,65.25 Miller Odo: [12] A Parcel for the Miller'])
  // One that starts from a thing forty rats drop: Questie draws three, and the app draws those three.
  const key = questPins(db, shown({ available: [[9, 12, 10.5, 20.25], [9, 12, 11.5, 20.25], [9, 12, 12.5, 20.25]] }))
  expect(told(key, 'available')).toEqual(['12 10.5,20.25 Cellar Rat: [5] The Strange Key', '12 11.5,20.25 Cellar Rat: [5] The Strange Key', '12 12.5,20.25 Cellar Rat: [5] The Strange Key'])
  // Nothing of its own: with no icon there is no pin.
  expect(questPins(db, shown({}))).toEqual([])
})

test('an icon Questie moved keeps its place, and is named only when there is no doubt', () => {
  const db = openQuestie(game(LINES))!
  // The miller drawn at the door of a dungeon, in a zone he does not stand in: he is the only giver.
  expect(told(questPins(db, shown({ available: [[7, 1497, 72.41, 11.37]] })), 'available')).toEqual(['1497 72.41,11.37 Miller Odo: [12] A Parcel for the Miller'])
  // Handed in to a creature or to an object, and the icon on neither: the quest names the pin.
  expect(told(questPins(db, shown({ turnin: [[7, 1497, 72.41, 11.37]] })), 'turnin')).toEqual(['1497 72.41,11.37 A Parcel for the Miller: A Parcel for the Miller'])
  expect(told(questPins(db, shown({ turnin: [[7, 12, 50, 50]] })), 'turnin')).toEqual(['12 50,50 Mill Notice Board: A Parcel for the Miller'])
  // A quest QuestieDB does not know still has its pin.
  expect(told(questPins(db, shown({ available: [[9999, 12, 1, 2]] })), 'available')).toEqual(['12 1,2 Quest 9999: Quest 9999'])
})

test('an icon of what is still to find is named after the nearest of the things to find', () => {
  const db = openQuestie(game(LINES))!
  const active = [{ id: 8, targets: ['m_103', 'o_900', 'x_1', 'm_99999'] }, { id: 10, targets: [] }]
  // Questie gathers a few places into one icon in their middle: not on anyone, but near someone.
  const pins = questPins(db, shown({ objective: [[8, 12, 49, 51], [8, 40, 33, 44], [10, 40, 61.5, 30]] }, active))
  expect(told(pins, 'objective')).toEqual(['12 49,51 Mill Notice Board: Rats in the Cellar', '40 33,44 Road Warden: Rats in the Cellar', '40 61.5,30 Scout the Ford: Scout the Ford'])
  // Two quests with an icon on the same spot are one pin that names both.
  const two = questPins(db, shown({ objective: [[8, 40, 33, 44], [10, 40, 33, 44]] }, [{ id: 8, targets: ['m_103'] }, { id: 10, targets: ['m_103'] }]))
  expect(told(two, 'objective')).toEqual(['40 33,44 Road Warden: Rats in the Cellar + Scout the Ford'])
})

test('who offers a service is pinned where they stand, and so are ore and herbs', () => {
  const db = openQuestie(game([
    ...LINES,
    `## X-Npc-105-S: ${b64({ [NPC.name]: 'Smith Hale', [NPC.friendly]: 'AH', [NPC.sub]: 'Armorer', [NPC.flags]: 4 + 16384 })}`,
    `## X-Npc-105-${NPC.spawns}: ${b64({ 40: [[55, 45]] })}`,
    // With a service, but friendly to no side: not for a player.
    `## X-Npc-106-S: ${b64({ [NPC.name]: 'Bandit Fence', [NPC.flags]: 4 })}`,
    `## X-Npc-106-${NPC.spawns}: ${b64({ 40: [[1, 1]] })}`,
    `## X-Object-901-S: ${b64({ [OBJECT.name]: 'Copper Vein' })}`,
    `## X-Object-901-${OBJECT.spawns}: ${b64({ 12: [[30, 30], [31, 32]] })}`,
    `## X-Object-902-S: ${b64({ [OBJECT.name]: 'Peacebloom' })}`,
    `## X-Object-902-${OBJECT.spawns}: ${b64({ 40: [[70, 70]] })}`,
    `## X-Item-60-S: ${b64({ [ITEM.name]: 'Copper Shortsword' })}`,
    `## X-Item-60-${ITEM.vendors}: ${b64([105])}`,
  ]))!
  // A vendor or a trainer carries its number for its panel, and a vendor what it sells.
  expect(fixedPins(db)).toEqual([
    // Miller Odo sells (flags 4) in the two zones he stands in; the place inside an instance is left out.
    { area: 12, x: 42.5, y: 65.25, name: 'Miller Odo', layers: ['vendors'], side: 'A', npc: 101 },
    { area: 40, x: 10, y: 20, name: 'Miller Odo', layers: ['vendors'], side: 'A', npc: 101 },
    { area: 40, x: 55, y: 45, name: 'Smith Hale', sub: 'Armorer', layers: ['vendors', 'repair'], side: 'AH', npc: 105, sells: [60] },
    { area: 12, x: 30, y: 30, name: 'Copper Vein', layers: ['ore'] },
    { area: 12, x: 31, y: 32, name: 'Copper Vein', layers: ['ore'] },
    { area: 40, x: 70, y: 70, name: 'Peacebloom', layers: ['herbs'] },
  ])
})

test('the search finds NPCs, quests and items by name, each on a place of the map', () => {
  const db = openQuestie(game([
    ...LINES,
    `## X-Npc-105-S: ${b64({ [NPC.name]: 'Smith Hale', [NPC.sub]: 'Armorer', [NPC.zone]: 40 })}`,
    `## X-Npc-105-${NPC.spawns}: ${b64({ 12: [[1, 2]], 40: [[55, 45]] })}`,
    // The same name twice: the first has no place, the second has.
    `## X-Npc-106-S: ${b64({ [NPC.name]: 'Cellar Ghost' })}`,
    `## X-Npc-107-S: ${b64({ [NPC.name]: 'Cellar Ghost' })}`,
    `## X-Npc-107-${NPC.spawns}: ${b64({ 12: [[9, 9]] })}`,
    `## X-Item-55-S: ${b64({ [ITEM.name]: 'Strange Key' })}`,
    `## X-Item-56-S: ${b64({ [ITEM.name]: 'Smithing Hammer' })}`,
    `## X-Item-56-${ITEM.vendors}: ${b64([105])}`,
    `## X-Item-56-${ITEM.npcDrops}: ${b64([102])}`,
    `## X-Item-57-S: ${b64({ [ITEM.name]: 'Mill Notice' })}`,
    `## X-Item-57-${ITEM.objectDrops}: ${b64([900])}`,
    `## X-Item-58-S: ${b64({ [ITEM.name]: 'Key to Nowhere' })}`,
    // Sold by two, one of whom has no place: three have it on the list.
    `## X-Npc-108-S: ${b64({ [NPC.name]: 'Fletcher Ann', [NPC.friendly]: 'H' })}`,
    `## X-Npc-108-${NPC.spawns}: ${b64({ 40: [[70, 30]] })}`,
    `## X-Item-59-S: ${b64({ [ITEM.name]: 'Rough Arrow' })}`,
    `## X-Item-59-${ITEM.vendors}: ${b64([105, 106, 108])}`,
  ]))!
  const index = searchIndex(db)
  const told = (typed: string): string[] => search(db, index, typed).map((f) => `${f.kind} ${f.name} (${f.note}) ${f.area} ${f.x},${f.y}`)
  // An NPC in the zone that is its own, whatever the case of what was typed.
  expect(told('smith h')).toEqual(['npc Smith Hale (Armorer) 40 55,45'])
  // Names that start with what was typed first, then the ones with a word that does. No place, no result.
  expect(told('cellar'), 'the quest of that name is taken from nobody: it has no place').toEqual(['npc Cellar Rat (NPC) 12 10.5,20.25', 'npc Cellar Ghost (NPC) 12 9,9'])
  // A quest where it is taken.
  expect(told('parcel')).toEqual(['quest A Parcel for the Miller (Quest, level 12, from Miller Odo) 12 42.5,65.25'])
  // An item on who sells it before who drops it; on what holds it; one nobody has is not found.
  expect(told('smithing')).toEqual(['item Smithing Hammer (Sold by Smith Hale) 40 55,45'])
  expect(told('strange key')).toEqual(['item Strange Key (Dropped by Cellar Rat) 12 10.5,20.25'])
  expect(told('mill n')).toEqual(['item Mill Notice (Found in Mill Notice Board) 12 50,50'])
  // An item with more than one seller is on each of them, for the window to show the nearest that serve the character.
  expect(search(db, index, 'rough').map((f) => `${f.name} (${f.note}) ${f.does} ${f.side} ${f.area} ${f.x},${f.y}`)).toEqual(['Rough Arrow (Sold by Smith Hale) true undefined 40 55,45', 'Rough Arrow (Sold by Fletcher Ann) true H 40 70,30'])
  expect(told('nowhere')).toEqual([])
  expect(told('  ')).toEqual([])
  expect(search(db, index, 'e', 3)).toHaveLength(3)
})

test('what comes off the strip is checked before it is used', () => {
  const told = shownFrom({
    icons: { a: [6, 12, 2423, 7446, 64, 40, 5650, 4725], t: [12, 12, 4210, 'x'], o: [102, 40, 4400] },
    active: [{ id: 12, done: true, targets: ['m_5', 7] }, { id: 'no' }, null],
  })
  expect(told).toEqual({
    icons: { available: [{ quest: 6, area: 12, x: 24.23, y: 74.46 }, { quest: 64, area: 40, x: 56.5, y: 47.25 }], turnin: [], objective: [] },
    active: [{ id: 12, done: true, targets: ['m_5'] }],
  })
  const nothing = { icons: { available: [], turnin: [], objective: [] }, active: [] }
  expect(shownFrom(undefined)).toEqual(nothing)
  expect(shownFrom('nonsense')).toEqual(nothing)
  // What an addon older than the icons sent: no pins, and no fault.
  expect(shownFrom({ available: [6, 64], items: true, active: [] })).toEqual(nothing)
  // What each objective asks for: a letter each, in their order. A letter not known, or none, leaves the icon without.
  expect(shownFrom({ icons: { o: [1, 40, 100, 200, 2, 40, 300, 400, 3, 40, 500, 600, 4, 40, 700, 800], k: 'sl?' } }).icons.objective.map((i) => i.kind)).toEqual(['slay', 'loot', undefined, undefined])
})

test('values come back as QuestieDB wrote them', () => {
  const value = { 1: 'Zoë', 2: [1, 23, 24, 300, -5], 3: [42.5, null, true, false], 4: { 7: [[1.25, 2]] } }
  expect(cbor(enc(value))).toEqual(value)
  expect(cbor(Buffer.from('gYEZAzc=', 'base64'))).toEqual([[823]])
  expect(cbor(Buffer.from([0xf9, 0x3e, 0x00]))).toBe(1.5) // a half-size float
  expect(() => cbor(Buffer.from([0x82, 0x01]))).toThrow()
})

test('with QuestieDB in the game folder, quests, NPCs and objects are read with their places', () => {
  const db = openQuestie(game(LINES))!
  expect(db.version).toBe('1.2.3')
  expect(db.ids).toEqual({ Quest: [7, 8, 9, 10], Npc: [101, 102, 103], Object: [900], Item: [] })
  // A scalar from the row of scalars, a table from its own line, a field that is not there.
  expect(db.get('Quest', 7, QUEST.name)).toBe('A Parcel for the Miller')
  expect(db.get('Quest', 7, QUEST.finishedBy)).toEqual([[102], [900]])
  expect(db.get('Quest', 8, QUEST.startedBy)).toBeUndefined()
  expect(db.get('Item', 55, ITEM.npcDrops)).toEqual([102])

  expect(db.places('Npc', 101)).toEqual({ 12: [[42.5, 65.25]], 40: [[10, 20]] })
  expect(db.places('Npc', 102)[12]).toHaveLength(40)
  expect(db.places('Npc', 103)).toEqual({ 40: [[33.5, 44.5]] })
  expect(db.places('Object', 900)).toEqual({ 12: [[50, 50]] })
  expect(db.zoneIndex.Npc.get('12')).toEqual([101, 102])
  expect(db.zoneIndex.Npc.get('40')).toEqual([101, 103])
  expect(db.zoneIndex.Object.get('12')).toEqual([900])
})

// Zone 1 is Dun Morogh. A Lua table whose keys are 1, or 1 and 2, is written as a list, not as a map.
test('a place in zone 1 is read in zone 1, though QuestieDB writes its zones as a list there', () => {
  const db = openQuestie(
    game([
      ...LINES,
      `## X-Npc-110-S: ${b64({ [NPC.name]: 'Innkeeper Belm', [NPC.friendly]: 'A', [NPC.flags]: 128 })}`,
      `## X-Npc-110-${NPC.spawns}: ${b64([[[47.38, 52.52]]])}`,
      `## X-Npc-111-S: ${b64({ [NPC.name]: 'Border Guard' })}`,
      `## X-Npc-111-${NPC.spawns}: ${b64([[[80, 50]], [[5, 50]]])}`,
      `## X-Npc-112-S: ${b64({ [NPC.name]: 'Mountaineer' })}`,
      `## X-Npc-112-${NPC.waypoints}: ${b64([[[[30.5, 40.5], [31, 41]]]])}`,
      `## X-Object-910-S: ${b64({ [OBJECT.name]: 'Copper Vein' })}`,
      `## X-Object-910-${OBJECT.spawns}: ${b64([[[60, 61]]])}`,
      `## X-Quest-10-${QUEST.triggerEnd}: ${b64(['Scout the pass', [[[70, 71]]]])}`,
    ]),
  )!
  expect(db.places('Npc', 110)).toEqual({ 1: [[47.38, 52.52]] })
  expect(db.places('Npc', 111)).toEqual({ 1: [[80, 50]], 2: [[5, 50]] })
  expect(db.places('Npc', 112)).toEqual({ 1: [[30.5, 40.5]] })
  expect(db.places('Object', 910)).toEqual({ 1: [[60, 61]] })
  expect(db.zoneIndex.Npc.get('1')).toEqual([110, 111, 112])
  expect(db.zoneIndex.Npc.has('0')).toBe(false)
  expect(fixedPins(db).filter((p) => p.name === 'Innkeeper Belm' || p.name === 'Copper Vein').map((p) => p.area)).toEqual([1, 1])
  expect(shownFromLog(db, [{ id: 10, done: false, objectives: [] }]).icons.objective).toEqual([{ quest: 10, area: 1, x: 70, y: 71, kind: 'event' }])
})

test('who sells an item, turned round: what each NPC sells', () => {
  const sells = (id: number, name: string, npcs: number[]): string[] => [`## X-Item-${id}-S: ${b64({ [ITEM.name]: name })}`, `## X-Item-${id}-${ITEM.vendors}: ${b64(npcs)}`]
  const db = openQuestie(game([...LINES, ...sells(56, 'Fresh Bread', [101, 103]), ...sells(57, 'Mild Spices', [101]), `## X-Item-58-S: ${b64({ [ITEM.name]: 'Rat Tail' })}`]))!
  expect(shops(db)).toEqual(new Map([[101, [56, 57]], [103, [56]]]))
})

test('without QuestieDB there is nothing to read, and that is not a fault', () => {
  expect(openQuestie(mkdtempSync(join(tmpdir(), 'twinmap-no-questie-')))).toBeNull()
  expect(openQuestie(game(['## X-Mode: baked'])), 'a QuestieDB with no quests in it').toBeNull()
})

test('a value that cannot be read is a value that is not there', () => {
  const db = openQuestie(game([...LINES, '## X-Npc-104-S: !!!not base64 cbor', `## X-Npc-104-${NPC.spawns}: /w==`]))!
  expect(db.get('Npc', 104, NPC.name)).toBeUndefined()
  expect(db.places('Npc', 104)).toEqual({})
  expect(db.get('Quest', 7, QUEST.level)).toBe(12)
})

// The player's own QuestieDB, when TWINMAP_QUESTIE names a game folder: how long it takes to open.
test.skipIf(!process.env.TWINMAP_QUESTIE)('the real QuestieDB opens in under two seconds', () => {
  const started = performance.now()
  const db = openQuestie(process.env.TWINMAP_QUESTIE!)!
  const ms = performance.now() - started
  console.log(`QuestieDB ${db.version}: ${db.ids.Quest.length} quests, ${db.ids.Npc.length} NPCs, ${db.ids.Object.length} objects, ${db.zoneIndex.Npc.size} zones, ${Math.round(ms)} ms`)
  expect(db.get('Quest', db.ids.Quest[0]!, QUEST.name)).toBeTypeOf('string')
  expect(ms).toBeLessThan(2000)
})

test('the search finds who does what was typed, whatever they are called', () => {
  const db = openQuestie(game([
    ...LINES,
    `## X-Npc-201-S: ${b64({ [NPC.name]: 'Shaina Fuller', [NPC.sub]: 'First Aid Trainer', [NPC.friendly]: 'A', [NPC.flags]: 16 })}`,
    `## X-Npc-201-${NPC.spawns}: ${b64({ 12: [[43, 66]] })}`,
    `## X-Npc-202-S: ${b64({ [NPC.name]: 'Arnok', [NPC.sub]: 'First Aid Trainer', [NPC.friendly]: 'H', [NPC.flags]: 16 })}`,
    `## X-Npc-202-${NPC.spawns}: ${b64({ 40: [[5, 6]] })}`,
    // No title under the name: found by the service alone.
    `## X-Npc-203-S: ${b64({ [NPC.name]: 'Dungar Longdrink', [NPC.friendly]: 'A', [NPC.flags]: 8 })}`,
    `## X-Npc-203-${NPC.spawns}: ${b64({ 12: [[71, 72]] })}`,
    // Friendly to nobody, and one that does nothing: neither is found so.
    `## X-Npc-204-S: ${b64({ [NPC.name]: 'Defias Medic', [NPC.sub]: 'First Aid Trainer', [NPC.flags]: 16 })}`,
    `## X-Npc-204-${NPC.spawns}: ${b64({ 12: [[1, 1]] })}`,
    `## X-Npc-205-S: ${b64({ [NPC.name]: 'First Mate Aid', [NPC.friendly]: 'A' })}`,
    `## X-Npc-205-${NPC.spawns}: ${b64({ 12: [[2, 2]] })}`,
  ]))!
  const index = searchIndex(db), doers = doerIndex(db)
  const told = (typed: string): string[] => search(db, index, typed, 12, doers).filter((f) => f.does).map((f) => `${f.name} (${f.note}) ${f.side} ${f.area} ${f.x},${f.y}`)
  expect(told('first aid')).toEqual(['Shaina Fuller (First Aid Trainer) A 12 43,66', 'Arnok (First Aid Trainer) H 40 5,6'])
  expect(told('Trainer FIRST')).toHaveLength(2)
  expect(told('flight')).toEqual(['Dungar Longdrink (flight) A 12 71,72'])
  // Too little typed to mean a trade.
  expect(told('fi')).toEqual([])
  // By name it is still found as before.
  expect(search(db, index, 'first mate', 12, doers).map((f) => f.name)).toEqual(['First Mate Aid'])
})

test('without Questie the pins of the log are made here: where to hand in what is done, where to find what is still asked for', () => {
  const db = openQuestie(game([
    ...LINES,
    // A quest that asks for a creature, an object and an item the rats drop; and one to do at a place.
    `## X-Quest-20-S: ${b64({ [QUEST.name]: 'Three Things' })}`,
    `## X-Quest-20-${QUEST.objectives}: ${b64([[[103, null, 0]], [[900, null, 0]], [[55, null, 0]]])}`,
    `## X-Quest-10-${QUEST.triggerEnd}: ${b64(['Scout the ford', { 40: [[61.5, 53.25]] }])}`,
  ]))!
  // As the addon sends it: the creature is done, the object and the item are not.
  const log = logFrom({ log: [{ id: 7, done: true, o: [1, 1] }, { id: 10, done: false, o: [0, 0] }, { id: 20, done: false, o: [1, 1, 2, 0, 3, 0] }] })!
  const shown = shownFromLog(db, log)
  expect(shown.icons.available).toEqual([])
  // Handed in to the rats or at the board: the rats stand in forty places a unit apart, shown four units apart.
  expect(shown.icons.turnin.filter((i) => i.x === 50)).toEqual([{ quest: 7, area: 12, x: 50, y: 50 }])
  expect(shown.icons.turnin.map((i) => i.x).slice(0, 3)).toEqual([10.5, 14.5, 18.5])
  expect(shown.icons.turnin.length).toBe(11)
  // The place to scout; the board and the rats that drop the key, not the creature already done.
  expect(shown.icons.objective.filter((i) => i.quest === 10)).toEqual([{ quest: 10, area: 40, x: 61.5, y: 53.25, kind: 'event' }])
  expect(shown.active.find((q) => q.id === 20)).toEqual({ id: 20, done: false, targets: ['o_900', 'm_102'] })
  const pins = questPins(db, shown)
  expect(pins.find((p) => p.type === 'objective' && p.x === 50)).toMatchObject({ area: 12, kind: 'object', name: 'Mill Notice Board', quests: ['Three Things'] })
  expect(pins.some((p) => p.type === 'objective' && p.name === 'Road Warden'), 'the creature is done').toBe(false)
  expect(questLog(db, shown)).toEqual([{ name: 'A Parcel for the Miller', done: true }, { name: 'Scout the Ford', done: false }, { name: 'Three Things', done: false }])
  // A game that tells no objectives: everything the quest asks for is shown. No section at all: Questie is running.
  expect(shownFromLog(db, logFrom({ log: [{ id: 20, done: false, o: [] }] })!).active[0]!.targets).toEqual(['m_103', 'o_900', 'm_102'])
  expect(logFrom(undefined)).toBeNull()
  expect(logFrom({ log: {} })).toEqual([])
})

// The player's game and its QuestieDB: what a vendor sells at what price, the server's rows of
// ItemSparse over the game's own. Prices as the trial of 17 November 2026 read them (design/vendors).
const real = gameFolderFrom([registryInstallPath()])
// The names are the game's, where QuestieDB has some of its own (Flagon of Mead).
test.skipIf(!real)('the innkeeper of Ironforge sells his 17 goods at the prices of the game, and an item only the server knows has its price', () => {
  const db = openQuestie(real!)!
  const caches = join(real!, '_forever_', 'Cache', 'ADB')
  const sent = readdirSync(caches).map((language) => join(caches, language, 'DBCache.bin')).filter((f) => existsSync(f)).map((f) => readFileSync(f))
  const files = openClientFiles(real!, sentKeys(real!))
  const facts = gameItemFacts(files, sent)!
  const sold = shops(db)
  const firebrew = shopRows(sold.get(5111)!, facts).map((r) => `${r.name} ${r.buy}/${r.perBuy}`)
  expect(firebrew).toEqual([
    'Bottle of Dalaran Noir 50/1', 'Cured Ham Steak 2000/5', 'Flagon of Dwarven Honeymead 1500/1', 'Flask of Stormwind Tawny 150/1', 'Haunch of Meat 125/5', 'Ice Cold Milk 125/5',
    'Jug of Badlands Bourbon 2000/1', 'Melon Juice 500/5', 'Moonberry Juice 2000/5', 'Morning Glory Dew 4000/5', 'Mutton Chop 500/5', 'Refreshing Spring Water 25/5',
    'Roasted Quail 4000/5', 'Skin of Dwarven Stout 120/1', 'Sweet Nectar 1000/5', 'Tough Jerky 25/5', 'Wild Hog Shank 1000/5',
  ])
  // Toxic Skullcap, from Tawny Grisette: the game has no row of it, the server sent one.
  expect(gameItemFacts(files, [])![281246]).toBeUndefined()
  expect(shopRows(sold.get(4554)!, facts).find((r) => r.id === 281246)).toEqual({ id: 281246, name: 'Toxic Skullcap', quality: expect.any(Number), buy: 150, perBuy: 1 })
}, 60_000)
