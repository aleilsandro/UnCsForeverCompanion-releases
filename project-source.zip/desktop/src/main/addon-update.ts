import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { addonVersion, addonsFolder } from './setup'

const run = promisify(execFile)
const repo = 'aleilsandro/UnCsForeverCompanion-releases'
const limit = 32 * 1024 * 1024

export function newer(remote: string, installed: string | null): boolean {
  const parse = (v: string): number[] | null => /^\d+\.\d+\.\d+$/.test(v) ? v.split('.').map(Number) : null
  const next = parse(remote), current = installed ? parse(installed) : null
  if (!next || next.some((n) => !Number.isSafeInteger(n))) throw new Error('Versione addon non valida')
  if (!installed) return true
  if (!current || current.some((n) => !Number.isSafeInteger(n))) throw new Error('Versione addon installata non riconosciuta')
  for (let i = 0; i < 3; i++) if (next[i] !== current[i]) return next[i]! > current[i]!
  return false
}

/** Download only a verified release archive; the helper validates ZIP paths and replaces atomically. */
export async function updateAddon(game: string, helper: string, tell: (s: string) => void): Promise<string> {
  const response = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, { headers: { 'User-Agent': 'UnCs-Forever-Companion', Accept: 'application/vnd.github+json' }, signal: AbortSignal.timeout(12000) })
  if (!response.ok) throw new Error(`GitHub non disponibile (${response.status})`)
  const release = await response.json() as { tag_name?: string; assets?: Array<{ name?: string; browser_download_url?: string; digest?: string; size?: number }> }
  const version = release.tag_name ?? ''
  if (!newer(version, addonVersion(game))) return 'Addon aggiornato'
  const matches = (release.assets ?? []).filter(a => a.name === `UnCsForeverCompanion-${version}-forever.zip`)
  if (matches.length !== 1) throw new Error('Archivio addon non disponibile nella release')
  const asset = matches[0]!, url = asset.browser_download_url ?? ''
  if (!url.startsWith(`https://github.com/${repo}/releases/download/${version}/`) || !/^sha256:[a-f0-9]{64}$/i.test(asset.digest ?? '') || !asset.size || asset.size > limit) throw new Error('Dati della release addon non validi')
  tell(`Scarico addon ${version}…`)
  const download = await fetch(url, { signal: AbortSignal.timeout(120000) })
  if (!download.ok || !download.body) throw new Error(`Download addon fallito (${download.status})`)
  const chunks: Uint8Array[] = []; let size = 0
  for await (const chunk of download.body as unknown as AsyncIterable<Uint8Array>) { size += chunk.byteLength; if (size > limit) throw new Error('Archivio addon troppo grande'); chunks.push(chunk) }
  if (size !== asset.size) throw new Error('Dimensione addon non valida')
  const zip = Buffer.concat(chunks), digest = createHash('sha256').update(zip).digest('hex')
  if (`sha256:${digest}` !== asset.digest!.toLowerCase()) throw new Error('Verifica addon non riuscita')
  const temp = await mkdtemp(join(tmpdir(), 'uncs-addon-'))
  try {
    const file = join(temp, 'addon.zip'); await writeFile(file, zip)
    tell(`Installazione addon ${version}…`)
    await run(helper, ['--update-addon', addonsFolder(game), file], { timeout: 120000, windowsHide: true })
    if (addonVersion(game) !== version) throw new Error('Versione addon installata non corrispondente')
  } finally { await rm(temp, { recursive: true, force: true }) }
  return `Addon ${version} installato: se WoW è aperto usa /reload`
}
