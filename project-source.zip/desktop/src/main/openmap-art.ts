// Read only the locally installed OpenMap's baked world-art tiles. The original textures remain in
// the user's installation; OpenMap's NOTICE describes their Blizzard and artist provenance.
import { readdirSync, readFileSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { decodeBlpCutout } from '../shared/blp'
import { encodePng } from './png'
import { decodeTga } from './tga'
import { parseNativeTileList } from '../shared/native-tiles'
import { parseCityMinis, type CityMini } from '../shared/city-mini'

const tilesDir = (game: string): string => join(game, '_forever_', 'Interface', 'AddOns', 'OpenMap', 'Media', 'Textures', 'Forever', 'MapZones')
const valid = /^(\d{1,2})_(\d{1,2})\.blp$/
const cache = new Map<string, Buffer>()
export function cityMiniManifest(game:string):CityMini[] {
  try {return parseCityMinis(readFileSync(join(game,'_forever_','Interface','AddOns','OpenMap','Data','Forever','CaveMinimap.lua'),'utf8'))} catch {return []}
}

export function openMapManifest(game: string): [number, number][] {
  try {
    return readdirSync(tilesDir(game)).flatMap((name) => {
      const m = valid.exec(name)
      return m ? [[Number(m[1]), Number(m[2])] as [number, number]] : []
    })
  } catch { return [] }
}
export async function openMapTile(game: string, name: string): Promise<Buffer | null> {
  if (!valid.test(name)) return null
  const path = join(tilesDir(game), name)
  const saved = cache.get(path)
  if (saved) { cache.delete(path); cache.set(path, saved); return saved }
  try {
    const { width, height, rgba } = decodeBlpCutout(await readFile(path))
    const bytes = encodePng(rgba, width, height, 4, 1)
    cache.set(path, bytes)
    if (cache.size > 48) cache.delete(cache.keys().next().value!)
    return bytes
  } catch { return null }
}

const miniDir = (game:string):string => join(game, '_forever_', 'Interface', 'AddOns', 'OpenMap', 'Media', 'Textures', 'Forever', 'MapMiniLOD')
const miniName = /^([01])_4_(\d{1,2})_(\d{1,2})\.tga$/
export function miniManifest(game:string): [number,number,number][] {
  try {
    return readdirSync(miniDir(game)).flatMap(name => {
      const m=miniName.exec(name)
      return m ? [[Number(m[1]),Number(m[2]),Number(m[3])] as [number,number,number]] : []
    })
  } catch { return [] }
}
export async function miniTile(game:string,name:string): Promise<Buffer|null> {
  if (!miniName.test(name)) return null
  const path=join(miniDir(game),name)
  const hit=cache.get(path)
  if (hit) { cache.delete(path); cache.set(path,hit); return hit }
  try {
    const {width,height,rgba}=decodeTga(await readFile(path))
    const bytes=encodePng(rgba,width,height,4,1)
    cache.set(path,bytes)
    if (cache.size > 96) cache.delete(cache.keys().next().value!)
    return bytes
  } catch { return null }
}

/** The city-name cutouts from the user's existing OpenMap installation. */
export async function cityBanner(game:string,id:number):Promise<Buffer|null> {
  if(![1454,1456,1457,1458].includes(id))return null
  try {
    const file=join(game,'_forever_','Interface','AddOns','OpenMap','Media','Textures','Forever','MapBanner',`${id}.tga`)
    const {width,height,rgba}=decodeTga(await readFile(file),false)
    return encodePng(rgba,width,height,4,1)
  } catch { return null }
}

export function nativeManifest(game:string): [number,number,number,number][] {
  try { return parseNativeTileList(readFileSync(join(game,'_forever_','Interface','AddOns','OpenMap','Data','Forever','Minimap.lua'),'utf8')) }
  catch { return [] }
}

/** OpenMap's locally installed world backdrop; these are not bundled with UnCs. */
export async function worldBackdrop(game:string,index:number):Promise<Buffer|null> {
  if (!Number.isInteger(index) || index < 1 || index > 12) return null
  const path=join(game,'_forever_','Interface','AddOns','OpenMap','Media','Textures','Forever','MapArt',`947_${index}.tga`)
  const hit=cache.get(path)
  if (hit) return hit
  try {
    const image=decodeTga(await readFile(path),false)
    // The source map is 1002×668; the last row/column of its 256px files are padding.
    const col=(index-1)%4, row=Math.floor((index-1)/4)
    const width=Math.min(image.width,1002-col*256), height=Math.min(image.height,668-row*256)
    if (width<=0 || height<=0) return null
    const rgba=new Uint8Array(width*height*4)
    for (let y=0; y<height; y++) rgba.set(image.rgba.subarray(y*image.width*4,y*image.width*4+width*4),y*width*4)
    const bytes=encodePng(rgba,width,height,4,1)
    cache.set(path,bytes)
    if (cache.size>128) cache.delete(cache.keys().next().value!)
    return bytes
  } catch { return null }
}
