import { realpathSync, renameSync, statSync, writeFileSync } from 'node:fs'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'
import { GATHERING_FILE, type GatheringByZone, type GatheringProfession } from '../shared/gathering'
import { gameMaps, UI_MAP_ASSIGNMENT_FILE, UI_MAP_FILE, type GameMap } from '../shared/maps'
import { AREA_TABLE_FILE } from '../shared/places'
import { readTable } from '../shared/wdc5'
import { gameFolderFrom, openClientFiles, registryInstallPath } from './client-files'
import classic from './gathering-classic.json'
import { sentKeys } from './keys'
import { openQuestie, questieFile } from './questie'

const LOCK_FILE = 1343608
const LOCK_LAYOUT = 0xda418152
const TYPE_SKILL = 2
const lockProfession = new Map<number, 'mining' | 'herbalism'>([[2, 'herbalism'], [3, 'mining']])
const npcMin = 4, npcMax = 5
const skinnable = new Map(Object.entries(classic.skinnable).map(([id, levels]) => [Number(id), levels]))
// Classic's threshold is (level - 10) * 10 below mastery 100 and level * 5 from level 20.
const skinningSkill = (level: number) => Math.max(1, level < 20 ? (level - 10) * 10 : level * 5)

function generate(root: string, gamePath?: string): void {
  const output = join(root, 'openmap', GATHERING_FILE)
  const mtime = (file: string) => statSync(file, { throwIfNoEntry: false })?.mtimeMs ?? 0
  const defaultPath = join(process.env['ProgramFiles(x86)'] ?? 'C:/Program Files (x86)', 'World of Warcraft')
  const game = gameFolderFrom([gamePath || defaultPath]) ?? gameFolderFrom([registryInstallPath()])
  const built = mtime(output)
  if (built && (!game || [join(game, '.build.info'), questieFile(game)].every(path => mtime(path) <= built))) return
  if (!game) throw Error('Installazione di WoW Forever non trovata.')
  const destination = relative(realpathSync(game), root)
  if (!isAbsolute(destination) && destination !== '..' && !destination.startsWith(`..${sep}`)) {
    throw Error('Scegli una cartella della mappa esterna all’installazione di WoW.')
  }
  const client = openClientFiles(game, sentKeys(game))
  const opens = (key: string) => client.opens(key)
  const table = (id: number) => {
    const bytes = client.read(id, true)
    if (!bytes) throw Error(`Tabella di WoW non disponibile: ${id}`)
    return readTable(bytes, opens)
  }
  const maps = gameMaps(table(UI_MAP_FILE), table(UI_MAP_ASSIGNMENT_FILE))
  const zones = maps.filter(map => map.level === 'zone' && map.area && map.rect && map.continent !== null)
  const mapsByArea = new Map<number, GameMap[]>()
  for (const map of zones) {
    const siblings = mapsByArea.get(map.area) ?? []
    siblings.push(map)
    mapsByArea.set(map.area, siblings)
  }
  const parents = new Map(table(AREA_TABLE_FILE).rows.map(row => [row.id, row.int(3)]))
  const mapForArea = (area: number): GameMap[] => {
    const seen = new Set<number>()
    while (area && !seen.has(area)) {
      const found = mapsByArea.get(area)
      if (found) return found
      seen.add(area)
      area = parents.get(area) ?? 0
    }
    return []
  }
  const result: GatheringByZone = {}
  function add(area: number, profession: GatheringProfession, min: number, max = min): void {
    for (const map of mapForArea(area)) {
      const zone = result[map.id] ??= {}
      const previous = zone[profession]
      zone[profession] = previous ? [Math.min(previous[0], min), Math.max(previous[1], max)] : [min, max]
    }
  }

  // Classic's area measurements stay separate from Forever-only zones or bodies of water.
  const fishingBase = new Map(Object.entries(classic.fishing).map(([area, base]) => [Number(area), base]))
  for (const map of zones) {
    const base = fishingBase.get(map.area)
    if (base !== undefined) (result[map.id] ??= {}).fishing = [Math.max(1, base), Math.max(1, base + 95)]
  }

  const db = openQuestie(game)
  if (db) {
    const rawLocks = client.read(LOCK_FILE, true)
    const locks = new Map(rawLocks?.readUInt32LE(156) === LOCK_LAYOUT ? readTable(rawLocks, opens).rows.map(row => [row.id, row]) : [])
    const nodeSkills = new Map<number, [profession: 'mining' | 'herbalism', level: number]>()
    for (const [lockId, ids] of Object.entries(classic.nodeLocks)) {
      const row = locks.get(+lockId)
      if (!row) continue
      for (let slot = 0; slot < 8; slot++) {
        const profession = lockProfession.get(row.int(1, slot))
        const level = row.int(2, slot)
        if (row.int(3, slot) !== TYPE_SKILL || !profession || level < 0 || level > 450) continue
        for (const id of ids) nodeSkills.set(id, [profession, Math.max(1, level)])
        break
      }
    }
    for (const [area, ids] of db.zoneIndex.Object) {
      for (const id of ids) {
        const skill = nodeSkills.get(id)
        if (skill) add(+area, ...skill)
      }
    }
    for (const [area, ids] of db.zoneIndex.Npc) {
      for (const id of ids) {
        const reference = skinnable.get(id)
        if (!reference) continue
        const min = db.get('Npc', id, npcMin), max = db.get('Npc', id, npcMax)
        if (typeof min !== 'number' || typeof max !== 'number' || min < 1 || max < min || max > 63) continue
        // A pooled NPC can carry the combined levels of different appearances.
        const upper = max - min > 10 && reference[1]! >= min ? Math.min(max, reference[1]!) : max
        add(+area, 'skinning', skinningSkill(min), skinningSkill(upper))
      }
    }
  }
  const pending = output + '.part'
  writeFileSync(pending, JSON.stringify(result))
  renameSync(pending, output)
  console.log(`Requisiti di raccolta per ${Object.keys(result).length} zone.`)
}

const [packagePath, gamePath] = process.argv.slice(2)
if (!packagePath) throw Error('Uso: node map-gathering.js <cartella-mappa> [cartella-wow]')
generate(realpathSync(resolve(packagePath)), gamePath)
