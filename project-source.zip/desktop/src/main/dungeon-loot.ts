import { existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { decodeBlpCutout } from '../shared/blp'
import type { DungeonJournalData, DungeonLootDetails, DungeonLootDetailsById } from '../shared/dungeon-journal'
import { typeOf } from '../shared/items'
import { readHotfixes, readTable, type Row } from '../shared/wdc5'
import { EncryptedFileError, type ClientFiles } from './client-files'
import { encodePng } from './png'
import { keep } from './tiles'

const ITEM = 841626, SPARSE = 1572924, SPELL = 1140089, SPELL_NAME = 1990283
const ITEM_EFFECT = 969941, ITEM_EFFECT_LINK = 3177687
// File IDs and layouts of the Forever client, as documented in WoWDBDefs.
const ITEM_LAYOUT = 0x9a2a4834, SPARSE_LAYOUT = 0x6fcc3191
const DESCRIPTION = 0, NAME = 4, VARIANCE = 6, STAT_PERCENT = 15, STAT_TYPE = 16, FLAGS = 27
const DELAY = 46, LEVEL = 50, BINDING = 59, SCHOOL = 60, REQUIRED = 64, SLOT = 65, QUALITY = 66

const slots: Record<number, string> = {
  1: 'Testa', 2: 'Collo', 3: 'Spalle', 4: 'Camicia', 5: 'Torace', 6: 'Vita', 7: 'Gambe',
  8: 'Piedi', 9: 'Polsi', 10: 'Mani', 11: 'Dito', 12: 'Monile', 13: 'Una mano', 14: 'Mano secondaria',
  15: 'A distanza', 16: 'Schiena', 17: 'Due mani', 19: 'Insegna', 20: 'Torace', 21: 'Mano primaria',
  22: 'Mano secondaria', 23: 'Mano secondaria', 25: 'Da lancio', 26: 'A distanza', 28: 'Reliquia',
}
const bindings = ['', 'Si vincola alla raccolta', 'Si vincola all’equipaggiamento', 'Si vincola all’utilizzo', 'Oggetto di missione']
const schools = ['', 'sacro', 'da fuoco', 'da natura', 'da gelo', 'da ombra', 'arcano']
const statNames: Record<number, string> = {
  0: 'Mana', 1: 'Salute', 3: 'Agilità', 4: 'Forza', 5: 'Intelletto', 6: 'Spirito', 7: 'Tempra',
  12: 'Difesa', 13: 'Schivata', 14: 'Parata', 15: 'Indice di blocco', 16: 'Indice di impatto in mischia',
  17: 'Indice di impatto a distanza', 18: 'Indice di impatto magico', 19: 'Critico in mischia', 20: 'Critico a distanza',
  21: 'Critico magico', 31: 'Indice di impatto', 32: 'Indice di critico', 36: 'Celerità', 37: 'Perizia',
  38: 'Potenza d’attacco', 39: 'Potenza d’attacco a distanza', 41: 'Potenza di cura', 42: 'Danni magici',
  43: 'Mana ogni 5 s', 44: 'Penetrazione armatura', 45: 'Potenza magica', 46: 'Salute ogni 5 s', 47: 'Penetrazione magica',
  48: 'Valore di blocco', 50: 'Armatura aggiuntiva', 51: 'Resistenza al fuoco', 52: 'Resistenza al gelo',
  53: 'Resistenza al sacro', 54: 'Resistenza all’ombra', 55: 'Resistenza alla natura', 56: 'Resistenza all’arcano',
}
const statSlotGroups = [[1, 4, 5, 7, 15, 17, 20, 25], [3, 6, 8, 10, 12], [2, 9, 11, 14, 16, 23], [13, 21, 22], [28]]
const triggers: Record<number, string> = { 0: 'Utilizzo', 1: 'Equipaggiamento', 2: 'Probabilità all’impatto' }

function spellText(description: string | undefined, effects: Row[], duration: Row | undefined): string | undefined {
  const resolved = description?.replace(/\$([st])([1-9])\b|\$d\b/g, (token: string, field?: string, index?: string) => {
    if (!field) {
      const ms = duration?.int(0)
      if (!ms || ms < 0 || (duration?.int(1) ?? 0) !== 0) return token
      const seconds = ms / 1000
      return seconds % 60 === 0 ? `${seconds / 60} min` : `${seconds} sec`
    }
    const effect = effects.find(row => row.int(2) + 1 === Number(index))
    if (!effect) return token
    if (field === 't') return effect.int(6) > 0 ? String(effect.int(6) / 1000) : token
    const points = effect.float(22)
    const scales = effect.int(23) !== 0 || [7, 14, 16, 18, 19].some(column => effect.float(column) !== 0)
    return !scales && Number.isFinite(points) && points ? String(Math.abs(points)) : token
  })
  return resolved && !/\$[\w@?{<%/*]/.test(resolved) ? resolved : undefined
}

export function dungeonLootCaches(game: string): string[] {
  const folder = join(game, '_forever_', 'Cache', 'ADB')
  return existsSync(folder)
    ? readdirSync(folder).map(language => join(folder, language, 'DBCache.bin')).filter(existsSync)
    : []
}

export function dungeonLootDetails(files: ClientFiles, caches: Buffer[], journal: DungeonJournalData, atlas: string): DungeonLootDetailsById {
  const ids = new Set(Object.values(journal.loot).flatMap(bosses => Object.values(bosses).flatMap(items => items.map(item => item.id))))
  const open = (key: string) => files.opens(key)
  const read = (id: number) => files.read(id, true)
  const base = read(ITEM), sparse = read(SPARSE)
  if (base?.readUInt32LE(156) !== ITEM_LAYOUT || sparse?.readUInt32LE(156) !== SPARSE_LAYOUT) {
    throw Error('Tabelle del bottino di WoW Forever non riconosciute.')
  }
  const rows = (id: number, texts?: number[]) => {
    const bytes = read(id)
    return bytes ? readTable(bytes, open, texts).rows : []
  }
  const keyed = (data: Row[], key = (row: Row) => row.id) => new Map(data.map(row => [key(row), row]))
  const fixes = (data: Buffer) => new Map(caches.flatMap(cache => [...readHotfixes(cache, data.readUInt32LE(152))]))
  const itemFixes = fixes(base), sparseFixes = fixes(sparse)
  const items = keyed(readTable(base, open).rows.filter(row => ids.has(row.id)))
  const itemTable = readTable(sparse, open, [0, 1, 2, 3, 4])
  const details = keyed(itemTable.rows.filter(row => ids.has(row.id)))
  const appearances = keyed(rows(982462))
  const defaultAppearances = new Map<number, number>()
  for (const row of rows(982457)) {
    if (row.parent === undefined || !ids.has(row.parent) || row.int(2) !== 0) continue
    const icon = appearances.get(row.int(3))?.int(2)
    if (icon && !defaultAppearances.has(row.parent)) defaultAppearances.set(row.parent, icon)
  }
  const damage = [1277743, 1277739, 1277738, 1277742].map(id => keyed(rows(id), row => row.int(0)))
  const points = keyed(rows(1310245))
  const armorQuality = keyed(rows(1283021)), armorTotal = keyed(rows(1283022), row => row.int(0))
  const armorLocation = keyed(rows(1284818)), armorShield = keyed(rows(1277741), row => row.int(1))
  const effects = keyed(rows(ITEM_EFFECT))
  const spells = keyed(rows(SPELL, [0, 1, 2]))
  const spellNames = keyed(rows(SPELL_NAME))
  const lootEffects = rows(ITEM_EFFECT_LINK).filter(link => link.parent !== undefined && ids.has(link.parent))
  const spellIds = new Set(lootEffects.map(link => effects.get(link.int(0))?.int(6)))
  const spellEffects = new Map<number, Row[]>()
  for (const row of rows(1140088)) {
    if (row.parent === undefined || !spellIds.has(row.parent) || row.int(1) !== 0) continue
    const list = spellEffects.get(row.parent) ?? []
    list.push(row)
    spellEffects.set(row.parent, list)
  }
  const spellMisc = keyed(rows(1003144).filter(row => spellIds.has(row.parent) && row.int(1) === 0), row => row.parent!)
  const durations = keyed(rows(1137828))
  const byItem = new Map<number, NonNullable<DungeonLootDetails['effects']>>()
  for (const link of lootEffects) {
    const itemId = link.parent!
    const effect = effects.get(link.int(0))
    if (!effect) continue
    const trigger = triggers[effect.int(1)], spellId = effect.int(6)
    const description = spells.get(spellId)?.text(1).trim()
    const duration = durations.get(spellMisc.get(spellId)?.int(3) ?? 0)
    const value = spellText(description, spellEffects.get(spellId) ?? [], duration) ?? spellNames.get(spellId)?.text(0).trim()
    if (!trigger || !value) continue
    const list = byItem.get(itemId) ?? []
    if (!list.some(row => row.trigger === trigger && row.text === value)) list.push({ trigger, text: value })
    byItem.set(itemId, list)
  }
  const iconCache = new Map<number, boolean>()
  const hasIcon = (icon: number): boolean => {
    if (icon <= 0) return false
    const cached = iconCache.get(icon)
    if (cached !== undefined) return cached
    try {
      keep(join(atlas, 'loot-icons', `${icon}.png`), () => {
        const raw = files.read(icon)
        if (!raw) throw Error('Texture assente')
        const { width, height, rgba } = decodeBlpCutout(raw)
        return encodePng(rgba, width, height, 4)
      })
      iconCache.set(icon, true)
      return true
    } catch (error) {
      if (!(error instanceof EncryptedFileError) && (error as NodeJS.ErrnoException).code) throw error
      iconCache.set(icon, false)
      return false
    }
  }
  const result: DungeonLootDetailsById = {}
  const sparseRow = (id: number): Row | undefined => {
    const hotfix = sparseFixes.get(id)
    if (hotfix === null) return undefined
    if (hotfix) {
      try {
        const row = itemTable.rowOf!(id, hotfix)
        if (row.text(NAME) && row.int(QUALITY) <= 8) return row
      } catch {
        // The base row is still usable if a server record is incomplete.
      }
    }
    return details.get(id)
  }
  for (const id of ids) {
    const item = items.get(id), fix = itemFixes.get(id)
    // Item's server record stores the unpacked fields: ClassID, SubclassID, and IconFileDataID at bytes 0, 4 and 13.
    const updated = fix?.length === 43 ? fix : undefined
    const kind = updated?.readInt32LE(0) ?? item?.int(0)
    const sub = updated?.readUInt8(4) ?? item?.int(1) ?? 0
    const icon = updated?.readInt32LE(13) ?? item?.int(7) ?? 0
    const tooltip: DungeonLootDetails = {}
    if (kind !== undefined) tooltip.type = typeOf(kind, sub).split(' · ').at(-1)
    const texture = [icon, defaultAppearances.get(id) ?? 0, 134400].find(hasIcon)
    if (texture) tooltip.icon = texture
    const row = sparseRow(id)
    if (row) {
      const slot = row.int(SLOT), quality = row.int(QUALITY), level = row.int(LEVEL)
      const name = row.text(NAME).trim(), description = row.text(DESCRIPTION).trim()
      const required = row.int(REQUIRED), binding = bindings[row.int(BINDING)]
      if (name) tooltip.name = name
      if (description) tooltip.description = description
      if (quality >= 0 && quality <= 8) tooltip.quality = quality
      if (level > 0) tooltip.level = level
      if (required > 0 && required < 128) tooltip.required = required
      if (binding) tooltip.binding = binding
      if (slots[slot]) tooltip.slot = slots[slot]
      const budgetSlot = slot === 26 ? (sub === 19 ? 3 : 0) : statSlotGroups.findIndex(group => group.includes(slot))
      const budgetColumn = quality === 2 ? 6 : quality === 3 || quality === 7 ? 5 : quality >= 4 && quality <= 6 ? 4 : -1
      const budget = budgetSlot >= 0 && budgetColumn >= 0 ? points.get(level)?.float(budgetColumn, budgetSlot) : undefined
      if (budget && ![0, 1, 2].some(index => row.int(55, index))) {
        const stats: NonNullable<DungeonLootDetails['stats']> = []
        for (let i = 0; i < 10; i++) {
          const label = statNames[row.int(STAT_TYPE, i)], amount = Math.round(row.int(STAT_PERCENT, i) * budget / 10000)
          if (label && amount) stats.push([label, amount])
        }
        if (stats.length) tooltip.stats = stats
      }
      const scaledQuality = quality === 7 ? 3 : quality
      if (scaledQuality >= 0 && scaledQuality <= 6) {
        const speed = row.int(DELAY) / 1000
        if (kind === 2 && speed > 0) {
          const twoHanded = slot === 17 || [2, 3, 18].includes(sub)
          const caster = sub === 19 || Boolean(row.int(FLAGS, 1) & 0x200)
          const dps = damage[Number(twoHanded) * 2 + Number(caster)]?.get(level)?.float(1, scaledQuality)
          const variance = row.float(VARIANCE), school = schools[row.int(SCHOOL)]
          if (dps && Number.isFinite(variance) && variance >= 0 && variance <= 2) {
            const average = dps * speed
            const min = Math.floor(average * (1 - variance / 2)), max = Math.round(average * (1 + variance / 2))
            tooltip.weapon = { min, max, speed, dps: Math.round((min + max) / (2 * speed) * 10) / 10, ...(school && { school }) }
          }
        }
        if (kind === 4) {
          const location = armorLocation.get(slot === 20 ? 5 : slot)
          const total = armorTotal.get(level), factor = armorQuality.get(level)?.float(0, scaledQuality)
          const armor = sub === 6 ? armorShield.get(level)?.float(0, scaledQuality)
            : sub >= 1 && sub <= 4 && location && total && factor ? total.float(sub) * factor * location.float(sub - 1) : undefined
          if (armor && armor > 0) tooltip.armor = Math.round(armor)
        }
      }
    }
    const itemEffects = byItem.get(id)
    if (itemEffects) tooltip.effects = itemEffects
    if (Object.keys(tooltip).length) result[id] = tooltip
  }
  return result
}
