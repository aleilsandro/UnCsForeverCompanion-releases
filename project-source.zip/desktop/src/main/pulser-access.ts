import { BrowserWindow, clipboard, dialog, safeStorage, shell } from 'electron'
import { createHash, randomBytes } from 'node:crypto'
import { readFileSync, renameSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import qrcode from 'qrcode-generator'

export const publicSite = 'https://uncs-server.tail1b66eb.ts.net:10000'
const tokenPattern = /^[A-Za-z0-9_-]{43}$/
type Browser = { id: string; label: string; added: number }
type Publisher = { id: string; reference: string; name?: string }

class AccessError extends Error {
  constructor(readonly status: number) { super(`Accesso Pulser: errore ${status}`) }
}

export function pulserAccess(dataDir: string, privateSite: string) {
  const file = join(dataDir, 'pulser-access')
  let token: string | undefined
  let qrWindow: BrowserWindow | undefined
  let busy = false
  try {
    const stored = safeStorage.decryptString(readFileSync(file))
    if (tokenPattern.test(stored)) token = stored
  } catch { /* first run or a Windows profile that no longer owns the credential */ }

  async function available(): Promise<boolean> {
    try {
      const response = await fetch(`${publicSite}/access/status`, { redirect: 'error', signal: AbortSignal.timeout(3200) })
      return response.ok && (await response.json()).pairing === true
    } catch { return false }
  }
  function headers(): Record<string, string> {
    return token ? { Authorization: `Bearer ${token}` } : {}
  }
  async function request<T>(path: string, data?: object, admin = false): Promise<T> {
    const response = await fetch(`${admin ? privateSite : publicSite}/access/${path}`, {
      method: data ? 'POST' : 'GET', redirect: 'error', signal: AbortSignal.timeout(5000),
      headers: { ...(!admin && headers()), ...(data && { 'Content-Type': 'application/json' }) },
      body: data ? JSON.stringify(data) : undefined,
    })
    if (!response.ok) throw new AccessError(response.status)
    return await response.json() as T
  }
  async function activate(): Promise<void> {
    if (!token) {
      if (!safeStorage.isEncryptionAvailable()) throw Error('Windows non riesce a proteggere le credenziali del Pulser.')
      const created = randomBytes(32).toString('base64url')
      writeFileSync(file + '.tmp', safeStorage.encryptString(created))
      renameSync(file + '.tmp', file)
      token = created
    }
    const id = createHash('sha256').update(token).digest('hex')
    await shell.openExternal(`${publicSite}/attiva/${id}`)
  }
  async function pairing(label: string): Promise<string | undefined> {
    try {
      const grant = await request<{ token: string }>('pair', { label })
      if (!tokenPattern.test(grant.token)) throw Error('Il server ha restituito un link non valido.')
      return `${publicSite}/abbina#${grant.token}`
    } catch (error) {
      if (!(error instanceof AccessError) || error.status !== 401) throw error
      await activate()
    }
  }
  async function run(action: () => Promise<void>): Promise<void> {
    if (busy) return
    busy = true
    try { await action() }
    catch (error) {
      await dialog.showMessageBox({
        title: 'UnCs Pulser', type: 'warning',
        message: error instanceof AccessError ? 'Operazione non riuscita. Riapri la voce dalla tray e riprova.'
          : 'Operazione non riuscita. Controlla il collegamento e riprova.',
      })
    } finally { busy = false }
  }
  function showQr(url: string): void {
    const qr = qrcode(0, 'M')
    qr.addData(url)
    qr.make()
    qrWindow?.close()
    const window = new BrowserWindow({
      title: 'Abbina un dispositivo · UnCs Pulser', width: 415, height: 510, resizable: false,
      autoHideMenuBar: true, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false },
    })
    qrWindow = window
    window.on('closed', () => { if (qrWindow === window) qrWindow = undefined })
    window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
    window.webContents.on('will-navigate', event => event.preventDefault())
    const html = `<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'"><style>body{background:#0e223d;color:#f9eed7;font:16px system-ui;text-align:center;padding:16px}h1{color:#e6c27e;font:26px Georgia}img{width:285px;height:285px;image-rendering:pixelated}</style><h1>Abbina un dispositivo</h1><p>Inquadra il QR con il telefono o il tablet.<br>Scade tra cinque minuti.</p><img alt="Codice QR per aprire la mappa" src="${qr.createDataURL(5, 20)}">`
    void window.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`).catch(() => window.close())
  }
  return {
    available,
    headers,
    openMap: () => run(async () => {
      if (!await available()) { await shell.openExternal(privateSite); return }
      const url = await pairing('Browser del PC di gioco')
      if (url) await shell.openExternal(url)
    }),
    linkDevice: (asQr: boolean) => run(async () => {
      const url = await pairing(asQr ? 'Telefono o tablet' : 'Browser di un altro PC')
      if (!url) return
      if (asQr) showQr(url)
      else {
        clipboard.writeText(url)
        await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Link copiato. Aprilo nel browser dell’altro PC entro cinque minuti.' })
      }
    }),
    manage: () => run(async () => {
      const { devices } = await request<{ devices: Browser[] }>('devices')
      if (!devices.length) {
        await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Non ci sono browser abbinati.' })
        return
      }
      const buttons = ['Annulla', ...devices.map(device => `${device.label} · ${new Date(device.added).toLocaleString('it-IT')}`)]
      const { response } = await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Quale browser vuoi scollegare?', buttons, cancelId: 0, defaultId: 0 })
      const selected = devices[response - 1]
      if (selected) {
        await request('revoke', { id: selected.id })
        await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Browser scollegato.' })
      }
    }),
    invite: () => run(async () => {
      const grant = await request<{ token: string; reference: string }>('invite', {}, true)
      if (!tokenPattern.test(grant.token)) throw Error('Codice invito non valido.')
      clipboard.writeText(grant.token)
      await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Codice d’invito copiato.', detail: `Passalo in privato a un gildano. È monouso e scade dopo sette giorni. Riferimento: ${grant.reference}.` })
    }),
    removePublisher: () => run(async () => {
      const { publishers } = await request<{ publishers: Publisher[] }>('publishers', undefined, true)
      if (!publishers.length) {
        await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Non ci sono Pulser attivati.' })
        return
      }
      const label = (p: Publisher) => p.name ? `${p.name} · ${p.reference}` : `Invito ${p.reference}`
      publishers.sort((a, b) => label(a).localeCompare(label(b), 'it'))
      for (let offset = 0; offset < publishers.length; offset += 8) {
        const page = publishers.slice(offset, offset + 8)
        const buttons = ['Annulla', ...page.map(label)]
        if (offset + page.length < publishers.length) buttons.push('Mostra altri')
        const { response } = await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Quale Pulser vuoi disattivare?', buttons, cancelId: 0, defaultId: 0 })
        if (response === 0) return
        const selected = page[response - 1]
        if (!selected) continue
        const confirmation = await dialog.showMessageBox({
          title: 'UnCs Pulser', type: 'question', message: `Disattivare ${label(selected)} e tutti i suoi browser?`,
          buttons: ['Annulla', 'Disattiva'], cancelId: 0, defaultId: 0,
        })
        if (confirmation.response === 1) {
          await request('remove-pulser', { id: selected.id }, true)
          await dialog.showMessageBox({ title: 'UnCs Pulser', message: 'Pulser e browser scollegati.' })
        }
        return
      }
    }),
  }
}
