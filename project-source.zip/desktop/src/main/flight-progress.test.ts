import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { afterEach, beforeEach, expect, test, vi } from 'vitest'
import { findGameWindow, programOf } from './capture'
import { flightProgress } from './flight-progress'

vi.mock('./capture', () => ({ findGameWindow: vi.fn(), programOf: vi.fn() }))

let root: string
let profile: string

beforeEach(async () => {
  root = await mkdtemp(join(tmpdir(), 'uncs-flights-'))
  profile = join(root, 'pulser')
  await mkdir(profile)
  vi.mocked(findGameWindow).mockReturnValue(1n)
  vi.mocked(programOf).mockReturnValue(join(root, 'Wow.exe'))
})

afterEach(async () => {
  await rm(root, { recursive: true, force: true })
})

async function saveFlights(account: string, character: string, ...names: string[]) {
  const file = join(root, 'WTF', 'Account', account, 'Forever', character, 'SavedVariables', 'OpenMap.lua')
  await mkdir(dirname(file), { recursive: true })
  await writeFile(file, [
    'OpenMapCharDB = {',
    '["flightsKnownV"] = 2,',
    '["flightsKnown"] = {',
    ...names.map(name => `["${name}"] = true,`),
    '},',
    '}',
  ].join('\r\n'))
}

test('imports Forever’s hyphenated character folders and caches each character separately', async () => {
  await saveFlights('Account', 'Alice-Raven', 'Stormwind, Elwynn')
  await saveFlights('Account', 'Bob-Raven', 'Auberdine, Darkshore')
  const progress = flightProgress(profile)

  expect(await progress.read('Alice Raven', 'A', { side: 'A', known: [4], checked: [0] }))
    .toEqual({ side: 'A', known: [4, 2], checked: [0] })
  expect(await progress.read('Bob Raven', 'A'))
    .toEqual({ side: 'A', known: [26], checked: [1] })

  vi.mocked(findGameWindow).mockReturnValue(null)
  const restarted = flightProgress(profile)
  expect(await restarted.read('Alice Raven', 'A')).toEqual({ side: 'A', known: [4, 2], checked: [0] })
  expect(await restarted.read('Bob Raven', 'A')).toEqual({ side: 'A', known: [26], checked: [1] })
})

test('leaves saved flights unverified when the character name matches multiple accounts', async () => {
  await saveFlights('FirstAccount', 'Alice-Raven', 'Stormwind, Elwynn')
  await saveFlights('SecondAccount', 'Alice-Raven', 'Auberdine, Darkshore')

  expect(await flightProgress(profile).read('Alice Raven', 'A'))
    .toEqual({ side: 'A', known: [], checked: [] })
})
