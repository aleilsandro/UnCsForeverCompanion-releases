import { expect, test } from 'vitest'
import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { cachePath, cacheRevision } from './map-cache'
test('isolates caches by addon revision and uses safe deterministic names', () => {
  const game=mkdtempSync(join(tmpdir(),'uncs-cache-'))
  const addon=join(game,'_forever_','Interface','AddOns','OpenMap')
  mkdirSync(addon,{recursive:true})
  writeFileSync(join(addon,'OpenMap.toc'),'first')
  const first=cacheRevision(game)
  expect(cachePath('cache','native',123)).toBe(cachePath('cache','native',123))
  expect(cachePath('cache','native',123)).not.toBe(cachePath('cache','art',123))
  expect(cachePath('cache','art','../../anything')).toMatch(/art-[a-f0-9]{64}\.png$/)
  writeFileSync(join(addon,'OpenMap.toc'),'a-different-size')
  expect(cacheRevision(game)).not.toBe(first)
})
