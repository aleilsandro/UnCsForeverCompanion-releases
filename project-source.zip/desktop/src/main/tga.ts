/** Uncompressed 24/32-bit TGA; decode origin and BGR channels explicitly. */
export function decodeTga(file: Buffer, tint = true): { width: number; height: number; rgba: Uint8Array } {
  if (file.length < 18 || file[1] !== 0 || file[2] !== 2) throw new Error('Unsupported TGA')
  const width = file.readUInt16LE(12), height = file.readUInt16LE(14), depth = file[16]!, origin = file[17]!
  if (!width || !height || width > 1024 || height > 1024 || (depth !== 24 && depth !== 32)) throw new Error('Unsupported TGA size')
  const stride = depth / 8, start = 18 + file[0]!
  if (start + width * height * stride > file.length) throw new Error('Truncated TGA')
  const rgba = new Uint8Array(width * height * 4)
  for (let y=0; y<height; y++) for (let x=0; x<width; x++) {
    const sx = origin & 16 ? width-1-x : x, sy = origin & 32 ? y : height-1-y
    const source = start + (sy * width + sx) * stride, target = (y * width + x) * 4
    const r=file[source+2]!, g=file[source+1]!, b=file[source]!, grey=.299*r+.587*g+.114*b
    rgba[target]=tint ? Math.round(r*.65+grey*.35) : r
    rgba[target+1]=tint ? Math.round((g*.65+grey*.35)*.93) : g
    rgba[target+2]=tint ? Math.round((b*.65+grey*.35)*.80) : b
    rgba[target+3]=stride === 4 ? file[source+3]! : 255
  }
  return { width, height, rgba }
}
