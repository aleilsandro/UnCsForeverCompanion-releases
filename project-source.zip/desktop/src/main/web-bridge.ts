import { app, dialog, Menu, nativeImage, Notification, shell, Tray, type MenuItemConstructorOptions } from 'electron'
import { autoUpdater } from 'electron-updater'
import { randomUUID } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { startLink } from './link'
import { uploadMap } from './pulser-map'
import { publicSite, pulserAccess } from './pulser-access'
import { pulserDownloads, pulserFeeds } from './pulser-update'
import { flightStatusFrom } from '../shared/flight-points'
import { flightProgress } from './flight-progress'
import { GROUP_STALE, groupFrom } from '../shared/group'
import { MIDDLE_YARDS } from '../shared/inside'
import { findGameWindow, programOf } from './capture'
import { gameFolderFrom, installedBuild, registryInstallPath } from './client-files'
import { finishedInteriors } from './interiors'
import startDungeonWorker from './dungeon-worker?nodeWorker'

const site = 'https://uncs-server.tail1b66eb.ts.net:8447'
const launchName = 'UnCs Forever Web Bridge'
const expiry = 25_000
const positionUploadInterval = 1000
const signalGrace = 5000
const guildName = 'Unconscious Clan'
const local = !app.isPackaged && process.argv.includes('--local')
const localKey = process.env.UNCS_WEB_LOCAL_PULSER_KEY ?? ''
const localSite = 'http://127.0.0.1:18796'

if (local) {
  const profile = process.env.UNCS_WEB_LOCAL_PULSER_PROFILE
  if (!profile || !/^[a-f0-9]{64}$/.test(localKey)) throw Error('Avvia il Pulser locale con web/local.ps1 -Pulser.')
  app.setPath('userData', profile)
  app.setPath('sessionData', profile)
}

let openRequested = process.argv.includes('--open-map')
let openMap: (() => void) | undefined
if (!app.requestSingleInstanceLock()) app.quit()
else void app.whenReady().then(() => {
  const file = join(app.getPath('userData'), 'source-id')
  let source = ''
  try { source = readFileSync(file, 'utf8').trim() } catch { /* first run */ }
  if (!/^[a-f0-9-]{36}$/.test(source)) {
    source = randomUUID()
    try { writeFileSync(file, source) } catch { /* works for this session */ }
  }
  const icon = nativeImage.createFromPath(local ? join(__dirname, '../../../design/pulser.ico') : join(process.resourcesPath, 'bridge.ico'))
  const tray = new Tray(icon)
  const identity = local ? 'UnCs Pulser locale' : `UnCs Pulser ${app.getVersion()}`
  const mapRoot = process.env.UNCS_WEB_MAP_ROOT
  const localTiles = mapRoot ? join(mapRoot, 'tiles') : null
  let dungeonTiles: string | null = localTiles
  let preparing: ReturnType<typeof startDungeonWorker> | undefined
  let lastDungeon: number | undefined
  function prepareDungeon(id: number): void {
    if (preparing || lastDungeon === id || !Number.isSafeInteger(id) || id <= 0 || id > 99999) return
    lastDungeon = id
    try {
      if (localTiles && finishedInteriors(localTiles)?.maps.some(map => map.id === id && map.kind !== 'world')) {
        dungeonTiles = localTiles
        return
      }
      const window = findGameWindow()
      const gameFolder = gameFolderFrom([window === null ? null : programOf(window), registryInstallPath()])
      const build = gameFolder && installedBuild(gameFolder)?.buildKey
      if (!gameFolder || !build || !/^[0-9a-f]+$/i.test(build)) return
      const folder = join(app.getPath('userData'), 'dungeon-cache', build)
      if (finishedInteriors(folder)?.maps.some(map => map.id === id && map.kind !== 'world')) {
        dungeonTiles = folder
        return
      }
      const worker = startDungeonWorker({ workerData: { gameFolder, folder, id } })
      preparing = worker
      worker.once('message', ({ ok }) => { if (ok && lastDungeon === id) dungeonTiles = folder })
      worker.once('error', () => { /* Coordinate fornite direttamente dal gioco restano utilizzabili. */ })
      worker.once('exit', () => { if (preparing === worker) preparing = undefined })
    } catch { /* Il posizionamento può continuare con le coordinate che il gioco ha fornito. */ }
  }
  const link = startLink(() => dungeonTiles)
  const access = local ? undefined : pulserAccess(app.getPath('userData'), site)
  const progress = flightProgress(app.getPath('userData'))
  openMap = local ? () => { void shell.openExternal(localSite) } : () => { void access?.openMap() }
  let status = 'In attesa di WoW'
  let pending = false, updating = false
  let publishing = false
  let lastValidSignal = 0
  let mapAdmin = false, importing = false
  let availableVersion = '', announcedVersion = ''
  const defineMenu = (): void => {
    tray.setToolTip(`${identity} · ${status}`)
    const entries: MenuItemConstructorOptions[] = [
      { label: identity, enabled: false },
      { label: status, enabled: false },
      { label: local ? 'Apri mappa locale' : 'Apri mappa web', click: openMap },
    ]
    if (!access) {
      entries.push({ label: 'Esci', click: () => app.quit() })
      tray.setContextMenu(Menu.buildFromTemplate(entries))
      return
    }
    entries.push(
      { label: 'Abbina un dispositivo', submenu: [
        { label: 'Mostra QR per telefono o tablet', click: () => void access.linkDevice(true) },
        { label: 'Copia link per un altro PC', click: () => void access.linkDevice(false) },
        { label: 'Scollega un browser', click: () => void access.manage() },
      ] },
      { label: 'Avvia al login di Windows', type: 'checkbox', checked: app.getLoginItemSettings().executableWillLaunchAtLogin,
        click: item => { app.setLoginItemSettings({ name: launchName, openAtLogin: item.checked, enabled: item.checked }); defineMenu() } },
      { label: updating ? 'Aggiornamento in corso…' : availableVersion ? `Aggiorna Pulser e addon · ${availableVersion}` : 'Cerca aggiornamenti',
        enabled: !updating && !importing, click: () => void update(true) },
    )
    if (mapAdmin) entries.push({
      label: 'Amministrazione',
      submenu: [
        { label: 'Crea invito Pulser', click: () => void access.invite() },
        { label: 'Disattiva un Pulser della gilda', click: () => void access.removePublisher() },
        { label: importing ? 'Invio cartografia in corso…' : 'Carica cartografia sul server', enabled: !importing && !updating, click: () => void importMap() },
      ],
    })
    entries.push({ label: 'Esci', enabled: !importing, click: () => app.quit() })
    tray.setContextMenu(Menu.buildFromTemplate(entries))
  }
  const tell = (message: string): void => {
    if (status === message) return
    status = message
    defineMenu()
  }
  defineMenu()
  const checkMapAccess = (): void => {
    void fetch(`${site}/map-import`, { redirect: 'error', signal: AbortSignal.timeout(5000) })
      .then(response => response.ok, () => false).then(allowed => {
        if (mapAdmin !== allowed) { mapAdmin = allowed; defineMenu() }
      })
  }
  if (!local) checkMapAccess()
  const accessCheck = local ? undefined : setInterval(checkMapAccess, 60_000)
  async function importMap(): Promise<void> {
    if (importing) return
    importing = true
    defineMenu()
    try {
      const selected = await dialog.showOpenDialog({ title: 'Scegli la cartella della cartografia', properties: ['openDirectory'] })
      const folder = selected.filePaths[0]
      if (selected.canceled || !folder) return
      const answer = await dialog.showMessageBox({ type: 'question', title: 'UnCs Pulser',
        message: 'Caricare la cartografia per tutti gli utenti autorizzati della mappa web?',
        detail: 'Scegli un pacchetto di immagini che hai il diritto di condividere.',
        buttons: ['Carica', 'Annulla'], defaultId: 1, cancelId: 1 })
      if (answer.response !== 0) return
      const count = await uploadMap(site, folder, (done, total) => { tray.setToolTip(`${identity} · Cartografia ${done}/${total}`) })
      await dialog.showMessageBox({ title: 'UnCs Pulser', message: `Cartografia salvata sul server. File caricati: ${count}.` })
    } catch (error) {
      await dialog.showMessageBox({ title: 'UnCs Pulser', type: 'warning', message: error instanceof Error ? error.message : 'Importazione non riuscita.' })
    } finally { importing = false; defineMenu() }
  }
  tray.on('double-click', openMap)
  if (openRequested) openMap()
  autoUpdater.autoDownload = false
  autoUpdater.autoInstallOnAppQuit = false
  autoUpdater.disableDifferentialDownload = true
  autoUpdater.on('error', () => { /* update() reports the failure */ })
  async function checkUpdate() {
    const feeds = await pulserFeeds(publicSite, site)
    let checked = false
    for (const url of feeds) {
      try {
        autoUpdater.setFeedURL({ provider: 'generic', url })
        const result = await autoUpdater.checkForUpdates()
        if (result?.isUpdateAvailable) return result
        if (result) checked = true
      } catch { /* try the next reachable source */ }
    }
    if (!checked) throw Error('Nessuna fonte aggiornamenti raggiungibile.')
    return null
  }
  async function update(interactive: boolean): Promise<void> {
    if (updating || importing) return
    updating = true
    if (interactive) defineMenu()
    try {
      const result = await checkUpdate()
      if (!result) {
        availableVersion = ''
        if (interactive) await dialog.showMessageBox({
          title: 'UnCs Pulser', message: 'Nessun aggiornamento disponibile al momento.',
          detail: `Installato: ${identity}. Se hai appena pubblicato una release, comparirà dopo che GitHub avrà verificato tutti gli allegati.`,
        })
        return
      }
      availableVersion = result.updateInfo.version
      if (!interactive) {
        if (announcedVersion !== availableVersion && Notification.isSupported()) {
          announcedVersion = availableVersion
          const notification = new Notification({ title: 'Aggiornamento UnCs Pulser', body: `Versione ${availableVersion} disponibile per Pulser e addon.`, icon })
          notification.on('click', () => void update(true))
          notification.show()
        }
        return
      }
      const answer = await dialog.showMessageBox({ type: 'question', message: `Installare UnCs Pulser ${availableVersion} e aggiornare l’addon?`,
        detail: 'Se WoW è aperto, usa /reload a installazione conclusa.',
        buttons: ['Aggiorna', 'Annulla'], defaultId: 0, cancelId: 1 })
      if (answer.response !== 0) return
      try { await autoUpdater.downloadUpdate() }
      catch { await autoUpdater.downloadUpdate() }
      autoUpdater.quitAndInstall(true, true)
    } catch {
      if (interactive) {
        const { response } = await dialog.showMessageBox({
          title: 'UnCs Pulser', type: 'warning', message: 'Aggiornamento non riuscito.',
          detail: 'Puoi riprovare dalla tray o aprire la pagina ufficiale dei download.',
          buttons: ['Chiudi', 'Apri download'], cancelId: 0, defaultId: 0,
        })
        if (response === 1) await shell.openExternal(pulserDownloads)
      }
    } finally {
      updating = false
      defineMenu()
    }
  }
  const updateStartup = local ? undefined : setTimeout(() => void update(false), 6000)
  const updateCheck = local ? undefined : setInterval(() => void update(false), 10 * 60_000)
  async function upload(data: object): Promise<boolean> {
    const authorization = local ? { Authorization: `Bearer ${localKey}` } : access?.headers()
    const res = await fetch(`${local ? localSite : publicSite}/bridge/publish`, {
      method: 'POST', redirect: 'error', headers: { 'Content-Type': 'application/json', ...authorization },
      body: JSON.stringify({ source, ...data }), signal: AbortSignal.timeout(4500),
    })
    if (!res.ok) {
      tell(res.status === 401 && !local ? 'Apri la mappa per attivare Pulser' : res.status === 403 ? 'Invio posizione non autorizzato' : `Server: errore ${res.status}`)
      return false
    }
    return true
  }
  const timer = setInterval(async () => {
    if (pending) return
    pending = true
    try {
      const { game, state } = link.snapshot()
      const { pos, geometry, flights, char } = state.sections
      const fresh = Date.now() - (state.updatedAt.pos ?? 0) < expiry
      const inst = pos?.inst?.kind === 'party' || pos?.inst?.kind === 'raid' ? pos.inst : undefined
      if (!inst) lastDungeon = undefined
      const player = pos?.publisher ?? (local && inst && char?.name ? { name: char.name, level: char.level, guild: guildName } : undefined)
      const sync = game === 'open' && fresh && player?.guild === guildName && player.name && pos
        && (inst || (!pos.inst && pos.wx !== undefined && pos.wy !== undefined))
      if (!sync) {
        const left = game === 'closed' || (player && player.guild !== guildName) || pos?.inst
        if (publishing && (left || Date.now() - lastValidSignal >= signalGrace) &&
            await upload({ stopped: true })) publishing = false
        tell(game === 'closed' ? 'In attesa di WoW' : game === 'minimized' ? 'WoW minimizzato' :
          !fresh ? 'In attesa del segnale dell’addon' : player?.guild !== guildName ? 'Condivisione Unconscious Clan non attiva' : 'In attesa di coordinate di gioco')
        return
      }
      if (inst && (inst.x === undefined || inst.y === undefined)) prepareDungeon(inst.id)
      lastValidSignal = Date.now()
      if (!local && !access?.headers().Authorization) {
        tell('Apri la mappa per attivare Pulser')
        return
      }
      const reported = flights && typeof flights === 'object' && 'name' in flights && flights.name === player.name
        ? flightStatusFrom(flights) : undefined
      const side = reported?.side ?? (char?.name === player.name ? char.side : undefined)
      const flightStatus = side === 'A' || side === 'H' ? await progress.read(player.name, side, reported) : undefined
      const companions = inst ? groupFrom(state.sections.group, Date.now() - (state.updatedAt.group ?? -GROUP_STALE)) : []
      const group = inst ? companions
        .filter(member => member.inst === inst.id && Math.abs(member.wx ?? Infinity) <= MIDDLE_YARDS && Math.abs(member.wy ?? Infinity) <= MIDDLE_YARDS)
        .map(member => ({ n: member.name, i: member.inst, wx: member.wx, wy: member.wy, l: member.floor })) : undefined
      const position = inst ? { inst: { id: inst.id, name: inst.name, kind: inst.kind, x: inst.x, y: inst.y, level: inst.level }, facing: pos.facing } : pos
      const sample = { name: player.name, level: player.level, guild: player.guild, pos: position, geometry: inst ? undefined : geometry,
        flights: flightStatus, group, party: inst ? companions.map(member => member.name) : undefined }
      if (await upload(sample)) {
        publishing = true
        tell(local ? 'Posizione sulla mappa locale' : 'Posizione condivisa')
      }
    } catch { tell('Server non raggiungibile') } finally { pending = false }
  }, positionUploadInterval)
  app.once('before-quit', () => {
    clearInterval(timer)
    clearInterval(accessCheck)
    clearTimeout(updateStartup)
    clearInterval(updateCheck)
    link.stop()
    void preparing?.terminate()
  })
}).catch(error => { dialog.showErrorBox('UnCs Pulser', String(error)); app.quit() })

app.on('second-instance', (_event, argv) => {
  if (!argv.includes('--open-map')) return
  if (openMap) openMap()
  else openRequested = true
})
app.on('window-all-closed', () => { /* closing the QR leaves the tray running */ })
