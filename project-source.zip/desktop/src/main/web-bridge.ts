import { app, dialog, Menu, nativeImage, Notification, shell, Tray, type MenuItemConstructorOptions } from 'electron'
import { autoUpdater } from 'electron-updater'
import { randomUUID } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { startLink } from './link'
import { uploadMap } from './pulser-map'
import { publicSite, pulserAccess } from './pulser-access'

const site = 'https://uncs-server.tail1b66eb.ts.net:8447'
const launchName = 'UnCs Forever Web Bridge'
const expiry = 25_000
const positionUploadInterval = 1000
const guildName = 'Unconscious Clan'

let openRequested = process.argv.includes('--open-map')
let openMap: (() => void) | undefined
if (!app.requestSingleInstanceLock()) app.quit()
else void app.whenReady().then(() => {
  const file = join(app.getPath('userData'), 'source-id')
  let source = ''
  try { source = readFileSync(file, 'utf8').trim() } catch { /* first run */ }
  if (!/^[a-f0-9-]{36}$/.test(source)) {
    source = randomUUID()
    try { writeFileSync(file, source) } catch { /* works for this session */ }
  }
  const icon = nativeImage.createFromPath(join(process.resourcesPath, 'bridge.ico'))
  const tray = new Tray(icon)
  const identity = `UnCs Pulser ${app.getVersion()}`
  const link = startLink()
  const access = pulserAccess(app.getPath('userData'), site)
  openMap = () => void access.openMap()
  let status = 'In attesa di WoW'
  let pending = false, updating = false
  let publishedTo: string | undefined
  let publicEnabled = false
  let mapAdmin = false, importing = false
  let availableVersion = '', announcedVersion = ''
  const defineMenu = (): void => {
    tray.setToolTip(`${identity} · ${status}`)
    const entries: MenuItemConstructorOptions[] = [
      { label: identity, enabled: false },
      { label: status, enabled: false },
      { label: 'Apri mappa web', click: openMap },
      { label: 'Abbina un dispositivo', submenu: [
        { label: 'Mostra QR per telefono o tablet', click: () => void access.linkDevice(true) },
        { label: 'Copia link per un altro PC', click: () => void access.linkDevice(false) },
        { label: 'Scollega un browser', click: () => void access.manage() },
      ] },
      { label: 'Avvia al login di Windows', type: 'checkbox', checked: app.getLoginItemSettings().executableWillLaunchAtLogin,
        click: item => { app.setLoginItemSettings({ name: launchName, openAtLogin: item.checked, enabled: item.checked }); defineMenu() } },
      { label: updating ? 'Aggiornamento in corso…' : availableVersion ? `Aggiorna Pulser e addon · ${availableVersion}` : 'Cerca aggiornamenti',
        enabled: !updating && !importing, click: () => void update(true) },
    ]
    if (mapAdmin) entries.push({
      label: 'Amministrazione',
      submenu: [
        { label: 'Crea invito Pulser', click: () => void access.invite() },
        { label: 'Disattiva un Pulser della gilda', click: () => void access.removePublisher() },
        { label: importing ? 'Invio cartografia in corso…' : 'Carica cartografia sul server', enabled: !importing && !updating, click: () => void importMap() },
      ],
    })
    entries.push({ label: 'Esci', enabled: !importing, click: () => app.quit() })
    tray.setContextMenu(Menu.buildFromTemplate(entries))
  }
  const tell = (message: string): void => {
    if (status === message) return
    status = message
    defineMenu()
  }
  defineMenu()
  const checkMapAccess = (): void => {
    void access.available().then(enabled => { publicEnabled ||= enabled })
    void fetch(`${site}/map-import`, { redirect: 'error', signal: AbortSignal.timeout(5000) })
      .then(response => response.ok, () => false).then(allowed => {
        if (mapAdmin !== allowed) { mapAdmin = allowed; defineMenu() }
      })
  }
  checkMapAccess()
  const accessCheck = setInterval(checkMapAccess, 60_000)
  async function importMap(): Promise<void> {
    if (importing) return
    importing = true
    defineMenu()
    try {
      const selected = await dialog.showOpenDialog({ title: 'Scegli la cartella della cartografia', properties: ['openDirectory'] })
      const folder = selected.filePaths[0]
      if (selected.canceled || !folder) return
      const answer = await dialog.showMessageBox({ type: 'question', title: 'UnCs Pulser',
        message: 'Caricare la cartografia per tutti gli utenti autorizzati della mappa web?',
        detail: 'Scegli un pacchetto di immagini che hai il diritto di condividere.',
        buttons: ['Carica', 'Annulla'], defaultId: 1, cancelId: 1 })
      if (answer.response !== 0) return
      const count = await uploadMap(site, folder, (done, total) => { tray.setToolTip(`${identity} · Cartografia ${done}/${total}`) })
      await dialog.showMessageBox({ title: 'UnCs Pulser', message: `Cartografia salvata sul server. File caricati: ${count}.` })
    } catch (error) {
      await dialog.showMessageBox({ title: 'UnCs Pulser', type: 'warning', message: error instanceof Error ? error.message : 'Importazione non riuscita.' })
    } finally { importing = false; defineMenu() }
  }
  tray.on('double-click', openMap)
  if (openRequested) openMap()
  autoUpdater.autoDownload = false
  autoUpdater.autoInstallOnAppQuit = false
  autoUpdater.disableDifferentialDownload = true
  autoUpdater.on('error', () => { /* update() reports the failure */ })
  async function update(interactive: boolean): Promise<void> {
    if (updating || importing) return
    updating = true
    if (interactive) defineMenu()
    try {
      const feed = await access.available() ? publicSite : site
      autoUpdater.setFeedURL({ provider: 'generic', url: `${feed}/bridge/releases/` })
      const result = await autoUpdater.checkForUpdates()
      if (!result?.isUpdateAvailable) {
        availableVersion = ''
        if (interactive) await dialog.showMessageBox({ message: `${identity} già aggiornato.` })
        return
      }
      availableVersion = result.updateInfo.version
      if (!interactive) {
        if (announcedVersion !== availableVersion && Notification.isSupported()) {
          announcedVersion = availableVersion
          const notification = new Notification({ title: 'Aggiornamento UnCs Pulser', body: `Versione ${availableVersion} disponibile per Pulser e addon.`, icon })
          notification.on('click', () => void update(true))
          notification.show()
        }
        return
      }
      const answer = await dialog.showMessageBox({ type: 'question', message: `Installare UnCs Pulser ${availableVersion} e aggiornare l’addon?`,
        detail: 'Se WoW è aperto, usa /reload a installazione conclusa.',
        buttons: ['Aggiorna', 'Annulla'], defaultId: 0, cancelId: 1 })
      if (answer.response !== 0) return
      await autoUpdater.downloadUpdate()
      autoUpdater.quitAndInstall(true, true)
    } catch {
      if (interactive) await dialog.showMessageBox({ type: 'warning', message: 'Aggiornamento non riuscito. Verifica la connessione e i permessi della cartella di WoW.' })
    } finally {
      updating = false
      defineMenu()
    }
  }
  const updateStartup = setTimeout(() => void update(false), 6000)
  const updateCheck = setInterval(() => void update(false), 30 * 60_000)
  async function upload(destination: string, data: object): Promise<boolean> {
    const res = await fetch(`${destination}/bridge/publish`, {
      method: 'POST', redirect: 'error', headers: { 'Content-Type': 'application/json', ...(destination === publicSite && access.headers()) },
      body: JSON.stringify({ source, ...data }), signal: AbortSignal.timeout(4500),
    })
    if (!res.ok) {
      tell(res.status === 401 ? 'Apri la mappa per attivare Pulser' : res.status === 403 ? 'Invio posizione non autorizzato' : `Server: errore ${res.status}`)
      return false
    }
    return true
  }
  const timer = setInterval(async () => {
    if (pending) return
    pending = true
    try {
      const { game, state } = link.snapshot()
      const { pos, geometry } = state.sections
      const fresh = Date.now() - (state.updatedAt.pos ?? 0) < expiry
      const player = pos?.publisher
      const sync = game === 'open' && fresh && player?.guild === guildName && player.name && pos?.wx !== undefined && pos.wy !== undefined && !pos.inst
      if (!sync) {
        if (publishedTo && await upload(publishedTo, { stopped: true })) publishedTo = undefined
        tell(game === 'closed' ? 'In attesa di WoW' : game === 'minimized' ? 'WoW minimizzato' :
          !fresh ? 'In attesa del segnale dell’addon' : player?.guild !== guildName ? 'Condivisione Unconscious Clan non attiva' : 'In attesa di coordinate nel mondo')
        return
      }
      const destination = publicEnabled ? publicSite : site
      if (publishedTo && publishedTo !== destination) {
        const previous = publishedTo
        publishedTo = undefined
        await upload(previous, { stopped: true }).catch(() => {})
      }
      if (destination === publicSite && !access.headers().Authorization) {
        tell('Apri la mappa per attivare Pulser')
        return
      }
      if (await upload(destination, { name: player.name, level: player.level, guild: player.guild, pos, geometry })) {
        publishedTo = destination
        tell('Posizione condivisa')
      }
    } catch { tell('Server non raggiungibile') } finally { pending = false }
  }, positionUploadInterval)
  app.once('before-quit', () => {
    clearInterval(timer)
    clearInterval(accessCheck)
    clearTimeout(updateStartup)
    clearInterval(updateCheck)
    link.stop()
  })
}).catch(error => { dialog.showErrorBox('UnCs Pulser', String(error)); app.quit() })

app.on('second-instance', (_event, argv) => {
  if (!argv.includes('--open-map')) return
  if (openMap) openMap()
  else openRequested = true
})
app.on('window-all-closed', () => { /* closing the QR leaves the tray running */ })
