import { app, dialog, Menu, nativeImage, Notification, shell, Tray } from 'electron'
import { autoUpdater } from 'electron-updater'
import { randomUUID } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { startLink } from './link'
import { uploadMap } from './pulser-map'

const site = 'https://uncs-server.tail1b66eb.ts.net:8447'
const launchName = 'UnCs Forever Web Bridge'
const expiry = 25_000

if (!app.requestSingleInstanceLock()) app.quit()
else void app.whenReady().then(() => {
  const file = join(app.getPath('userData'), 'source-id')
  let source = ''
  try { source = readFileSync(file, 'utf8').trim() } catch { /* first run */ }
  if (!/^[a-f0-9-]{36}$/.test(source)) {
    source = randomUUID()
    try { writeFileSync(file, source) } catch { /* works for this session */ }
  }
  const icon = nativeImage.createFromPath(join(process.resourcesPath, 'bridge.ico'))
  const tray = new Tray(icon)
  const link = startLink()
  let status = 'In attesa di WoW'
  let pending = false, updating = false, publishing = false
  let mapAdmin = false, importing = false
  let availableVersion = '', announcedVersion = ''
  const defineMenu = (): void => {
    tray.setToolTip(`UnCs Pulser · ${status}`)
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: status, enabled: false },
      { label: 'Apri mappa web', click: () => void shell.openExternal(site) },
      { label: 'Avvia al login di Windows', type: 'checkbox', checked: app.getLoginItemSettings().executableWillLaunchAtLogin,
        click: item => { app.setLoginItemSettings({ name: launchName, openAtLogin: item.checked, enabled: item.checked }); defineMenu() } },
      { label: updating ? 'Aggiornamento in corso…' : availableVersion ? `Aggiorna Pulser e addon · ${availableVersion}` : 'Cerca aggiornamenti',
        enabled: !updating && !importing, click: () => void update(true) },
      { label: importing ? 'Invio cartografia in corso…' : 'Carica cartografia sul server', visible: mapAdmin, enabled: !importing && !updating, click: () => void importMap() },
      { label: 'Esci', enabled: !importing, click: () => app.quit() },
    ]))
  }
  const tell = (message: string): void => {
    if (status === message) return
    status = message
    defineMenu()
  }
  defineMenu()
  const checkMapAccess = (): void => {
    void fetch(`${site}/map-import`, { redirect: 'error', signal: AbortSignal.timeout(5000) }).then(response => {
      if (mapAdmin !== response.ok) { mapAdmin = response.ok; defineMenu() }
    }).catch(() => {})
  }
  checkMapAccess()
  const accessCheck = setInterval(checkMapAccess, 60_000)
  async function importMap(): Promise<void> {
    if (importing) return
    importing = true
    defineMenu()
    try {
      const selected = await dialog.showOpenDialog({ title: 'Scegli la cartella della cartografia', properties: ['openDirectory'] })
      const folder = selected.filePaths[0]
      if (selected.canceled || !folder) return
      const answer = await dialog.showMessageBox({ type: 'question', title: 'UnCs Pulser',
        message: 'Caricare la cartografia per tutti gli utenti autorizzati della mappa web?',
        detail: 'Scegli un pacchetto di immagini che hai il diritto di condividere.',
        buttons: ['Carica', 'Annulla'], defaultId: 1, cancelId: 1 })
      if (answer.response !== 0) return
      const count = await uploadMap(site, folder, (done, total) => { tray.setToolTip(`UnCs Pulser · Cartografia ${done}/${total}`) })
      await dialog.showMessageBox({ title: 'UnCs Pulser', message: `Cartografia salvata sul server. File caricati: ${count}.` })
    } catch (error) {
      await dialog.showMessageBox({ title: 'UnCs Pulser', type: 'warning', message: error instanceof Error ? error.message : 'Importazione non riuscita.' })
    } finally { importing = false; defineMenu() }
  }
  tray.on('double-click', () => void shell.openExternal(site))
  autoUpdater.autoDownload = false
  autoUpdater.autoInstallOnAppQuit = false
  autoUpdater.disableDifferentialDownload = true
  autoUpdater.setFeedURL({ provider: 'generic', url: `${site}/bridge/releases/` })
  autoUpdater.on('error', () => { /* update() reports the failure */ })
  async function update(interactive: boolean): Promise<void> {
    if (updating || importing) return
    updating = true
    if (interactive) defineMenu()
    try {
      const result = await autoUpdater.checkForUpdates()
      if (!result?.isUpdateAvailable) {
        availableVersion = ''
        if (interactive) await dialog.showMessageBox({ message: `UnCs Pulser ${app.getVersion()} già aggiornato.` })
        return
      }
      availableVersion = result.updateInfo.version
      if (!interactive) {
        if (announcedVersion !== availableVersion && Notification.isSupported()) {
          announcedVersion = availableVersion
          const notification = new Notification({ title: 'Aggiornamento UnCs Pulser', body: `Versione ${availableVersion} disponibile per Pulser e addon.`, icon })
          notification.on('click', () => void update(true))
          notification.show()
        }
        return
      }
      const answer = await dialog.showMessageBox({ type: 'question', message: `Installare UnCs Pulser ${availableVersion} e aggiornare l’addon?`,
        detail: 'Se WoW è aperto, usa /reload a installazione conclusa.',
        buttons: ['Aggiorna', 'Annulla'], defaultId: 0, cancelId: 1 })
      if (answer.response !== 0) return
      await autoUpdater.downloadUpdate()
      autoUpdater.quitAndInstall(true, true)
    } catch {
      if (interactive) await dialog.showMessageBox({ type: 'warning', message: 'Aggiornamento non riuscito. Verifica il collegamento a Tailscale e i permessi della cartella di WoW.' })
    } finally {
      updating = false
      defineMenu()
    }
  }
  const updateStartup = setTimeout(() => void update(false), 6000)
  const updateCheck = setInterval(() => void update(false), 30 * 60_000)
  async function upload(data: object): Promise<boolean> {
    const res = await fetch(`${site}/bridge/publish`, {
      method: 'POST', redirect: 'error', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source, ...data }), signal: AbortSignal.timeout(4500),
    })
    if (!res.ok) {
      tell(res.status === 403 ? 'Accesso Tailscale non autorizzato' : `Server: errore ${res.status}`)
      return false
    }
    return true
  }
  const timer = setInterval(async () => {
    if (pending) return
    pending = true
    try {
      const { game, state } = link.snapshot()
      const { pos, char, guild, geometry } = state.sections
      const fresh = Date.now() - (state.updatedAt.pos ?? 0) < expiry
      const share = Date.now() - (state.updatedAt.guild ?? 0) < 60_000 &&
        (guild as { share?: boolean } | undefined)?.share === true
      const sync = game === 'open' && fresh && share && char?.name && pos?.wx !== undefined && pos.wy !== undefined && !pos.inst
      if (!sync) {
        if (publishing && await upload({ stopped: true })) publishing = false
        tell(game === 'closed' ? 'In attesa di WoW' : game === 'minimized' ? 'WoW minimizzato' :
          !fresh ? 'In attesa del segnale dell’addon' : !share ? 'Condivisione gilda disattivata' : 'In attesa di coordinate nel mondo')
        return
      }
      if (await upload({ name: char.name, level: char.level, pos, geometry })) {
        publishing = true
        tell('Posizione condivisa')
      }
    } catch { tell('Server non raggiungibile') } finally { pending = false }
  }, 3000)
  app.once('before-quit', () => {
    clearInterval(timer)
    clearInterval(accessCheck)
    clearTimeout(updateStartup)
    clearInterval(updateCheck)
    link.stop()
  })
}).catch(error => { dialog.showErrorBox('UnCs Pulser', String(error)); app.quit() })
