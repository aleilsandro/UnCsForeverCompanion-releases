import {expect,test} from 'vitest'
import {cityBlend} from './city-blend'

test('feathers the boundary without fading the centre and respects a mask',()=>{
  const width=100,height=100,rgba=new Uint8Array(width*height*4).fill(255)
  cityBlend(rgba,width,height)
  const alpha=(x:number,y:number)=>rgba[(y*width+x)*4+3]!
  expect(alpha(50,50)).toBe(255)
  expect(alpha(50,0)).toBeLessThan(5)
  expect(alpha(50,5)).toBeGreaterThan(alpha(50,1))
  expect(alpha(5,5)).toBeLessThan(alpha(50,5))
  const hidden=new Uint8Array(width*height*4).fill(255)
  cityBlend(hidden,width,height,{width:1,height:1,rgba:new Uint8Array([0,0,0,0])})
  expect(hidden[(50*width+50)*4+3]).toBe(0)
})
