const releasePage = 'https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases'
export const pulserDownloads = `${releasePage}/latest`

export async function pulserFeeds(publicSite: string, privateSite: string): Promise<string[]> {
  const servers = [publicSite, privateSite].map(site => `${site}/bridge/releases/`)
  async function manifest(url: string): Promise<string | undefined> {
    try {
      const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(4500) })
      if (!response.ok) return
      const text = await response.text()
      return /^version: (\d+\.\d+\.\d+)\s*$/m.exec(text)?.[1]
    } catch { return }
  }
  const [latest, ...available] = await Promise.all([
    manifest(`${pulserDownloads}/download/latest.yml`),
    ...servers.map(url => manifest(`${url}latest.yml`)),
  ])
  // Once discovered, use the immutable tag for both the manifest and the setup.
  const feeds = latest ? [{ url: `${releasePage}/download/${latest}/`, version: latest }] : []
  for (const [index, url] of servers.entries()) {
    const version = available[index]
    if (version) feeds.push({ url, version })
  }
  return feeds.sort((a, b) => b.version.localeCompare(a.version, 'en', { numeric: true })).map(feed => feed.url)
}
