import { lstat, readFile, readdir } from 'node:fs/promises'
import { join } from 'node:path'

const maxFile = 32 * 1024 * 1024
const maxTotal = 1500 * 1024 * 1024

export async function uploadMap(site: string, folder: string, progress: (done: number, total: number) => void): Promise<number> {
  const files: { name: string; path: string; size: number }[] = []
  let total = 0
  async function scan(name: string, depth: number): Promise<void> {
    if (depth > 6) return
    const file = join(folder, ...name.split('/'))
    const info = await lstat(file)
    if (info.isSymbolicLink()) return
    if (info.isDirectory()) {
      for (const child of await readdir(file)) {
        if (/^[a-zA-Z0-9_.-]+$/.test(child)) await scan(`${name}/${child}`, depth + 1)
      }
    } else if (info.isFile() && /\.(?:png|dxt|json)$/.test(name)) {
      total += info.size
      if (info.size <= 0 || info.size > maxFile || total > maxTotal || files.length >= 20000) {
        throw Error('Il pacchetto cartografico supera i limiti di importazione.')
      }
      files.push({ name, path: file, size: info.size })
    }
  }
  await scan('openmap', 0)
  try { await lstat(join(folder, 'tiles')); await scan('tiles', 0) } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
  }
  if (!files.some(file => file.name === 'openmap/manifest.json')) throw Error('Cartella non valida. Serve openmap/manifest.json.')
  const root = `${site}/map-import`
  const request = async (url: string, options: RequestInit, timeout: number): Promise<Response> => {
    const res = await fetch(url, { ...options, redirect: 'error', signal: AbortSignal.timeout(timeout) })
    if (!res.ok) {
      const detail = await res.json().catch(() => ({})) as { error?: string }
      throw Error(detail.error || `Importazione non riuscita (HTTP ${res.status}).`)
    }
    return res
  }
  const { id } = await (await request(root, { method: 'POST' }, 15000)).json() as { id: string }
  if (!/^[a-f0-9-]{36}$/.test(id)) throw Error('Identificativo importazione non valido.')
  const batch = `${root}/${id}`
  try {
    for (const [index, file] of files.entries()) {
      const bytes = await readFile(file.path)
      if (bytes.length !== file.size) throw Error(`File modificato durante l’importazione: ${file.name}`)
      await request(`${batch}/${file.name}`, { method: 'PUT', body: new Uint8Array(bytes) }, 120000)
      progress(index + 1, files.length)
    }
    await request(batch, { method: 'POST' }, 120000)
    return files.length
  } catch (error) {
    await request(batch, { method: 'DELETE' }, 15000).catch(() => {})
    throw error
  }
}
