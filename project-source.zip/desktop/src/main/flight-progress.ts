import { readFileSync, renameSync, writeFileSync } from 'node:fs'
import { readdir, readFile, stat } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { dirname, join } from 'node:path'
import { findGameWindow, programOf } from './capture'
import { flightCatalog } from '../shared/flight-catalog'
import { flightStatusFrom, type FlightStatus } from '../shared/flight-points'

const normalized = (value: string) => value.normalize('NFC').toLowerCase()
// Forever uses a dash in the character folder and a space in the addon's display name.
const characterName = (value: string) => normalized(value).trim().replace(/[-\s]+/g, ' ')
const folders = async (path: string) => (await readdir(path, { withFileTypes: true }).catch(() => []))
  .filter(entry => entry.isDirectory()).map(entry => entry.name)

async function openMapFile(character: string): Promise<string | undefined> {
  const window = findGameWindow()
  const executable = window === null ? null : programOf(window)
  if (!executable) return
  const accounts = join(dirname(executable), 'WTF', 'Account')
  const identity = characterName(character)
  const matches: string[] = []
  for (const account of await folders(accounts)) {
    const accountPath = join(accounts, account)
    for (const realm of await folders(accountPath)) {
      const realmPath = join(accountPath, realm)
      for (const name of await folders(realmPath)) {
        if (characterName(name) === identity || characterName(name + ' ' + realm) === identity) {
          matches.push(join(realmPath, name, 'SavedVariables', 'OpenMap.lua'))
        }
      }
    }
  }
  if (matches.length === 1) return matches[0]
}

/** Read the existing OpenMap character export as text. The game directory is opened read-only. */
async function savedFlightNames(path: string): Promise<Set<string>> {
  const text = await readFile(path, 'utf8').catch(() => '')
  const names = new Set<string>()
  for (const [, , values] of text.matchAll(/^([ \t]*)\["flightsKnown"\]\s*=\s*\{\r?\n([\s\S]*?)^\1\},?[ \t]*\r?$/gm)) {
    for (const [, name] of values!.matchAll(/^\s*\["((?:\\.|[^"\\])*)"\]\s*=\s*true,?\s*$/gm)) {
      names.add(normalized(name!.replace(/\\(["\\])/g, '$1')))
    }
  }
  return names
}

export function flightProgress(profile: string) {
  let active: { character: string; file: string; status: FlightStatus; importFile?: string; nextCheck: number; mtime?: number } | undefined

  async function read(character: string, side: FlightStatus['side'], report?: FlightStatus): Promise<FlightStatus> {
    if (!active || active.character !== character || active.status.side !== side) {
      const id = createHash('sha256').update(normalized(character)).digest('hex')
      const file = join(profile, `flight-status-${id}.json`)
      let status: FlightStatus = { side, known: [], checked: [] }
      try {
        const previous = flightStatusFrom(JSON.parse(readFileSync(file, 'utf8')))
        if (previous?.side === side) status = previous
      } catch { /* The next confirmed points rebuild the cache. */ }
      active = { character, file, status, nextCheck: 0 }
    }
    const known = new Set([...active.status.known, ...(report?.known ?? [])])
    const checked = new Set([...active.status.checked, ...(report?.checked ?? [])])
    if (Date.now() >= active.nextCheck) {
      active.nextCheck = Date.now() + 30_000
      active.importFile ??= await openMapFile(character)
      if (active.importFile) {
        const info = await stat(active.importFile).catch(() => null)
        if (info?.isFile() && info.size <= 8 * 1024 * 1024 && info.mtimeMs !== active.mtime) {
          active.mtime = info.mtimeMs
          const names = await savedFlightNames(active.importFile)
          const faction = side === 'A' ? 1 : 2
          for (const [id, name, world, , , sides] of flightCatalog) {
            if ((sides & faction) && names.has(normalized(name))) {
              known.add(id)
              checked.add(world)
            }
          }
        }
      }
    }
    if (known.size !== active.status.known.length || checked.size !== active.status.checked.length) {
      active.status = { side, known: [...known], checked: [...checked] }
      try {
        writeFileSync(active.file + '.tmp', JSON.stringify(active.status))
        renameSync(active.file + '.tmp', active.file)
      } catch { /* The current session can still show what it read. */ }
    }
    return active.status
  }
  return { read }
}
