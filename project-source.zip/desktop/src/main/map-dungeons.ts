import { existsSync, readFileSync, realpathSync, renameSync, statSync, writeFileSync } from 'node:fs'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'
import { deflateSync } from 'node:zlib'
import { dxt1Picture } from '../shared/blp'
import { DUNGEON_LOOT_FILE, dungeonGuides, type DungeonJournalData } from '../shared/dungeon-journal'
import { blockHeights, SIDE, STEP } from '../shared/heights'
import { buriedBuildings, type Piece } from '../shared/inside'
import { gameMaps, UI_MAP_ASSIGNMENT_FILE, UI_MAP_FILE, type GameMap } from '../shared/maps'
import { AREA_TABLE_FILE } from '../shared/places'
import { BLOCKS, BLOCK_YARDS, terrainFiles, WORLDS } from '../shared/world'
import { readTable } from '../shared/wdc5'
import { EncryptedFileError, gameFolderFrom, openClientFiles, registryInstallPath } from './client-files'
import { dungeonJournal } from './dungeon-journal'
import { dungeonLootCaches, dungeonLootDetails } from './dungeon-loot'
import { buildingOf, convertInteriors, ENCOUNTERS_FILE, finishedInteriors, layOut, MAP_FILE, mapEntries, placedIn, ROOM_PICTURES_FILE, roomPictures } from './interiors'
import { sentKeys } from './keys'
import { openQuestie } from './questie'
import { keep } from './tiles'

const capitalIds = new Set([1453, 1454, 1455, 1456, 1457, 1458])

function cavesOf(folder: string, read: (id: number) => Buffer | null, pictures: ReturnType<typeof roomPictures>, maps: GameMap[]) {
  const roomFolder = join(folder, 'rooms')
  const sizeCache = new Map<number, [number, number] | null>()
  const sizeOf = (id: number): [number, number] | null => {
    if (!sizeCache.has(id)) {
      const raw = read(id), picture = raw && dxt1Picture(raw)
      sizeCache.set(id, picture ? [picture.width, picture.height] : null)
    }
    return sizeCache.get(id)!
  }
  const prepared = new Set<number>()
  return WORLDS.flatMap(({ continent, file }) => {
    const wdt = read(file)
    if (!wdt) return []
    const terrain = terrainFiles(wdt)
    const heights = new Map<number, Float32Array | null>()
    const groundAt = (u: number, v: number): number | null => {
      const column = Math.floor(u / BLOCK_YARDS), row = Math.floor(v / BLOCK_YARDS)
      if (column < 0 || row < 0 || column >= BLOCKS || row >= BLOCKS) return null
      const key = row * BLOCKS + column
      if (!heights.has(key)) {
        const id = terrain.get(key), raw = id && read(id)
        heights.set(key, raw ? blockHeights(raw, column, row) : null)
      }
      const x = Math.round((u - column * BLOCK_YARDS) / STEP), y = Math.round((v - row * BLOCK_YARDS) / STEP)
      const height = heights.get(key)?.[y * SIDE + x]
      return height === undefined || !Number.isFinite(height) ? null : height
    }
    const capitals = maps.filter(map => map.continent === continent && capitalIds.has(map.id) && map.rect)
    const origin = BLOCKS / 2 * BLOCK_YARDS
    const buildings = new Map<number, ReturnType<typeof buildingOf>>()
    const caves = placedIn(wdt, read).flatMap((placement, id) => {
      const north = origin - placement.v, west = origin - placement.u
      if (capitals.some(({ rect }) => north >= rect!.minX && north <= rect!.maxX && west >= rect!.minY && west <= rect!.maxY)) return []
      if (!buildings.has(placement.file)) {
        const raw = read(placement.file)
        buildings.set(placement.file, raw ? buildingOf(raw) : null)
      }
      const building = buildings.get(placement.file)
      const sources = building && pictures.get(building.number)
      if (!building || !sources) return []
      const { pieces } = layOut(placement, building, sources, sizeOf)
      if (!buriedBuildings(pieces, groundAt).length) return []
      const available: Piece[] = []
      for (const piece of pieces) {
        const output = join(roomFolder, `${piece.file}.dxt`)
        if (!prepared.has(piece.file) && !existsSync(output)) {
          const raw = read(piece.file), picture = raw && dxt1Picture(raw)
          if (!picture) continue
          keep(output, () => deflateSync(picture.data, { level: 9 }))
        }
        prepared.add(piece.file)
        available.push(piece)
      }
      return available.length ? [{ id, world: continent, pieces: available.sort((a, b) => a.bottom - b.bottom) }] : []
    })
    return caves
  })
}

const [mapPath, gamePath] = process.argv.slice(2)
if (!mapPath) throw Error('Uso: node map-dungeons.js <cartella-mappa> [cartella-wow]')
const root = realpathSync(resolve(mapPath))
const atlas = join(root, 'openmap'), tiles = join(root, 'tiles')
const journalPath = join(atlas, 'dungeon-journal.json'), cavePath = join(atlas, 'caves.json')
const lootPath = join(atlas, DUNGEON_LOOT_FILE)
const inside = finishedInteriors(tiles)
const wanted = new Set(dungeonGuides.map(guide => guide.map))
const defaultPath = join(process.env['ProgramFiles(x86)'] ?? 'C:/Program Files (x86)', 'World of Warcraft')
const game = gameFolderFrom([gamePath || defaultPath]) ?? gameFolderFrom([registryInstallPath()])
const caches = game ? dungeonLootCaches(game) : []
const modified = (file: string): number => statSync(file, { throwIfNoEntry: false })?.mtimeMs ?? 0
const made = modified(lootPath)
const refreshLoot = !made || modified(journalPath) > made
  || Boolean(game && [join(game, '.build.info'), ...caches].some(file => modified(file) > made))
if (!inside || !existsSync(journalPath) || !existsSync(cavePath) || (game && refreshLoot)) {
  if (!game) throw Error('Installazione di WoW Forever non trovata.')
  const destination = relative(realpathSync(game), root)
  if (!isAbsolute(destination) && destination !== '..' && !destination.startsWith(`..${sep}`)) {
    throw Error('Scegli una cartella della mappa esterna all’installazione di WoW.')
  }
  const files = openClientFiles(game, sentKeys(game))
  const table = (id: number) => {
    const raw = files.read(id, true)
    if (!raw) throw Error(`Tabella di WoW non disponibile: ${id}`)
    return readTable(raw, key => files.opens(key))
  }
  const read = (id: number): Buffer | null => {
    try { return files.read(id) } catch (error) {
      if (error instanceof EncryptedFileError) return null
      throw error
    }
  }
  const save = (file: string, data: unknown): void => {
    writeFileSync(file + '.part', JSON.stringify(data))
    renameSync(file + '.part', file)
  }
  const maps = () => gameMaps(table(UI_MAP_FILE), table(UI_MAP_ASSIGNMENT_FILE))
  const pictures = () => roomPictures(table(ROOM_PICTURES_FILE))
  if (!inside) {
    const dungeons = mapEntries(table(MAP_FILE), table(ENCOUNTERS_FILE)).filter(map => wanted.has(map.id))
    const converted = convertInteriors(dungeons, pictures(), read, tiles)
    console.log(`Mappe dei dungeon di Forever: ${converted.maps.length}.`)
  }
  if (!existsSync(journalPath)) {
    const db = openQuestie(game)
    if (db) save(journalPath, dungeonJournal(db, table(AREA_TABLE_FILE), maps()))
    else console.warn('QuestieDB assente: quest e bottino non preparati.')
  }
  if (!existsSync(cavePath)) {
    const caves = cavesOf(tiles, read, pictures(), maps())
    if (caves.length) save(cavePath, caves)
    console.log(`Caverne e miniere di Forever: ${caves.length}.`)
  }
  if (refreshLoot && existsSync(journalPath)) {
    try {
      const journal = JSON.parse(readFileSync(journalPath, 'utf8')) as DungeonJournalData
      const loot = dungeonLootDetails(files, caches.map(file => readFileSync(file)), journal, atlas)
      save(lootPath, loot)
      console.log(`Schede del bottino di Forever: ${Object.keys(loot).length}.`)
    } catch (error) {
      console.warn('Schede del bottino di Forever non aggiornate.', error)
    }
  }
}
