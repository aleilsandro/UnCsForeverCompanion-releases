// Turns the minimap pictures of a continent into what the map shows, in a folder of the app. Done
// once per build of the game.
//
// The map has eight zoom levels of tiles of 256 pixels. Zoom 7 is the game's own detail (about a
// pixel a yard): the picture of a block is four tiles. Each level below halves it; at zoom 0 one
// tile holds the whole square of 64 x 64 blocks.
//
// What is kept, where the game has a picture:
//   <folder>/blocks/<column>/<row>.dxt   a block's picture as the game stores it (DXT1 blocks, 512
//                                         pixels wide, a few 256), deflated. Zoom 7 is its four
//                                         quarters and zoom 6 is the whole of it halved: both are
//                                         drawn from this file, with the very pixels of the game,
//                                         at a third of the size of a PNG.
//   <folder>/<zoom>/<column>/<row>.png   the tiles of zoom 5 and below, each the four under it halved.
// A picture the game stores some other way is kept as PNG tiles at zoom 7 and 6 instead.
import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join as joinPath } from 'node:path'
import { deflateSync } from 'node:zlib'
import { decodeBlp, decodeDxt, dxt1Of } from '../shared/blp'
import { BLOCK_PIXELS, BLOCKS, minimapTiles } from '../shared/world'
import { crop, double, halve, join } from '../shared/pixels'
import { encodePng } from './png'

export const TILE = 256
export const MAX_ZOOM = 7
const MARKER = 'done.json'
const FORMAT = 2 // of the folder: 1 kept every tile as a PNG

export interface ConvertResult {
  /** False when the folder was already complete and nothing was read. */
  converted: boolean
  /** Tiles the map can show from the folder, all levels. */
  tiles: number
  /** Pictures the world lists that could not be read. */
  missing: number
}

/** The folder for the tiles of one build: a new build of the game gets a new folder. */
export function tilesFolder(base: string, buildKey: string): string {
  return joinPath(base, 'tiles', buildKey)
}

/** The file of a block's picture. */
export function blockFile(folder: string, column: number, row: number): string {
  return joinPath(folder, 'blocks', String(column), `${row}.dxt`)
}

/** The file of a tile of zoom 5 or below (and of zoom 6 and 7 where a block has no .dxt). */
export function tileFile(folder: string, zoom: number, column: number, row: number): string {
  return joinPath(folder, String(zoom), String(column), `${row}.png`)
}

/** The list of the game's maps, kept beside the continents so the game's archive need not be opened for it. */
export const MAPS_FILE = 'maps.json'
/** The names written over the map (shared/places.ts), kept the same way. */
export const PLACES_FILE = 'places.json'
/** The doors of the dungeons and the flight routes (shared/services.ts), kept the same way. */
export const TRAVEL_FILE = 'travel.json'
export const ICONS_FOLDER = 'icons'

/**
 * The file the window may have for a path it asks, or null: only what the converters write, nothing
 * else on the disk. base: the folder of the build. path: as in "/azeroth/blocks/31/49.dxt". A
 * ground is a continent by its name or a dungeon by "i" and its number, with its shaded relief
 * under "shade/"; the rest is the lists, the pictures of the rooms (interiors.ts), of the items and
 * of the spells by their file (item-icons.ts).
 */
export function servedFile(base: string, path: string): string | null {
  const icon = /^\/icons\/([a-z0-9-]{1,40})\.png$/.exec(path)
  if (icon) return joinPath(base, ICONS_FOLDER, `${icon[1]}.png`)
  // The ground of the 3D view (heights.ts), a continent's only.
  const levels = /^\/([a-z]+)\/levels\/(\d)\/(\d{1,2})\/(\d{1,2})\.bin$/.exec(path)
  if (levels) return joinPath(base, levels[1]!, 'levels', levels[2]!, levels[3]!, `${levels[4]}.bin`)
  const item = /^\/(items|pictures)\/(\d{1,7})\.png$/.exec(path)
  if (item) return joinPath(base, item[1]!, `${item[2]}.png`)
  const m = /^\/(?:(maps|places|travel|interiors|caves|under|items|trainers)\.json|rooms\/(\d{1,9})\.dxt|([a-z]+|i\d{1,5})\/(?:blocks\/(\d{1,2})\/(\d{1,2})\.dxt|(shade\/)?(\d)\/(\d{1,3})\/(\d{1,3})\.png))$/.exec(path)
  if (!m) return null
  if (m[1]) return joinPath(base, `${m[1]}.json`)
  if (m[2]) return joinPath(base, 'rooms', `${m[2]}.dxt`)
  if (m[4] !== undefined) return blockFile(joinPath(base, m[3]!), Number(m[4]), Number(m[5]))
  // The shaded relief (heights.ts): same tiles, its own folder.
  return tileFile(joinPath(base, m[3]!, m[6] ? 'shade' : ''), Number(m[7]), Number(m[8]), Number(m[9]))
}

/** What a finished folder holds, or null when the continent is not converted, or only in part, or in an older layout. */
export function finished(folder: string): ConvertResult | null {
  const marker = joinPath(folder, MARKER)
  if (!existsSync(marker)) return null
  const { tiles, missing, format } = JSON.parse(readFileSync(marker, 'utf8')) as { tiles: number; missing: number; format?: number }
  return format === FORMAT ? { converted: false, tiles, missing } : null
}

/** Writes a file unless it is there already: what lets an interrupted conversion resume. */
export function keep(file: string, bytes: () => Buffer): void {
  if (existsSync(file)) return
  mkdirSync(dirname(file), { recursive: true })
  // Under another name first: a file is either whole or not there.
  writeFileSync(file + '.part', bytes())
  renameSync(file + '.part', file)
}

/**
 * Converts one continent. wdt: its world file. read: a game file by number. folder: where it goes.
 * A folder left half done is finished: files already there are kept, so an interrupted run resumes.
 */
export function convertWorld(
  wdt: Buffer,
  read: (id: number) => Buffer | null,
  folder: string,
  onProgress?: (done: number, total: number) => void,
): ConvertResult {
  const before = finished(folder)
  if (before) return before
  // A folder finished in an older layout is of no use: start again.
  if (existsSync(joinPath(folder, MARKER))) rmSync(folder, { recursive: true, force: true })

  let tiles = 0, missing = 0, done = 0
  const png = (zoom: number, column: number, row: number, rgb: Uint8Array): void => {
    tiles++
    keep(tileFile(folder, zoom, column, row), () => encodePng(rgb, TILE, TILE))
  }

  const source = minimapTiles(wdt)
  // One block. Gives its picture at 256 pixels, for the levels below.
  const block = (column: number, row: number): Uint8Array | undefined => {
    const file = source.get(row * BLOCKS + column)
    if (file === undefined) return undefined
    let half: Uint8Array | undefined
    try {
      const raw = read(file)
      const dxt = raw && dxt1Of(raw)
      if (dxt && (dxt.size === BLOCK_PIXELS || dxt.size === BLOCK_PIXELS / 2)) {
        // The usual case: the game's own blocks, kept as they are.
        keep(blockFile(folder, column, row), () => deflateSync(dxt.data, { level: 9 }))
        tiles += 5
        const rgb = decodeDxt(dxt.data, dxt.size, dxt.size)
        half = dxt.size === BLOCK_PIXELS ? halve(rgb, BLOCK_PIXELS) : rgb
      } else if (raw) {
        const picture = decodeBlp(raw)
        const rgb = picture.width === BLOCK_PIXELS ? picture.rgb : picture.width === BLOCK_PIXELS / 2 ? double(picture.rgb, picture.width) : undefined
        if (rgb) {
          for (let i = 0; i < 4; i++) png(MAX_ZOOM, column * 2 + (i & 1), row * 2 + (i >> 1), crop(rgb, BLOCK_PIXELS, (i & 1) * TILE, (i >> 1) * TILE, TILE))
          half = halve(rgb, BLOCK_PIXELS)
          png(MAX_ZOOM - 1, column, row, half)
        }
      }
    } catch {
      half = undefined
    }
    onProgress?.(++done, source.size)
    if (!half) missing++
    return half
  }
  // A tile is the four under it, halved: made from the bottom up, one branch at a time, so only a
  // handful of pictures are in memory at once. Where nothing is under it there is no tile.
  const tile = (zoom: number, column: number, row: number): Uint8Array | undefined => {
    if (zoom === MAX_ZOOM - 1) return block(column, row)
    const four = [0, 1, 2, 3].map((i) => tile(zoom + 1, column * 2 + (i & 1), row * 2 + (i >> 1)))
    if (four.every((part) => !part)) return undefined
    const rgb = halve(join(four, TILE), TILE * 2)
    png(zoom, column, row, rgb)
    return rgb
  }
  tile(0, 0, 0)

  mkdirSync(folder, { recursive: true })
  writeFileSync(joinPath(folder, MARKER), JSON.stringify({ tiles, missing, format: FORMAT }))
  return { converted: true, tiles, missing }
}

/**
 * Takes away the tiles of every other build: a new build of the game gets a new folder of some
 * 260 MB, and the ones before it would stay for ever. Called once the folder of this build is
 * whole, so a conversion that fails halfway leaves the map of before to be used. Only folders
 * named as a build is (32 hex digits) are touched: nothing else that may lie there. Gives back how
 * many went.
 */
export function dropOtherBuilds(base: string, buildKey: string): number {
  const root = joinPath(base, 'tiles')
  let gone = 0
  try {
    for (const name of readdirSync(root)) {
      if (name === buildKey || !/^[0-9a-f]{32}$/.test(name)) continue
      try {
        rmSync(joinPath(root, name), { recursive: true, force: true })
        gone++
      } catch {
        // a file in use: it goes at the next start
      }
    }
  } catch {
    // no folder of tiles: nothing to take away
  }
  return gone
}
