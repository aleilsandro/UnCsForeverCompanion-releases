import type { Position, Publisher } from '../shared/game'
import { LOST_AFTER, type LinkSnapshot } from '../shared/link'

const isWorldPosition = (pos: Position): boolean => !pos.inst &&
  [pos.wx, pos.wy].every(value => Number.isFinite(value) && value! >= 0 && value! <= 100000) &&
  [pos.ww, pos.wh].every(value => Number.isFinite(value) && value! > 0 && value! < 10000)

interface KnownPosition { name: string; zone: string | undefined; pos: Position }

export function publishingPresence(guild: string, allowLocalInstance: boolean) {
  let known: KnownPosition | undefined

  return function read({ game, state }: LinkSnapshot, now: number): { player: Publisher; pos?: Position; zone?: string } | undefined {
    const posAt = state.updatedAt.pos ?? -Infinity
    const presenceAt = state.updatedAt.presence ?? -Infinity
    const pos = now - posAt < LOST_AFTER ? state.sections.pos : undefined
    const presence = now - presenceAt < LOST_AFTER ? state.sections.presence : undefined
    const presenceIsLatest = presence && (!pos || presenceAt >= posAt)
    const char = state.sections.char
    const localPlayer = allowLocalInstance && !presence && pos?.inst && char?.name
      ? { name: char.name, level: char.level, guild } : undefined
    const player = presenceIsLatest ? presence.publisher : pos?.publisher ?? localPlayer
    if (game === 'closed' || state.protocol || player?.guild !== guild || !player.name) {
      known = undefined
      return
    }

    const zone = (presenceIsLatest ? presence.zone : pos?.zone) || undefined
    const inInstance = presenceIsLatest ? presence.inInstance === true : !!pos?.inst
    const samePlayer = pos?.publisher?.name === player.name && pos.publisher.guild === guild || localPlayer === player
    if (inInstance) {
      known = undefined
      const inst = samePlayer ? pos?.inst : undefined
      return { player, pos: inst?.kind === 'party' || inst?.kind === 'raid' ? pos : undefined, zone: 'In un’istanza' }
    }
    if (pos && samePlayer && isWorldPosition(pos) && (!zone || pos.zone === zone)) {
      known = { name: player.name, zone: pos.zone, pos }
      return { player, pos, zone }
    }
    if (known && (known.name !== player.name || (zone && known.zone !== zone))) known = undefined
    return { player, pos: known && zone ? known.pos : undefined, zone }
  }
}
