// Read the player's local game archive on a worker so zoom never blocks the window.
import { parentPort, workerData } from 'node:worker_threads'
import { mkdir, readFile, writeFile, rename, unlink } from 'node:fs/promises'
import { cachePath, type CacheKind } from './map-cache'
import { openClientFiles, type ClientFiles } from './client-files'
import { sentKeys } from './keys'
import { decodeBlp, decodeBlpCutout } from '../shared/blp'
import { encodePng } from './png'
import { openMapTile, miniTile, worldBackdrop, cityBanner } from './openmap-art'
import { cityArt } from './city-art'
import { UI_MAP_FILE,UI_MAP_ASSIGNMENT_FILE,gameMaps } from '../shared/maps'
import { readTable } from '../shared/wdc5'
import { parseCityBanners } from '../shared/city-banner'
import { join } from 'node:path'
const { gameFolder, cacheDir } = workerData as { gameFolder:string; cacheDir:string }
let files: ClientFiles | undefined
parentPort?.on('message', async ({ id, file, kind }: { id:number; file:number|string; kind:CacheKind }) => {
  let result: Buffer | null = null
  let fromCache = false
  const cached = cachePath(cacheDir,kind,file)
  try {
    try {
      const bytes=await readFile(cached)
      if (kind==='bannerdata' || kind==='mapdata') {
        const value=JSON.parse(bytes.toString('utf8'))
        if(Array.isArray(value) && (kind==='bannerdata' ? value.length===4 : value.length>0)) {result=bytes;fromCache=true}
      } else if (bytes.length >= 8 && bytes.length < 10_000_000 && bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex'))) { result=bytes; fromCache=true }
    } catch { /* not cached yet */ }
    if (!result && kind === 'mapdata') {
      files ??= openClientFiles(gameFolder, sentKeys(gameFolder))
      const map=files.read(UI_MAP_FILE),assignment=files.read(UI_MAP_ASSIGNMENT_FILE)
      if(map && assignment) {
        const maps=gameMaps(readTable(map,key=>files!.opens(key)),readTable(assignment,key=>files!.opens(key)))
        if(maps.length)result=Buffer.from(JSON.stringify(maps))
      }
    } else if (!result && kind === 'bannerdata') {
      files ??= openClientFiles(gameFolder, sentKeys(gameFolder))
      const map=files.read(UI_MAP_FILE),assignment=files.read(UI_MAP_ASSIGNMENT_FILE)
      if(map && assignment) {
        const maps=gameMaps(readTable(map,key=>files!.opens(key)),readTable(assignment,key=>files!.opens(key)))
        const data=await readFile(join(gameFolder,'_forever_','Interface','AddOns','OpenMap','Data','Forever','Banners.lua'),'utf8')
        const banners=parseCityBanners(data,maps)
        if(banners.length===4)result=Buffer.from(JSON.stringify(banners))
      }
    } else if (!result && kind === 'banner') {
      result=await cityBanner(gameFolder,Number(file))
    } else if (!result && kind === 'citymini') {
      files ??= openClientFiles(gameFolder, sentKeys(gameFolder))
      const raw=files.read(Number(file))
      if(raw) {
        const {width,height,rgba}=decodeBlpCutout(raw)
        for(let i=0;i<rgba.length;i+=4){const r=rgba[i]!,g=rgba[i+1]!,b=rgba[i+2]!,grey=.299*r+.587*g+.114*b;rgba[i]=Math.round(r*.65+grey*.35);rgba[i+1]=Math.round((g*.65+grey*.35)*.93);rgba[i+2]=Math.round((b*.65+grey*.35)*.80)}
        result=encodePng(rgba,width,height,4,1)
      }
    } else if (!result && kind === 'city') {
      files ??= openClientFiles(gameFolder, sentKeys(gameFolder))
      result = await cityArt(gameFolder, String(file), files)
    } else if (!result && kind !== 'native') {
      result = kind === 'art' ? await openMapTile(gameFolder, String(file)) : kind === 'mini' ? await miniTile(gameFolder, String(file)) : await worldBackdrop(gameFolder, Number(file))
    } else if (!result) {
      files ??= openClientFiles(gameFolder, sentKeys(gameFolder))
      const raw = files.read(Number(file))
      if (raw) {
        const {width,height,rgb}=decodeBlp(raw)
        for (let i=0;i<rgb.length;i+=3) {
          const r=rgb[i]!,g=rgb[i+1]!,b=rgb[i+2]!,grey=.299*r+.587*g+.114*b
          rgb[i]=Math.round(r*.65+grey*.35)
          rgb[i+1]=Math.round((g*.65+grey*.35)*.93)
          rgb[i+2]=Math.round((b*.65+grey*.35)*.80)
        }
        result=encodePng(rgb,width,height,3,1)
      }
    }
    if (result && !fromCache) {
      // Atomic replacement: interruption never leaves a partial image in the cache.
      try {
        await mkdir(cacheDir,{recursive:true})
        const temp=`${cached}.${process.pid}.${id}.tmp`
        try { await writeFile(temp,result); await rename(temp,cached) } catch { await unlink(temp).catch(()=>{}) }
      } catch { /* full or unavailable disk: the current session can still use the image */ }
    }
  } catch { result=null }
  parentPort?.postMessage({id,bytes:result})
})
