import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { decodeBlpCutout } from '../shared/blp'
import { cityFrom } from '../shared/city'
import { decodeTga } from './tga'
import { encodePng } from './png'
import type { ClientFiles } from './client-files'
import { cityBlend } from './city-blend'

/** Assemble the game's own city tiles and apply the locally installed OpenMap cutout. */
export async function cityArt(game:string, encoded:string, files:ClientFiles):Promise<Buffer|null> {
  const c=cityFrom(JSON.parse(encoded)); if (!c) return null
  let mask:ReturnType<typeof decodeTga>|undefined
  // Stormwind has no dedicated cutout: OpenMap uses its rounded feather there. Using only
  // the rectangle's edge leaves the city's decorative parchment on top of Elwynn Forest.
  const textures=join(game,'_forever_','Interface','AddOns','OpenMap','Media','Textures','Forever')
  const maskFile=c.id===1453 ? join(textures,'MapFeatherRound.tga') : join(textures,'MapCityMask',`${c.id}.tga`)
  try { mask=decodeTga(await readFile(maskFile),false) } catch { /* fall back to the geometric feather */ }
  const rgba=new Uint8Array(c.w*c.h*4), cols=Math.ceil(c.w/c.tw)
  for (let i=0;i<c.files.length;i++) {
    const raw=files.read(c.files[i]!); if (!raw) return null
    const tile=decodeBlpCutout(raw), ox=(i%cols)*c.tw, oy=Math.floor(i/cols)*c.th
    const width=Math.min(c.tw,c.w-ox), height=Math.min(c.th,c.h-oy)
    if (tile.width<width || tile.height<height) return null
    for (let y=0;y<height;y++) rgba.set(tile.rgba.subarray(y*tile.width*4,(y*tile.width+width)*4),((oy+y)*c.w+ox)*4)
  }
  cityBlend(rgba,c.w,c.h,mask)
  return encodePng(rgba,c.w,c.h,4,1)
}
