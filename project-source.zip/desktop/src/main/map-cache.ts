import { createHash } from 'node:crypto'
import { statSync } from 'node:fs'
import { join } from 'node:path'
import { installedBuild } from './client-files'
export type CacheKind = 'native'|'art'|'mini'|'base'|'city'|'citymini'|'banner'|'bannerdata'|'mapdata'
/** Cache is private to a WoW build and an OpenMap installation revision. */
export function cacheRevision(game:string):string {
  let addon='missing'
  try { const s=statSync(join(game,'_forever_','Interface','AddOns','OpenMap','OpenMap.toc')); addon=`${s.size}:${s.mtimeMs}` } catch {}
  let build='unknown'
  try { build=installedBuild(game)?.buildKey ?? 'unknown' } catch {}
  return createHash('sha256').update(`uncs-map-v2|${game}|${build}|${addon}`).digest('hex').slice(0,24)
}
export function cachePath(root:string,kind:CacheKind,file:number|string):string {
  // Stormwind's rounded mask changed; retain every other precomputed image.
  let cityVersion='-feather-v2'
  if (kind==='city' && typeof file==='string') try { if (JSON.parse(file).id===1453) cityVersion='-stormwind-v3' } catch { /* invalid input is handled by the worker */ }
  const hash=createHash('sha256').update(`${kind}${kind === 'city' ? cityVersion : kind === 'citymini' ? '-warm-v1' : ''}:${file}`).digest('hex')
  return join(root,`${kind}-${hash}.${kind==='bannerdata' || kind==='mapdata' ? 'json' : 'png'}`)
}
