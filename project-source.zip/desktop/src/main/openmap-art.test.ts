import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { describe, expect, test } from 'vitest'
import { openMapManifest, openMapTile, worldBackdrop } from './openmap-art'

describe('OpenMap local tiles', () => {
  test('only numeric tile names are listed and missing/corrupt files are rejected', async () => {
    const game = mkdtempSync(join(tmpdir(), 'uncs-map-'))
    const dir = join(game, '_forever_', 'Interface', 'AddOns', 'OpenMap', 'Media', 'Textures', 'Forever', 'MapZones')
    mkdirSync(dir, { recursive: true })
    writeFileSync(join(dir, '3_7.blp'), 'not an image')
    writeFileSync(join(dir, 'wrong.blp'), 'other')
    expect(openMapManifest(game)).toEqual([[3, 7]])
    expect(await openMapTile(game, '../wrong.blp')).toBeNull()
    expect(await openMapTile(game, '3_7.blp')).toBeNull()
    expect(await openMapTile(game, '99_99.blp')).toBeNull()
  })
})

test('crops padded world-map edge tiles to the actual art size', async () => {
  const game=mkdtempSync(join(tmpdir(), 'uncs-backdrop-'))
  const dir=join(game,'_forever_','Interface','AddOns','OpenMap','Media','Textures','Forever','MapArt')
  mkdirSync(dir,{recursive:true})
  const tga=Buffer.alloc(18+256*256*4);tga[2]=2;tga.writeUInt16LE(256,12);tga.writeUInt16LE(256,14);tga[16]=32
  writeFileSync(join(dir,'947_12.tga'),tga)
  const png=await worldBackdrop(game,12)
  expect(png).not.toBeNull()
  expect([png!.readUInt32BE(16),png!.readUInt32BE(20)]).toEqual([234,156])
  expect(await worldBackdrop(game,13)).toBeNull()
})
