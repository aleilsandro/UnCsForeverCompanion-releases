// What the first run needs to know: where the game is, whether the addon is in it, whether Questie
// is. Here the app only looks: the addon comes from CurseForge. What it writes next to the addon is in signal.ts.
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import type { SetupStatus } from '../shared/setup'
import { questieFile } from './questie'
import { shortestPathFolder } from './walk'

const ADDONS = ['_forever_', 'Interface', 'AddOns']

/** The folder of a game where addons live. */
export const addonsFolder = (gameFolder: string): string => join(gameFolder, ...ADDONS)

/** The player's choices the app keeps between runs. */
export interface Settings {
  /** The game folder the player picked by hand, when the app did not find it alone. */
  gameFolder?: string
  /** The first run was gone through once: the app opens on the map. */
  setupDone?: boolean
  /** The window stays over the others. */
  onTop?: boolean
  /** The map is shown to the other devices of the home network. */
  lan?: boolean
  /** The code those devices must hold. Made once, so an address saved on a phone keeps working. */
  lanCode?: string
}

/** The settings as they were saved; nothing where the file is missing or is not ours. */
export function readSettings(file: string): Settings {
  try {
    const read: unknown = JSON.parse(readFileSync(file, 'utf8'))
    if (typeof read !== 'object' || !read) return {}
    const { gameFolder, setupDone, onTop, lan, lanCode } = read as Record<string, unknown>
    return {
      ...(typeof gameFolder === 'string' ? { gameFolder } : {}),
      ...(setupDone === true ? { setupDone } : {}),
      ...(onTop === true ? { onTop } : {}),
      ...(lan === true ? { lan } : {}),
      ...(typeof lanCode === 'string' && /^[\w-]{8,64}$/.test(lanCode) ? { lanCode } : {}),
    }
  } catch {
    return {}
  }
}

export function writeSettings(file: string, settings: Settings): void {
  try {
    writeFileSync(file, JSON.stringify(settings, null, 1))
  } catch {
    // the choice lasts this run only
  }
}

/** Whether the addon in a game folder takes its news from the fonts alone ("X-Channel: 2" in its .toc); one from before it wants the slots too. */
export function addonHearsFonts(gameFolder: string): boolean {
  try {
    return /^##\s*X-Channel:\s*2\s*$/m.test(readFileSync(join(gameFolder, ...ADDONS, 'UnCsForeverCompanion', 'UnCsForeverCompanion.toc'), 'utf8'))
  } catch {
    return false
  }
}

/** The version of the UnCs Forever Companion addon in a game folder, as its .toc says; null when it is not there. */
export function addonVersion(gameFolder: string): string | null {
  try {
    const toc = readFileSync(join(gameFolder, ...ADDONS, 'UnCsForeverCompanion', 'UnCsForeverCompanion.toc'), 'utf8')
    return /^##\s*Version:\s*(.+)$/m.exec(toc)?.[1]?.trim() ?? 'unknown'
  } catch {
    return null
  }
}

export function setupStatus(gameFolder: string | null, settings: Settings, version: string): SetupStatus {
  return {
    gameFolder,
    addon: gameFolder ? addonVersion(gameFolder) : null,
    questie: gameFolder ? existsSync(questieFile(gameFolder)) : false, // its data, which is what the app reads
    shortestPath: gameFolder ? existsSync(shortestPathFolder(gameFolder)) : false,
    done: settings.setupDone === true,
    version,
    onTop: settings.onTop === true,
  }
}
