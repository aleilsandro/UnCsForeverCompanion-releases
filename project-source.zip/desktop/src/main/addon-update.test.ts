import { afterEach, expect, test, vi } from 'vitest'
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { newer, updateAddon } from './addon-update'

afterEach(() => vi.unstubAllGlobals())
test('compares numeric release versions without downgrading', () => {
  expect(newer('0.13.11', '0.13.9')).toBe(true)
  expect(newer('0.13.9', '0.13.10')).toBe(false)
  expect(newer('0.13.10', '0.13.10')).toBe(false)
  expect(newer('0.13.10', null)).toBe(true)
  expect(() => newer('0.13.10', 'unknown')).toThrow()
})

test('rejects a corrupt archive without touching the installed addon', async () => {
  const root = mkdtempSync(join(tmpdir(), 'uncs-update-test-'))
  const folder = join(root, '_forever_', 'Interface', 'AddOns', 'UnCsForeverCompanion')
  mkdirSync(folder, { recursive: true }); writeFileSync(join(folder, 'UnCsForeverCompanion.toc'), '## Version: 0.13.0')
  const release = { tag_name: '0.13.11', assets: [{ name: 'UnCsForeverCompanion-0.13.11-forever.zip', browser_download_url: 'https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/download/0.13.11/UnCsForeverCompanion-0.13.11-forever.zip', digest: `sha256:${'0'.repeat(64)}`, size: 3 }] }
  vi.stubGlobal('fetch', vi.fn().mockResolvedValueOnce(new Response(JSON.stringify(release))).mockResolvedValueOnce(new Response('bad')))
  try { await expect(updateAddon(root, 'unused-helper', () => {})).rejects.toThrow('Verifica addon'); expect(readFileSync(join(folder, 'UnCsForeverCompanion.toc'), 'utf8')).toContain('0.13.0') }
  finally { rmSync(root, { recursive: true, force: true }) }
})
