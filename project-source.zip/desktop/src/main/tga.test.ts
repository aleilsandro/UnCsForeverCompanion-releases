import { expect, test } from 'vitest'
import { decodeTga } from './tga'
test('reads a bottom-origin BGR pixel and keeps transparency', () => {
  const b=Buffer.alloc(22); b[2]=2; b.writeUInt16LE(1,12); b.writeUInt16LE(1,14); b[16]=32
  b.set([20,40,80,200],18)
  const img=decodeTga(b)
  expect([img.width,img.height,img.rgba[3]]).toEqual([1,1,200])
  expect(img.rgba[0]).toBeGreaterThan(img.rgba[2]!)
})
test('rejects truncated or unsupported pictures', () => {
  expect(() => decodeTga(Buffer.alloc(3))).toThrow()
  const b=Buffer.alloc(18);b[2]=2;b.writeUInt16LE(1,12);b.writeUInt16LE(1,14);b[16]=32
  expect(() => decodeTga(b)).toThrow()
})
