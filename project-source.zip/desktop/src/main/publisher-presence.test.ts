import { expect, test } from 'vitest'
import type { Position, Presence } from '../shared/game'
import type { LinkSnapshot } from '../shared/link'
import { publishingPresence } from './publisher-presence'

const player = { name: 'Alice', guild: 'Unconscious Clan' }
const world: Position = { publisher: player, zone: 'Elwynn Forest', wx: 123, wy: 456, ww: 1002, wh: 668 }
const presence: Presence = { publisher: player, zone: world.zone }

function snapshot(pos?: Position, posAt = 0, heartbeat?: Presence, at = 0, game: LinkSnapshot['game'] = 'open'): LinkSnapshot {
  return { game, seconds: 0, reads: 0, cpu: 0, state: {
    sections: { pos, presence: heartbeat }, updatedAt: { pos: posAt, presence: at },
    protocol: null, blocks: 0, lost: 0, corrupt: 0,
  } }
}

test('keeps a stationary character while fresh presence arrives without new coordinates', () => {
  const read = publishingPresence(player.guild, false)
  expect(read(snapshot(world, 1000), 1000)?.pos).toEqual(world)
  expect(read(snapshot(world, 1000, presence, 59000), 60000)).toEqual({ player, pos: world, zone: world.zone })
  expect(read(snapshot(world, 1000, { ...presence, zone: 'Westfall' }, 65000), 66000)).toEqual({ player, zone: 'Westfall', pos: undefined })
  expect(read(snapshot(world, 1000, presence, 72000), 73000)?.pos).toBeUndefined()
})

test('clears cached coordinates on opt-out, a character switch, or loss of the game signal', () => {
  const read = publishingPresence(player.guild, false)
  read(snapshot(world, 1000), 1000)
  expect(read(snapshot(world, 1000, {}, 2000), 2100)).toBeUndefined()
  expect(read(snapshot(world, 1000, presence, 45000), 46000)?.pos).toBeUndefined()
  read(snapshot(world, 50000), 50000)
  expect(read(snapshot(world, 50000, { ...presence, publisher: { ...player, name: 'Bob' } }, 76000), 77000)?.pos).toBeUndefined()
  expect(read(snapshot(world, 80000, presence, 80000, 'closed'), 81000)).toBeUndefined()
  expect(read(snapshot(world, 80000, presence, 80000, 'minimized'), 106000)).toBeUndefined()
})
