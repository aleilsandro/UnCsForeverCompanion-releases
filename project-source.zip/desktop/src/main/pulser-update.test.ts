import { afterEach, expect, test, vi } from 'vitest'
import { pulserDownloads, pulserFeeds } from './pulser-update'

const publicSite = 'https://public.test'
const privateSite = 'https://private.test'
const manifest = (version: string) => new Response(`version: ${version}\n`)

afterEach(() => vi.unstubAllGlobals())

test('resolves the GitHub latest manifest to an immutable version even if UnCs is down', async () => {
  vi.stubGlobal('fetch', vi.fn(async (url: string) => {
    if (url === `${pulserDownloads}/download/latest.yml`) return manifest('0.13.22')
    throw Error('network unavailable')
  }))
  await expect(pulserFeeds(publicSite, privateSite)).resolves.toEqual([
    'https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/download/0.13.22/',
  ])
})

test('uses the available UnCs feeds when the GitHub release has no compatible manifest', async () => {
  vi.stubGlobal('fetch', vi.fn(async (url: string) => {
    if (url.startsWith(publicSite)) return manifest('0.13.9')
    if (url.startsWith(privateSite)) return manifest('0.13.21')
    return new Response('Not found', { status: 404 })
  }))
  await expect(pulserFeeds(publicSite, privateSite)).resolves.toEqual([
    `${privateSite}/bridge/releases/`, `${publicSite}/bridge/releases/`,
  ])
})
