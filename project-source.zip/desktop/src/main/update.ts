import { app, BrowserWindow } from 'electron'
import { autoUpdater } from 'electron-updater'
import { join } from 'node:path'
import { WINDOW } from '../shared/window'
import { updateAddon } from './addon-update'

export type Updating = { message: string; percent?: number }

/** Show progress at every packaged start. Network errors never prevent opening the map. */
export function updateFirst(open: () => void, say: (line: string) => void, game: string | null): void {
  if (!app.isPackaged) return open()
  const win = new BrowserWindow({ title: 'UnCs Forever Companion', width: 420, height: 340, resizable: false, maximizable: false, frame: false, backgroundColor: WINDOW.background, webPreferences: { preload: join(__dirname, '../preload/index.js') } })
  let current: Updating = { message: 'Avvio del companion…' }
  const tell = (message: string, percent?: number): void => { current = { message, percent }; say(message); if (!win.isDestroyed()) win.webContents.send('update', current) }
  win.webContents.on('did-finish-load', () => { if (!win.isDestroyed()) win.webContents.send('update', current) })
  void win.loadFile(join(__dirname, '../renderer/index.html'), { hash: 'update' })
  const start = async (): Promise<void> => {
    if (game) {
      try { tell('Controllo aggiornamenti addon…'); const result = await updateAddon(game, join(process.resourcesPath, 'uncs-helper.exe'), tell); tell(result); if (result.includes('/reload')) await new Promise(resolve => setTimeout(resolve, 2500)) }
      catch (error) { tell(`Addon: aggiornamento non disponibile. ${error instanceof Error ? error.message : ''}`); await new Promise(resolve => setTimeout(resolve, 2000)) }
    } else { tell('Cartella WoW non trovata: aggiorna la posizione nelle impostazioni'); await new Promise(resolve => setTimeout(resolve, 2000)) }
    if (!process.argv.includes('--updated')) {
      try {
        tell('Controllo aggiornamenti companion…')
        autoUpdater.setFeedURL({ provider: 'generic', url: process.env.UNCS_UPDATES || 'https://github.com/aleilsandro/UnCsForeverCompanion-releases/releases/latest/download' })
        autoUpdater.autoDownload = false
        autoUpdater.on('error', error => say(`update error: ${error.message.split('\n')[0]}`))
        const found = await Promise.race([autoUpdater.checkForUpdates(), new Promise<null>(resolve => setTimeout(() => resolve(null), 12000))])
        if (found?.isUpdateAvailable) {
          tell(`Scarico companion ${found.updateInfo.version}…`, 0)
          autoUpdater.on('download-progress', progress => tell(`Scarico companion ${found.updateInfo.version}…`, progress.percent))
          await autoUpdater.downloadUpdate()
          tell(`Installazione companion ${found.updateInfo.version}…`, 100)
          await new Promise(resolve => setTimeout(resolve, 1200))
          autoUpdater.quitAndInstall(false, true)
          return
        }
      } catch (error) { tell(`Companion: aggiornamento non disponibile. ${error instanceof Error ? error.message.split('\n')[0] : ''}`); await new Promise(resolve => setTimeout(resolve, 2000)) }
    }
    tell('Apertura della mappa…')
    open()
    if (!win.isDestroyed()) win.destroy()
  }
  void start().catch(error => { say(`startup: ${String(error)}`); open(); if (!win.isDestroyed()) win.destroy() })
}
