// Prepare only the dungeon entered, on a worker, and keep previously prepared dungeons.
import { parentPort, workerData } from 'node:worker_threads'
import { readTable } from '../shared/wdc5'
import { openClientFiles } from './client-files'
import { sentKeys } from './keys'
import { convertInteriors, ENCOUNTERS_FILE, finishedInteriors, MAP_FILE, mapEntries, ROOM_PICTURES_FILE, roomPictures } from './interiors'

const {gameFolder,folder,id}=workerData as {gameFolder:string;folder:string;id:number}
try {
  const previous=finishedInteriors(folder), old=previous?.maps ?? []
  if (old.some(m=>m.id===id && m.kind!=='world')) {parentPort?.postMessage({ok:true}); process.exit(0)}
  const client=openClientFiles(gameFolder,sentKeys(gameFolder))
  const maps=client.read(MAP_FILE,true), rooms=client.read(ROOM_PICTURES_FILE,true), encounters=client.read(ENCOUNTERS_FILE,true)
  if(!maps || !rooms || !encounters) throw new Error('Tabelle del gioco non disponibili')
  const table=(bytes:Buffer)=>readTable(bytes,key=>client.opens(key))
  const entries=mapEntries(table(maps),table(encounters)).filter(m=>m.id===id && m.kind!=='world')
  if(!entries.length) throw new Error('Dungeon non presente nelle tabelle del gioco')
  const made=convertInteriors(entries,roomPictures(table(rooms)),file=>client.read(file),folder,undefined,previous)
  parentPort?.postMessage({ok:made.maps.some(m=>m.id===id)})
} catch(error) {parentPort?.postMessage({ok:false,error:error instanceof Error ? error.message : String(error)})}
