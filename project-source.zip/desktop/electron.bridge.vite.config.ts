import { defineConfig } from 'electron-vite'
import { svelte } from '@sveltejs/vite-plugin-svelte'

export default defineConfig({
  main: { build: { outDir: 'out/bridge', rollupOptions: { input: 'src/main/web-bridge.ts' } } },
  preload: {},
  renderer: { plugins: [svelte()] },
})
