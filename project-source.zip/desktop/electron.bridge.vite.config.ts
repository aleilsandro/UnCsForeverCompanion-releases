import { defineConfig } from 'electron-vite'
import { svelte } from '@sveltejs/vite-plugin-svelte'

export default defineConfig({
  main: { build: { outDir: 'out/bridge', rollupOptions: { input: ['src/main/web-bridge.ts', 'src/main/map-services.ts', 'src/main/map-dungeons.ts', 'src/main/map-gathering.ts'] } } },
  preload: {},
  renderer: { plugins: [svelte()] },
})
