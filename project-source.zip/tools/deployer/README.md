# UnCs Deploy per WebCompanion

Applicazione Windows dedicata al WebCompanion sul server UnCs. **Rileggi main** verifica commit e versione; **Pubblica sul server** distribuisce la web app; **Pubblica Pulser e addon** avvia la pubblicazione tramite il workflow GitHub. Per le operazioni sul server serve l’accesso SSH già configurato per il nome host uncs-server. Il collegamento sul Desktop deve puntare all’eseguibile in questa cartella.

Compilare da PowerShell 7 su Windows con Git, Node.js e npm installati:

    pwsh -NoProfile -File tools/deployer/build.ps1

Se npm non è nella cartella standard di Node, passare il percorso di npm-cli.js con -Npm. L’eseguibile viene compilato per l’utente Windows corrente. GitHub conserva sorgenti e istruzioni di compilazione.

Per distribuire la web app, usa **Rileggi main** e verifica commit e versione prima di scegliere **Pubblica sul server**. La compilazione include la cartografia della revisione privata. Dopo il deploy, controlla su /healthz la versione e mapRevision, poi apri la mappa da un browser abbinato e controlla icone e interni dei dungeon. **Pubblica Pulser e addon** avvia un workflow separato. La tray rileva l’aggiornamento dopo la pubblicazione della release.
