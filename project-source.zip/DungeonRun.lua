-- Manual dungeon sessions belong to the current character and last until leaving the instance.
local _, ns = ...
local function Plain(value, kind)
  if type(value) == kind and not (issecretvalue and issecretvalue(value)) then return value end
end

local function Normalize(name)
  return name:lower():gsub("[%p%c%s]+", " "):match("^%s*(.-)%s*$")
end

local function Zone()
  local name, kind, _, _, _, _, _, id = GetInstanceInfo()
  if Plain(kind, "string") ~= "party" then return end
  if Plain(id, "number") and id > 0 then return id, Plain(name, "string") or "Dungeon", true end
  return nil, nil, true
end

local map, dungeon, catalog, selected, started, finished, balance
local earned, killed, defeated = 0, {}, 0
local returningFromDeath = false
local showingQuests, selectedQuest = false, nil
local panel, title, stats, progress, start, back, questTab, scroll, content, detail
local rows = {}
local BOSS_HEIGHT, LOOT_HEIGHT = 43, 30
local PANEL_WIDTH = 302
local LIST_WIDTH = PANEL_WIDTH - 41
local EXIT_DELAY = 2
local UNKNOWN_BOSS = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_8"

local function Money()
  return Plain(GetMoney(), "number")
end

local STATS_FORMAT = "Tempo %02d:%02d   |   Guadagno "
  .. [[%d |TInterface\MoneyFrame\UI-GoldIcon:12:12|t  ]]
  .. [[%02d |TInterface\MoneyFrame\UI-SilverIcon:12:12|t  ]]
  .. [[%02d |TInterface\MoneyFrame\UI-CopperIcon:12:12|t]]

local function UpdateStats()
  local elapsed = started and math.floor((finished or GetTime()) - started) or 0
  stats:SetText(STATS_FORMAT:format(
    math.floor(elapsed / 60), elapsed % 60, math.floor(earned / 10000), math.floor(earned / 100) % 100, earned % 100))
  local total = catalog and #catalog.bosses or 0
  progress:SetText(total > 0 and ("Boss %d/%d"):format(defeated, total) or "")
end

local function Row(index)
  if rows[index] then return rows[index] end
  local row = CreateFrame("Button", nil, content)
  row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetSize(22, 22)
  row.icon:SetPoint("LEFT", 3, 0)
  row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  row.text:SetJustifyH("LEFT")
  row.text:SetMaxLines(1)
  rows[index] = row
  return row
end

local function SetRowLayout(row, x, y, width, height, inset, textOffset)
  row:ClearAllPoints()
  row:SetSize(width, height)
  row:SetPoint("TOPLEFT", content, "TOPLEFT", x, -y)
  row.text:ClearAllPoints()
  row.text:SetPoint("LEFT", row, "LEFT", inset, textOffset)
  row.text:SetPoint("RIGHT", row, "RIGHT", -4, textOffset)
end

local function ShowPortrait(row, display, size)
  if not row.portrait then
    row.portrait = row:CreateTexture(nil, "ARTWORK")
    row.portrait:SetPoint("LEFT", 3, 0)
  end
  -- Render only when a recycled row is assigned a different creature.
  if row.display ~= (display or false) then
    row.display = display or false
    row.portrait:SetTexture(nil)
    if display and type(SetPortraitTextureFromCreatureDisplayID) == "function" then
      pcall(SetPortraitTextureFromCreatureDisplayID, row.portrait, display)
    end
    local texture = row.portrait:GetTexture()
    if texture == nil or texture == 0 or texture == "" then row.portrait:SetTexture(UNKNOWN_BOSS) end
  end
  row.portrait:SetSize(size, size)
  row.portrait:Show()
end

local function QuestValue(api, kind, id)
  if type(api) ~= "function" then return end
  local ok, value = pcall(api, id)
  if ok then return Plain(value, kind) end
end

local function QuestTitle(quest)
  local name = QuestValue(C_QuestLog and C_QuestLog.GetTitleForQuestID, "string", quest.id)
  return name and name ~= "" and name or quest.name
end

local function QuestCompleted(id)
  local completed = (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted) or IsQuestFlaggedCompleted
  return QuestValue(completed, "boolean", id)
end

local function QuestStatus(id)
  local done = QuestCompleted(id)
  if done then return "Completata", .43, .92, .56 end
  if QuestValue(C_QuestLog and C_QuestLog.ReadyForTurnIn, "boolean", id) then
    return "Da consegnare", 1, .82, .34
  end
  if QuestValue(C_QuestLog and C_QuestLog.IsOnQuest, "boolean", id) then
    return "In corso", .63, .82, 1
  end
  if done == false then return "Non fatta", .75, .75, .75 end
  return "Stato non disponibile", .75, .75, .75
end

local function DungeonQuests()
  local quests = {}
  local playerFaction = UnitFactionGroup and Plain(UnitFactionGroup("player"), "string")
  local side = playerFaction == "Alliance" and "A" or playerFaction == "Horde" and "H"
  for _, quest in ipairs(catalog and catalog.quests or {}) do
    if not side or not quest.faction or quest.faction == side then quests[#quests + 1] = quest end
  end
  return quests
end

local function PrepareRow(row, x, y, width, height, inset, textOffset)
  SetRowLayout(row, x, y, width, height, inset, textOffset)
  if row.portrait then row.portrait:Hide() end
  if row.status then row.status:Hide() end
  row:SetScript("OnEnter", nil)
  row:SetScript("OnLeave", nil)
  row:SetScript("OnClick", nil)
  row.icon:SetTexture(nil)
  row.text:SetTextColor(1, 1, 1)
end

local function ShowQuestStatus(row, id)
  if not row.status then
    row.status = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.status:SetPoint("TOPLEFT", row.text, "BOTTOMLEFT", 0, -3)
  end
  local status, r, g, b = QuestStatus(id)
  row.status:SetTextColor(r, g, b)
  row.status:SetText(status)
  row.status:Show()
end

local function LayoutList(isBossList, count, height)
  local rowsPerColumn, width, columns = math.max(1, count), LIST_WIDTH, 1
  local panelHeight, panelWidth = 345, PANEL_WIDTH
  if isBossList then
    local roomY = math.max(40, UIParent:GetHeight() - 143)
    local roomX = math.max(200, UIParent:GetWidth() - 56)
    local maxRows = math.max(1, math.floor(roomY / height))
    local maxColumns = math.max(1, math.floor(roomX / 225))
    columns = math.min(maxColumns, math.ceil(rowsPerColumn / maxRows))
    rowsPerColumn = math.ceil(rowsPerColumn / columns)
    width = math.min(width, math.floor(roomX / columns))
    height = math.min(height, math.max(1, math.floor(roomY / rowsPerColumn)))
    panelHeight, panelWidth = 113 + rowsPerColumn * height, math.max(PANEL_WIDTH, width * columns + 24)
  end
  panel:SetSize(panelWidth, panelHeight)
  scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", isBossList and -12 or -29, 12)
  scroll:EnableMouseWheel(not isBossList)
  if isBossList then scroll:SetVerticalScroll(0) end
  content:SetSize(width * columns, rowsPerColumn * height)
  if scroll.ScrollBar then scroll.ScrollBar:SetShown(not isBossList and content:GetHeight() > scroll:GetHeight()) end
  return rowsPerColumn, width, height
end

local function Refresh()
  local current = selected and catalog and catalog.bosses[selected]
  title:SetText(selectedQuest and QuestTitle(selectedQuest) or current and current[1] or dungeon)
  start:SetShown(not current and not showingQuests)
  start:SetEnabled(not started)
  start:SetText(finished and "Sessione completata" or started and "Sessione in corso" or "Avvia sessione")
  back:SetShown(current ~= nil or selectedQuest ~= nil)
  back:SetText(selectedQuest and "Torna alle missioni" or "Torna ai boss")
  questTab:SetText(showingQuests and "Boss" or "Missioni")
  UpdateStats()
  for _, row in ipairs(rows) do row:Hide() end

  if selectedQuest then
    LayoutList(false, 1, LOOT_HEIGHT)
    local status = QuestStatus(selectedQuest.id)
    detail:SetText(status .. "\n\n" .. (selectedQuest.detail or "Dettagli non disponibili."))
    detail:Show()
    content:SetHeight(math.max(30, math.ceil(detail:GetStringHeight()) + 14))
    if scroll.ScrollBar then scroll.ScrollBar:SetShown(content:GetHeight() > scroll:GetHeight()) end
    return
  end
  detail:Hide()

  local isBossList = not current and not showingQuests
  local entries = showingQuests and DungeonQuests() or current and (current[2] or {}) or catalog and catalog.bosses or {}
  local rowsPerColumn, width, height = LayoutList(isBossList, #entries, current and LOOT_HEIGHT or BOSS_HEIGHT)
  local portraitSize = math.max(1, math.min(35, height - 6))
  for index, entry in ipairs(entries) do
    local row = Row(index)
    local x = math.floor((index - 1) / rowsPerColumn) * width
    local y = ((index - 1) % rowsPerColumn) * height
    PrepareRow(row, x, y, width, height, current and 31 or showingQuests and 6 or portraitSize + 12, showingQuests and 8 or 0)
    if showingQuests then
      row.text:SetText(QuestTitle(entry))
      ShowQuestStatus(row, entry.id)
      row:SetScript("OnClick", function()
        selectedQuest = entry
        scroll:SetVerticalScroll(0)
        Refresh()
      end)
    elseif current then
      local id, name = entry[1], entry[2]
      local itemTexture = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
      row.icon:SetTexture((itemTexture and Plain(itemTexture(id), "number")) or 134400)
      row.text:SetText(name)
      row:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetHyperlink("item:" .. id)
        GameTooltip:Show()
      end)
      row:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
      local name = entry[1]
      ShowPortrait(row, entry.display, portraitSize)
      row.text:SetText(killed[name] and ("✓  " .. name) or (index .. ".  " .. name))
      if killed[name] then row.text:SetTextColor(.43, .92, .56) end
      row:SetScript("OnClick", function()
        selected = index
        scroll:SetVerticalScroll(0)
        Refresh()
      end)
    end
    row:Show()
  end
  if #entries == 0 then
    local row = Row(1)
    PrepareRow(row, 0, 0, width, height, 3, 0)
    row.text:SetText(showingQuests and "Nessuna missione censita" or current and "Bottino non disponibile" or "Lista dei boss non disponibile")
    row:Show()
  end
end

local function BuildPanel()
  panel = CreateFrame("Frame", "UnCsDungeonSession", UIParent, "BackdropTemplate")
  panel:SetSize(PANEL_WIDTH, 345)
  panel:SetPoint("CENTER", UIParent, "CENTER", 220, 0)
  panel:SetFrameStrata("DIALOG")
  panel:SetClampedToScreen(true)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  panel:RegisterForDrag("LeftButton")
  panel:SetScript("OnDragStart", panel.StartMoving)
  panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
  panel:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14,
    insets = { left = 4, right = 4, top = 4, bottom = 4 } })
  panel:SetBackdropColor(.05, .10, .17, .96)
  panel:SetBackdropBorderColor(.80, .65, .38)
  local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", -3, -3)

  title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 14, -15)
  title:SetMaxLines(1)
  title:SetJustifyH("LEFT")
  stats = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  stats:SetPoint("TOPLEFT", 14, -43)
  progress = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  progress:SetPoint("TOPRIGHT", -34, -17)
  title:SetPoint("TOPRIGHT", progress, "TOPLEFT", -8, 2)

  local function Button(label, width, left)
    local button = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    button:SetSize(width or 145, 26)
    button:SetPoint("TOPLEFT", left or 12, -63)
    button:SetText(label)
    return button
  end
  start = Button("Avvia sessione")
  start:SetScript("OnClick", function()
    if started or not map or Zone() ~= map then return end
    started, balance = GetTime(), Money()
    Refresh()
  end)
  back = Button("Torna ai boss")
  back:SetScript("OnClick", function()
    selected, selectedQuest = nil, nil
    scroll:SetVerticalScroll(0)
    Refresh()
  end)

  questTab = Button("Missioni", 80, 164)
  questTab:SetScript("OnClick", function()
    showingQuests = not showingQuests
    selected, selectedQuest = nil, nil
    scroll:SetVerticalScroll(0)
    Refresh()
  end)

  scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 12, -99)
  scroll:SetPoint("BOTTOMRIGHT", -29, 12)
  content = CreateFrame("Frame", nil, scroll)
  content:SetSize(LIST_WIDTH, 30)
  scroll:SetScrollChild(content)
  detail = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  detail:SetPoint("TOPLEFT", 6, -5)
  detail:SetWidth(LIST_WIDTH - 14)
  detail:SetJustifyH("LEFT")
  detail:Hide()

  local remaining = 0
  panel:SetScript("OnUpdate", function(_, elapsed)
    remaining = remaining - elapsed
    if not started or finished or remaining > 0 then return end
    remaining = .25
    UpdateStats()
  end)
end

local function Open()
  if not panel then BuildPanel() end
  Refresh()
  panel:Show()
end

local function RefreshZone(confirmed)
  local id, name, inside = Zone()
  if not id and map and started then
    if inside then return end
    local dead = UnitIsDeadOrGhost and Plain(UnitIsDeadOrGhost("player"), "boolean")
    if dead then
      returningFromDeath = true
      balance = nil
      panel:Hide()
      return
    end
  end
  -- A subzone or loading screen can briefly report no dungeon or a different map.
  if map and started and id ~= map and not confirmed then return end
  if id == map then
    if returningFromDeath then
      returningFromDeath = false
      balance = Money()
      Open()
    end
    return
  end
  returningFromDeath = false
  map, dungeon = id, name
  catalog = id and ns.dungeonRunData[id]
  showingQuests, selectedQuest = false, nil
  selected, started, finished, balance = nil, nil, nil, nil
  earned, killed, defeated = 0, {}, 0
  if panel then scroll:SetVerticalScroll(0) end
  if map then Open() elseif panel then panel:Hide() end
end

ns.OpenDungeonRun = function()
  RefreshZone(false)
  if not map or Zone() ~= map then return false end
  Open()
  return true
end

-- Bosses.lua already receives the game's successful encounter events.
ns.RecordDungeonRunBoss = function(name, id)
  if not started or finished or not catalog or Zone() ~= map then return end
  local names = catalog.encounters[id]
  if not names and name then
    local key = Normalize(name)
    for _, boss in ipairs(catalog.bosses) do
      if Normalize(boss[1]) == key then names = { boss[1] }; break end
    end
  end
  if not names then return end
  local changed = false
  for _, boss in ipairs(names) do
    if not killed[boss] then
      killed[boss], changed = true, true
      defeated = defeated + 1
    end
  end
  if not changed then return end
  if defeated == #catalog.bosses then
    finished = GetTime()
    ns.DungeonProgress()[map] = true
  end
  if not selected and not showingQuests then Refresh() else UpdateStats() end
end

local events = CreateFrame("Frame")
local zoneCheck, nextQuestRead = 0, 0
for _, event in ipairs({ "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST", "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_TURNED_IN", "PLAYER_MONEY" }) do
  events:RegisterEvent(event)
end
events:SetScript("OnEvent", function(_, event)
  if event == "QUEST_TURNED_IN" or event == "QUEST_ACCEPTED" or event == "PLAYER_ENTERING_WORLD" then nextQuestRead = 0 end
  if event == "QUEST_LOG_UPDATE" or event == "QUEST_ACCEPTED" or event == "QUEST_TURNED_IN" then
    if showingQuests and panel:IsShown() then Refresh() end
    return
  end
  if event ~= "PLAYER_MONEY" then
    local after = C_Timer and C_Timer.After
    RefreshZone(not after)
    if after then
      zoneCheck = zoneCheck + 1
      local scheduled = zoneCheck
      after(started and EXIT_DELAY or .6, function()
        if scheduled == zoneCheck then RefreshZone(true) end
      end)
    end
    return
  end
  if not started or finished or Zone() ~= map then return end
  local amount = Money()
  if not amount then balance = nil; return end
  if balance and amount > balance then earned = earned + amount - balance end
  balance = amount
  UpdateStats()
end)

ns.sections[#ns.sections + 1] = { name = "run_kills", period = 1, refresh = 10, combat = true, build = function()
  local list = {}
  for name in pairs(killed) do list[#list + 1] = name end
  table.sort(list)
  return { map = map or 0, list = list }
end }

-- Read individual Spelunker criteria, including the alternate Legacy achievement records.
-- IDs were checked against the Forever client's data published by cjber/legacy-forever.
local LEGACY_ACHIEVEMENTS = { 62031, 62032, 62033, 64016, 64017, 64018 }
local LEGACY_CRITERIA = {
  [33] = {{3263, 117734}}, -- Shadowfang Keep
  [36] = {{3262, 117731}},
  [43] = {{18524, 117732}},
  [47] = {{18528, 117739}},
  [48] = {{18526, 117737}},
  [70] = {{18531, 117746}},
  [90] = {{18529, 117738}},
  [109] = {{18533, 117750}},
  [129] = {{18530, 117745}},
  [189] = {{116058, 117740}, {116059, 117741}, {116060, 117742}, {3264, 117743}},
  [209] = {{3265, 117747}},
  [229] = {{18534, 117752}, {3268, 117753}},
  [230] = {{3266, 117751}},
  [289] = {{19263, 117754}},
  [329] = {{119884, 117755}, {18471, 117756}},
  [349] = {{18532, 117748}},
  [429] = {{545, 117757}, {18535, 117758}, {546, 117759}},
  [2959] = {{116050, 117735}},
  [2994] = {{116057, 117749}},
  [2974] = {{116055, 117761}},
  [2998] = {{116054, 117730}},
  [2999] = {{116049, 117729}},
  [3001] = {{116056, 117760}},
  [3039] = {{116052, 117744}},
}
-- The shared Ragefire Chasm/Hall of Thanes criterion is ambiguous and is not mapped.
local legacyMaps, nextLegacyRead = {}, 0
local function ReadLegacyDungeons()
  local now = GetTime()
  if now < nextLegacyRead then return legacyMaps end
  nextLegacyRead = now + 10
  if not GetAchievementNumCriteria or not GetAchievementCriteriaInfo then return legacyMaps end
  local earnedCriteria = {}
  for _, achievement in ipairs(LEGACY_ACHIEVEMENTS) do
    local ok, count = pcall(GetAchievementNumCriteria, achievement)
    count = ok and Plain(count, "number") or 0
    for index = 1, math.min(count or 0, 64) do
      local read, _, _, completed, _, _, _, _, _, _, id = pcall(GetAchievementCriteriaInfo, achievement, index)
      if read and Plain(completed, "boolean") == true and Plain(id, "number") then
        earnedCriteria[id] = true
      end
    end
  end
  local maps = {}
  for id, criteria in pairs(LEGACY_CRITERIA) do
    local complete = true
    for _, alternatives in ipairs(criteria) do
      if not (earnedCriteria[alternatives[1]] or earnedCriteria[alternatives[2]]) then
        complete = false
        break
      end
    end
    if complete then maps[#maps + 1] = id end
  end
  table.sort(maps)
  legacyMaps = maps
  return maps
end

local completedQuests, activeQuests
local function ReadQuestProgress()
  local now = GetTime()
  if now < nextQuestRead then return completedQuests, activeQuests end
  nextQuestRead = now + 15
  local doneIds, activeIds = {}, {}
  local doneAvailable, activeAvailable = false, false
  for index, id in ipairs(ns.dungeonQuestIds) do
    if index % 64 == 0 then coroutine.yield() end
    local done = QuestCompleted(id)
    if done ~= nil then doneAvailable = true end
    if done then
      doneIds[#doneIds + 1] = id
    else
      local active = QuestValue(C_QuestLog and C_QuestLog.IsOnQuest, "boolean", id)
      if active ~= nil then activeAvailable = true end
      if active then activeIds[#activeIds + 1] = id end
    end
  end
  if doneAvailable then completedQuests = doneIds end
  if activeAvailable then activeQuests = activeIds end
  return completedQuests, activeQuests
end

-- Sent separately from the live run so the completion remains visible after leaving.
ns.sections[#ns.sections + 1] = { name = "dungeon_progress", period = 2, refresh = 15, spread = true, build = function()
  local name = ns.ready and ns.PlayerName()
  if not name then return end
  local maps = {}
  for id, completed in pairs(ns.DungeonProgress()) do
    if type(id) == "number" and id > 0 and completed == true then maps[#maps + 1] = id end
  end
  table.sort(maps)
  local quests, active = ReadQuestProgress()
  return { name = name, maps = maps, legacy = ReadLegacyDungeons(), quests = quests, active = active }
end }
