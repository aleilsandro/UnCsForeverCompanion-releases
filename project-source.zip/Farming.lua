-- Observe copper changes for the current login and keep the last balance seen per character.
local _, ns = ...
local session, balance, timer, expenses
local walletTransition, zeroRead
local resetBalance = true
local SETTLE_SECONDS = .75
local EXPENSE_LIMIT = 100
local merchantOpen, mailOpen = false, false
local buyback, invoices
local pending = 0
local lootPatterns, lootEstimate
local nextLootRead = 0

local function Plain(value, kind)
  if type(value) == kind and not (issecretvalue and issecretvalue(value)) then return value end
end

local function Clock()
  return GetServerTime and GetServerTime() or time()
end

local function Name()
  return ns.ready and ns.PlayerName()
end

local function Wallet()
  local db = ns.db
  if type(db.farmingWallets) ~= "table" then db.farmingWallets = {} end
  return db.farmingWallets
end

local function SortedWallets()
  local characters = {}
  for _, wallet in pairs(Wallet()) do characters[#characters + 1] = wallet end
  table.sort(characters, function(a, b)
    if a.name == b.name then return a.realm < b.realm end
    return a.name < b.name
  end)
  return characters
end

local function Sample()
  if walletTransition then return end
  local money = Plain(GetMoney(), "number")
  local name = Name()
  if not session or not money or not name then return end
  -- A transient zero before the loading event must not become a withdrawal.
  if money == 0 and balance ~= 0 and C_Timer and C_Timer.After then
    if not zeroRead then
      local check = {}
      zeroRead = check
      C_Timer.After(SETTLE_SECONDS, function()
        if zeroRead ~= check then return end
        check.confirmed = true
        Sample()
      end)
    end
    if not zeroRead.confirmed then return end
  end
  zeroRead = nil

  if balance and not resetBalance then
    local change = money - balance
    if change > 0 then
      session.earned = session.earned + change
      pending = pending + change
    elseif change < 0 then
      session.spent = session.spent - change
      if #expenses == EXPENSE_LIMIT then table.remove(expenses, 1) end
      expenses[#expenses + 1] = { Clock(), -change }
    end
  end
  balance, resetBalance = money, false
  local realm = Plain(GetRealmName(), "string") or ""
  local key = Plain(UnitGUID("player"), "string") or (name .. "-" .. realm)
  local wallet = Wallet()
  local existing = wallet[key]
  if not existing or existing.money ~= money or existing.name ~= name or existing.realm ~= realm then
    wallet[key] = { name = name, realm = realm, money = money, seen = Clock() }
  elseif Clock() - existing.seen >= 60 then
    existing.seen = Clock()
  end
end

-- Match only the client's own loot messages, including locales with positional arguments.
local function LootPattern(format)
  if not format then return end
  local function Escape(text)
    return (text:gsub("([^%w])", "%%%1"))
  end
  local parts, order, cursor = { "^" }, {}, 1
  while true do
    local first, last, position, kind = format:find("%%(%d*[$]?)([sd])", cursor)
    if not first then break end
    parts[#parts + 1] = Escape(format:sub(cursor, first - 1))
    parts[#parts + 1] = kind == "d" and "(%d+)" or "(.-)"
    order[#order + 1] = tonumber(position:match("%d+")) or #order + 1
    cursor = last + 1
  end
  if #order == 0 then return end
  parts[#parts + 1] = Escape(format:sub(cursor)) .. "$"
  return { text = table.concat(parts), order = order }
end

local function TrackLoot(message)
  message = Plain(message, "string")
  if not session or not message then return end
  if not lootPatterns then
    lootPatterns = {}
    lootPatterns[1] = LootPattern(LOOT_ITEM_SELF_MULTIPLE)
    lootPatterns[2] = LootPattern(LOOT_ITEM_SELF)
  end
  for index = 1, 2 do
    local pattern = lootPatterns[index]
    if pattern then
      local captures = { message:match(pattern.text) }
      if captures[1] then
        local args = {}
        for i, value in ipairs(captures) do args[pattern.order[i]] = value end
        local link, quantity = args[1], tonumber(args[2]) or 1
        local key = link and link:match("|H(item:%d+[^|]*)|h")
        if key and quantity > 0 then
          local item = session.loot[key]
          if item then item.quantity = item.quantity + quantity
          else session.loot[key] = { link = link, quantity = quantity } end
          return
        end
      end
    end
  end
end

local function LootUnitPrice(link)
  local info = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if not info then return end
  local ok, _, _, quality, _, _, _, _, _, _, _, vendor, _, _, bind = pcall(info, link)
  if not ok then return end
  vendor, quality, bind = Plain(vendor, "number"), Plain(quality, "number"), Plain(bind, "number")
  if not vendor or vendor < 0 then return end

  local itemBind = Enum and Enum.ItemBind
  local tradable = bind == (itemBind and itemBind.None or 0) or bind == (itemBind and itemBind.OnEquip or 2)
    or bind == (itemBind and itemBind.OnUse or 3)
  if not tradable or not quality or quality == 0 then return vendor end
  local api = Auctionator and Auctionator.API and Auctionator.API.v1
  if not api or type(api.GetAuctionPriceByItemLink) ~= "function" then return vendor end
  if type(api.GetAuctionAgeByItemLink) == "function" then
    local read, age = pcall(api.GetAuctionAgeByItemLink, "UnCs Forever Companion", link)
    age = read and Plain(age, "number")
    if age and age > 7 then return vendor end
  end
  local read, price = pcall(api.GetAuctionPriceByItemLink, "UnCs Forever Companion", link)
  price = read and Plain(price, "number")
  if not price or price <= 0 then return vendor end
  return math.max(vendor, math.floor(price * 95 / 100))
end

local function EstimateLoot()
  local now = Clock()
  if lootEstimate and now < nextLootRead then return lootEstimate end
  nextLootRead = now + 5
  local value, count, unpriced = 0, 0, 0
  for _, item in pairs(session.loot) do
    local price = LootUnitPrice(item.link)
    count = count + item.quantity
    if price then value = value + price * item.quantity
    else unpriced = unpriced + item.quantity end
  end
  lootEstimate = { value = value, count = count, unpriced = unpriced }
  return lootEstimate
end

local function Record(entries, label, amount)
  if not label or not amount or amount <= 0 then return end
  local key = label .. "\031" .. amount
  local entry = entries[key]
  if entry then entry.count = entry.count + 1
  else entries[key] = { amount = amount, count = 1 } end
end

local function Buyback()
  if not GetNumBuybackItems or not GetBuybackItemInfo then return end
  local count = Plain(GetNumBuybackItems(), "number")
  if not count then return end
  local entries = {}
  for i = 1, math.min(count, 20) do
    local ok, name, _, price, quantity = pcall(GetBuybackItemInfo, i)
    if ok then
      name, price = Plain(name, "string"), Plain(price, "number")
      if name then Record(entries, name .. "\031" .. (Plain(quantity, "number") or 0), price) end
    end
  end
  return entries
end

local function Invoices()
  if not GetInboxNumItems or not GetInboxHeaderInfo or not GetInboxInvoiceInfo then return end
  local count = Plain(GetInboxNumItems(), "number")
  if not count then return end
  local entries = {}
  for i = 1, math.min(count, 100) do
    local ok, kind, item = pcall(GetInboxInvoiceInfo, i)
    if ok and Plain(kind, "string") == "seller" then
      local read, _, _, _, subject, money = pcall(GetInboxHeaderInfo, i)
      if read then Record(entries, Plain(item, "string") or Plain(subject, "string"), Plain(money, "number")) end
    end
  end
  return entries
end

local function Difference(before, after)
  if not before or not after then return 0 end
  local amount = 0
  for key, entry in pairs(after) do
    local prior = before[key] and before[key].count or 0
    if entry.count > prior then amount = amount + (entry.count - prior) * entry.amount end
  end
  return amount
end

local function Reconcile()
  timer = nil
  if not session then return end
  Sample()
  if merchantOpen then
    local snapshot = Buyback()
    local sold = Difference(buyback, snapshot)
    if sold > 0 and sold <= pending then
      session.vendor = session.vendor + sold
      pending = pending - sold
    end
    buyback = snapshot
  end
  if mailOpen then
    local snapshot = Invoices()
    local collected = Difference(snapshot, invoices)
    if collected > 0 and collected <= pending then
      session.auction = session.auction + collected
    end
    invoices = snapshot
  end
  pending = 0
end

local function Schedule()
  if timer then return end
  if C_Timer and C_Timer.After then
    local scheduled = {}
    timer = scheduled
    C_Timer.After(.25, function() if timer == scheduled then Reconcile() end end)
  else Reconcile() end
end

local function SuspendWallet()
  walletTransition, zeroRead, timer = {}, nil, nil
  resetBalance, pending = true, 0
  merchantOpen, mailOpen = false, false
  buyback, invoices = nil, nil
end

local function ResumeWallet()
  local transition = walletTransition
  local function Ready()
    if walletTransition ~= transition then return end
    walletTransition = nil
    Sample()
  end
  if C_Timer and C_Timer.After then C_Timer.After(SETTLE_SECONDS, Ready)
  else Ready() end
end

local events = CreateFrame("Frame")
for _, event in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_LEAVING_WORLD", "PLAYER_LOGOUT", "PLAYER_MONEY", "CHAT_MSG_LOOT", "MERCHANT_SHOW", "MERCHANT_CLOSED", "MERCHANT_UPDATE", "MAIL_SHOW", "MAIL_CLOSED", "MAIL_INBOX_UPDATE" }) do
  events:RegisterEvent(event)
end
events:SetScript("OnEvent", function(_, event, detail, reload)
  if event == "PLAYER_LEAVING_WORLD" then
    SuspendWallet()
  elseif event == "PLAYER_ENTERING_WORLD" then
    SuspendWallet()
    if not session then
      local db = UnCsForeverCompanionSheet or {}
      UnCsForeverCompanionSheet = db
      if type(db.farmingExpenses) ~= "table" then db.farmingExpenses = {} end
      expenses = db.farmingExpenses
      local previous = db.farmingSession
      if Plain(reload, "boolean") and type(previous) == "table" and type(previous.started) == "number" and previous.started <= Clock() then
        session = previous
      else
        session = { started = Clock(), earned = 0, spent = 0, vendor = 0, auction = 0 }
      end
      if type(session.loot) ~= "table" then session.loot = {} end
      db.farmingSession = session
    end
    ResumeWallet()
  elseif event == "PLAYER_LOGOUT" then
    if timer then Reconcile() else Sample() end
  elseif event == "CHAT_MSG_LOOT" then
    TrackLoot(detail)
  elseif event == "PLAYER_MONEY" then
    if walletTransition then return end
    Sample()
    Schedule()
  elseif event == "MERCHANT_SHOW" then
    if timer then Reconcile() end
    merchantOpen, buyback = true, Buyback()
  elseif event == "MAIL_SHOW" then
    if timer then Reconcile() end
    mailOpen, invoices = true, Invoices()
  elseif event == "MERCHANT_CLOSED" then
    merchantOpen, buyback = false, nil
  elseif event == "MAIL_CLOSED" then
    mailOpen, invoices = false, nil
  elseif merchantOpen or mailOpen then
    Schedule()
  end
end)

local function SignedGold(copper)
  local amount = math.abs(copper)
  return (copper < 0 and "-" or "") .. ("%d |TInterface\\MoneyFrame\\UI-GoldIcon:12:12|t  %02d |TInterface\\MoneyFrame\\UI-SilverIcon:12:12|t  %02d |TInterface\\MoneyFrame\\UI-CopperIcon:12:12|t")
    :format(math.floor(amount / 10000), math.floor(amount / 100) % 100, math.floor(amount) % 100)
end

local farmPanel, duration, amounts, summaryLabels, listRows, listMessage
local views, previousPage, nextPage, detailsButton
local view, listPage, expanded = "summary", 1, false
local SUMMARY_ROWS = 4
local LIST_PAGE_SIZE = 8

local function UpdateList()
  local showingWallets = view == "wallets"
  local entries = showingWallets and SortedWallets() or expenses
  local matches = {}
  if showingWallets then
    for _, wallet in ipairs(entries) do matches[wallet.name] = (matches[wallet.name] or 0) + 1 end
  end

  local pages = math.max(1, math.ceil(#entries / LIST_PAGE_SIZE))
  listPage = math.min(listPage, pages)
  for i, row in ipairs(listRows) do
    local index = (listPage - 1) * LIST_PAGE_SIZE + i
    local entry = entries[showingWallets and index or (#entries - index + 1)]
    row.label:SetShown(entry ~= nil)
    row.amount:SetShown(entry ~= nil)
    if entry then
      if showingWallets then
        local label = entry.name
        if matches[entry.name] > 1 and entry.realm ~= "" then label = label .. " · " .. entry.realm end
        row.label:SetText(label)
        row.amount:SetText(SignedGold(entry.money))
      else
        row.label:SetText(date("%d/%m/%y  %H:%M", entry[1]))
        row.amount:SetText(SignedGold(entry[2]))
      end
    end
  end

  if showingWallets then
    duration:SetText(("%d personaggi rilevati · Pagina %d/%d"):format(#entries, listPage, pages))
    listMessage:SetText("Accedi agli altri PG con l’addon attivo per registrarne il saldo.")
    listMessage:SetShown(#entries <= 1)
  else
    duration:SetText(("Ultime %d uscite · Pagina %d/%d"):format(#entries, listPage, pages))
    listMessage:SetText("Nessuna spesa registrata.")
    listMessage:SetShown(#entries == 0)
  end
  previousPage:SetShown(pages > 1)
  nextPage:SetShown(pages > 1)
  previousPage:SetEnabled(listPage > 1)
  nextPage:SetEnabled(listPage < pages)
end

local function UpdatePanel()
  if view ~= "summary" then
    UpdateList()
    return
  end
  local seconds = math.max(0, Clock() - session.started)
  local loot = EstimateLoot()
  amounts[1]:SetText(seconds > 0 and SignedGold(session.earned * 3600 / seconds) or "—")
  amounts[2]:SetText(SignedGold(loot.value))
  amounts[3]:SetText(balance and SignedGold(balance) or "—")
  amounts[4]:SetText(SignedGold(session.earned - session.spent))
  if not expanded then return end

  duration:SetText(("Online da %d h %02d min %02d s"):format(math.floor(seconds / 3600), math.floor(seconds / 60) % 60, seconds % 60))

  local total = 0
  for _, wallet in pairs(Wallet()) do total = total + wallet.money end
  amounts[5]:SetText(seconds > 0 and SignedGold(session.spent * 3600 / seconds) or "—")
  amounts[6]:SetText(seconds > 0 and SignedGold(loot.value * 3600 / seconds) or "—")
  amounts[7]:SetText(SignedGold(session.vendor))
  amounts[8]:SetText(SignedGold(session.auction))
  amounts[9]:SetText(SignedGold(session.earned - session.vendor - session.auction))
  amounts[10]:SetText(SignedGold(session.spent))
  amounts[11]:SetText(SignedGold(total))
end

local function ShowView(selected)
  view, listPage = selected, 1
  local summary = view == "summary"
  for key, button in pairs(views) do button:SetEnabled(key ~= view) end
  farmPanel:SetHeight(summary and (expanded and 360 or 178) or 338)
  duration:SetShown(not summary or expanded)
  detailsButton:SetShown(summary)
  detailsButton:SetText(expanded and "Nascondi dettagli" or "Dettagli")
  for i, label in ipairs(summaryLabels) do
    local visible = summary and (expanded or i <= SUMMARY_ROWS)
    if visible then
      local y = (expanded and -67 or -47) - (i - 1) * 23
      label:SetPoint("TOPLEFT", 14, y)
      amounts[i]:SetPoint("TOPRIGHT", -14, y)
    end
    label:SetShown(visible)
    amounts[i]:SetShown(visible)
  end
  if summary then
    for _, row in ipairs(listRows) do row.label:Hide(); row.amount:Hide() end
    listMessage:Hide()
    previousPage:Hide()
    nextPage:Hide()
  end
  UpdatePanel()
end

local function BuildPanel()
  farmPanel = CreateFrame("Frame", "UnCsFarmingSession", UIParent, "BackdropTemplate")
  farmPanel:SetWidth(316)
  farmPanel:SetPoint("TOP", UIParent, "CENTER", -195, 180)
  farmPanel:SetFrameStrata("DIALOG")
  farmPanel:SetClampedToScreen(true)
  farmPanel:SetMovable(true)
  farmPanel:EnableMouse(true)
  farmPanel:RegisterForDrag("LeftButton")
  farmPanel:SetScript("OnDragStart", farmPanel.StartMoving)
  farmPanel:SetScript("OnDragStop", farmPanel.StopMovingOrSizing)
  farmPanel:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14,
    insets = { left = 4, right = 4, top = 4, bottom = 4 } })
  farmPanel:SetBackdropColor(.05, .10, .17, .96)
  farmPanel:SetBackdropBorderColor(.80, .65, .38)

  local close = CreateFrame("Button", nil, farmPanel, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", -3, -3)
  local title = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 14, -15)
  title:SetText("Farming")
  duration = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  duration:SetPoint("TOPLEFT", 14, -42)

  amounts, summaryLabels = {}, {}
  local labels = { "Gold/ora", "Loot stimato", "Gold attuali", "Guadagno netto", "Loss/ora", "Loot stimato/ora",
    "Mercante", "Asta riscossa", "Altri incassi", "Spese", "Totale personaggi" }
  for i, label in ipairs(labels) do
    local line = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    line:SetText(label)
    summaryLabels[i] = line
    amounts[i] = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  end
  listRows = {}
  for i = 1, LIST_PAGE_SIZE do
    local y = -67 - (i - 1) * 23
    local label = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    label:SetPoint("TOPLEFT", 14, y)
    label:SetWidth(163)
    label:SetWordWrap(false)
    label:SetJustifyH("LEFT")
    local amount = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    amount:SetPoint("TOPRIGHT", -14, y)
    listRows[i] = { label = label, amount = amount }
  end
  listMessage = farmPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  listMessage:SetPoint("TOPLEFT", 14, -112)
  listMessage:SetWidth(282)
  listMessage:SetJustifyH("LEFT")

  local function PanelButton(width, offset, bottom, label, onClick)
    local button = CreateFrame("Button", nil, farmPanel, "UIPanelButtonTemplate")
    button:SetSize(width, 25)
    button:SetPoint("BOTTOMLEFT", offset, bottom)
    button:SetText(label)
    button:SetScript("OnClick", onClick)
    return button
  end
  views = {
    summary = PanelButton(91, 14, 12, "Riepilogo", function() ShowView("summary") end),
    expenses = PanelButton(112, 110, 12, "Storico spese", function() ShowView("expenses") end),
    wallets = PanelButton(75, 227, 12, "Saldi PG", function() ShowView("wallets") end),
  }
  previousPage = PanelButton(75, 14, 45, "Indietro", function() listPage = listPage - 1; UpdateList() end)
  nextPage = PanelButton(75, 94, 45, "Avanti", function() listPage = listPage + 1; UpdateList() end)
  detailsButton = CreateFrame("Button", nil, farmPanel, "UIPanelButtonTemplate")
  detailsButton:SetSize(114, 24)
  detailsButton:SetPoint("TOPRIGHT", -36, -10)
  detailsButton:SetScript("OnClick", function()
    expanded = not expanded
    ShowView("summary")
  end)

  local elapsed = 0
  farmPanel:SetScript("OnUpdate", function(_, delta)
    elapsed = elapsed + delta
    if elapsed < 1 then return end
    elapsed = 0
    UpdatePanel()
  end)
end

ns.ShowFarming = function()
  if not session then return false end
  if not farmPanel then BuildPanel() end
  expanded = false
  ShowView("summary")
  farmPanel:Show()
  return true
end

ns.sections[#ns.sections + 1] = { name = "farming", period = 5, refresh = 15, combat = true, build = function()
  local name = Name()
  if not name or not session then return end
  Sample()
  if pending > 0 then Schedule() end
  return {
    name = name, seconds = math.max(0, Clock() - session.started),
    earned = session.earned, spent = session.spent, vendor = session.vendor, auction = session.auction,
    loot = EstimateLoot(), balance = balance,
  }
end }

-- Keep the larger account list off the strip's five-second timer.
ns.sections[#ns.sections + 1] = { name = "farming_wallets", period = 8, refresh = 120, build = function()
  local name = Name()
  if not name or not session then return end
  return { name = name, wallets = SortedWallets() }
end }

-- Expense history is persisted per character and only retransmitted on a change or a refresh.
ns.sections[#ns.sections + 1] = { name = "farming_expenses", period = 8, refresh = 120, build = function()
  local name = Name()
  if not name or not expenses then return end
  local recent = {}
  for index = #expenses, 1, -1 do recent[#recent + 1] = expenses[index] end
  return { name = name, expenses = recent }
end }
